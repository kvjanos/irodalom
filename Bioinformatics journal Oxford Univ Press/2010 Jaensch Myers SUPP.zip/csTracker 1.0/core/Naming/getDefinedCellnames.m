function [ cellNames, treeDepth ] = getDefinedCellnames(  )
%see also: numericCellnameToCellname, cellnameToNumericCellname

%             1    2    3    4     5     6     7       8         9         10           11       12  13  14   15   16     17     18     19      20    21   22    23      24         25     26     27      28      29      30      31      32      33      34    
cellNames = {'P0','P1','AB','P2','EMS','ABp','ABa','cellst8','cellst16','cellst32', 'cellst64', 'P3','C','E','MS','ABpl','ABpr','ABal','ABar', 'P4', 'D', 'Ca', 'Cp','intestine' , 'MSa', 'MSp','ABprp','ABpra','ABplp','ABpla','ABarp','ABara','ABalp','ABala'};
treeDepth = [ 1     2    2   3     3     3     3      4          5           6           7        4   4   4   4     4       4      4     4      5     5     5     5      5           5      5       5       5       5       5       5       5      5       5 ];
