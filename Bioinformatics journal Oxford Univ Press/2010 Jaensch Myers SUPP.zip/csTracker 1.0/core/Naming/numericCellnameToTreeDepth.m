function [ treeDepth ] = numericCellnameToTreeDepth( numCellname )
%see also: getDefinedCellnames, cellnameToNumericCellname, numericCellnameToCellname

[cellnames, td] = getDefinedCellnames();
if(numCellname <= length(td))
    treeDepth = td(numCellname);
else
    error('numeric cell name %d is not defined',numCellname);
end

end

