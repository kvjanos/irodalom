function [ name ] = numericSidenameToSidename( numSidename )
%see also: sidenameToNumericSidename, getDefinedSidenames

sideNames = getDefinedSidenames();
N = length(numSidename);

for i = 1 : N
    if(numSidename <= length(sideNames))
        if(N == 1)
        name = sideNames{numSidename};
        else
        name{i} = sideNames{numSidename(i)};
        end
    else
        error('numeric side name %d is not defined',numSidename);
    end
end