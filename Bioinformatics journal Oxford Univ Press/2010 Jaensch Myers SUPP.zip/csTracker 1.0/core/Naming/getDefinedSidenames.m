function [ sides ] = getDefinedSidenames(  )
%see also: numericSidenameToSidename

%             1          2        3
sides = {'posterior','anterior','undefined ap-position'};