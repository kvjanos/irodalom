function [ identifier ] = getSideIdentifier( R, header, varargin)
%GETCENTROSOMEIDENTIFIER 
%also see: getCellIdentifier, getCentrosomeIdentifier

%
%input:             R      - a single row from a table
%                   header - the header specifying the columns in R
%variable input:    'SideDimensionLength' - 'full' or a number specifying how many letters of the sidename shall be used,
%                                           example: 'full' ==> 'anterior', 1 ==> 'a', 4 ==> 'ante'
%output:    identifier - an identifier for the cell side (posterior or anterior) depending on the
%                        data available in R

sideDimensionLength = getVarargin(varargin, 'SideDimensionLength', 'full');

colIdx = headerIndex(header,  {'side'}, 'error');
sideColIdx      = colIdx(1);

numSide    = R(sideColIdx);
identifier = getSidename(numSide, sideDimensionLength);
end

function sidename = getSidename(numSide, sideDimensionLength)
    sidename = numericSidenameToSidename(numSide);
    if(isnumeric(sideDimensionLength))
        sidename = sidename(1:sideDimensionLength);
    end
end
