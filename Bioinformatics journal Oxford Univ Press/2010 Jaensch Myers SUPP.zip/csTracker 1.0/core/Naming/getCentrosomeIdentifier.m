function [ identifier ] = getCentrosomeIdentifier( R, header, varargin)
%GETCENTROSOMEIDENTIFIER 
%also see: getCellIdentifier, getSideIdentifier

%
%input:             R      - a single row from a table
%                   header - the header specifying the columns in R
%variable input:    'Separator'           - a string,  used to separate multiple dimensions, default: '_' 
%                   'AlwaysAddTrID'       - a boolean, default: 0
%                   'AlwaysAddObjID'      - a boolean, default: 0
%                   'InludeDimension'     - a boolean, default: 0, example: 'cellname=P0, side=anterior' vs 'P0, anterior'
%                   'UseCellID'           - a boolean, default: 0, cellID is only used if switched on here
%                   'SideDimensionLength' - 'full' or a number specifying how many letters of the sidename shall be used,
%                                           example: 'full' ==> 'anterior', 1 ==> 'a', 4 ==> 'ante'
%
%output:    identifier - an identifier for the centrsome depending on the
%                        data available in R


arg_idx = find(strcmpi('Separator', varargin));
if(isempty(arg_idx))
    separator = '_';
else
    separator = varargin{arg_idx+1};
end

arg_idx = find(strcmpi('AlwaysAddTrID', varargin));
if(isempty(arg_idx))
    alwaysAddTrID = 0;
else
    alwaysAddTrID = varargin{arg_idx+1};
end

arg_idx = find(strcmpi('AlwaysAddObjID', varargin));
if(isempty(arg_idx))
    alwaysAddObjID = 0;
else
    alwaysAddObjID = varargin{arg_idx+1};
end

arg_idx = find(strcmpi('InludeDimension', varargin));
if(isempty(arg_idx))
    inludeDimension = 0;
else
    inludeDimension = varargin{arg_idx+1};
end

arg_idx = find(strcmpi('UseCellID', varargin));
if(isempty(arg_idx))
    useCellID = 0;
else
    useCellID = varargin{arg_idx+1};
end

arg_idx = find(strcmpi('SideDimensionLength', varargin));
if(isempty(arg_idx))
    sideDimensionLength = 'full';
else
    sideDimensionLength = varargin{arg_idx+1};
end


colIdx = headerIndex(header,  {'cellName', 'side', 'trID', 'objID', 'cellID'}, 'none');
cellNameColIdx  = colIdx(1);
sideColIdx      = colIdx(2);
trIDColIdx      = colIdx(3);
objIDColIdx     = colIdx(4);
cellIDColIdx    = colIdx(5);

if(trIDColIdx > 0)
    trID = R(trIDColIdx);
    identifier_trID = sprintf('trID=%03d',trID);
else    
    identifier_trID = [];
end

if(objIDColIdx > 0)
    objID = R(objIDColIdx);
    identifier_objID = sprintf('objID=%06d',objID);
else    
    identifier_objID = [];
end

if(cellNameColIdx > 0 && sideColIdx > 0)
    numCellName = R(cellNameColIdx);
    numSide     = R(sideColIdx);
    
    try
        side     = getSidename(numSide, sideDimensionLength);
        cellName = numericCellnameToCellname(numCellName);
        if(inludeDimension)
            identifier = sprintf('cellname=%s%sside=%s',cellName,separator,side);
        else
            identifier = sprintf('%s%s%s',cellName,separator,side);
        end
    
    catch
          alwaysAddTrID = 1;
          identifier = [];
    end   
    
    if(alwaysAddTrID)
        identifier = [identifier separator identifier_trID];
    end
    if(alwaysAddObjID)
        identifier = [identifier separator identifier_objID];
    end
elseif(useCellID && cellIDColIdx > 0 && sideColIdx > 0)
    cellID  = R(cellIDColIdx);
    numSide = R(sideColIdx);
    
    side = getSidename(numSide, sideDimensionLength);
    
    if(inludeDimension)
        identifier = sprintf('cellID=%02d%sside=%s',cellID,separator,side);
    else
        identifier = sprintf('cellID=%02d%s%s',cellID,separator,side);
    end
    identifier = [identifier separator identifier_trID];
    
    if(alwaysAddObjID)
        identifier = [identifier separator identifier_objID];
    end
elseif(trIDColIdx > 0)
    identifier = identifier_trID;
    if(alwaysAddObjID)
        identifier = [identifier separator identifier_objID];
    end
else    
    identifier = identifier_objID;
end
end

function sidename = getSidename(numSide, sideDimensionLength)
    sidename = numericSidenameToSidename(numSide);
    if(isnumeric(sideDimensionLength))
        sidename = sidename(1:sideDimensionLength);
    end
end
