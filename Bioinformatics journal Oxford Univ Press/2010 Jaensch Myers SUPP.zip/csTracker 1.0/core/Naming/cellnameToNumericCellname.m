function [ numCellname ] = cellnameToNumericCellname( cellname )
%see also: getDefinedCellnames, numericCellnameToCellname

cellnames = getDefinedCellnames();

numCellname = find(strcmpi(cellname, cellnames));

if(isempty(numCellname))
    error('cellname ''%s'' is not defined',cellname);
end
