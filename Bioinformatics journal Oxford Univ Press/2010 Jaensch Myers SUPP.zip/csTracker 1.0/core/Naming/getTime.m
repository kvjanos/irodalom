function [ str ] = getTime( R, header, varargin )


normTimeColIdx = headerIndex(header, 'normTime', 'none');
realTimeColIdx = headerIndex(header, 'realTime', 'none');

useRealTime              = getVarargin(varargin, 'useRealTime',              0, 0, 'single');
alwaysIncludeFrameNumber = getVarargin(varargin, 'alwaysIncludeFrameNumber', 0, 0, 'single');


if(normTimeColIdx > 0)
   str = sprintf('t = %3d sec (rel. to NEBD)',R(normTimeColIdx));
elseif(realTimeColIdx > 0 && useRealTime)
   str = sprintf('t = %3d sec',R(realTimeColIdx));
else
   str = sprintf('frame# %3d',R(4));
   alwaysIncludeFrameNumber = 0;
end

if(alwaysIncludeFrameNumber)
    str = [str sprintf(', frame# %3d',R(4))];
end