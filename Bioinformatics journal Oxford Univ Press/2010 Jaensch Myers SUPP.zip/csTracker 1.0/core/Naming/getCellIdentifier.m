function [ identifier ] = getCellIdentifier( R, header, varargin) 
%also see: getCentrosomeIdentifier

%
%input:             R      - a single row from a table
%                   header - the header specifying the columns in R
%variable input:    'Separator'           - a string,  used to separate multiple dimensions, default: '_' 
%                   'AlwaysAddTrID'       - a boolean, default: 0
%                   'AlwaysAddObjID'      - a boolean, default: 0
%                   'AlwaysAddCellID'     - a boolean, default: 0
%                   'IncludeDimension'    - a boolean, default: 0, example: 'cellname=P0' vs 'P0'
%
%output:    identifier - an identifier for the cell depending on the
%                        data available in R

separator           = getVarargin(varargin, 'Separator', '_');
alwaysAddTrID       = getVarargin(varargin, 'AlwaysAddTrID', 0);
alwaysAddObjID      = getVarargin(varargin, 'AlwaysAddObjID', 0);
alwaysAddCellID     = getVarargin(varargin, 'AlwaysAddCellID', 0);
includeDimension    = getVarargin(varargin, 'IncludeDimension', 0);

colIdx = headerIndex(header,  {'cellName', 'side', 'trID', 'objID', 'cellID'}, 'none');
cellNameColIdx  = colIdx(1);
sideColIdx      = colIdx(2);
trIDColIdx      = colIdx(3);
objIDColIdx     = colIdx(4);
cellIDColIdx    = colIdx(5);

if(trIDColIdx > 0)
    trID = R(trIDColIdx);
    identifier_trID = sprintf('trID=%03d',trID);
else    
    identifier_trID = [];
end

if(objIDColIdx > 0)
    objID = R(objIDColIdx);
    identifier_objID = sprintf('objID=%06d',objID);
else    
    identifier_objID = [];
end

if(cellNameColIdx > 0)
    numCellName = R(cellNameColIdx);
   
    try
        cellName =  numericCellnameToCellname(numCellName);
        if(includeDimension)
            identifier = sprintf('cellname=%s',cellName);
        else
            identifier = sprintf('%s',cellName);
        end
        if(alwaysAddCellID && cellIDColIdx > 0)
             cellID     = R(cellIDColIdx);
             identifier = [identifier separator sprintf('cellID=%02d',cellID)];
        end
    catch
        if(cellIDColIdx > 0)
            cellID     = R(cellIDColIdx);
            identifier = sprintf('cellID=%02d',cellID);
        else
            identifier    = identifier_trID;
            alwaysAddTrID = 0;
        end
    end   
    
    if(alwaysAddTrID)
        identifier = [identifier separator identifier_trID];
    end
    if(alwaysAddObjID)
        identifier = [identifier separator identifier_objID];
    end
elseif(cellIDColIdx > 0)
    cellID  = R(cellIDColIdx);
    
    identifier = sprintf('cellID=%02d',cellID);
    identifier = [identifier separator identifier_trID];
    
    if(alwaysAddObjID)
        identifier = [identifier separator identifier_objID];
    end
elseif(trIDColIdx > 0)
    identifier = identifier_trID;
    if(alwaysAddObjID)
        identifier = [identifier separator identifier_objID];
    end
else    
    identifier = identifier_objID;
end
end