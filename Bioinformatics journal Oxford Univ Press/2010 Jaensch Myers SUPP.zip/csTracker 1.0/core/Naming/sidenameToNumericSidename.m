function [ numSidename ] = sidenameToNumericSidename( sidename )
%see also: getDefinedSidenames, numericSidenameToSidename

if(strcmpi(sidename(1),'a'))
    sidename = 'anterior';
elseif(strcmpi(sidename(1),'p'))
    sidename = 'posterior';
elseif(strcmpi(sidename(1),'u'))
    sidename = 'undefined ap-position';
end

sidenames = getDefinedSidenames();

numSidename = find(strcmpi(sidename, sidenames));

if(isempty(numSidename))
    error('side name ''%s'' is not defined',sidename);
end
