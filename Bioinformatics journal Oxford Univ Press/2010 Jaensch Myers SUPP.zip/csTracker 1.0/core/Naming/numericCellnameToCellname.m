function [ name ] = numericCellnameToCellname( numCellname )
%see also: getDefinedCellnames, cellnameToNumericCellname, numericCellnameToTreeDepth

cellnames = getDefinedCellnames();

N =  length(numCellname);
for i = 1 : N
    if(numCellname <= length(cellnames))
        if(N == 1)
            name = cellnames{numCellname(i)};
        else
            name{i} = cellnames{numCellname(i)};
        end
    else
        error('numeric cell name %d is not defined',numCellname);
    end
end