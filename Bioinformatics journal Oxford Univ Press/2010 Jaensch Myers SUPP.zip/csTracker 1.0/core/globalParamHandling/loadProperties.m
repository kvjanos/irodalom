function [p, filenameLoaded ] = loadProperties( )
%also see: saveProperties

global pathHomeDir;
filenameLoaded = [pathHomeDir filesep 'properties.xml']; 
p = xml_read (filenameLoaded);

if(~isfield(p, 'mfileAlgorithmParameters'))
    p.mfileAlgorithmParameters = 'ap_centrosomesDefault';
end
if(~isfield(p, 'fluorescentMarker'))
    p.fluorescentMarker = 'centrosome';
end

if(~isfield(p, 'movieGroup'))
    p.movieGroup = 'undefined movie group';
end
if(~isfield(p, 'isMultiCell'))
    p.isMultiCell = 1;
end
if(~isfield(p, 'objective'))
    p.objective = 'water (new SD)';
end
if(~isfield(p, 'NA'))
    p.NA = 1.4;
end
if(~isfield(p, 'emissionWavelength'))
    p.emissionWavelength = 525;
end
if(~isfield(p, 'refractiveIndex'))
    p.refractiveIndex = 1.33;
end
if(~isfield(p, 'sigmaPSF'))
    p.sigmaPSF = 150; %nm
end
if(~isfield(p,'embryoDimension'))
    [param_ap,param_bio ] = eval(p.mfileAlgorithmParameters);
    p.embryoDimension = param_bio.embryoDimension;
end
if(length(p.embryoDimension)<3)
    p.embryoDimension(3) = 20;
end