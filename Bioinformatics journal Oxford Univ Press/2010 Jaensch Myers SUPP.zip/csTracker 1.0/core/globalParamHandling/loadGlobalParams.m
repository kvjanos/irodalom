function p = loadGlobalParams( workingDir, forceReload )
%LOADGLOBALPARAMS Summary of this function goes here
%   Detailed explanation goes here
if(nargin < 2)
    forceReload = 0;
end
global param;
global pathHomeDir;

if(isAbsolutePath(workingDir))
    filename = fullfile(workingDir, 'globalParams.xml');
else
    filename = getFullPath(workingDir, 'globalParams.xml');
end

if(~forceReload && nargout == 0 && isfield(param, 'currentFileLoaded') && strcmpi(filename, param.currentFileLoaded))
    fprintf('global params for %s already loaded\n', workingDir);
else
    fprintf('loading global params for %s ...\n', workingDir);
    
    p = xml_read (filename);
    param = p;
    param.currentFileLoaded = filename;
    if(isAbsolutePath(workingDir))    
        pathHomeDir = [getRootDirectoryOfDirectory(workingDir, param.homeDir) filesep param.homeDir];
    end

    try
        prop = loadProperties();
        param = catstruct(param,prop);
    catch
        if(getDebugLevel >= 2)
            printDebugStack(lasterror)
        end
    end

    fprintf('Done!\n');

    if(~isfield(param, 'isMultiCell'))
        param.isMultiCell = 1;
    end
    if(~isfield(param, 'isStackMultiImage')) %not used
        param.isStackMultiImage = 0;  
    end
    if(~isfield(param, 'zStretchingCorrection')) %not used
        param.zStretchingCorrection = .5;
    end
    if(~isfield(param, 'debugMode'))
        param.debugMode = 0;
    end
    
    param.resolutionVector = [param.resolution param.resolution param.zResolution];
 
    [param.ap, param.bio ] = eval(param.mfileAlgorithmParameters);

    param.r1 = param.bio.r1;
    param.r2 = param.bio.r2;

    thisWorkingDir    = fileparts(filename); %the absolute path to the workingDir
    param.workingDir  = thisWorkingDir;
    relPathWorkingDir = getChildPath(thisWorkingDir, pathHomeDir);
    if(~strcmp(relPathWorkingDir, param.relPathWorkingDir))
        try
            updateGlobalParams( relPathWorkingDir );
        catch
            warning('updateGlobalParams failed!!!');
            printDebugStack(lasterror);
        end
    end
    
    if(~isfield(param, 'nextFreeObjID'))
        try
            fn = getFullPath(param.relPathCandidatesFile);
            [T, header] = loadList(fn);
            objIDColIdx = headerIndex(header, 'objID');
            param.nextFreeObjID = max(T(:,objIDColIdx))+1;
            saveGlobalParams();
        catch
            printDebugStack(lasterror);
        end
    end
    p = param;
end
% if(~strcmp(workingDir, param.workingDir))
%     try
%         %search for the image sequence two folders above the working dir
%         %require that the first two directory names of the new image
%         %directory are equal to the old image directory and that the first
%         %image file (of the image sequence) exists in the new directory
%         newImagePath = getParentDirectory(workingDir,2);
%         dirNamesOld = getDirectoryNames(param.pathImages);
%         dirNamesNew = getDirectoryNames(newImagePath);
%         [imgPath, firstFullFilename ext] = fileparts(param.imageSequence.firstFullFilename);
%         if(strcmpi(dirNamesOld{1},dirNamesNew{1}) && ...
%            strcmpi(dirNamesOld{2},dirNamesNew{2}) && ...
%            exist([newImagePath filesep firstFullFilename ext], 'file'))
%            warning('updateGlobalParams: source image folder has been chosen automatically as %s',newImagePath);
%         else
%             newImagePath = uigetdir(workingDir,'Please, select the directory containing the analyzed images');
%         end
%     catch
%         newImagePath = uigetdir(workingDir,'Please, select the directory containing the analyzed images');
%     end
%     updateGlobalParams( workingDir, newImagePath );
% end


end