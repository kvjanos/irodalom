function saveImagingParams( abs_or_rel_PathToImageFolder, imagingParams, properties )
%
% abs_or_rel_PathToImageFolder - the path the image folder the
%                                param-structure belongs to
%imagingParams                 - the param-structure
%properties {optional}         - used to remove redundant fields                    
%

global pathHomeDir;

if(isAbsolutePath(abs_or_rel_PathToImageFolder))
    stackDirectory = abs_or_rel_PathToImageFolder;
else
    stackDirectory = fullfile(pathHomeDir, abs_or_rel_PathToImageFolder);
end

if(nargin >= 3)
    %remove all fields that are present in properties (properties are
    %always appended to the imagingParams when loaded, see loadImagingParams.m)
    
    imagingParams = rmfieldIfExists(imagingParams, fieldnames(properties));
 end


xml_write([stackDirectory filesep 'imagingParams.xml'], imagingParams);
 
