function [p, filenameLoaded] = loadImagingParams( abs_or_rel_PathToImageFolder )
%LOADIMAGINGPARAMS Summary of this function goes here
%   Detailed explanation goes here

global pathHomeDir;
if(isAbsolutePath(abs_or_rel_PathToImageFolder))
    stackDirectory = abs_or_rel_PathToImageFolder;
else
    stackDirectory = fullfile(pathHomeDir, abs_or_rel_PathToImageFolder);
end
filenameLoaded = [stackDirectory filesep 'imagingParams.xml'];
p = xml_read (filenameLoaded);
try
    prop = loadProperties();
    p = catstruct(p,prop);
catch
    if(getDebugLevel >= 2)
        printDebugStack(lasterror)
    end
end

if(isfield(p,'imageSequence'))
    p.imageSequence.absPath             = getFullPath(p.imageSequence.relPath);
    p.imageSequence.firstFullFilename   = [p.imageSequence.absPath filesep p.imageSequence.firstFilename];
end