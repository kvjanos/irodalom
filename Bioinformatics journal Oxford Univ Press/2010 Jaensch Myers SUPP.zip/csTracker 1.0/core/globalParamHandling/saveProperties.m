function saveProperties( properties )
%also see: loadProperties
global pathHomeDir;
fn = [pathHomeDir filesep 'properties.xml'];
[path, homeDir] = fileparts(pathHomeDir);
if(~strcmpi(homeDir, properties.homeDir))
    error('homeDir in properties is "%s", but current path is "%s"',properties.homeDir,pathHomeDir);
end
xml_write(fn, properties);