function [ fullFilename ] = getFullPath( relPath, filename )
%GETFULLPATH Summary of this function goes here
%   Detailed explanation goes here
global pathHomeDir;

if(nargin == 1)
    fullFilename = [pathHomeDir filesep relPath];
else
    fullFilename = [pathHomeDir filesep relPath filesep filename];
end
