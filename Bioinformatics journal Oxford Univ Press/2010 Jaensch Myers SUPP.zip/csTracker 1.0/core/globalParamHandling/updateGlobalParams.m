function updateGlobalParams(newRelPathWorkingDir)
%also see: loadGlobalParams, saveGlobalParams\

    global param; %this is important as otherwise changes to 'param' will not be propagated to other functions
    f = ['updating working directory in ' getFullPath(newRelPathWorkingDir) filesep 'globalParams.xml...'];
    fprintf('%s\n',f);
    
    
    %update the working dir in all relative paths
    fNames                  = fieldnames(param);
    oldRelPathWorkingDir    = param.relPathWorkingDir;
    param.relPathWorkingDir = newRelPathWorkingDir;
    for i = 1 : length(fNames)
        field = fNames{i};
        if(strStartsWith(field, 'relPath'))
            %field
            path =  param.(field);
            if(strStartsWith(path, oldRelPathWorkingDir))
                newRelPath = strrep(path, oldRelPathWorkingDir, newRelPathWorkingDir);
                param.(field) = newRelPath;
            end
        end
    end
         
    if(~strcmp(param.relPathWorkingDir , newRelPathWorkingDir))
        error('updating global params failed');
    end
     
    saveGlobalParams();
    fprintf('DONE!\n');    
end
