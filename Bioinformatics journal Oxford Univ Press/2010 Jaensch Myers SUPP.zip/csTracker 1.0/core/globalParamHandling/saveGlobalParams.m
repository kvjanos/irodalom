function filename = saveGlobalParams()
    global param;
    p = param;
    param = rmfieldIfExists(param, 'imgSource'); %dynamically loaded
    param = rmfieldIfExists(param, 'NEBD'); %saved in properties.xml
    param = rmfieldIfExists(param, 'ap'); %algorithm parameters
    param = rmfieldIfExists(param, 'GaussianFit'); %old field
    

    fn = getFullPath(param.relPathGlobalParams);
    xml_write(fn, param);
    filename = fn;
    
    param = p;
end