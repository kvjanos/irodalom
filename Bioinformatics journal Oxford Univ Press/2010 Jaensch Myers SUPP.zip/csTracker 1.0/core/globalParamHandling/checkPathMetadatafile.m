function checkPathMetadatafile(  )
global param;

if(~isfield(param, 'pathMetadataFile') || isempty( param.pathMetadataFile) || ~exist(param.pathMetadataFile,'file') )
    
    
    if(ischar( param.pathImages )) %directory or image sequence
        dir = param.pathImages;
    else
        dir = fileparts(param.pathImages);
    end
    
    
    p = tryReadSpinningDiskMetaFile(dir);
    if(~isempty(p))
        param.pathMetadataFile = p.pathMetadataFile;
    else
        warning('The metadatafile could not be found in %s',dir);
    end

end
