function [ relPath ] = getRelativePath( absPathWithOrWithoutFilename )

global pathHomeDir;
relPath = getChildPath(absPathWithOrWithoutFilename, pathHomeDir);
