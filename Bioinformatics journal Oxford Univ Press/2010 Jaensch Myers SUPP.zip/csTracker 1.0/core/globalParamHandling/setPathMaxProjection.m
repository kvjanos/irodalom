function setPathMaxProjection( )

%delete this file, check dependencies!!!


% global param;
% 
% %searching for the max projection file
% if(ischar(param.pathImages))
%    pathMaxPrj = param.pathImages; %pathImages does not include filename
% else
%    pathMaxPrj = fileparts(param.pathImages{1}); %pathImages includes filename
% end
% 
% pathMaxPrj = [pathMaxPrj filesep 'maxProjection'];
% pathMaxPrjSearchPattern = [pathMaxPrj filesep '*max*.tif'];
% 
% D = dir(pathMaxPrjSearchPattern);
% 
% if(isempty(D))
%     error('The max projection file could not be found. Was looking for %s',pathMaxPrjSearchPattern);
% end
% 
% param.pathMaxPrj = [pathMaxPrj filesep D(1).name];
% 
% param.pathMaxPrj
% if(~exist(param.pathMaxPrj, 'file'))
%     error('The max projection file could not be found. Was looking for %s',pathMaxPrjSearchPattern);
% end
% 

