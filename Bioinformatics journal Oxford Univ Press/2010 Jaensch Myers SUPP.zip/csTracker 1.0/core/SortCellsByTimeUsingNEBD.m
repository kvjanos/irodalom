function [ T, header ] = SortCellsByTimeUsingNEBD( T, header)

NEBDColIdx   = headerIndex(header, 'NEBD');
cellIDColIdx = headerIndex(header, 'cellID');
[header, NEBDTimeRankColIdx, wa, T] = addHeaderEntry(header, 'NEBDTimeRank', -1, T);

[T, sortIx] = sortrows(T, [NEBDColIdx, cellIDColIdx]);

lastCellID = -inf;
rank = 0;
for i = 1 : size(T,1)
    cellID = T(i,cellIDColIdx);
    if(T(i,NEBDColIdx) > 0)
        if(cellID ~= lastCellID)
            rank = rank + 1;
        end
        T(i,NEBDTimeRankColIdx) = rank;            
    end
    lastCellID = cellID;
end

T(sortIx,:) = T(:,:);
