function [ T, header ] = ComputeDerivedParameters( T, header )

if(isempty(T))
    warning('T is empty');
    return
end

global param;

try
    [T, header] = AssignCellStage( T, header );
catch
     printDebugStack(lasterror,2)
end
try
    [T, header] = ComputeTimeRelativeToNEBD(T, header);
catch
     printDebugStack(lasterror,2)
end

try
    [T, header] = SortCellsByTimeUsingNEBD(T, header);
catch
     printDebugStack(lasterror,2)
end

try
    [header, colIdx] = addHeaderEntry(header, 'realtime');
    T(:,colIdx) = (T(:,4)-1) * param.frameInterval;

    if(max(T(:,colIdx)) > 4000)
        [header, hrsColIdx] = addHeaderEntry(header, 'realtimeHrs');
        T(:,hrsColIdx) = T(:,colIdx) / 3600;
    end
catch
     printDebugStack(lasterror,2)
end

[header, colIdx, wa,T] = addHeaderEntry(header, 'valid', 1, T); %add valid-column if not exists

gaussPrefix = '';
sigmaX2DColIdx = headerIndex(header, [gaussPrefix 'sigmaX2D'], 'none');
sigmaY2DColIdx = headerIndex(header, [gaussPrefix 'sigmaY2D'], 'none');

if(sigmaX2DColIdx > 0 && sigmaY2DColIdx > 0)
    resSigmaX2D = T(:,sigmaX2DColIdx) * param.resolution;
    resSigmaY2D = T(:,sigmaY2DColIdx) * param.resolution;
    
    [header, res_sigmaX2DColIdx] = addHeaderEntry(header, 'resSigmaX2D');
    T(:,res_sigmaX2DColIdx) =  resSigmaX2D;

    [header, res_sigmaY2DColIdx] = addHeaderEntry(header, 'resSigmaY2D');
    T(:,res_sigmaY2DColIdx) = resSigmaY2D;
end    

gaussMult2DColIdx = headerIndex(header, [gaussPrefix 'gaussMult2D'], 'none');
gaussAdd2DColIdx  = headerIndex(header, [gaussPrefix 'gaussAdd2D'],  'none');
bgLevelColIdx     = headerIndex(header, 'bgLevel', 'none');
if(sigmaX2DColIdx > 0 && sigmaY2DColIdx > 0 && gaussMult2DColIdx > 0)
    
    [header, diagonalSigma2DColIdx] = addHeaderEntry(header, 'diagonalSigmaXY2D');
    T(:,diagonalSigma2DColIdx) = sqrt(resSigmaX2D .^2 + resSigmaY2D.^2);  

    [header, meanSigma2DColIdx] = addHeaderEntry(header, 'meanSigmaXY2D');
    T(:,meanSigma2DColIdx) = mean([resSigmaX2D, resSigmaY2D],2);

    [header, meanSigma2DColIdx] = addHeaderEntry(header, 'csRadiusGaussianFitting');
    T(:,meanSigma2DColIdx) = T(:,sigmaX2DColIdx) + T(:,sigmaY2DColIdx); %2*mean([T(:,sigmaX2DColIdx), T(:,sigmaY2DColIdx)],2);

    [header, colIdx] = addHeaderEntry(header, 'csRadiusGaussianFitting_circleEquiv');
    T(:,colIdx) = param.resolution * 2 * sqrt(T(:,sigmaX2DColIdx) .* T(:,sigmaY2DColIdx)); %2*sqrt(sigmax * sigmay)

    [header,meanSigmaXY2D_sphereVolumeColIdx] = addHeaderEntry(header, 'meanSigmaXY2D_sphereVolume');
    T(:,meanSigmaXY2D_sphereVolumeColIdx) = (4/3.0)*pi*T(:,meanSigma2DColIdx).^3;

    [header,prodSigmaXY2DColIdx] = addHeaderEntry(header, 'prodSigmaXY2D');    
    T(:,prodSigmaXY2DColIdx) = prod([resSigmaX2D, resSigmaY2D],2);
    
    [header, ratioSigmaXY2DColIdx] = addHeaderEntry(header, 'ratioSigmaXY2D');
    T(:,ratioSigmaXY2DColIdx) = max(resSigmaX2D,resSigmaY2D) ./ min(resSigmaX2D,resSigmaY2D);
    
    [header, colIdx] = addHeaderEntry(header, 'ratioPeakBG2D');
    T(:,colIdx) = (T(:,gaussMult2DColIdx) + T(:,gaussAdd2DColIdx)) ./ T(:,gaussAdd2DColIdx);
    
    [header, totalInt2DColIdx] = addHeaderEntry(header, 'totalInt2D');
    %see http://de.wikipedia.org/wiki/Normalverteilung
    T(:,totalInt2DColIdx) = (2*pi) * T(:,gaussMult2DColIdx) .*  resSigmaX2D .* resSigmaY2D;
    
    if(bgLevelColIdx > 0)
        [header, normTotalInt2DColIdx] = addHeaderEntry(header, 'normTotalInt2D');
        %see http://de.wikipedia.org/wiki/Normalverteilung
        T(:,normTotalInt2DColIdx) = T(:,totalInt2DColIdx) ./ T(:,bgLevelColIdx);
    end

    [header, localnormTotalInt2DColIdx] = addHeaderEntry(header, 'localnormTotalInt2D');
    T(:,localnormTotalInt2DColIdx) = T(:,totalInt2DColIdx) ./ T(:,gaussAdd2DColIdx);

    [header, colIdx] = addHeaderEntry(header, 'ratioSigmaXY2DDivLogTotalInt2D');
    T(:,colIdx) =  T(:,ratioSigmaXY2DColIdx)./log(T(:,totalInt2DColIdx));
end

tolerance = .15;
[T, header] = acceptRadialIntensityCorrectedGaussianFit(T, header, 'csRadiusCorrected_circleEquiv', 'csRadiusGaussianFitting_circleEquiv', 'csRadiusRadialIntProfile_circleEquiv', tolerance);
[T, header] = acceptRadialIntensityCorrectedGaussianFit(T, header, 'maxprj_csRadiusCorrected_circleEquiv', 'maxprj_csRadiusGaussianFitting_circleEquiv', 'maxprj_csRadiusRadialIntProfile_circleEquiv', tolerance);

[T, header] = correctForPSF(T, header, 'csRadiusCorrected', 'csRadiusCorrected_PSFcorrected', 'csRadiusCorrected_PSFcorrected_sphereVolume');
[T, header] = correctForPSF(T, header, 'csRadiusCorrected_meanAxis', 'csRadiusCorrected_mean_PSFcorrected', 'csRadiusCorrected_mean_PSFcorrected_sphereVolume');
[T, header] = correctForPSF(T, header, 'csRadiusCorrected_circleEquiv', 'csRadiusCorrected_circleEquiv_PSFcorrected', 'csRadiusCorrected_circleEquiv_PSFcorrected_sphereVolume');
[T, header] = correctForPSF(T, header, 'maxprj_csRadiusCorrected_circleEquiv', 'maxprj_csRadiusCorrected_circleEquiv_PSFcorrected', 'maxprj_csRadiusCorrected_circleEquiv_PSFcorrected_sphereVolume');
[T, header] = correctForPSF(T, header, 'csRadiusGaussianFitting_circleEquiv', 'csRadiusGaussianFitting_circleEquiv_PSFcorrected', 'csRadiusGaussianFitting_circleEquiv_PSFcorrected_sphereVolume');
[T, header] = correctForPSF(T, header, 'csRadiusRadialIntProfile_circleEquiv', 'csRadiusRadialIntProfile_circleEquiv_PSFcorrected', 'csRadiusRadialIntProfile_circleEquiv_PSFcorrected_sphereVolume');
[T, header] = correctForPSF(T, header, 'maxprj_csRadiusGaussianFitting_circleEquiv', 'maxprj_csRadiusGaussianFitting_circleEquiv_PSFcorrected', 'maxprj_csRadiusGaussianFitting_circleEquiv_PSFcorrected_sphereVolume');
[T, header] = correctForPSF(T, header, 'maxprj_csRadiusRadialIntProfile_circleEquiv', 'maxprj_csRadiusRadialIntProfile_circleEquiv_PSFcorrected', 'maxprj_csRadiusRadialIntProfile_circleEquiv_PSFcorrected_sphereVolume');

[T, header] = computeSphereVolumeFromRadius(T, header,'csRadiusRadialIntProfile_circleEquiv', 'csRadiusRadialIntProfile_circleEquiv_sphereVolume');
[T, header] = computeSphereVolumeFromRadius(T, header,'csRadiusGaussianFitting_circleEquiv', 'csRadiusGaussianFitting_circleEquiv_sphereVolume');
[T, header] = computeSphereVolumeFromRadius(T, header,'maxprj_csRadiusRadialIntProfile_circleEquiv', 'maxprj_csRadiusRadialIntProfile_circleEquiv_sphereVolume');
[T, header] = computeSphereVolumeFromRadius(T, header,'maxprj_csRadiusGaussianFitting_circleEquiv', 'maxprj_csRadiusGaussianFitting_circleEquiv_sphereVolume');


fittedxcorrSigmaColIdx = headerIndex(header, 'fittedxcorrSigma', 'none');
if(fittedxcorrSigmaColIdx > 0)
    [header, colIdx] = addHeaderEntry(header, 'resFittedXcorrSigma');
    T(:,colIdx) = T(:,fittedxcorrSigmaColIdx) * param.resolution;
end

xcorrSigmaColIdx = headerIndex(header, 'xcorrSigma', 'none');
if(xcorrSigmaColIdx > 0)
    [header, colIdx] = addHeaderEntry(header, 'resXcorrSigma');
    T(:,colIdx) = T(:,xcorrSigmaColIdx) * param.resolution;
end

z0ColIdx = headerIndex(header, 'z0', 'none');
if(z0ColIdx > 0)
    [header, colIdx] = addHeaderEntry(header, 'resZ0');
    T(:,colIdx) = T(:,z0ColIdx) * param.zResolution;
end

zColIdx = headerIndex(header, 'z', 'none');
if(zColIdx > 0)
    [header, colIdx] = addHeaderEntry(header, 'resZ');
    T(:,colIdx) = T(:,zColIdx) * param.zResolution;
end

try
    [T, header] = ComputeCSVelocity( T, header );
catch
    printDebugStack(lasterror,2)
end

thisDebugLevel = getDebugLevel();
try
    setDebugLevel(0);
    [T, header] = ComputeSpindleProperties(T, header);
catch ME
 printDebugStack(ME,2)
end
setDebugLevel(thisDebugLevel);

end

function [T, header] = computeSphereVolumeFromRadius(T, header,radiusColName, volumeMeasurementColName)
    radiusColIdx = headerIndex(header, radiusColName, 'none');
    if(radiusColIdx > 0)
        [header,sphereVolumeColIdx] = addHeaderEntry(header, volumeMeasurementColName);
        T(:,sphereVolumeColIdx) = (4/3.0)*pi*T(:,radiusColIdx).^3 ./ (1000^3);
    end
end

function [T, header] = correctForPSF(T, header, inputRadiusColName, outputRadiusColName, outputVolumeRadiusColName)
global param;
radiusColIdx = headerIndex(header, inputRadiusColName, 'none');
if(radiusColIdx > 0)
    [header, radius_PSFcorrectedColIdx] = addHeaderEntry(header, outputRadiusColName);
    radiusRaw = T(:,radiusColIdx);
    radiusPSF = 2*param.sigmaPSF;
    ix_abovePSF =  radiusRaw > radiusPSF;

    T(ix_abovePSF,radius_PSFcorrectedColIdx) = sqrt(radiusRaw(ix_abovePSF).^2 - radiusPSF^2);
    T(~ix_abovePSF,radius_PSFcorrectedColIdx) = radiusPSF;

    if(nargin >= 5)
        [T, header] =  computeSphereVolumeFromRadius(T, header,outputRadiusColName, outputVolumeRadiusColName);
    end
end
end


function [T, header] = acceptRadialIntensityCorrectedGaussianFit(T, header, radius_RadialIntensityColName, radius_GaussianFitColName, outputColName, tolerance)

csRadiusCorrected_circleEquivColIdx         = headerIndex(header, radius_RadialIntensityColName, 'none');
csRadiusGaussianFitting_circleEquivColIdx   = headerIndex(header, radius_GaussianFitColName, 'none');
if(csRadiusCorrected_circleEquivColIdx > 0 && csRadiusGaussianFitting_circleEquivColIdx > 0)
    % accept radius from radial intensity profile only if its difference to
    % the radius from the gaussian fit is within the specified tolerance
    [header, csRadiusRadialIntProfile_circleEquivColIdx] = addHeaderEntry(header, outputColName);
    relDiff = abs(T(:,csRadiusGaussianFitting_circleEquivColIdx) - T(:,csRadiusCorrected_circleEquivColIdx)) ./ T(:,csRadiusGaussianFitting_circleEquivColIdx);
    ixWithinTolerance = relDiff <= tolerance;
    T(ixWithinTolerance, csRadiusRadialIntProfile_circleEquivColIdx) = T(ixWithinTolerance,csRadiusCorrected_circleEquivColIdx);
    T(~ixWithinTolerance, csRadiusRadialIntProfile_circleEquivColIdx) = T(~ixWithinTolerance,csRadiusGaussianFitting_circleEquivColIdx);
end
end