function [x2_aligned, y2_aligned, displacement ] = AlignCurves_autoMaxDisplacement( x1,y1,x2,y2, interpolationInterval, allowScaling )

if(interpolationInterval < 1)
    sub_x_steps = 1 / interpolationInterval;
    interpolationInterval = 1;
    x1 = x1 * sub_x_steps;
    x2 = x2 * sub_x_steps;
    sub_x_precision = 1;
else
    sub_x_precision = 0;
end

preDisplacement = x1(1) - x2(1);
preDisplacement = x1(ceil(end/2)) - x2(ceil(end/2));

x2_org = x2;
x2 = x2 + preDisplacement;

xmin = min([x1(:);x2(:)]);
xmax = max([x1(:);x2(:)]);

x2_lb = x2(ceil(.3*end));
x2_ub = x2(ceil(.7*end));

maxDisplacement = max(abs(x2_lb - x1(1)),abs(x2_ub - x1(end)));

[ x2_aligned, y2_aligned, displacement, scalingFactor ] = AlignTwoPartialCurves( x1, y1, x2, y2, xmin, xmax, interpolationInterval, maxDisplacement, allowScaling );

displacement = displacement + preDisplacement;

if(sub_x_precision)
    displacement = displacement / sub_x_steps;
end

if(getDebugLevel() >= 2)
    figure, hold on
    plot(x1,y1,'r')
    plot(x2_org,y2,'k')
    plot(x2_aligned,y2_aligned,'k:')
end
end

