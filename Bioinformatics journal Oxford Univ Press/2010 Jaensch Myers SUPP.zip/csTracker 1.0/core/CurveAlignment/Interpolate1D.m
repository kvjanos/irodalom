function [ xi,yi ] = Interpolate1D( x,y,T )
    %x - x-values
    %y - y-values, same length as x
    %T - interpolation interval
    
    xi = x(1):T:x(end);
    yi = interp1q(x(:),y(:),xi(:));
end

