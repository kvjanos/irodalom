function [ x2_aligned, y2_aligned, displacement, scalingFactor, quality ] = AlignTwoPartialCurves( x1, y1, x2, y2, xmin, xmax, interpolationInterval, maxDisplacement, allowScaling )
% see also: AlignTwoCurves

if(nargin < 9)
    allowScaling = 0;
end
if(nargin == 0)
    maxDisplacement = 150;
    interpolationInterval = 1;
    xmin=-500;
    xmax=0;
    xmin=-1000;
    xmax=1000;
    x1=[
        -680
        -640
        -600
        -560
        -520
        -480
        -440
        -400
        -360
        -320
        -280
        -240
        -200
        -160
        -120
        -80
        -40
        0
        40
        80
        120
        160
        200];
    x2 = x1;
    
    y1 = [
        272.60244
        162.606246
        210.766732
        185.046694
        188.282168
        187.556468
        195.969996
        215.525192
        221.367282
        249.305256
        274.81562
        309.320728
        361.663706
        400.480866
        440.340082
        471.748624
        494.706984
        494.271318
        489.144186
        471.68737
        502.34799
        500.021486
        509.847874];
    
    y2 = [
        196.24568
        204.532108
        219.439872
        214.902238
        227.456192
        244.911942
        271.807286
        305.281408
        331.855476
        353.965874
        390.56354
        432.10761
        464.588056
        491.89873
        506.165664
        520.900572
        512.566338
        518.83655
        513.52254
        507.623296
        512.04531
        504.100494
        500.891834
        ];
end
[x1i,y1i] = Interpolate1D(x1,y1,interpolationInterval);
[x2i,y2i] = Interpolate1D(x2,y2,interpolationInterval);

xmin = max([xmin,x1i(1),x2i(1)]);    
xmax = min([xmax,x1i(end),x2i(end)]);    
ix1 = x1i >= xmin & x1i <= xmax;
ix2 = x2i >= xmin & x2i <= xmax;

x_p   = x1i(ix1);
y1i_p = y1i(ix1);
y2i_p = y2i(ix2);

[displacement, scalingFactor, quality ] = AlignTwoCurves(x_p, y1i_p, y2i_p, maxDisplacement, allowScaling );
x2i = x2i + displacement;
x2  = x2  + displacement;

orgT = x2(2) - x2(1);
ix1 = find(x2 >= x2i(1),1,'first');
ix1 = find(x2i == x2(ix1));

x2_aligned = x2i(ix1:orgT:end);
y2_aligned = y2i(ix1:orgT:end);

% figure, subplot 121, hold on, plot(x1, y1, 'o-r'), plot(x2, y2, 'd-k'),
%         subplot 122, hold on, plot(x1, y1, 'o-r'), plot(x2_aligned, y2_aligned, 'd-k');


end

