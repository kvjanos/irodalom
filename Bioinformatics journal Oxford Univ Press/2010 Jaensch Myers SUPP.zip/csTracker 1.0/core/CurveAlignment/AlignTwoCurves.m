function [ displacement, scalingFactor, quality ] = AlignTwoCurves( x,y1,y2, maxDisplacement, allowScaling )

if(nargin < 5)
    allowScaling = 0;
end
if(nargin == 0)
    maxDisplacement = 100;
    x=[
        -680
        -640
        -600
        -560
        -520
        -480
        -440
        -400
        -360
        -320
        -280
        -240
        -200
        -160
        -120
        -80
        -40
        0
        40
        80
        120
        160
        200];
    
    y1 = [
        272.60244
        162.606246
        210.766732
        185.046694
        188.282168
        187.556468
        195.969996
        215.525192
        221.367282
        249.305256
        274.81562
        309.320728
        361.663706
        400.480866
        440.340082
        471.748624
        494.706984
        494.271318
        489.144186
        471.68737
        502.34799
        500.021486
        509.847874];
    
    y2 = [
        196.24568
        204.532108
        219.439872
        214.902238
        227.456192
        244.911942
        271.807286
        305.281408
        331.855476
        353.965874
        390.56354
        432.10761
        464.588056
        491.89873
        506.165664
        520.900572
        512.566338
        518.83655
        513.52254
        507.623296
        512.04531
        504.100494
        500.891834
        ];
    
    ix = x >= -600 & x <= 0;
    x = x(ix);
    y1 = y1(ix);
    y2 = y2(ix);
end


% figure, hold on, plot(x, y1, '-or'), plot(x, y2, 'dk-')

n = length(x);
a = -maxDisplacement : maxDisplacement;
d = zeros(1,length(a));
alpha  = ones(1,length(a));
i = 0;
fig1 = figure;

for k = a
    i = i + 1;
    c1 = y1(max(1,1+k):min(n, n+k));
    c2 = y2(max(1,1-k):min(n, n-k));
    if(allowScaling)
        alpha(i) = scalingFactorBetweenVectors( c1,c2 );
        c2 = alpha(i)*c2;
    end
    d(i) = sum(abs(c1 - c2)) / length(c1);
    if(getDebugLevel() >= 3)
        clf(fig1)
        plot(c1,'-ok'), hold on, plot(c2,'-kx');
        title(sprintf('k = %d',k));
        printFigureToPostScript(fig1, [myTempDir filesep 'alignCurves.ps'],1);
    end
end

penality = alpha;
penality(penality < 1) = 1 ./ penality(penality < 1);
penality = penality .^ 2;
q = d .* penality;
if(getDebugLevel() >= 3)
    figure, hold on
    plot(a, d, '-ok', 'DisplayName', 'd');
    plot(a, q, '-db', 'DisplayName', 'q');
    legend('show')
    figure, plot(a, alpha, '-xr', 'DisplayName', 'alpha');
    legend('show')
    figure, plot(a, penality, '-xr', 'DisplayName', 'penality');
    legend('show')
end
close(fig1);
[quality, minDistIdx] = min(q);
displacement = a(minDistIdx);
scalingFactor = alpha(minDistIdx);
% figure, hold on, plot(x, y1, '-or'), plot(x+displacement, y2, 'dk-')

end

