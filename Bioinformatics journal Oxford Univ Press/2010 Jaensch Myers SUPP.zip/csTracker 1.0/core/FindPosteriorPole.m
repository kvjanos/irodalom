function [ p_posterior, p_anterior ] = FindPosteriorPole(workingDir, filenameIn, skipIfFileoutExists)
%FindPosteriorSide determines which pole is posterior and anterior,
%respectively. The embryo must have its main axis parallel with the image
%x-axis.
%
%method: Let I be the maximum projection of the frame where the first
%centrosome has been detected, the contour of the embryo in this image has
%a bounding box (minx,miny,maxx,maxy). If the centrosome is closer to minx,
%then minx is the posterior side (x_posterior)) otherwise maxx is the posterior side.

% see also: AssignCellNames, AssignPosteriorAnterior

fprintf('%s\n',mfilename);

if(nargin == 0)
    workingDir = [baseDir filesep 'RSA1-GFP2_WT_4to8cellstage\workingDir\1'];
    workingDir = [baseDir filesep 'RSA1-GFP2_WT_2to4cellstage\workingDir\1'];
    workingDir = [baseDir filesep 'yTUB-GFP24_WT_1to8cellstage\workingDir\8'];
    filenameIn = 'tracksComplete_pairs_trTree.txt';
    setDebugLevel(1)
end
global param;
[filenameIn, filenameOut, dirDebug ] = initProcessingStep( workingDir, filenameIn, 'side', mfilename);

if(~exist('skipIfFileoutExists','var'))
    skipIfFileoutExists = 0;
end
if(skipIfFileoutExists && isfield(param, 'posterior'))
    p_posterior = param.posterior;
    if(isfield(param, 'anterior'))
        p_anterior = param.anterior;
    else
        p_anterior = [];
    end
    return
end
setImageSource('type','smoothed');

[T, header] = loadList(filenameIn);
T = sortrows(T, 4); %sort by time
[T, header] = ComputeDerivedParameters(T,header);

trIDColIdx   = headerIndex(header, 'trID');
cellIDColIdx = headerIndex(header, 'cellID');

cellIDs_initialCellstage = CellIDsOfInitialCellstage(T, header);
initialCellStage         = length(cellIDs_initialCellstage);

idx_cellIDs_initialCellstage = ismember(T(:,cellIDColIdx),cellIDs_initialCellstage); 
if(initialCellStage == 1)
    %movie starts at 1-cell stage ==> both cs in P0 are near the posterior pole at the beginning
    t1 = min(T(idx_cellIDs_initialCellstage,4));
    trIDs_nearPosterior = unique(T(idx_cellIDs_initialCellstage,trIDColIdx));
    trIDs_nearAnterior  = [];
elseif(initialCellStage == 2)
    %movie starts at 2-cell stage
    %- the cell with the later cs-pair is P1
    
    cellID2displacement = SortCellsByTimeUsingSpindleLength( T, header, cellIDs_initialCellstage );

    %the first cell is AB
    %the last cell is P1
    trIDs_nearAnterior  = unique(T(ismember(T(:,cellIDColIdx),cellID2displacement(1,1)), trIDColIdx));
    trIDs_nearPosterior = unique(T(ismember(T(:,cellIDColIdx),cellID2displacement(2,1)), trIDColIdx));
    t1 = 'all';
elseif(initialCellStage == 4)
    cellID2displacement = SortCellsByTimeUsingSpindleLength( T, header, cellIDs_initialCellstage );
    %the first two cells are ABa and ABp
    %the last two cells are EMS and P2
    trIDs_nearAnterior  = unique(T(ismember(T(:,cellIDColIdx),cellID2displacement(1:2,1)), trIDColIdx));
    trIDs_nearPosterior = unique(T(ismember(T(:,cellIDColIdx),cellID2displacement(3:4,1)), trIDColIdx));
    t1 = 'all';
else %initial cell stage > 4 or non-wildtype morphology
    p_posterior = setPosterior(workingDir);
    p_anterior = [];
    return
end

if(ischar(t1))
    R_nearPosterior = T(ismember(T(:,trIDColIdx),trIDs_nearPosterior),:);
    R_nearAnterior  = T(ismember(T(:,trIDColIdx),trIDs_nearAnterior),:);
else
    R_nearPosterior = T(T(:,4) == t1 & ismember(T(:,trIDColIdx),trIDs_nearPosterior),:);
    R_nearAnterior  = T(T(:,4) == t1 & ismember(T(:,trIDColIdx),trIDs_nearAnterior),:);
end
p_nearPosterior = mean(R_nearPosterior(:,1:2));
if(isempty(R_nearAnterior))
    p_nearAnterior = [];
else
    p_nearAnterior  = mean(R_nearAnterior(:,1:2));
end

maxPrj = loadMaxProjection();
if(isempty(t1) || ischar(t1))
    t1 = min(T(:,4));
end
I = maxPrj(:,:,t1);
[mask, I_overlay] = FindEmbryoContourInSingleImage2( I );
bb = BoundingBoxOfMask( mask );
y_mid = mean(bb(1:2));
p_left  = [bb(3) y_mid];
p_right = [bb(4) y_mid];

if(norm(p_nearPosterior-p_left) < norm(p_nearPosterior-p_right))
    if(isempty(p_nearAnterior) || norm(p_nearAnterior-p_left) > norm(p_nearAnterior-p_right))
        p_posterior = p_left;
        p_anterior  = p_right;
    else
        warning('both positions are closer to the left pole than to the right pole');
        if(norm(p_nearPosterior-p_left) < norm(p_nearAnterior-p_left))
            p_posterior = p_left;
            p_anterior  = p_right;
        else
            p_posterior = p_right;
            p_anterior  = p_left;
        end
    end
else
    if(isempty(p_nearAnterior) || norm(p_nearAnterior-p_left) < norm(p_nearAnterior-p_right))
        p_posterior = p_right;
        p_anterior  = p_left;
    else
        warning('both positions are closer to the right pole than to the left pole.');
        if(norm(p_nearPosterior-p_right) < norm(p_nearAnterior-p_right))
            p_posterior = p_right;
            p_anterior  = p_left;
        else
            p_posterior = p_left;
            p_anterior  = p_right;
        end
    end
end
props = loadProperties();
props.posterior = p_posterior;
props.anterior  = p_anterior;
saveProperties(props);

if(getDebugLevel >= 1)
    fig1 = figure;
    imshow(I_overlay,[]);
    hold on
    y = ceil(param.imgSource.imageHeight/2);
    plot(p_posterior(1),p_posterior(2), 'o');
    plot(p_anterior(1),p_anterior(2), 'o');
    text(p_posterior(1)+7, p_posterior(2), 'posterior', 'color', 'r');
    text(p_anterior(1)+7, p_anterior(2), 'anterior', 'color', 'r');
    title(sprintf('max projection, frame# %03d, %s',t1,strrep(param.tag,'_',' ')));
    saveas(fig1, [dirDebug filesep 'embryo_contour.fig']);
    if(getDebugLevel < 2)
        close(fig1)
    end
end
