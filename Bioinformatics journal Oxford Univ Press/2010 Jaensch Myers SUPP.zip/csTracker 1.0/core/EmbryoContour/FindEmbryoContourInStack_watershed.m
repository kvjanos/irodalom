function [embryoMask, Ioverlay_initialMarker, limitsEmbryoArea_pixels, markerOk ] = FindEmbryoContourInStack_watershed( stack, fillBlackCorners, embryoDimension2D, resolutionXY, specifyInitialMarkerManually )
% see also: FindEmbroContourInMaxProjection, MarkOutsideEmbryoCandidates

for i = 1 : size(stack,3);
    fprintf('.');
end
fprintf('\n');

margin = 40;
embryoDimension2D(1) = min(embryoDimension2D(1), round((size(stack,2)-1.5*margin)*resolutionXY/1000));
embryoDimension2D(2) = min(embryoDimension2D(2), round((size(stack,1)-1.5*margin)*resolutionXY/1000));

areaTolerance = [.5 2];
expectedEmbryoArea_pixels = pi*prod(embryoDimension2D)/4 * (1000 / resolutionXY)^2;
limitsEmbryoArea_pixels = round(areaTolerance * expectedEmbryoArea_pixels);

if(specifyInitialMarkerManually)
    markerOk = 1;
    initialMarkerFrame = min(4, size(stack,3));
    I = stack(:,:,initialMarkerFrame);
    ws_marker = userInputMarker(I);
else
    markerOk = 0;
    %go through the time points until we find a threshold segmention with
    %area within the specified limits
    %(the first few frames are usually darker, some initialization of the microscope seems to be going on there)
    for initialMarkerFrame = min(4, size(stack,3)) : size(stack,3)
        medianPrj = median(stack(:,:,max(1,initialMarkerFrame-1):min(initialMarkerFrame+1,size(stack,3))),3);
        if(fillBlackCorners)
            I = FillBlackCorners( medianPrj );
        else
            I = medianPrj;
        end
        I_smoothed = imsmooth(I, 2);
        Ithr = otsu(I_smoothed, 3);
        
        %consider class-2 (cytoplasm) and class-3 (centrosomes/nuclei) pixels as embryo region
        m = Ithr > 0;
        m = extractBiggestBinaryRegion(m);
        %check whether the embryo region touches the images border
        %if so, consider only class-3 pixels as embryo region
        if(any(m(:,1)>0) || any(m(:,end)>0) || any(m(1,:)>0) || any(m(end,:)>0))
            m = Ithr > 0.5;
            m = extractBiggestBinaryRegion(m);
        end
        ws_marker = bwmorph(m, 'erode', 5);
        ws_marker = imfill(ws_marker,'holes'); %fill holes
        ws_marker = extractBiggestBinaryRegion(ws_marker);
        rp        = regionprops(bwlabel(ws_marker), 'Area');
        if(~isempty(rp))
            area_     = rp.Area;
            if(area_ >= limitsEmbryoArea_pixels(1) && area_ <= limitsEmbryoArea_pixels(2))
                markerOk = 1;
                break
            end
        end
    end
end


if(~markerOk && ~specifyInitialMarkerManually)
    warning(sprintf('no segmentation with area within [%d, %d] found', limitsEmbryoArea_pixels));
    
    initialMarkerFrame = ceil(size(stack,3)/2);
    I = stack(:,:,initialMarkerFrame);
    len = ceil(8*1000 / resolutionXY);
    ws_marker = false(size(I));
    
    x0 = ceil((size(I,2)-len)/2);
    y0 = ceil((size(I,1)-len)/2);
    ws_marker(max(1,y0):min(size(I,1),y0+len),max(1,x0):min(size(I,2),x0+len)) = true;
end


Ioverlay_initialMarker = OverlayMask(stack(:,:,initialMarkerFrame), ws_marker,0, 'black');

frames = [initialMarkerFrame:size(stack,3), initialMarkerFrame-1:-1:1];
embryoMask = zeros(size(stack));
for i = 1 : length(frames)
    fprintf('.');
    
    if(i > 1 && frames(i) - frames(i-1) < -1)
        embryoRegion = embryoRegionAtInitialFrame;
    end
    I = stack(:,:,frames(i));
    if(frames(i) == initialMarkerFrame)
        %do watershed with initial marker from otsu thresholding
        embryoRegion = FindEmbryoContourInSingleImage_watershed(I, ws_marker);
        embryoRegionAtInitialFrame = embryoRegion;
    else
        %do watershed with eroded watershed segmentation from previous frame as marker
        marker_from_prev_frame = bwmorph(embryoRegion, 'erode', 7);
        embryoRegion = FindEmbryoContourInSingleImage_watershed(I, marker_from_prev_frame);
    end
    embryoMask(:,:,frames(i)) = extractBiggestBinaryRegion(embryoRegion);
end
fprintf('\n');

if(getDebugLevel() >= 1 && ~isempty(getDebugDir()))
    fn_debug = [getDebugDir filesep 'area_settings.txt'];
    
    txt =      sprintf('embryoDimension2D         = (%d,%d) microns\n', embryoDimension2D);
    txt = [txt sprintf('resolutionXY              = %d nm/pixel\n', resolutionXY)];
    txt = [txt sprintf('expectedEmbryoArea_pixels = %d\n', expectedEmbryoArea_pixels)];
    txt = [txt sprintf('areaTolerance             = (%d,%d)\n', areaTolerance)];
    txt = [txt sprintf('limitsEmbryoArea_pixels   = (%d,%d)\n', limitsEmbryoArea_pixels)];
    
    if(~markerOk)
        txt = [txt sprintf('no segmentation with area within [%d, %d] found', limitsEmbryoArea_pixels)];
    end
    PrintToFile(txt, fn_debug, 'a', 1);
end
end

function marker = userInputMarker(img)

marker = zeros(size(img));
cnt = 0;
img = overlayMask(img, marker);
figure, imshow(img, [])
while(1)
    [bw,xi,yi] = roipoly(imadjust(img));
    if(length(xi) < 3)
        break
    end
    cnt = cnt+1;
    marker = max(marker,bw);
    img = overlayMask(img, marker);
end
if(cnt == 0)
    marker = [];
end
end

