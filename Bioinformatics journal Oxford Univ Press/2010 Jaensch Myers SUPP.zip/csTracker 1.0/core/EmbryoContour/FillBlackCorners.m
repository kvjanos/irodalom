function [I, linearIdx_blackCorners] = FillBlackCorners( I )    
    %check whether there is a black margin in the corners caused by image rotation
    corners = zeros(4,1);
    corners(1) = sum(sum(imcropCentered3(I,[1,1],2)));
    corners(2) = sum(sum(imcropCentered3(I,[1,size(I,2)],2)));
    corners(3) = sum(sum(imcropCentered3(I,[size(I,1),1],2)));
    corners(4) = sum(sum(imcropCentered3(I,[size(I,1),size(I,2)],2)));
    corners = corners == 0;
    linearIdx_blackCorners = [];
    if(sum(corners) >= 1)
%         if(getDebugLevel >= 2)
%             warning('There has been a black margin detected in the image corners. Trying to fill the margin.');
%         end

        linearIdx_blackCorners = find(I(:) == 0);        
        I(linearIdx_blackCorners) = mean(I(:))/2;
    end
end    