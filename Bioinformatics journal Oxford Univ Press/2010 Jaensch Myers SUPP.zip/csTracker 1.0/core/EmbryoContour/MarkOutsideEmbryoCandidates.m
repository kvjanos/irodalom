function [ varargout ] = MarkOutsideEmbryoCandidates( varargin )
% marks all candidates that are positioned outside the embryo region
% see also: FindEmbroContourInMaxProjection

if(nargin == 0)
    workingDir  = [baseDir filesep 'yTUB-GFP4_SAS4_30-33hrsRNAi_2to4cellstage\workingDir\8'];
    filenameIn  = finalCandidatesFile();
        
    varargin{1} = workingDir;
    varargin{2} = filenameIn;
end
fprintf('%s\n',mfilename);

updateEmbryoDimensionInProperties = getVarargin(varargin, 'updateEmbryoDimensionInProperties', 1, 1);

global param;
[T, header, filenameIn, filenameOut] = processInput(varargin, 'OutsideEmbryoFlag');
workingDir = param.workingDir;
if(isempty(T))
    varargout{1} = filenameOut;
    return;
end
embryoMask = loadEmbryoMask('convex hull', updateEmbryoDimensionInProperties);

[header, outsideEmbryoFlagColIdx,columnHasBeenAdded, T] = addHeaderEntry(header, 'outsideEmbryoFlag',0,T);

for i = 1 : size(T,1)
    x = round(T(i,1));
    y = round(T(i,2));
    
    x = max(1,x);
    x = min(size(embryoMask,2),x);
    
    y = max(1,y);
    y = min(size(embryoMask,1),y);
    
    t = T(i,4);
    T(i, outsideEmbryoFlagColIdx) = embryoMask(y,x,t) == 0;
end

if(isempty(filenameOut))
    varargout{1} = T;
    varargout{2} = header;
else
    fprintMatrix(filenameOut, T, header);
    varargout{1} = filenameOut;
end