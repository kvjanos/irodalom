function [ stackMask, stackOverlay, shapeFactor, angle_, area_ ] = FindEmbryoContourInStack( stack, segmentationAlgorithm )
%FINDEMBRYOCONTOURINSTACK 
%input: stack
%       segmentationAlgorithm: thresholdingOnSingleImages, watershedOnStack
%
%see also: FindEmbryoROIFromStack

N = size(stack,3);
shapeFactor  = zeros(N,1);
area_        = zeros(N,1);
angle_       = zeros(N,1);
stackOverlay = zeros(size(stack),class(stack));

if(strcmpi(segmentationAlgorithm, 'watershedOnStack'))
    fillBlackCorners = 0;
    for i = 1 : N
        stack(:,:,i) = imsmooth(stack(:,:,i), 2);
    end
    [stackMask, I_overlay_initialMarker] = FindEmbryoContourInStack_watershed(stack, fillBlackCorners);
elseif(strcmpi(segmentationAlgorithm, 'thresholdingOnSingleImages'))
    stackMask    = zeros(size(stack));
    for i = 1 : N
        fprintf('.');
        stackMask(:,:,i) = FindEmbryoContourInSingleImage2( stack(:,:,i) );
    end
else
    error('unknown segmentation algorithm "%s"',segmentationAlgorithm);
end
for i = 1 : N
    I = stack(:,:,i);
    mask = stackMask(:,:,i);
    props = myregionprops( bwlabel(mask), 'ShapeFactor', 'Area', 'Orientation');

    if(~isempty(props))
        shapeFactor(i)      = props.ShapeFactor;
        angle_(i)           = props.Orientation;
        area_(i)            = props.Area;
        
        contour = bwmorph(mask,'remove'); %reduce regions to their boundaries
        stackOverlay(:,:,i) = OverlayGrayColored(I,contour*max(I(:)),'white');   
    else
        warning('object properties are empty. no contour found?');
        %figure, imshow(I_overlay,[]);
    end
    
end
fprintf('\n');

if(getDebugLevel >= 1)
    try
        filenameDebug = [getDebugDir filesep mfilename '_all.mat'];
        save(filenameDebug, 'stack', 'stackMask', 'stackOverlay', 'shapeFactor','angle_','area_');
%         filenameDebug_Stack = [getDebugDir filesep mfilename '_allEmbryoContour.tif'];
%         WriteStackAsMultiTIFF(im2uint16(stackOverlay),filenameDebug_Stack);
        
        fig1 = sfigure;
        ax(1) = gca;
        hold on;
        ax(2) = axes('Position',get(ax(1),'Position'),'XAxisLocation','bottom','YAxisLocation','right','Color','none','XMinorTick','off');
        hold on;

        
        plot(ax(1),shapeFactor,'ok-','LineWidth',2,'DisplayName','shape factor');
        plot(ax(2),area_,'or-','LineWidth',2,'DisplayName','area');

        legend(ax(1),'show','Location','SouthWest');
        legend(ax(2),'show','Location','SouthEast');
       
        xlabel(ax(1),'index');
        ylabel(ax(1),'shape factor');
        ylabel(ax(2),'area');
       
        filenameDebug = [getDebugDir filesep mfilename '_all.fig'];
        saveas(fig1,filenameDebug);
        	
        clf(fig1);
        filenameDebug_ps = makeFilenameUnique([getDebugDir filesep mfilename '_all.ps']);

        for i = 1 : size(stackOverlay,3)
            imshow(imadjust(stackOverlay(:,:,i)),[]);
            title(sprintf('angle = %.1f, shape factor = %.2f', angle_(i), shapeFactor(i)));
            print(sprintf('-f%d',fig1),'-dpsc2','-append', filenameDebug_ps)
        end
        close(fig1);        	
    catch
        printDebugStack(lasterror)
    end
end



