function mask = FindEmbryoContourInSingleImage_watershed( I, marker )
%see also: FindEmbroContourInMaxProjection

%input: I      - image with embryo image
%       marker - marker for the embryo region, background region will be added automatically

    margin = 15; %used to defined the background marker, 
                 %choose a value which ensures that the embryo never comes
                 %closer to any image border than 'margin'

    I_med = medfilt2(I, [13 13]);
%     I_smoothed = imsmooth(I, 4);
%     Ithr = otsu(I_smoothed, 3);
%     marker = bwmorph(Ithr>0, 'erode', 11);
%     marker = extractBiggestBinaryRegion(marker);
    I_edges = sobel_edgeDetector(I_med);
    I_edges = imsmooth(I_edges, 1.0);
   % marker = userInputMarker(I_med);
    
%     marker = ones(100,200);
%     marker = embedMatrix(marker, size(I));
    markerEmbryoContour =  bwmorph(marker,'remove');
    markerEmbryoContour = bwmorph(markerEmbryoContour, 'dilate', 1);
    marker(1:margin,:) = 1;
    marker(end-margin+1:end,:) = 1;
    marker(:,1:margin) = 1;
    marker(:,end-margin+1:end) = 1;
    marker(markerEmbryoContour) = 0;
    
    img = imimposemin(I_edges, marker);
    ws = watershed(img);
    mask = ws > 1; %1 is the background label
    mask = imfill(mask,'holes'); %fill holes
    
%     I_overlay = OverlayGrayColored(imadjust(I), marker, 'white');
%     figure, imshow(I_overlay,[]);
%     I_overlay = OverlayGrayColored(I, ws==0, 'black');
%     figure, imshow(I_overlay,[]);
%     fnTemp = makeFilenameUnique([myTempDir filesep 'ecw' filesep 'EmbryoContourWatershedMarker.tif']);
%     imwrite(I_overlay, fnTemp, 'Compression', 'none')
%     fnTempMarker = makeFilenameUnique([myTempDir filesep 'ecw_marker' filesep 'EmbryoContourWatershedMarker.tif']);
%     imwrite(OverlayMask(imadjust(I), marker, 0, 'black'), fnTempMarker, 'Compression', 'none')
end

function marker = userInputMarker(img)
    marker = zeros(size(img));
    while(1)
        [bw,xi,yi] = roipoly(imadjust(img));
        if(isempty(xi))
            break
        end
        marker = max(marker,bw);
        img = OverlayMask(img, bw);
    end
end

