function [mask, I_overlay, contour, I_smooth] = FindEmbryoContourInSingleImage2( I, centrosomeMask )
% - embryo contour detection based on background substraction and thresholding
% - background is estimated by a 3rd order polynomial
% - the embryo needs to be surrounded by background with a margin of at least the margin specified
% - if a centrosome mask is specified the centrosome area is replaced by the
%   average gray value of the cytoplasm in the vicinity of the centrosome

    
    margin = 35;

    I_org = I;
    
    %check whether there is a black margin in the corners caused by image rotation
    [I,linearIdx_blackCorners] = FillBlackCorners( I );
    I_smooth = imsmooth(I,5);
    
    if(nargin >= 2) %centrosome mask is specified ==> get rid of centrosomes in the image
        centrosomeMaskContour = bwmorph(centrosomeMask,'remove'); %reduce regions to their boundaries
        
        avgIntensityNearCS    = mean(I_smooth(centrosomeMaskContour > 0));
        I_smooth(centrosomeMask > 0 & I_smooth > avgIntensityNearCS) = avgIntensityNearCS/2;
    end

    s = 5;
    N_periods = 20;
    x = 1 : s : size(I,2);
    y = 1 : s : size(I,1);
    
    y1 = ceil(TriangleWave_Nperiods(x, N_periods, margin-1)+1);
    y2 = ceil(size(I,1) - TriangleWave_Nperiods(x, N_periods, margin));

    x1 = ceil(TriangleWave_Nperiods(y, N_periods, margin-1)+1);
    x2 = ceil(size(I,2) - TriangleWave_Nperiods(y, N_periods, margin));

    x = [x  x  x1 x2];
    y = [y1 y2 y  y];
    
    %filter sampled points at 'black corners'
    indPoints = sub2ind(size(I),y,x);
    indPoints = setdiff(indPoints, linearIdx_blackCorners);
    [y,x] = ind2sub(size(I), indPoints);
    imgBG = getBackgroundImage(x,y,I_smooth);
    
    if(getDebugLevel >= 2)
        sfigure;
        subplot(2,2,1)
        imshow(I_smooth,[min(I_smooth(:)), max(I_smooth(:))]);
        title('smoothed image');
        
        subplot(2,2,2)
        imshow(I_smooth,[min(I_smooth(:)), max(I_smooth(:))]);
        title('smoothed image with bg sample points');
        hold on;
        plot(x,y,'rx');

        subplot(2,2,4)
        imshow(imgBG,[min(I_smooth(:)), max(I_smooth(:))]);
        title('(estimated) background image');
%         colormap hsv
       
        
        sfigure
        subplot(2,2,3)
        surfc(imgBG,'LineStyle','none','FaceColor','interp','FaceAlpha',1.0);
%         colormap hsv
        shading interp
        title('(estimated) background image');

    end
    
    I_smooth = max(0,I_smooth-imgBG);
 
    I_thr = otsu(I_smooth,3);
        
    mask = I_thr > 0;
    mask = imfill(mask,'holes'); %fill holes
    mask = extractBiggestBinaryRegion(mask);
    
    if(getDebugLevel >= 2 || nargout > 1)
        contour = bwmorph(mask,'remove'); %reduce regions to their boundaries
        maxI = max(I_org(:));
        I_overlay = OverlayGrayColored(I_org,contour*maxI,'white');   
    end
    
    if(getDebugLevel>=2)
        fig1 = sfigure;
        maximize(fig1);
        subplot(2,2,1), imshow(I);
        title('org image');
        subplot(2,2,2), imshow(I_smooth,[]);
        title('smoothed and background subtracted');
        subplot(2,2,3), imshow(I_thr,[]);
        title('thresholded');
        subplot(2,2,4), imshow(I_overlay,[]);
        title('contour on org image');
        %colormap hsv
    end
end

function y = TriangleWave_Nperiods(x, N, a)
T = floor((x(end) - x(1)) / N);
y = TriangleWave(x, T, a); 
end
function y = TriangleWave(x, T, a)
q=floor(x/T);
T2 = T/2;
x0 = x - q*T;
y = interp1([0 T2 T],[0,a,0],x0);
end
