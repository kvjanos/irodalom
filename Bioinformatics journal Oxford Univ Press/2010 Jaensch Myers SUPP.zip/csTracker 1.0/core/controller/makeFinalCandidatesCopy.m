function [ fn_candidatesAll, fn_movie ] = makeFinalCandidatesCopy( fn, skipIfFileoutExists)
%see also: makeFinalCopy, makeCompleteTracksCopy, makeCandidatesAllCopy_helper

if(nargin < 2)
    skipIfFileoutExists = 0;
end
global param

workingDir = fileparts(fn);
loadGlobalParams(workingDir);

fn_candidatesAll = [workingDir filesep finalCandidatesFile()];
if(~(skipIfFileoutExists && exist(fn_candidatesAll, 'file')))
     copyfile(fn,fn_candidatesAll,'f');
     [T, header] = loadList(fn);
     [T, header] = ComputeDerivedParameters(T, header);
     fprintMatrix(fn, T, header);
     
     if(strcmpi(param.fluorescentMarker, 'histone'))
        csRadius = 'csRadiusGaussianFitting';
        csRadius = 'fittedxcorrSigma';
        csRadius = 'rf_maxSigmaXY2D_pix';
     elseif(strcmpi(param.fluorescentMarker, 'nucleusMembrane'))
        csRadius = 'xcorrradius';
        csRadius = 'xcorrradiusOrgScale';
    else
        csRadius = [];
    end
    fn_movie = makeTrackingMovie(workingDir, fn_candidatesAll, [], 0, 'showTrID',0,'showObjID',1, 'markerRadiusColName', csRadius);
end


end

