function run_all_batch(testOnly)

if(nargin < 1)
    testOnly = 0;
end

regEx_imageSeriesNumbering = '_t[0-9]{4}'; %format of the numbering for multi-file image stacks

listOfMovieCollectionDirs = {

    };

dirOut = baseDir();

startFromHomedir        = zeros(length(listOfMovieCollectionDirs), 1);
movieGroupAlreadyExists = zeros(length(listOfMovieCollectionDirs), 1);
movieGroupName          = cell(length(listOfMovieCollectionDirs),  1);

%% check if directory only contains 'firstFilenames.txt' ==> call 'run_all_from_homeDir'
firstFilenames = {};
for i = 1 : length(listOfMovieCollectionDirs)
    movieCollectionDir = listOfMovieCollectionDirs{i};
    [list_firstFilenames, moreFilesPresent ] = readFirstFilenamesFile( movieCollectionDir );
    startFromHomedir(i) = ~isempty(list_firstFilenames) && ~moreFilesPresent;
    firstFilenames = [firstFilenames;list_firstFilenames];
end
%% check for filename consistency
for i = 1 : length(listOfMovieCollectionDirs)
    movieCollectionDir = listOfMovieCollectionDirs{i};
    deleteFileIfExists([movieCollectionDir filesep 'IJ_Prefs.txt'])
    
    if(startFromHomedir(i))
        continue
    end
    
    D = dir(movieCollectionDir);
    filenames = {};
    for j = 1 : length(D)
        if(~D(j).isdir && ~strcmpi(D(j).name, 'properties.xml'))
            filenames{end+1} = D(j).name;
        end
    end
    
    if(isempty(filenames))
        error('no files found in %s',movieCollectionDir);
    end
    errorCount = checkFilenameConsistency( filenames, regEx_imageSeriesNumbering );
    if(errorCount > 0)
        error('sorry, your filenames in %s are not consistent (see messages above)',movieCollectionDir);
    end
    
    %add filenames of the already existing movies of this movie group (fake file extension .xyz)
    fn_properties = [movieCollectionDir filesep 'properties.xml'];
    props = xml_read(fn_properties);
    movieGroupName{i} = props.movieGroup;
    try
        movGroup = loadMovieGroupByName(props.movieGroup);
        movieGroupAlreadyExists(i) = 1;
    catch
        movGroup = [];
        movieGroupAlreadyExists(i) = 0;
    end
    if(~isempty(movGroup))
        filenames_existingMovies = {};
        for j = 1 : length(movGroup.movies)
            movieTag         = movGroup.movies{j}.movieTag;
            filenames_existingMovies{end+1} = [movieTag '.xyz'];
        end
        
        %first check if the already existing movie names are consistent
        errorCount = checkFilenameConsistency( filenames_existingMovies, regEx_imageSeriesNumbering );
        if(errorCount > 0)
            error('the filenames of the new movies in %s are consistent, but the filenames in the already existing movies of the group "%s" are not consistent (see messages above). cannot add any movies to this group',movieCollectionDir, props.movieGroup);
        else
            %then check if the new and the existing movies together are consistent
            filenames_all = [filenames filenames_existingMovies];
            errorCount = checkFilenameConsistency( filenames_all, regEx_imageSeriesNumbering );
            if(errorCount > 0)
                error('sorry, your filenames in %s are not consistent with the already existing movies in the group "%s" (see messages above)',movieCollectionDir, props.movieGroup);
            end
        end
    end
    
end

%% check whether movie home dir already exists
n = zeros(length(listOfMovieCollectionDirs),1);
for i = 1 : length(listOfMovieCollectionDirs)
    movieCollectionDir = listOfMovieCollectionDirs{i};
    if(startFromHomedir(i))
        continue
    end
    metaFiles = dir([movieCollectionDir filesep '*.txt']);
    for j = 1 : length(metaFiles)
        n(i) = n(i)+1;
        nameStub = getFilenameWithoutExtension(metaFiles(j).name);
        dirName  = [dirOut filesep nameStub];
        if(exist(dirName, 'dir'))
            if(length(dir(dirName)) > 2)
                error('directory %s already exists and is not empty, please rename the movie in %s', dirName, movieCollectionDir);
            end
        end
    end
end

%% check if 'findChipROI' is turned off if new spinning disc has been used
for i = 1 : length(listOfMovieCollectionDirs)
    movieCollectionDir = listOfMovieCollectionDirs{i};
    if(startFromHomedir(i))
        continue
    end
    fn_prop = [movieCollectionDir filesep 'properties.xml'];
    p = xml_read (fn_prop);
    
    expected_findChipROI = mp_objectiveNameToChipROI(p.objective);
    if(isfield(p, 'findChipROI') && expected_findChipROI ~= p.findChipROI)
        error('findChipROI should be turned off for objective "%s" in %s',p.objective,fn_prop);
    end
end

%% check whether the resolution specified in the meta file makes sense
for i = 1 : length(listOfMovieCollectionDirs)
    movieCollectionDir = listOfMovieCollectionDirs{i};
    if(startFromHomedir(i))
        continue
    end
    
    fn_prop = [movieCollectionDir filesep 'properties.xml'];
    p = xml_read (fn_prop);
    expected_resolution = mp_objectiveNameToResolution(p.objective);
    
    D = dir([movieCollectionDir filesep '*.txt']);
    for j = 1 : length(D)
        fn_meta = [movieCollectionDir filesep D(j).name];
        md = readSpinningDiskMetaFile(fn_meta);
        if(md.resolution ~= expected_resolution)
            error('resolution should be %d for objective "%s" in %s',expected_resolution,p.objective,fn_meta);
        end
    end
    
end

if(~testOnly)
    %% run analysis
    for i = 1 : length(listOfMovieCollectionDirs)
        movieCollectionDir = listOfMovieCollectionDirs{i};
        if(~startFromHomedir(i))
            run_all(movieCollectionDir, dirOut);
        end
    end
    if(~isempty(firstFilenames))
        fn_run_all_fromHomeDir =  [fileparts(listOfMovieCollectionDirs{1}) filesep 'run_all_fromHomeDir.txt'];
        deleteFileIfExists(fn_run_all_fromHomeDir);
        for i = 1 : length(firstFilenames)
            PrintToFile(firstFilenames{i},fn_run_all_fromHomeDir);
        end
        run_all_fromHomeDir(firstFilenames);
    end
    %% register movies
    registerMovies();
else
    fprintf('all movies are ready for processing in:\n')
    for i = 1 : length(listOfMovieCollectionDirs)
        movieCollectionDir = listOfMovieCollectionDirs{i};
        if(~startFromHomedir(i))
            fprintf('\t%s\t(n=%d, movie group already exists = %d) "%s"\n',movieCollectionDir,n(i),movieGroupAlreadyExists(i),movieGroupName{i})
        end
    end
    if(~isempty(firstFilenames))
        fprintf('processing of the following movies will be started from the home directories:\n')
        for i = 1 : length(firstFilenames)
            fn = firstFilenames{i};
            fprintf('\t%s\n',fn)
        end
    end
end
end
