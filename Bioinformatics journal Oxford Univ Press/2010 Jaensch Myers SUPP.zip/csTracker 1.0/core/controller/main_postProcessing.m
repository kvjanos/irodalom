function main_postProcessing(workingDir, processingSteps_FunctionHandleOrStrIdent)
%also see: main_postProcessing_batch


if(nargin == 0)
    workingDir = [baseDir filesep 'RSA1-GFP_wt_8to16cellstage\workingDir\1'];

    setDebugLevel(1);
    processingSteps_FunctionHandleOrStrIdent = 'trackCentrosomes';
end
workingDir

if(nargin >= 2 && ~ischar(processingSteps_FunctionHandleOrStrIdent))
    strProcessingStepsFunction = func2str(processingSteps_FunctionHandleOrStrIdent);
    fn_error = [myTempDir filesep sprintf('error_%s.log',strProcessingStepsFunction)];
else
    fn_error = [myTempDir filesep sprintf('error_%s.log',mfilename)];
end

global param;
global pathHomeDir;
try
    if(nargin >= 2 && ~ischar(processingSteps_FunctionHandleOrStrIdent))
        try
            processingSteps_FunctionHandleOrStrIdent(workingDir, fn_error);
        catch
            processingSteps_FunctionHandleOrStrIdent(workingDir);
        end
    else
        if(strcmpi(processingSteps_FunctionHandleOrStrIdent, 'trackCentrosomes'))
            pSteps_csTracking(workingDir);
        end
    end
catch
    warning('post processing not successful for %s',workingDir);
    if(nargin >= 2 && ~ischar(processingSteps_FunctionHandleOrStrIdent))
        PrintToFile(sprintf('%s: processing (%s) not successful for %s',datestr(clock),func2str(processingSteps_FunctionHandleOrStrIdent),workingDir),fn_error);
    else
        PrintToFile(sprintf('%s: processing not successful for %s',datestr(clock),workingDir),fn_error);
    end
    printDebugStack(lasterror,0,fn_error);
end