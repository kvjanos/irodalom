function run_all_fromHomeDir( firstFilenamesOrMovieDirs )
if(nargin == 0)
    firstFilenamesOrMovieDirs = {
        [baseDir filesep 'yTUB-GFP_wt_1cellstage']
        [baseDir filesep 'yTUB-GFP_wt_1to4cellstage']
        [baseDir filesep 'RSA1-GFP_wt_8to16cellstage']
        [baseDir filesep 'yTUB-GFP_sas4RNAi_2cellstage']
        [baseDir filesep 'yTUB-GFP_zyg1ts_1cellstage']
    };
end
try
    listMovieDir = prepareImageStack_batch(firstFilenamesOrMovieDirs);
    main_batch(listMovieDir);
catch
    printDebugStack(lasterror);
end