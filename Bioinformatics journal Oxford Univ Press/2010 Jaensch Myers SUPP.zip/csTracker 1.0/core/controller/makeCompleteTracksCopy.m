function [ fn_tracks, fn_movie ] = makeCompleteTracksCopy( fn, skipIfFileoutExists, makeMovieWithInsets, showObjID)
%see also: makeFinalCopy, makeFinalCandidatesCopy

if(nargin < 2)
    skipIfFileoutExists = 0;
end
if(nargin < 3)
    makeMovieWithInsets = 1;
end
if(nargin < 4)
    showObjID = 0;
end

workingDir = fileparts(fn);
fn_tracks = [workingDir filesep completeTracksFile()];
if(~(skipIfFileoutExists && exist(fn_tracks, 'file')))
    copyfile(fn,fn_tracks,'f');
    if(makeMovieWithInsets)
        makeTrackingMovie(workingDir, fn_tracks, [], 0, 'replaceCSPatchByCenterImage',1 );
    end
    fn_movie = makeTrackingMovie(workingDir, fn_tracks, [], 0, 'showObjID', showObjID);
end