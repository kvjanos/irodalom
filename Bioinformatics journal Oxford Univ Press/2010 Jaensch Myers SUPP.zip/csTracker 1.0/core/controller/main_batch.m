function main_batch( movieDirList, numWorkingDir )
%also see: main
close all

if(nargin == 0)
    
    movieDirList ={
        [baseDir filesep 'SPD2-GFP3_RNAires(cterm2)_SPD5-Alexa597_XFP_10hrsRNAi_2cellstage_noDC\SPD2-GFP3_RNAires(cterm2)_SPD5-Alexa597_XFP_10hrsRNAi_2cellstage_noDC_t0000.tif']
        [baseDir filesep 'SPD2-GFP4_RNAires(cterm2)_SPD5-Alexa597_XFP_10hrsRNAi_2cellstage_noDC\SPD2-GFP4_RNAires(cterm2)_SPD5-Alexa597_XFP_10hrsRNAi_2cellstage_noDC_t0000.tif']
        [baseDir filesep 'SPD2-GFP5_RNAires(cterm2)_SPD5-Alexa597_XFP_10hrsRNAi_2cellstage_noDC\SPD2-GFP5_RNAires(cterm2)_SPD5-Alexa597_XFP_10hrsRNAi_2cellstage_noDC_t0000.tif']
        [baseDir filesep 'SPD2-GFP6_RNAires(cterm2)_SPD5-Alexa597_XFP_10hrsRNAi_2cellstage_noDC\SPD2-GFP6_RNAires(cterm2)_SPD5-Alexa597_XFP_10hrsRNAi_2cellstage_noDC_t0000.tif']
        };
end

if(nargin < 2)
    numWorkingDir = 1;
end

%profile on
%% skip filename ==> movie home directory is needed only
for i = 1 : length(movieDirList)
    fn = movieDirList{i};
    if(strEndsWith(fn, '.tif'))
        movieDirList{i} = fileparts(fn);
    end
end

%% check if all files exist
for i = 1 : length(movieDirList)
    if(~exist(movieDirList{i},'dir'))
        warning('directory %s not found',movieDirList{i});
    end
end

%% do the processing
fn_error    = [myTempDir filesep sprintf('error_%s.log',mfilename)];
for i = 1 : length(movieDirList)
    fprintf('movie dir = %s',movieDirList{i});
    try
        close all;
        movieDir_i = movieDirList{i};
        if(exist([movieDir_i filesep 'raw'], 'dir'))
            setDebugLevel(1);
            workingDir = main(movieDir_i,[], numWorkingDir);
        else
            PrintToFile(sprintf('%s: main not executed, because the image directory ''raw'' does not exist in %s',datestr(clock),movieDir_i),fn_error,[],1);
        end
    catch
        PrintToFile(sprintf('%s: main not successful for %s',datestr(clock),movieDir_i),fn_error,[],1);
        printDebugStack(lasterror,0,fn_error);
    end
end
% profile off
% profile viewer
% p = profile('info');
% profsave(p,'profile_results')
