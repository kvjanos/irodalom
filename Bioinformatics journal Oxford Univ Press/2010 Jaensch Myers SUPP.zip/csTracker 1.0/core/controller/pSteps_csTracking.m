function pSteps_csTracking(workingDir, fn_error)

if(~exist('fn_error', 'var'))
    fn_error = [myTempDir filesep 'error_' mfilename '.log'];
end

global param;
loadGlobalParams(workingDir);
setDebugLevel(1);

assignCellNames         = 1;
detectNEBD              = 1;
computeRefinedRadius    = 1;

skipIfFileoutExists     = 1;
%% object detection
%find spot-like objects
fn = FindCentrosomeCandidates_LoG2D_LocalMax3D(workingDir, [], skipIfFileoutExists);
fn = FilterIntersectingObjects_atSamePixelLocation(workingDir, fn, 'qualityColName', 'xcorr', skipIfFileoutExists);

%refine normXcorrelation score and remove clearly intersecting objects
fn = FittedModelCorrelation(workingDir, fn,'updatePosition2D',1,'maxXCorrScoreSearchRadius','byDetectionScale',skipIfFileoutExists);
fn = FilterIntersectingObjects_onSamePlane(workingDir, fn, skipIfFileoutExists);

%refine radius estimate by Gaussian fitting
if(~skipIfFileoutExists)
    deleteDirectoryIfExists([workingDir filesep 'debug\GaussianFitting2D_elliptical_singleGaussianRotated']);
end
fn = GaussianFitting2D_elliptical( workingDir, fn, skipIfFileoutExists);
fn = FindBrightestPlane( workingDir, fn, skipIfFileoutExists);
fn = GaussianFitting2D_elliptical( workingDir, fn, skipIfFileoutExists, 'skipPositiveSigmaXEntries',1);

%remove remaining intersecting objects
fn = FilterIntersectingObjects_atSamePixelLocation(workingDir, fn, 'qualityColName', 'gIntensityRatio', skipIfFileoutExists);
fn = FilterIntersectingObjects_anisotropicSpace3D(workingDir, fn, 'qualityColName', 'gIntensityRatio', skipIfFileoutExists);

%refine normXcorrelation on new locations
fn = FittedModelCorrelation(workingDir, fn,'updatePosition2D',0,'maxXCorrScoreSearchRadius',1,skipIfFileoutExists);

fn = ComputeIntensityRatio(workingDir, fn, skipIfFileoutExists);
fn = FilterSplodges(workingDir, fn, skipIfFileoutExists); %splodge = random bright spot visible only on a single plan, caused by a camera defect
fn = MarkOutsideEmbryoCandidates( workingDir, fn, skipIfFileoutExists );

fn = makeFinalCandidatesCopy(fn, skipIfFileoutExists);


%% object linking
skipIfFileoutExists = 0;
fn_candidates_for_extension = finalCandidatesFile();
fn = finalCandidatesFile();

if(~skipIfFileoutExists)
    delete([workingDir filesep 'MainTr*.*']);
    delete([workingDir filesep 'tracksComplete*.*']);
    delete([workingDir filesep '*timeplotOfTracks*.*']);
    delete([workingDir filesep 'finalTracking*.*']);
end

fn = ExtractMainTrajectories( workingDir, fn, [], [], skipIfFileoutExists );
if(~skipIfFileoutExists)
    deleteDirectoryIfExists([workingDir filesep 'debug' filesep 'extendTracks']);
end

[fn, fn_back, fn_forw] = extendTracksInBothDirections_ResolveBFConflicts(workingDir, fn, fn_candidates_for_extension, [], [], skipIfFileoutExists);
makeTrackingMovie(workingDir, fn, [], skipIfFileoutExists);

if(~skipIfFileoutExists)
    deleteDirectoryIfExists([workingDir filesep 'debug' filesep 'JoinTracks']);
end
fn = JoinTracks(workingDir, fn, skipIfFileoutExists);
makeTrackingMovie(workingDir, fn, [], skipIfFileoutExists);

fn = FilterTracksByLengthOnCompleteTracks(workingDir, fn, skipIfFileoutExists);

makeMovieWithInsets = 0;
showObjID           = 0;
delete([workingDir filesep 'trackComplete*.*']);
fn = makeCompleteTracksCopy(fn, skipIfFileoutExists, makeMovieWithInsets, showObjID);

%check track integrity
FindBrokenTracks(workingDir, fn, 'error');
FindMultipleTrackAssignments( workingDir, fn, {}, 'error')


%% post-processing on tracks

if(computeRefinedRadius)
    fn = EstimateCsRadiusFromGaussianFitAndRawData( workingDir, fn, skipIfFileoutExists);
end

if(assignCellNames)
    fn = pairsOfTracks(workingDir, fn, skipIfFileoutExists);
    fn = parentTrack(workingDir, fn, skipIfFileoutExists);
    
    try
        fn = AssignPosteriorAnterior(workingDir, fn, skipIfFileoutExists);
        fn = AssignCellnames(workingDir, fn, skipIfFileoutExists);
    catch ME
        if(strcmpi(ME.identifier, 'error:posteriorPositionNotAvailable'))
            warning('%s partially skipped for %s',mfilename,workingDir);
            PrintToFile(sprintf('%s: %s partially skipped for %s',datestr(clock),mfilename,workingDir),fn_error);
            printDebugStack(ME,0,fn_error);
        else
            rethrow(ME)
        end
    end
end


if(detectNEBD)
    makeTrackingMovie(workingDir, fn, [], skipIfFileoutExists);
    try
        fn = FindNEBD(workingDir, fn, skipIfFileoutExists, 'ignoreNEBDInfo');
        %         fn = FindNEBD(workingDir, fn, skipIfFileoutExists);
        makeTrackingMovie(workingDir, fn, [], skipIfFileoutExists);
    catch ME
        warning('%s partially skipped for %s',mfilename, workingDir);
        PrintToFile(sprintf('%s: %s partially skipped for %s',datestr(clock),mfilename,workingDir),fn_error);
        printDebugStack(ME,0,fn_error);
    end
end

makeFinalCopy( fn );

%% the end
close all
fprintf('processing finished for %s\n',param.tag);

end
