function [ list_firstFilenames, moreFilesPresent ] = readFirstFilenamesFile( movieCollectionDir )
%read the file 'firstFilenames.txt' in a movie collection directory
%return empty if 'firstFilenames.txt' does not exist
%
%output:  list_firstFilenames - file names in 'firstFilenames.txt'
%         moreFilesPresent    - indicates if there are other files (except
%                               'properties.xml') present in the directory

if(nargin == 0)
    movieCollectionDir = [baseDir filesep '_new set\dv SPD2-GFP XFP RNAi 1-cell notDeconvolved'];
end

deleteFileIfExists([movieCollectionDir filesep 'IJ_Prefs.txt'])
 

D = dir([movieCollectionDir filesep '*.*']);
isDir = valuesFromStructureArray(D, 'isdir', 1);
D = D(~isDir);
D_xml = dir([movieCollectionDir filesep 'properties.xml']);

N = length(D) - length(D_xml);

fn = [movieCollectionDir filesep 'firstFilenames.txt'];
if(~exist(fn,'file'))
    list_firstFilenames = {};
    moreFilesPresent = N > 0;
    return
end

moreFilesPresent = N > 1;
lines = readAllLinesFromTextfile(fn);
list_firstFilenames = cell(length(lines),1);

for i = 1 : length(lines)
    list_firstFilenames{i} = eval(lines{i});
end


end

