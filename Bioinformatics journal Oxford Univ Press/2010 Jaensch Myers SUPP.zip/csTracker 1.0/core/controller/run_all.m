function run_all( movieCollectionDir, dirOut )

try
    firstFilenames = MakeFoldersForMovies(movieCollectionDir, dirOut);
    listMovieDir   = prepareImageStack_batch(firstFilenames);
    main_batch(listMovieDir);
catch
    fn_error = [myTempDir filesep sprintf('error_%s.log',mfilename)];
    PrintToFile(sprintf('%s: run_all not successful for %s',datestr(clock),movieCollectionDir),fn_error);
    printDebugStack(lasterror,0,fn_error);
end

