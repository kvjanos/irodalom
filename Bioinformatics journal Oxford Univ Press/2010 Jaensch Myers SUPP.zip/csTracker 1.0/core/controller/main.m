function workingDir = main(movieDir, p, numWorkingDir, emptyWorkingDirIfExists, functionHandle_pSteps)
%   movieDir - home directory of a movie
%   p        - a structure with fields that will be set below to the global
%              variable 'param', param will first be initialized with
%              default values and then overwritten with the values specified in p
%   numWorkingDir - a (numeric) name for the working directory, e.g. numWorkingDir = 1
%                   if empty or unspecified, the next free working directory will be determined
%
%also see: main_postProcessing, main_batch


close all
global param
global pathHomeDir;

if(nargin < 2)
    p = [];
end
if(nargin < 3)
    numWorkingDir = [];
end
if(nargin < 4)
    emptyWorkingDirIfExists = 0;
end
if(nargin < 5)
    functionHandle_pSteps = [];
end

if(nargin==0)
    movieDir  =  [baseDir filesep 'SPD2-GFP1_yTUB-Alexa617_XFP_24hrsRNAi_2cellstage_deconvolved'];
    numWorkingDir = 1;
    setDebugLevel(1);
end

pathHomeDir = movieDir;
param = loadProperties();

%image stack properties
param.firstTimepoint  =   1;
param.lastTimepoint   =  -1; %set to -1 in order to set automatically to the last available time point

if(~isempty(p))
    fields = fieldnames(p);
    for i = 1 : length(fields)
        param.(fields{i}) = p.(fields{i});
    end
end

if(param.firstTimepoint ~= 1 || param.lastTimepoint   ~=  -1)
    warning('Not all time points are included in the analysis');
end

param.totalTimepointsCount = param.totalImageCount/param.zCount;
param.resolutionVector     = [param.resolution param.resolution param.zResolution];

%% check timepoint settings
if(param.firstTimepoint > param.lastTimepoint && param.lastTimepoint ~= -1 )
    error('first timepoint must be less than or equal to last timepoint');
end
if(param.lastTimepoint > param.totalTimepointsCount)
    error('last timepoint must be less than or equal to the total number of timepoints');
end

%% setting time points to process
if(param.lastTimepoint == -1) %set last time point automatically
    param.lastTimepoint = param.totalImageCount / param.zCount;
end
param.firstFrame = (param.firstTimepoint-1)*param.zCount+1;
param.lastFrame  = (param.lastTimepoint)*param.zCount;
param.totalImageCountToProcess = param.lastFrame - param.firstFrame + 1;

%% setting paths and output filenames
workingDirBase = [pathHomeDir filesep 'workingDir' filesep];

if(exist('numWorkingDir', 'var') && ~isempty(numWorkingDir))
    num = numWorkingDir;
else
    num = FindFreeWorkingDirNumber(workingDirBase);
end
workingDir = [workingDirBase sprintf('%d',num)];
if(exist(workingDir,'dir'))
    warning('Using existing workingDir: %s', workingDir);
    figWait = figure;
    h = uicontrol('Position',[20 20 200 40],'String','Continue',...
        'Callback','uiresume(gcbf)');
    disp('10 seconds to continue...');
    uiwait(gcf, 10);
    close(figWait);
end

param.relPathWorkingDir     = getChildPath(workingDir, pathHomeDir);
param.relPathDebug          = [param.relPathWorkingDir '\debug'];
param.relPathGlobalParams   = [param.relPathWorkingDir '\globalParams.xml'];
param.relPathCandidatesFile = [param.relPathWorkingDir '\candidates.txt'];
param.nextFreeObjID         = 1;

workingDirExists = exist(workingDir, 'dir');

if(workingDirExists)
    try
        loadGlobalParams(workingDir);
        globalParamsFileExists = 1;
    catch
        globalParamsFileExists = 0;
    end
else
    globalParamsFileExists = 0;
end

if(emptyWorkingDirIfExists)
    try
        ensureEmptyDirExists(workingDir);
        ensureEmptyDirExists(getFullPath(param.relPathDebug));
    catch
        ensureDirExists(workingDir);
        ensureDirExists(getFullPath(param.relPathDebug));
    end
    saveGlobalParams();
else
    ensureDirExists(workingDir);
    ensureDirExists(getFullPath(param.relPathDebug));
    if(~globalParamsFileExists)
        saveGlobalParams();
    end
end

try
    if(isempty(functionHandle_pSteps))
        main_postProcessing(workingDir, @pSteps_csTracking);
    else
        main_postProcessing(workingDir, functionHandle_pSteps);
    end
catch
    printDebugStack(lasterror);
end

end

function num = FindFreeWorkingDirNumber(workingDirBase)
num = 1;
while(1)
    workingDir = [workingDirBase sprintf('%d',num)];
    if(~exist(workingDir,'dir'))
        break;
    end
    num = num + 1;
end
end
