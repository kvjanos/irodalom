function main_postProcessing_batch( processingFunctionHandle, workingDirs,  processingStepsFunctionHandle )
%also see: main_postProcessing

fprintf('%s\n',mfilename);
if(nargin == 0 || isempty(processingFunctionHandle))
    processingFunctionHandle = @main_postProcessing;
end

if(nargin < 2)
    
    workingDirs = {};
   
end

close all
clearHistogram
setDebugLevel(1);
fn_success = [myTempDir filesep sprintf('succes_%s.log',mfilename)];

if(nargin >= 3 && ~ischar(processingStepsFunctionHandle))
    strFunc = func2str(processingStepsFunctionHandle);
else
    strFunc = func2str(processingFunctionHandle);
end

N = length( workingDirs);
for i = 1 : N
    try
        close all
        workingDir = workingDirs{i};
        if(nargin >= 3)
            processingFunctionHandle(workingDir,processingStepsFunctionHandle);
        else
            processingFunctionHandle(workingDir);
        end
        PrintToFile(sprintf('%s: "%s" successfully executed for %s',datestr(clock),strFunc,workingDir),fn_success);
        waitbar(i/N);
    catch
        printDebugStack(lasterror);
    end
end
waitbar();
showHistogram
