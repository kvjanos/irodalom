function [fn_final, fn_movie ] = makeFinalCopy( fn, makeTrackingMovies )
%see also: makeCompleteTracksCopy, makeFinalCandidatesCopy

if(nargin < 2)
    makeTrackingMovies = 1;
end
global param;

fn_final = [fileparts(fn) filesep finalTrackingFile];

if(~strcmpi(fn, fn_final))
    copyfile(fn, fn_final);
end

[T, header] = loadList(fn_final);
[T, header] = ComputeDerivedParameters(T, header);
fprintMatrix(fn_final, T, header);


if(makeTrackingMovies)
    if(strcmpi(param.fluorescentMarker, 'histone'))
        csRadius = 'csRadiusGaussianFitting';
        csRadius = 'fittedxcorrSigma';
    else
        csRadius = [];
    end
    workingDir = fileparts(fn_final);
    try
        timeplotOfTracks(workingDir, fn_final, 'figFile', '.');
    catch
        printDebugStack(lasterror);
    end
    
    fn_movie = makeTrackingMovie(workingDir, fn_final, [], 0, 'markerRadiusColName', csRadius, 'showEmbryoContour', 1);
    
end