function cstracker( movieDir )
fullpathMovieDir = [baseDir filesep movieDir];
run_all_fromHomeDir({fullpathMovieDir});
end

