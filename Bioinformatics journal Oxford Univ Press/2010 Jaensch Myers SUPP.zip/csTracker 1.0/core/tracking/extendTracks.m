function [ varargout ] = extendTracks( workingDir, filenameIn, filenameInAllCandidates, direction, objectsNotToBeRejected, objectsToBeRejected, forbiddenEdges, theoreticalMaxVelo3D, theoreticalMaxVelo2D, skipIfFileoutExists)
%
%input:
%filenameIn                 - the name of the file containing the tracks to be extended
%filenameInAllCandidates    - the name of the file containing the
%                             candidates including all candidates that are
%                             part of the given tracks
%objectsNotToBeRejected     - in any filtering, do not filter objects with these objectIDs
%objectsToBeRejected        - additionally filter all objects with these objectIDs
%
%also see: graphBasedTracking, extendTracksInBothDirections, extendTracksInBothDirections_ResolveBFConflicts

clearHistogram();
if(nargin == 0)
    direction = -1;
    workingDir = [baseDir filesep 'RSA1-GFP3_WT_8to16cellstage\workingDir\1'];
    filenameIn = 'MainTr.txt';
    
    filenameInAllCandidates = finalCandidatesFile();
    setDebugLevel(1);
end
if(direction < 0)
    opName = 'extTrBack';
else
    opName = 'extTrForw';
end
global param;

[filenameIn, filenameOut, dirDebug ] = initProcessingStep( workingDir, filenameIn, opName, mfilename );
filenameInAllCandidates              = addDirectoryToFilename(workingDir, filenameInAllCandidates);
if(exist('skipIfFileoutExists','var') && skipIfFileoutExists && exist(filenameOut, 'file'))
    varargout{1} = filenameOut;
    return
end

%% algorithm parameters
relativeDifferences             = 1; %use "(f1-f2) / min(f1,f2)" as appearance distance measure
weight_csAppearence             = .3;

maxVelocity3D = 250; %nm/sec
maxVelocity2D = 250; %nm/sec

strategyForRemovingRadiusHysteresisEdges    = 'beforeBipartiteMatching';  %'optimal', 'beforeBipartiteMatching', 'afterBipartiteMatching'
strategyForRemovingHighWeightEdges          = 'beforeBipartiteMatching'; % 'beforeBipartiteMatching', 'afterBipartiteMatching'

%reject                     - reject all candidates marked as being outside the embryo
%considerAsValidObjects     - consider candidates marked as being outside the embryo as valid candidates
strategyForOutsideEmbryoCandidates = 'reject'; % 'reject', 'considerAsValidObjects'

%accept extension of a track only if the bipartite matching of all matched targets
%with all sources (i.e. a reverse matching) is identical to the original match
requireIdenticalReverseMatch = 0;

%accept extension of a track only if the cost(original match) < factorReverseMatchBetterThanOriginalMatch*cost(reverse match)
%note that in this case the reverse match does not need to be identical with the original match
factorReverseMatchBetterThanOriginalMatch = 0;

%remove not only the forbidden edges from the bipartite graph but also all
%edges E emanating from the respective source vertex of a forbidden edge F with w(E) > w(F)
removeEdgesWithWeightGreaterThanForbiddenEdge = 0;

%backward tracking: a track with min size < 300 will not be extended with candidates > 350 nm
%forward tracking:  a track with max size > 350 will not be extended with candidates < 300 nm
radiusHysteresis                = param.ap.radiusHysteresis; %[300 350];
factorStddevEdgeWeightThreshold = 4; % mean edge weight + 4 times stddev of the matched edges in the main tracks


fprintf('%s\n',mfilename);
if(~exist('objectsNotToBeRejected', 'var'))
    objectsNotToBeRejected = [];
end
if(~exist('objectsToBeRejected', 'var'))
    objectsToBeRejected = [];
end
if(~exist('forbiddenEdges', 'var'))
    forbiddenEdges = [];
end
if(~exist('theoreticalMaxVelo3D', 'var'))
    theoreticalMaxVelo3D = [];
end
if(~exist('theoreticalMaxVelo2D', 'var'))
    theoreticalMaxVelo2D = [];
end

%reverse the object order for all backward edges (now we have objID1 = source
%and objID2 = target independend of the tracking direction)
if(~isempty(forbiddenEdges))
    ix = forbiddenEdges(:,3) < 0;
    forbiddenEdges(ix,1:2) = forbiddenEdges(ix,[2,1]);
end

if(~isempty(objectsToBeRejected) && size(objectsToBeRejected, 2) == 2)
    objectsToBeRejected = objectsToBeRejected(objectsToBeRejected(:,2) == direction, 1);
end

[T_tracks, header_tracks]   = loadList(filenameIn); %the tracks to be extended
[T_tracks, header_tracks ]  = ComputeDerivedParameters( T_tracks, header_tracks ); %includes velocity, spindle properties
objIDColIdx_tracks          = headerIndex(header_tracks, 'objID');
trIDColIdx_tracks           = headerIndex(header_tracks, 'trID');
trDirectionColIdx_tracks    = headerIndex(header_tracks, 'trDirection','none');

[T, header] = loadList(filenameInAllCandidates);
[T, header] = ComputeDerivedParameters( T, header ); %includes velocity, spindle properties
[header, trIDColIdx, columnHasBeenAdded, T ] = addHeaderEntry( header, 'trID', -1, T );
objIDColIdx                 = headerIndex(header, 'objID');
radiusColName               = 'meanSigmaXY2D';
meanSigmaXY2DColIdx         = headerIndex(header, radiusColName);

%% compute mean and standard deviation for change of centrosome properties from the main tracks
csAppearanceParameters          = {'meanSigmaXY2D','totalInt2D'};
csAppearanceWeights             = ones(length(csAppearanceParameters),1) / (length(csAppearanceParameters));
cs_appearanceParameters_colIdx  = headerIndex(header, csAppearanceParameters);

[csAppearanceChange_mean, csAppearanceChange_stddev, differencesAppearance]     = MeanAndStdDev_CSDynamics_FromTracks(T_tracks, header_tracks, csAppearanceParameters,relativeDifferences );
[meanDiffPos3D, stdDiffPos3D, differencesPos3D]                                 = MeanAndStdDev_CSDynamics_FromTracks(T_tracks, header_tracks, {'pos3D'} );

velo3D = T_tracks(:,headerIndex(header_tracks,'velo3D'));
velo3D = velo3D(velo3D > 0); % filter out 0-velocity (beginning of each track)
velo2D = T_tracks(:,headerIndex(header_tracks,'velo2D'));
velo2D = velo2D(velo2D > 0); % filter out 0-velocity (beginning of each track)

maxVelocity3D = repmat(maxVelocity3D, 1, param.lastTimepoint);
maxVelocity2D = repmat(maxVelocity2D, 1, param.lastTimepoint);

% maxVelocity3D = min(maxVelocity3D, multiplierActualMaxVelocity*max(velo3D));
% maxVelocity2D = min(maxVelocity2D, multiplierActualMaxVelocity*max(velo2D));

if(~isempty(theoreticalMaxVelo3D))
    maxVelocity3D = min(theoreticalMaxVelo3D, maxVelocity3D);
end
if(~isempty(theoreticalMaxVelo2D))
    maxVelocity2D = min(theoreticalMaxVelo2D, maxVelocity2D);
end

maxAllowedDistance3D = (maxVelocity3D * param.frameInterval);
maxAllowedDistance2D = (maxVelocity2D * param.frameInterval);

T(:,trIDColIdx)                     = -1;
[header, trDirectionColIdx]         = addHeaderEntry( header, 'trDirection');
T(:,trDirectionColIdx)              =  0;
[header, trLengthColIdx]            = addHeaderEntry( header, 'trLength' );
T(:,trLengthColIdx)                 =  0;

if(direction < 0)
    [header, zScoreTrColIdx]        = addHeaderEntry( header, 'zScoreBackTr' );
else
    [header, zScoreTrColIdx]        = addHeaderEntry( header, 'zScoreForwTr' );
end
T(:,zScoreTrColIdx)                 =  -1;
[header, matchingCostColIdx, wa, T] = addHeaderEntry( header, 'matchingCost', -1, T );




%% update track properties for each candidate which is already part of a track
for i = 1 : size(T_tracks,1)
    index = T(:,objIDColIdx) == T_tracks(i,objIDColIdx_tracks);
    T(index, trIDColIdx)                    = T_tracks(i,trIDColIdx_tracks);
    if(trDirectionColIdx_tracks>0)
        T(index, trDirectionColIdx)         = T_tracks(i,trDirectionColIdx_tracks);
    end
end

T = T(~ismember(T(:,objIDColIdx), objectsToBeRejected) | T(:,trIDColIdx) > 0 ,:); %when filtering make sure, to include all candidates that are already part of a track
objectsToBeRejectedButInMainTrack = objectsToBeRejected(ismember(objectsToBeRejected, T(T(:,trIDColIdx) > 0, objIDColIdx)));
if(~isempty(objectsToBeRejectedButInMainTrack))
    error('there are objects to be rejected that occur in the main tracks. tracking direction = %d',direction);
end

if(strcmpi(strategyForOutsideEmbryoCandidates,'reject'));
    outsideEmbryoFlagColIdx = headerIndex(header, 'outsideEmbryoFlag', 'warning');
    if(outsideEmbryoFlagColIdx > 0)
        T = T(T(:,outsideEmbryoFlagColIdx) == 0 | T(:,trIDColIdx) > 0,:); %when filtering make sure, to include all candidates that are already part of a track
    end
elseif(strcmpi(strategyForOutsideEmbryoCandidates,'considerAsValidObjects'));
else
    error('unknown option for strategyForOutsideEmbryoCandidates: %s',strategyForOutsideEmbryoCandidates);
end

try
    filenameDebug = [dirDebug filesep 'params_' getFilenameWithoutExtension(filenameOut) '.txt'];
    fnDebug = [dirDebug filesep 'info_' getFilenameWithoutExtension(filenameOut) '.txt'];
    fnDebugPS = [dirDebug filesep 'info_' getFilenameWithoutExtension(filenameOut) '.ps'];
    fprintDebugInfo(filenameDebug, sprintf('maxVelocity3D = %f\nmaxVelocity2D = %f\nmaxAllowedDistance3D = %f\nmaxAllowedDistance2D = %f',maxVelocity3D,maxVelocity2D,maxAllowedDistance3D,maxAllowedDistance2D));
    deleteFileIfExists(fnDebugPS);
    if(getDebugLevel>=2)
        fig1=figure;
    end
catch
end

N = size(T,1)
DAG                             = {};
DAG_edgeWeightsForThresholding  = {};
DAG_CoreEdges                   = {};

T = sortrows(T, [4, trIDColIdx]); %sort by time and trID
tChangeIndices = computeTchangeIndices(T);

timeToIndices = {}; %for each frame a 2-element vector with the first and the last index into T (T must be sorted by time)
for i = 1 : size(tChangeIndices,1)
    time = T(tChangeIndices(i,1),4);
    timeToIndices{time} = [tChangeIndices(i,1),tChangeIndices(i,2)];
end

FindMultipleTrackAssignments(T,header);

%% build the DAG
frameCount = length(timeToIndices);
matchingCosts_mainTracks = [];

for i = 1 : frameCount-1
    if(isempty(timeToIndices{i}) || isempty(timeToIndices{i+1}))
        G                                   = [];
        G_edgeWeightsForThresholding        = [];
        G_CoreEdges                         = [];
    else
        A = timeToIndices{i}(1)   : timeToIndices{i}(2);
        B = timeToIndices{i+1}(1) : timeToIndices{i+1}(2);
        G                               = zeros(length(A), length(B));
        G_CoreEdges                     = zeros(length(A), length(B));
        G_edgeWeightsForThresholding    = zeros(length(A), length(B));
        
        for a = 1 : length(A)
            h = A(a);
            trID_h = T(h,trIDColIdx);
            for b = 1 : length(B)
                k = B(b);
                trID_k = T(k,trIDColIdx);
                %                 dist3D_zHalfWeighted = RealDistance(T(h,1:3),T(k,1:3),.5);
                dist3D = RealDistance(T(h,1:3),T(k,1:3));
                dist2D = RealDistance(T(h,1:2),T(k,1:2));
                G_CoreEdges(a,b) = trID_h > 0 && trID_h == trID_k;
                %allow only edges that are ok with the distance in 3D AND in 2D
                %but make sure for each pair of vertices with the same trackID there will be an edge
                if(dist3D <= maxAllowedDistance3D(i) && dist2D <= maxAllowedDistance2D(i) || G_CoreEdges(a,b))
                    G(a,b) = computeEdgeWeight(h,k);
                    if(~G_CoreEdges(a,b)) %not in same main track
                        G_edgeWeightsForThresholding(a,b) = G(a,b);
                    else %in same main track
                        G_edgeWeightsForThresholding(a,b) = 0;
                        T(h, matchingCostColIdx) = G(a,b);
                        matchingCosts_mainTracks = [matchingCosts_mainTracks G(a,b)];
                    end
                else
                    G(a,b) = inf;
                end
                
            end
        end
    end
    DAG{i}                              = G;
    DAG_edgeWeightsForThresholding{i}   = G_edgeWeightsForThresholding;
    DAG_CoreEdges{i}                    = G_CoreEdges;
end
mean_MatchingCost_mainTracks    = mean(matchingCosts_mainTracks);
stddev_MatchingCost_mainTracks  = std(matchingCosts_mainTracks);
maxThresholdingEdgeWeight       = (mean_MatchingCost_mainTracks + factorStddevEdgeWeightThreshold*stddev_MatchingCost_mainTracks);

labelsAll  = cell(1,size(T,1));
for ii = 1 : size(T,1)
    labelsAll{ii} = sprintf('obj%d (idx%d)\n(tr%d)', T(ii,objIDColIdx),ii, T(ii,trIDColIdx));
end

DAG = makeEdgeWeightsPositive(DAG); %zeros can cause problems! however, no negative edge weights are to be expected


%% do the frame-to-frame matching in the specified direction
GlobalMatchingGraph = TrackingByBipartiteMatching(DAG,direction);

T = ComputeTrackLengths(T, trIDColIdx, trLengthColIdx);
T = T(T(:,trIDColIdx) > 0,:);
FindBrokenTracks( T, header );
if(nargout <= 1 || nargout == 3)
    fprintMatrix(filenameOut,T,header);
    varargout{1} = filenameOut;
    if(nargout == 3)
        varargout{2} = T;
        varargout{3} = header;
    end
else
    varargout{1} = T;
    varargout{2} = header;
end
if(nargin == 0)
    %    showTrackingMovie(filenameOut,0,'insets');
    showTrackingMovie(filenameOut,0);
end

% showHistogram(myTempDir());
close all


    function [w, wp, wa] = computeEdgeWeight(h,k)
        %h must be the earlier timepoint!
        
        csAppearanceDistances                   = (T(k,cs_appearanceParameters_colIdx)-T(h,cs_appearanceParameters_colIdx)); %it must be later timepoint - earlier point, not vice versa!!! compare with how 'diff' computes differences
        if(relativeDifferences)
            csAppearanceDistances               = csAppearanceDistances ./ min(T(k,cs_appearanceParameters_colIdx),T(h,cs_appearanceParameters_colIdx));
        end
        
        csAppearanceDistances_normalized        = (csAppearanceDistances - csAppearanceChange_mean) ./ csAppearanceChange_stddev;
        wa                                      = abs(csAppearanceDistances_normalized) * csAppearanceWeights;
        
        csPositionDistance                      = RealDistance(T(k,1:3),T(h,1:3));
        %wp                                     = abs((csPositionDistance-meanDiffPos3D) / stdDiffPos3D);
        wp                                      = csPositionDistance / stdDiffPos3D;
        
        if(weight_csAppearence == 0)
            w = RealDistance(T(h,1:3),T(k,1:3));
        else
            w = (1-weight_csAppearence)*wp + weight_csAppearence * wa;
        end
        
        %% debugging info
        if(getDebugLevel() >= 2)
            distParameters = {'x','y','z'};
            distParametersColIdx = [1 2 3];
            allParameters       = [distParameters       csAppearanceParameters];
            allParametersColIdx = [distParametersColIdx cs_appearanceParameters_colIdx];
            for idx = [h,k]
                fprintf('t=%03d\tobjID: %05d',T(idx,4), T(idx,objIDColIdx));
                for c = 1 : length(allParameters)
                    fprintf('\t%s = %.6f',allParameters{c}, T(idx,allParametersColIdx(c)));
                end
                fprintf('\n');
            end
            
            %         for c = 1 : length(distParameters)
            %             fprintf('%s:\t%05d --> %05d = %.3f\n',distParameters{c},T(h,objIDColIdx),T(k,objIDColIdx), csPositionDistances_normalized(c));
            %         end
            fprintf('csPositionDistance (non-normalized):\t%05d --> %05d = %.3f\n\n',T(h,objIDColIdx),T(k,objIDColIdx), csPositionDistance);
            fprintf('position distance:\t%05d --> %05d = %.3f\n\n',T(h,objIDColIdx),T(k,objIDColIdx), wp);
            
            for c = 1 : length(csAppearanceParameters)
                fprintf('%s:\t%05d --> %05d = %.3f\n',csAppearanceParameters{c},T(h,objIDColIdx),T(k,objIDColIdx), csAppearanceDistances_normalized(c));
            end
            fprintf('appearance distance:\t%05d --> %05d = %.3f\n\n',T(h,objIDColIdx),T(k,objIDColIdx), wa);
            fprintf('combined distance:\t%05d --> %05d = %.3f\n\n',T(h,objIDColIdx),T(k,objIDColIdx), w);
            
            dist3D = RealDistance(T(h,1:3),T(k,1:3),1);
            dist2D = RealDistance(T(h,1:2),T(k,1:2),1);
            fprintf('dist3D:\t%05d --> %05d = %.3f\n',T(h,objIDColIdx),T(k,objIDColIdx), dist3D);
            fprintf('dist2D:\t%05d --> %05d = %.3f\n',T(h,objIDColIdx),T(k,objIDColIdx), dist2D);
            fprintf('------------------------------------------------\n');
            
            
        end
    end

    function analyzeEdgeWeights(objID_h, objID_k)
        %objID_h needs to be in the frame before objID_k (signed differences!)
        h = find(T(:,objIDColIdx) == objID_h);
        k = find(T(:,objIDColIdx) == objID_k);
        computeEdgeWeight(h,k);
    end

    function showEdgeWeightComputation
        %debug-level must be set to >= 2
        %first objID must be at the earlier timepoint!
        analyzeEdgeWeights(10097,10258);
        analyzeEdgeWeights(10206,10258);
    end
    function checkUniqueTrID(trIDs, type, time1, time2)
        trIDs = trIDs(trIDs>0);
        if(~isempty(trIDs))
            [unique_trIDs,trIDs_count] = countOccurrences(trIDs(trIDs>0));
            multiTrID = unique_trIDs(trIDs_count>1);
            if(~isempty(multiTrID))
                fprintf('the following %s trIDs occur multiple times at frame %d -> %d',type, time1, time2);
                fprintf('%d',multiTrID);
                error('%s trIDs occur multiple times at frame %d -> %d',type, time1, time2);
            end
        end
    end

    function M = TrackingByBipartiteMatching(DAG_WeightMatrix, direction)
        M = {};
        
        frameCount = length(timeToIndices);
        
        %do the linking on a frame by frame basis
        if(direction > 0)
            frames = 1 : frameCount-1;
        else
            frames = frameCount-1 : -1 : 1;
        end
        
        % terms:
        % time1, time2  the tracking direction is always time1 --> time2
        %               for forward tracking this means time1 + 1 = time2 and for
        %               backward tracking time1 - 1 = time2
        % source:       a vertex in the bipartite graph on the side which
        %               has been tracked in the previous iteration, non-free
        %               source is a source for which a target with the same
        %               trID exists
        % target:       a vertex in the bipartite graph on the other side
        %               targets may already be assigned a track ID (non-free
        %               targets, trID > 0)
        % source track: the track with the trackID of a source up to the
        %               current time point (time1)
        for i = frames
            G = DAG_WeightMatrix{i};
            if(isempty(G))
                continue;
            end
            G_edgeWeightsForThresholding = DAG_edgeWeightsForThresholding{i};
            G_coreEdges                  = DAG_CoreEdges{i};
            if(direction > 0) %forward
                allSources = timeToIndices{i}(1)   : timeToIndices{i}(2);
                allTargets = timeToIndices{i+1}(1) : timeToIndices{i+1}(2);
            else  %backward
                G                            = G';
                G_coreEdges                  = G_coreEdges';
                G_edgeWeightsForThresholding = G_edgeWeightsForThresholding';
                allTargets = timeToIndices{i}(1)   : timeToIndices{i}(2);
                allSources = timeToIndices{i+1}(1) : timeToIndices{i+1}(2);
            end
            time1 = T(allSources(1),4);
            time2 = T(allTargets(1),4);
            
            %check that no trackID occurs more than ones
            checkUniqueTrID(T(allSources, trIDColIdx), 'sources', time1, time2)
            checkUniqueTrID(T(allSources, trIDColIdx), 'targets', time1, time2)
            
            %remove all free sources (they would start new tracks)
            G_all = G;
            allSources_all = allSources;
            allTargets_all = allTargets;
            
            idxFreeSources = T(allSources, trIDColIdx) <= 0;
            allSources = allSources(~idxFreeSources);
            G(idxFreeSources, :)                            = [];
            G_edgeWeightsForThresholding(idxFreeSources, :) = [];
            G_coreEdges(idxFreeSources, :)                  = [];
            
            showGraph(G,'initial graph')
            
            %remove forbidden edges
            if(~isempty(forbiddenEdges))
                %column format: [objID1, objID2, trDirection, matchingCost]
                for s = 1 : length(allSources)
                    maxMatchingCostForThisSource = inf;
                    objID_s = T(allSources(s), objIDColIdx);
                    for t = 1 : length(allTargets)
                        if(G(s,t) < inf)
                            objID_t = T(allTargets(t), objIDColIdx);
                            for e = 1 : size(forbiddenEdges,1)
                                objID1 = forbiddenEdges(e, 1);
                                objID2 = forbiddenEdges(e, 2);
                                
                                if(objID1 == objID_s && objID2 == objID_t)
                                    maxMatchingCostForThisSource = G(s,t);
                                    %remove the forbidden edge
                                    G(s,t) = inf;
                                    break
                                end
                            end
                        end
                    end
                    
                    %also remove all edges emanating from this source with
                    %edge weight greater than the weight of the forbidden edge
                    if(removeEdgesWithWeightGreaterThanForbiddenEdge && maxMatchingCostForThisSource < inf)
                        for t = 1 : length(allTargets)
                            if(G(s,t) < inf && G(s,t) > maxMatchingCostForThisSource)
                                G(s,t) = inf;
                                objID_t = T(allTargets(t), objIDColIdx);
                            end
                        end
                    end
                end
                showGraph(G,'forbidden edges removed')
            end
            
            F_radiusHys         = zeros(size(G));
            F_weightAboveThr    = zeros(size(G));
            
            %find radius hysteresis edges and edges with
            %weight greater than the threshold
            for s = 1 : length(allSources)
                %get the minimum (backward) / maximum (forward) radius in the source track
                idxSource   = allSources(s);
                trIDSource  = T(idxSource, trIDColIdx);
                
                sourceFullfilsRadiusHys = 0;
                if(direction < 0) %backward
                    R = T(T(:,trIDColIdx) == trIDSource & T(:,4) >= time1,:);
                    minCSRadiusSourceTrack = min(R(:,meanSigmaXY2DColIdx));
                    if(minCSRadiusSourceTrack < radiusHysteresis(1))
                        sourceFullfilsRadiusHys = 1;
                    end
                else %forward
                    R = T(T(:,trIDColIdx) == trIDSource & T(:,4) <= time1,:);
                    maxCSRadiusSourceTrack = max(R(:,meanSigmaXY2DColIdx));
                    if(maxCSRadiusSourceTrack > radiusHysteresis(2))
                        sourceFullfilsRadiusHys = 1;
                    end
                end
                
                for t = 1 : length(allTargets)
                    if(G(s,t) < inf)
                        %check radius hysteresis
                        if(sourceFullfilsRadiusHys)
                            idxTarget       = allTargets(t);
                            radiusTarget    = T(idxTarget, meanSigmaXY2DColIdx);
                            if(direction < 0 && radiusTarget > radiusHysteresis(2) || ... %backward
                                    direction > 0 && radiusTarget < radiusHysteresis(1))       %forward
                                F_radiusHys(s,t) = 1;
                            end
                        end
                        
                        %check egde weight
                        if(G_edgeWeightsForThresholding(s,t) > maxThresholdingEdgeWeight)
                            F_weightAboveThr(s,t) = 1;
                        end
                    end
                end
            end
            
            if(strcmpi(strategyForRemovingHighWeightEdges,'beforeBipartiteMatching'))
                %delete all edges whose weight is greater than a threshold
                G(F_weightAboveThr==1) = inf;
                showGraph(G,sprintf('edges with edge weight exceeding threshold (=%f) removed',maxThresholdingEdgeWeight));
            end
            
            if(strcmpi(strategyForRemovingRadiusHysteresisEdges, 'beforeBipartiteMatching'))
                G(F_radiusHys==1) = inf;
                showGraph(G,'edges that violate the radius hysteresis removed');
            end
            
            if(strcmpi(strategyForRemovingRadiusHysteresisEdges,'optimal'))
                ForbiddenEdges  = F_radiusHys;
            else
                ForbiddenEdges  = zeros(size(G));
            end
            allMatches      = {}; %for debugging info only
            
            itCounter       = 1;
            while(1)
                forbiddenEdgesAdded = 0;
                PrintToFile(sprintf('%d ==> %d',time1, time2), fnDebug);
                showGraph(G, 'before matching')
                
                %determine the non-free sources
                nonFreeSource2CanonicalTarget = []; %two colums: non-free source:corresponding target
                for s = 1 : length(allSources)
                    trID_source = T(allSources(s),trIDColIdx);
                    t = find(T(allTargets,trIDColIdx)==trID_source);
                    if(~isempty(t))
                        if(length(t)>1)
                            error('more than one target with trID %d found at t: %d ==> %d',trID_source, time1, time2);
                        end
                        nonFreeSource2CanonicalTarget(end+1,:) = [s,t];
                    end
                end
                
                if(strcmpi(strategyForRemovingRadiusHysteresisEdges,'optimal') || forbiddenEdgesAdded)
                    %compute a minimum sum distance matching that includes
                    %no forbidden edges (i.e., no radius hysteresis edges)
                    BipartiteMatching = OptBipartiteMatchingWithoutForbiddenEdges(G,ForbiddenEdges);
                else
                    %compute a minimum sum distance matching using the Hungarian algorithm
                    BipartiteMatching = Hungarian2(G);
                end
                showMatching(BipartiteMatching, 'initial matching');
                
                if(strcmpi(strategyForRemovingHighWeightEdges,'afterBipartiteMatching'))
                    %delete all matches whose weight is greater than a threshold
                    
                    %%without debugging we can use this shorter code:
                    %BipartiteMatching(F_weightAboveThr) = 0;
                    
                    %%with debugging info:
                    %-----------
                    for s = 1 : length(allSources)
                        t = find(BipartiteMatching(s,:),1);
                        if(~isempty(t) && F_weightAboveThr(s,t))
                            BipartiteMatching(s,t) = 0;
                            objID_s = T(allSources(s), objIDColIdx);
                            objID_t = T(allTargets(t), objIDColIdx);
                        end
                    end
                    %-----------
                    
                    showMatching(BipartiteMatching, 'matches whose weight is greater than a threshold deleted');
                end
                
                
                if(strcmpi(strategyForRemovingRadiusHysteresisEdges,'afterBipartiteMatching'))
                    %delete all matches that violate the radius hysteresis
                    
                    %%without debugging we can use this shorter code:
                    %BipartiteMatching(F_radiusHys) = 0;
                    
                    %%with debugging info:
                    %-----------
                    for s = 1 : length(allSources)
                        t = find(BipartiteMatching(s,:),1);
                        if(~isempty(t) && F_radiusHys(s,t))
                            BipartiteMatching(s,t) = 0;
                            objID_s = T(allSources(s), objIDColIdx);
                            objID_t = T(allTargets(t), objIDColIdx);
                        end
                    end
                    %-----------
                    
                    showMatching(BipartiteMatching, 'matches that violate the radius hysteresis deleted');
                end
                
                %ensure that all non-free targets are matched if there is a source with the same trackID
                somethingChanged = 1;
                while(somethingChanged)
                    somethingChanged = 0;
                    for j = 1 : size(nonFreeSource2CanonicalTarget,1)
                        t = nonFreeSource2CanonicalTarget(j,2);
                        %is the non-free target not matched to any source?
                        s = find(BipartiteMatching(:,t),1);
                        if(isempty(s))
                            %what is the canonical source of t?
                            s1 = nonFreeSource2CanonicalTarget(j,1);
                            %what is the target t1 of s1?
                            t1 = find(BipartiteMatching(s1,:),1); %t1 maybe or may not be empty
                            BipartiteMatching(s1,t1) = 0;
                            BipartiteMatching(s1,t)  = 1;
                            somethingChanged = 1;
                        end
                    end
                end
                showMatching(BipartiteMatching, 'enforce match for all non-free targets that have source with same trackID');
                
                %ensure that all sources are matched for which a target with the same trackID exists
                somethingChanged = 1;
                while(somethingChanged)
                    somethingChanged = 0;
                    for j = 1 : size(nonFreeSource2CanonicalTarget,1)
                        s = nonFreeSource2CanonicalTarget(j,1);
                        %is the source not matched to any target?
                        t = find(BipartiteMatching(s,:),1);
                        if(isempty(t))
                            %what is the canonical target of s?
                            t1 = nonFreeSource2CanonicalTarget(j,2);
                            %what is the source of t1?
                            s1 = find(BipartiteMatching(:,t1),1); %s1 may or may not be empty
                            BipartiteMatching(s1,t1) = 0;
                            BipartiteMatching(s,t1)  = 1;
                            somethingChanged = 1;
                        end
                    end
                end
                showMatching(BipartiteMatching, 'enforce match for all sources that have target with same trackID');
                
                %delete all matches where source and target trackID are different
                %and the target trackID is not among the sources
                %(i.e. tracks that crash into the begin/end of a track in the next/previos frame )
                for s = 1 : length(allSources)
                    %is there a matched target?
                    t = find(BipartiteMatching(s,:),1);
                    if(~isempty(t))
                        trIDSource = T(allSources(s),trIDColIdx);
                        trIDTarget = T(allTargets(t),trIDColIdx);
                        %is the target not free and in another track than the source?
                        if(trIDTarget > 0 && trIDTarget ~= trIDSource)
                            %is the target trackID not among the sources?
                            s1 = find(T(allSources, trIDColIdx) == trIDTarget, 1);
                            if(isempty(s1))
                                BipartiteMatching(s,t) = 0;
                            end
                            
                        end
                    end
                end
                showMatching(BipartiteMatching, 'delete matches with different trackIDs where targetID is not among the sources');
                
                %determine which sources reach a free target (possibly over other vertices)
                sourceReachesFreeTarget = reaches_freeTarget(BipartiteMatching, T(allSources,trIDColIdx), T(allTargets,trIDColIdx));
                
                %swap matches between different trIDs
                for u = 1 : size(nonFreeSource2CanonicalTarget,1)-1
                    su = nonFreeSource2CanonicalTarget(u,1);
                    tu = nonFreeSource2CanonicalTarget(u,2);
                    
                    for v = u+1 : size(nonFreeSource2CanonicalTarget,1)
                        sv = nonFreeSource2CanonicalTarget(v,1);
                        tv = nonFreeSource2CanonicalTarget(v,2);
                        
                        %leave matches between different trIDs alone if
                        %both sources reach a free target (possibly over other vertices)
                        if(sourceReachesFreeTarget(su) && sourceReachesFreeTarget(sv))
                            continue;
                        end
                        
                        if(BipartiteMatching(su,tv))
                            BipartiteMatching(su,: ) = 0;
                            BipartiteMatching(: ,tu) = 0;
                            BipartiteMatching(su,tu) = 1;
                        end
                        if(BipartiteMatching(sv,tu))
                            BipartiteMatching(sv,tu) = 0;
                            BipartiteMatching(sv,: ) = 0;
                            BipartiteMatching(: ,tv) = 0;
                            BipartiteMatching(sv,tv) = 1;
                        end
                    end
                end
                showMatching(BipartiteMatching, 'swap matches between different trIDs');
                
                if(requireIdenticalReverseMatch || factorReverseMatchBetterThanOriginalMatch > 0)
                    %check matching in the other direction
                    %if the reserve matches is not the same as the original, delete the original match
                    allMatchedTargets       = allTargets(sum(BipartiteMatching, 1)==1);
                    allMatchedTargetsObjIDs = T(allMatchedTargets, objIDColIdx);
                    allTargets_allObjIDs    = T(allTargets_all, objIDColIdx);
                    
                    ix_matched = ismember(allTargets_allObjIDs, allMatchedTargetsObjIDs);
                    allTargets_all_matched  = allTargets_all(ix_matched);
                    allTargets_all_matchedObjIDs = T(allTargets_all_matched, objIDColIdx);
                    
                    %G_rev contains on the target side all objects that
                    %are matched in 'BipartiteMatching' and all objects on the source side (including the free sources
                    %that were removed before bipartite matching)
                    G_rev = G_all(:,ix_matched);
                    showGraph(G_rev, 'reverse graph', allSources_all, allTargets_all_matched, []);
                    
                    BipartiteMatching_rev = Hungarian2(G_rev);
                    showMatching(BipartiteMatching_rev, 'reverse matching',allSources_all, allTargets_all_matched, []);
                    
                    for s = 1 : length(allSources)
                        t = find(BipartiteMatching(s,:),1);
                        if(~isempty(t))
                            objID_s = T(allSources(s),objIDColIdx);
                            objID_t = T(allTargets(t),objIDColIdx);
                            
                            % the source to which t is matched in the reverse matching
                            t_all_matched = find(allTargets_all_matchedObjIDs == objID_t); %t and t_all refer to the same object!!!
                            if(isempty(t_all_matched) || T(allTargets_all_matched(t_all_matched),objIDColIdx) ~= objID_t)
                                time1
                                direction
                                error('corresponding target not found in allTargets_all_matched')
                            end
                            s_rev = find(BipartiteMatching_rev(:,t_all_matched),1);
                            if(isempty(s_rev))
                                objID_s_rev = -1;
                            else
                                objID_s_rev = T(allSources_all(s_rev),objIDColIdx);
                            end
                            
                            matchingCost_original    = G(s,t);
                            matchingCost_reverseBest = G_rev(s_rev,t_all_matched);
                            
                            %is the reserve matching different or much more expensive?
                            if(~G_coreEdges(s,t) && ...
                                    (objID_s_rev < 0 || (objID_s ~= objID_s_rev && ...
                                    (requireIdenticalReverseMatch==1 || matchingCost_original > factorReverseMatchBetterThanOriginalMatch*matchingCost_reverseBest))))
 
                                %mark the edge as forbidden
                                if(ForbiddenEdges(s,t) == 1)
                                    reason = debugInfo__.numReasonToReason{ForbiddenEdges(s,t)};
                                    error('(t=%d,objID=%d) ==(%f)==> (t=%d,objID=%d) is already marked as forbidden: %s',time1,objID_s,G(s,t),time2,objID_t, reason);
                                else
                                    if(objID_s_rev < 0)
                                        ForbiddenEdges(s,t) = 2;
                                    else
                                        ForbiddenEdges(s,t) = 3;
                                    end
                                    forbiddenEdgesAdded = 1;
                                    
                                    reason = debugInfo__.numReasonToReason{ForbiddenEdges(s,t)};
                                end
                            end
                        end
                    end
                    %showMatching(BipartiteMatching, 'matching graph after reserve matching');
                end
                                
                if(~forbiddenEdgesAdded)
                    break
                end
                
                itCounter = itCounter + 1;
            end
            
            %consistency check: search for non-unique matches
            if(any(sum(BipartiteMatching,1)>1))
                error('A target has been matched multiple times at time %d --> %d',time1,time2);
            end
            if(any(sum(BipartiteMatching,2)>1))
                error('A source has been matched multiple times at time %d --> %d',time1,time2);
            end
            
            newTrackIDPropagation = {};
            %update tracks
            for s = 1 : length(allSources)
                t = find(BipartiteMatching(s,:),1);
                if(~isempty(t))
                    idxSource = allSources(s);
                    idxTarget = allTargets(t);
                    
                    %is there a target with the same trackID as the source?
                    t1 = find(T(allTargets,trIDColIdx)==T(idxSource, trIDColIdx));
                    if(~isempty(t1))
                        %what is the source of t1?
                        s1 = find(BipartiteMatching(:,t1),1);
                        %is t1 unmatched?
                        if(isempty(s1))
                            error('%s, %d ==> %d, canonical target with objID %d has not been matched',param.tag,time1,time2,T(allTargets(t1),objIDColIdx));
                            
                            %%free the target with the same trackID as the source
                            %T(allTargets(t1),trIDColIdx)= -1;
                        end
                    end
                    
                    if(T(idxTarget,trIDColIdx) ~= T(idxSource,trIDColIdx)) %update only if vertex is not already part of the source track
                        oldTrID = T(idxTarget,trIDColIdx);
                        T(idxTarget,trIDColIdx)             = T(idxSource,trIDColIdx);
                        T(idxTarget,trDirectionColIdx)      = direction;
                        newTrID = T(idxTarget,trIDColIdx);
                        
                        if(oldTrID > 0)
                            %source matched to non-free target with different trackID
                            %==> propagate the new trackID
                            %[accumulate the propagation events and apply as a batch thereafter
                            %(necessary to correctly handle track-ID reassignments
                            % where more than one track is involved!!!)]
                            if(direction > 0) %forward
                                trIDPropagation.ix = T(:,4) > time2 & T(:,trIDColIdx)==oldTrID;
                            else  %backward
                                trIDPropagation.ix = T(:,4) < time2 & T(:,trIDColIdx)==oldTrID;
                            end
                            trIDPropagation.newTrID = newTrID;
                            newTrackIDPropagation{end+1} = trIDPropagation;
                        end
                    end
                    if(direction > 0) %forward
                        T(idxSource,zScoreTrColIdx)     = G_edgeWeightsForThresholding(s,t);
                        T(idxSource,matchingCostColIdx) = G(s,t);
                    else  %backward
                        T(idxTarget,zScoreTrColIdx)     = G_edgeWeightsForThresholding(s,t);
                        T(idxTarget,matchingCostColIdx) = G(s,t);
                    end
                    
                end
            end
            
            for kk = 1 : length(newTrackIDPropagation)
                trIDPropagation = newTrackIDPropagation{kk};
                T(trIDPropagation.ix, trIDColIdx)        = trIDPropagation.newTrID;
                %                 T(trIDPropagation.ix, trDirectionColIdx) = direction;
            end
            
            if(direction > 0) %forward
                M{i} = BipartiteMatching;
            else  %backward
                M{i} = BipartiteMatching';
            end
        end
        
        
        
        function showMatching(M, titleTxt, this_allSources, this_allTargets, this_ambiguousTargets)
            if(getDebugLevel() >= 2)
                if(nargin < 3)
                    M_ = G_edgeWeightsForThresholding;
                    M_(M == 0) = inf;
                    showGraph(M_,sprintf('matching graph\nedge weights = modified z-score (max allowed score = %.2f)\n%s', maxThresholdingEdgeWeight,titleTxt));
                else
                    M_ = M;
                    M_(M == 0) = inf;
                    showGraph(M_,sprintf('matching graph\nedge weights = modified z-score (max allowed score = %.2f)\n%s', maxThresholdingEdgeWeight,titleTxt),this_allSources, this_allTargets, this_ambiguousTargets);
                end
            end
        end
        function showGraph(Graph, titleTxt, this_allSources, this_allTargets, this_ambiguousTargets)
            if(getDebugLevel() >= 2)
                if(nargin < 3)
                    this_allSources = allSources;
                    this_allTargets = allTargets;
                    this_ambiguousTargets = []; %ambiguousTargets;
                end
                
                fig1=sfigure;maximize(fig1);
                labelsSources = cell(length(this_allSources),1);
                labelsTargets = cell(length(this_allTargets),1);
                for ii = 1 : length(this_allSources)
                    labelsSources{ii} = sprintf('%d(trID=%d)', T(this_allSources(ii),objIDColIdx),T(this_allSources(ii),trIDColIdx));
                end
                for ii = 1 : length(this_allTargets)
                    if(exist('this_ambiguousTargets','var'))
                        if(ismember(ii,this_ambiguousTargets))
                            extraText = '!';
                        else
                            extraText = '';
                        end
                    else
                        extraText = '';
                    end
                    labelsTargets{ii} = sprintf('%d%s(trID=%d)', T(this_allTargets(ii),objIDColIdx),extraText, T(this_allTargets(ii),trIDColIdx));
                end
                drawBipartiteGraph(Graph, inf, labelsSources, labelsTargets);
                title(sprintf('t: %d ==> %d\n%s',time1, time2, titleTxt));
                printFigureToPostScript(fig1,fnDebugPS, 1);
            end
        end
    end

end %of main function

function b = reaches_freeTarget(M, sourceTrIDs, targetTrIDs)
b = zeros(length(sourceTrIDs),1);
for s = 1 : length(sourceTrIDs)
    b(s) = reaches_freeTarget_singleSource(M, s, sourceTrIDs, targetTrIDs);
end
end
function b = reaches_freeTarget_singleSource(M, s, sourceTrIDs, targetTrIDs)
sourcesVisited = [];
while(1)
    sourcesVisited = [sourcesVisited s];
    t = find(M(s,:),1);
    if(isempty(t))
        b = 0; break;
    else
        targetTrID = targetTrIDs(t);
        if(targetTrID <= 0)
            b = 1; break;
        else
            s = find(sourceTrIDs == targetTrID, 1);
            if(isempty(s))
                b = 0; break;
            end
            if(any(sourcesVisited==s))
                b = 0; break;
            end
            
        end
    end
    
end


end