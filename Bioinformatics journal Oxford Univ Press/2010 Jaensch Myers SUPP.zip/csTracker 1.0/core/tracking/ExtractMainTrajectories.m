function [ filenameOut] = ExtractMainTrajectories( workingDir, filenameIn, objectsNotToBeRejected, objectsToBeRejected, skipIfFileoutExists )

global param;
[filenameIn, filenameOut ] = initProcessingStep( workingDir, filenameIn, '>MainTr', mfilename ); %the '>' symbol means: start new filename instead of appending the op-name

if(exist('skipIfFileoutExists','var') && skipIfFileoutExists && exist(filenameOut, 'file'))
    return
end

theoreticalMaxVelo3D = [];
theoreticalMaxVelo2D = [];
doSecondRunWithMaxVelocityDependingOnCentrosomeNumber = 0;

skipIfFileoutExists  = 0;
%% first run with scalar max velocity
fn = graphBasedTracking( workingDir, filenameIn, objectsNotToBeRejected, objectsToBeRejected, theoreticalMaxVelo3D, theoreticalMaxVelo2D, skipIfFileoutExists);
fn2 = fn;
fn  = [workingDir filesep 'MainTrRaw1.txt'];
copyfile(fn2, fn, 'f')
delete(fn2);
makeTrackingMovie(workingDir, fn, [], skipIfFileoutExists);

fn = FilterNoiseTracks( workingDir, fn, skipIfFileoutExists);

%% second run with max velocity for each time point
if(doSecondRunWithMaxVelocityDependingOnCentrosomeNumber)
    movefile_fast([workingDir filesep 'debug' filesep 'graphBasedTracking'],[workingDir filesep 'debug' filesep 'graphBasedTracking_constMaxVelo']);
    movefile_fast([workingDir filesep 'debug' filesep 'FilterNoiseTracks'],[workingDir filesep 'debug' filesep 'FilterNoiseTracks_constMaxVelo']);
    makeTrackingMovie(workingDir, fn, [], skipIfFileoutExists);
    
    fnStub_debugFigures = getFullPath([param.relPathDebug filesep 'TheoreticalMaxVelocity'], 'theoreticalMaxVelo');
    [theoreticalMaxVelo3D, theoreticalMaxVelo2D] = TheoreticalMaxVelocity( workingDir, fn, fnStub_debugFigures );
    
    fn = graphBasedTracking( workingDir, filenameIn, objectsNotToBeRejected, objectsToBeRejected, theoreticalMaxVelo3D, theoreticalMaxVelo2D, skipIfFileoutExists);
    fn2 = fn;
    fn  = [workingDir filesep 'MainTrRaw2.txt'];
    copyfile(fn2, fn, 'f')
    delete(fn2);
    makeTrackingMovie(workingDir, fn, [], skipIfFileoutExists);
    
    fn = FilterNoiseTracks( workingDir, fn, skipIfFileoutExists);
end

fn2 = fn;
fn  = filenameOut;
copyfile(fn2, fn, 'f')

makeTrackingMovie(workingDir, fn, [], skipIfFileoutExists);
end