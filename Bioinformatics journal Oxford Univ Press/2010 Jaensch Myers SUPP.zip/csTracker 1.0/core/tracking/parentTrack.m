function [ filenameOut ] = parentTrack( workingDir, filenameIn, skipIfFileoutExists)
%finds for pairs of tracks their (common) parent track
%
%method:
%let pos_t1(i) be the spatial position of a centrosome i in its first frame with frame# t1
%let pos_tN(i) be the spatial position of a centrosome i in its last  frame with frame# tN
%
%determine spatial positions of parent and child tracks to compute distances
%and match childs to parents using greedy matching
%1. position of parent track pos = pN(p)
%2. position of child tracks a and b (with same cellID)
%                   = pos_t1(a)                  IF  t1(a) < t1(b)
%                   = pos_t1(b)                  IF  t1(a) > t1(b)
%                   = mean(pos_t1(a),pos_t1(b))  IF  t1(a) = t1(b)

%maximum time between disappearance of parent centrosome and apperance of child centrosome
maxGapTime = 15; %minutes

%maximum time where parent centrosome and child centrosomes appear together
maxOverlapTime = 3; %minutes

%remarks: -  a child track may start before the end of its parent track, but a
%            parent track must always start before its child track starts
%         -  calls ComputeTreeDepth at the end of this functions


fprintf('%s\n',mfilename);
if(nargin == 0)
    workingDir = [baseDir filesep 'yTUB-GFP1_WT_8cellstage\workingDir\9'];
    filenameIn = 'tracksComplete_pairs.txt';

    workingDir = [baseDir filesep 'SPD2-GFP3_T233A_T232S_12hrsRNAi\workingDir\1'];
    filenameIn = 'MainTr_extTrNoBFC_joinTr_pairs.txt';

    workingDir = [baseDir filesep 'yTUB-GFP24_WT_1to8cellstage\workingDir\8'];
    filenameIn = 'tracksComplete_pairs.txt';
    
    setDebugLevel(2)
end

global param;
[filenameIn, filenameOut, debugDir ] = initProcessingStep( workingDir, filenameIn, 'trTree', mfilename);
if(exist('skipIfFileoutExists','var') && skipIfFileoutExists && exist(filenameOut, 'file'))
    return
end

[T, header] = loadList(filenameIn);
[T, header] = ComputeDerivedParameters(T, header);
internalFrameNoColIdx   = headerIndex(header, 'internalFrameNo');
cellIDColIdx            = headerIndex(header, 'cellID');
trIDColIdx              = headerIndex(header,'trID' );
meanSigmaXY2DColIdx     = headerIndex(header,'meanSigmaXY2D' );

[header, parentTrIDColIdx] = addHeaderEntry(header, 'parentTrID');


T = sortrows(T,[trIDColIdx,4]);
T_all = T;
T_all(:, parentTrIDColIdx) = -1;
T = T(T(:,cellIDColIdx) > 0,:);

minCellDevDurationInFrames = param.bio.minCellDevDuration * 60 / param.frameInterval;
radiusHysteresis           = param.ap.radiusHysteresis; %[300 350];

if(~isempty(T))
    firstFrameCellID    = AggregateXGroups(T(:,cellIDColIdx),T(:,4), @min); %1st col: cellID, 2nd col: frame# (t)
    lastFrameCellID     = AggregateXGroups(T(:,cellIDColIdx),T(:,4), @max); %1st col: cellID, 2nd col: frame# (t)
    
    %filter all partial tracks at the beginning of the movie
    for i = 1 : size(firstFrameCellID,1)
        cellID = firstFrameCellID(i,1);
        t1   = firstFrameCellID(i,2);
        tN   = lastFrameCellID(i,2);
        
        %initial radius
        R    = T(T(:,cellIDColIdx) == cellID & T(:,internalFrameNoColIdx) <= 2, :);
        r1   = min(R(:,meanSigmaXY2DColIdx));

        if(t1 == 1 && tN - t1 < minCellDevDurationInFrames && r1 > radiusHysteresis(1))
            %check whether any other centrosomes start shortly after (or before) this pair 
            % ==> if not assume it is P0 and don't filter
            t1_allOthers = min(T_all(T_all(:,cellIDColIdx) ~= cellID,4));
            
            if(isempty(t1_allOthers) || t1_allOthers - t1 > 2/3*minCellDevDurationInFrames)
                %don't filter
            else
                T(T(:,cellIDColIdx) == cellID,:) = [];
            end
        end
    end
    
    
    if(~isempty(T))
        firstFrameTrID      = AggregateXGroups(T(:,trIDColIdx),T(:,4), @min); %1st col: trID, 2nd col: frame# (t)
        lastFrameTrID       = AggregateXGroups(T(:,trIDColIdx),T(:,4), @max); %1st col: trID, 2nd col: frame# (t)
        firstFrameCellID    = AggregateXGroups(T(:,cellIDColIdx),T(:,4), @min); %1st col: cellID, 2nd col: frame# (t)
                 
        G = zeros(size(firstFrameCellID,1), size(lastFrameTrID,1));
        maxGapFrames = maxGapTime * 60 / param.frameInterval;
        maxOverlapFrames= maxOverlapTime * 60 / param.frameInterval;
        for i = 1 : size(firstFrameCellID,1)
            child_cellID    = firstFrameCellID(i,1);
            child_rowIndex  = T(:,cellIDColIdx) == child_cellID;
            child_trIDs     = T(child_rowIndex, trIDColIdx);
            child_t1        = firstFrameCellID(i,2); % = min(t1(chil1),t1(child2))
            child_pos       = T(T(:,4) == child_t1 & child_rowIndex,1:3);
            
            %child pos has either 1 or 2 rows, depending on whether two
            %corresponding centrosomes appear at the same frame or not ==> use mean
            %position in case they appear at the same frame
            child_pos    = mean(child_pos,1);

            for j = 1 : size(lastFrameTrID,1)
                parent_trID    = lastFrameTrID(j,1);
                parent_tN      = lastFrameTrID(j,2);
                parent_t1      = firstFrameTrID(j,2);
                parent_pos = T(T(:,4) == parent_tN & T(:,trIDColIdx) == parent_trID,1:3);
                
                dist2D_parent_child =  RealDistance(child_pos(1:2),parent_pos(1:2));
                max_dist2D_parent_child = maxParentChildDistance2D(max(parent_tN,child_t1));
                if(~ismember(parent_trID, child_trIDs) && ...
                        child_t1 - parent_tN <= maxGapFrames && ...        %max time gap between parent and child
                        parent_t1 < child_t1 && ...                        %parent must start before child
                        parent_tN - child_t1 <= maxOverlapFrames && ...    %max overlap between parent and child
                        parent_tN - child_t1 < child_t1 - parent_t1 && ... %overlap must be shorter than part of parent that does not overlap
                        dist2D_parent_child <= max_dist2D_parent_child)    %max distance 2D (automatically estimated)
                    
                    G(i,j) = RealDistance(child_pos,parent_pos);
                else
                    G(i,j) = inf;
                end
            end
        end
        
%         M = GreedyBipartiteMatching(G);
        M = Hungarian2(G);
        
        for i = 1 : size(M,1)
            cellID = firstFrameCellID(i,1);
            j = find(M(i,:),1);
            if(isempty(j))
                parentTrID = 0;
            else
                parentTrID = lastFrameTrID(j,1);
            end
            T_all(T_all(:,cellIDColIdx) == cellID, parentTrIDColIdx) = parentTrID;
        end
        if(getDebugLevel >= 1)
            fig1 = sfigure;
            subplot(1,2,1), drawBipartiteGraph(G,inf,firstFrameCellID(:,1),lastFrameTrID(:,1));
            subplot(1,2,2), drawBipartiteGraph(M,0,firstFrameCellID(:,1),lastFrameTrID(:,1));
            saveas_debug(fig1, [debugDir filesep 'matching_graph.fig'], 1);
            if(getDebugLevel < 2)
                close(fig1);
            end
        end
    end
end

[T_all, header] = ComputeTreeDepth(T_all, header);
fprintMatrix(filenameOut, T_all, header);
if(nargin == 0)
    showTrackingMovie(filenameOut,0)
    timeplotOfTracks(filenameOut);
end

% --- nested function -------------
    function maxDist2D = maxParentChildDistance2D(t)
        %computes a reasonable maximum 2D-distance between a parent and a child
        %centrosome as the embryo length divided by the number of cells
        %
        %the number of cells is estimated as half the maximum number of centrosomes
        %tracked simultaneously at any time point up to timepoint t
        
        embryoDiagonal2D = norm(param.embryoDimension(1:2))*1000; %nanometer
        
        %find maximum number of centrosomes up to timepoint t
        [uniqueT, counts] = countOccurrences(T(T(:,4) <= t,4));
        
        numCells = max(counts)/2;
        maxDist2D = 2 * embryoDiagonal2D / numCells;
    end

end