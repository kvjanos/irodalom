function [ T, header ] = ComputeDistanceToNearestCS( T, header, flag_ignoreObject, distanceDimension )
aHugeDistance = 999999; %replacement for infinity, 50 micron is appr. length of embryo

if(distanceDimension == 2)
    distToNearestObjColName = 'dist2DToNearestObj';
elseif(distanceDimension == 3)
    distToNearestObjColName = 'dist3DToNearestObj';
else
    error('distanceDimension must be 2 or 3');
end
[header, distToNearestObjColIdx, wa, T]  = addHeaderEntry(header, distToNearestObjColName, aHugeDistance, T);

if(distanceDimension == 2)
    clusterColumns = {'z','t'};
else
    clusterColumns = {'t'};
end

T = [T flag_ignoreObject(:)]; %last column is flag_ignoreObject
E = clusterTable(T, headerIndex(header, clusterColumns));


T = [];
for i = 1 : length(E)
    R = E{i};
    flag_ignoreObject = R(:,end);
    ixInclude = find(~flag_ignoreObject);
    
    R = R(:,1:end-1);
    D = computeDistanceMatrix(R, aHugeDistance);
    if(isempty(ixInclude))
        R(:, distToNearestObjColIdx) = repmat(aHugeDistance,size(R,1),1);
    else
        R(:, distToNearestObjColIdx) = min(D(:,ixInclude),[],2);
    end
    T = [T;R];
end
end

function [D] = computeDistanceMatrix(R, aHugeDistance)
    n = size(R,1);
    D = ones(n,n)*aHugeDistance;
    for i = 1 : n-1
        for j = i+1 : n
            D(i,j) = RealDistance(R(i,1:3), R(j,1:3));
            D(j,i) = D(i,j);
        end
    end
end