function [ varargout ] = JoinTracks( varargin )
%searches for pairs of tracks with lastFrame(track1)+1 = firstFrame(track2)
%and joins them if:
% - the joined track is not longer than the maximum cell division duration
% - the centrosome does not change more than the maximum change in any of the specified properties below
% - a track with max radius > 350 nm will not be joined with a track with min radius < 300 nm (radius hysteresis)
% - then also joins tracks that are clearly broken (too short, too large
%   initial radius) with less strict conditions

if(nargin == 0)
    workingDir   = [baseDir filesep 'SPD2-GFP1_WT_4to8cellstage\workingDir\8'];
    filenameIn  = 'MainTr_extTrNoBFC.txt';
    varargin{1} = workingDir;
    varargin{2} = filenameIn;
    setDebugLevel(1)
end
global param;
[T, header, filenameIn, filenameOut, dirDebug] = processInput(varargin, '*joinTr', mfilename);
if(isempty(T))
    varargout{1} = filenameOut;
    return;
end

maxTrackLength       = ceil(param.bio.maxCellDevDuration * 60 / param.frameInterval); %45 min
minFullTrackLength   = ceil(param.bio.minCellDevDuration * 60 / param.frameInterval); %10 min

maxDifferenceColumnnames                                     = {'meanSigmaXY2D','totalInt2D','pos3D','pos2D'};
maxDifferenceTolerance_allTracks                             = [     1               1         1.0     1.5];
maxDifferenceTolerance_forShortTracksNotAtTheMovieBorders    = [     2               2         2.0     2.0];
maxDifferenceTolerance_forRightTracksWithHugeInitialRadius   = [     2               2         2.0     2.0];

%a track with max radius > 350 nm will not be joined with a track with min radius < 300 nm
radiusHysteresis_allTracks                              = param.ap.radiusHysteresis; %[300 350];
radiusHysteresis_forShortTracksNotAtTheMovieBorders     = [250 500];
radiusHysteresis_forRightTracksWithHugeInitialRadius    = [250 500];
maxValidInitialRadius                                   = radiusHysteresis_allTracks(2);

    function [G, trIDs] = BuildGraph(T, maxDifferenceColumnnames, maxDifferenceValues, considerOnlyShortTracksNotAtTheMovieBorders, considerOnlyRightTracksWithHugeInitialRadius, roundCounter)
        if(considerOnlyShortTracksNotAtTheMovieBorders && considerOnlyRightTracksWithHugeInitialRadius)
            error('only one of the parameters "considerOnlyRightTracksWithHugeInitialRadius" and "considerOnlyRightTracksWithHugeInitialRadius" can be set to true');
        end
        firstFrameTrID       = AggregateXGroups(T(:,trIDColIdx),T(:,4), @min); %1st col: trID, 2nd col: frame# (t)
        lastFrameTrID        = AggregateXGroups(T(:,trIDColIdx),T(:,4), @max); %1st col: trID, 2nd col: frame# (t)
        
        trIDs = firstFrameTrID(:,1);
        
        
        %% check for possible joinings and build a bipartite graph with 3D-distance as edge weight
        G = ones(size(firstFrameTrID,1),size(firstFrameTrID,1))*inf; %graph of possible joinings
        
        for i = 1 : size(firstFrameTrID,1)
            trIDi = firstFrameTrID(i,1);
            ti = lastFrameTrID(i,2);
            for j = 1 : size(firstFrameTrID,1)
                trIDj = firstFrameTrID(j,1);
                tj = firstFrameTrID(j,2);
                if(ti+1 == tj)
                    Ri = T(T(:,trIDColIdx) == trIDi,:);
                    Rj = T(T(:,trIDColIdx) == trIDj,:);
                    leftTrackAtMovieStart = Ri(1,4) == 1;
                    rightTrackAtMovieEnd  = Rj(end,4) == Tmax;

                    if(isempty(Ri) || isempty(Rj))
                        continue;
                    end
                    if(considerOnlyShortTracksNotAtTheMovieBorders)
                        %at least one of the two tracks must be shorter
                        %than minFullTrackLength and not start at the first
                        %timepoint and not end at the last timepoint
                        if(~(size(Ri,1) < minFullTrackLength && firstFrameTrID(i,2)>1 && lastFrameTrID(i,2)<param.lastTimepoint || ...
                                size(Rj,1) < minFullTrackLength && firstFrameTrID(j,2)>1 && lastFrameTrID(j,2)<param.lastTimepoint))
                            continue;
                        end
                    end

                    if(considerOnlyRightTracksWithHugeInitialRadius)
                        %the radius at the first timepoint in the right
                        %track must be bigger than maxValidInitialRadius
                        if(~(Rj(1,meanSigmaXY2DColIdx) > maxValidInitialRadius))
                            continue;
                        end
                        txt_radius = sprintf('(initial radius (meanSigmaXY2D) = %.f nm)', Rj(1,meanSigmaXY2DColIdx));
                    else
                        txt_radius = '';
                    end

                    PrintToFile(sprintf('%d ==> %d %s?', trIDi, trIDj, txt_radius),fnDebug, 'a', 1); %1 - printToScreen
                    
                    if(size(Ri,1) + size(Rj,1) <= maxTrackLength) %is joined track shorter than max track length?
                        difference = ComputeRowDifference([Ri(end,:);Rj(1,:)],diffColIdx);
                        difference = abs(difference);
                        diffOk = 1;
                        for k = 1 : length(maxDifferenceColumnnames)
                            if(difference(k) > maxDifferenceValues(k))
                                PrintToFile(sprintf('  difference in %s is too big to join trID=%d and trID=%d, %f vs %f',maxDifferenceColumnnames{k}, trIDi, trIDj, difference(k), maxDifferenceValues(k)), fnDebug, 'a', 1); %1 - printToScreen
                                diffOk = 0;
                            end
                        end
                        
                        if(diffOk) %join trIDi and trIDj
                            txt_diffOk = 'differences ok: ';
                            for k = 1 : length(maxDifferenceColumnnames)
                                txt_diffOk = [txt_diffOk sprintf('%s: %f < %f, ',maxDifferenceColumnnames{k}, difference(k), maxDifferenceValues(k))];
                            end
                            txt_diffOk = txt_diffOk(1:end-2); %remove last comma
                            PrintToFile(sprintf('  %s', txt_diffOk), fnDebug, 'a', 1); %1 - printToScreen
                            
                            ix = T(:,trIDColIdx) == trIDi | T(:,trIDColIdx) == trIDj;
                            
                            R = T(ix, :);
                            R(:,trIDColIdx) = trIDi;
                            
                            maxCsRadius_i = max(Ri(:,meanSigmaXY2DColIdx));
                            minCsRadius_j = min(Rj(:,meanSigmaXY2DColIdx));
                                                      
                            corrcoef_radius   = corrcoef([R(:,4),R(:,meanSigmaXY2DColIdx)]); %time vs. radius
                            corrcoef_radius   = corrcoef_radius(end,1); %usually corrcoef_radius(end,1) means corrcoef_radius(2,1), however if there is only one value it indexes to corrcoef_radius(1,1)!
                            corrcoef_radiusRj = corrcoef([Rj(:,4),Rj(:,meanSigmaXY2DColIdx)]); %time vs. radius
                            corrcoef_radiusRj = corrcoef_radiusRj(end,1);
                            
                            radiusHysteresisOk = ~(maxCsRadius_i > radiusHysteresis(2) && minCsRadius_j < radiusHysteresis(1));
                            
                            tracksJoined = 0;

                            if(radiusHysteresisOk)
                                tracksJoined  =  1;
                                PrintToFile(sprintf('  radiusHysteresisOk: yes'), fnDebug, 'a', 1); %1 - printToScreen
                            else
                                txt_notFulfilled = sprintf('    radius hysteresis ([%d, %d])',radiusHysteresis(1), radiusHysteresis(2));
                                PrintToFile(sprintf('  the following conditions are not fulfilled:\n    %s',txt_notFulfilled), fnDebug, 'a', 1); %1 - printToScreen
                            end
                            
                            if(tracksJoined)
                                G(i,j) = RealDistance(Ri(end,1:3),Rj(1,1:3));
                            end
                            
                            if(getDebugLevel()>=2)
                                clf(fig1)
                                plot(R(:,4),R(:,meanSigmaXY2DColIdx),'k-o');
                                ylabel('meanSigmaXY2D');
                                hold on
                                yl = ylim;
                                plot([ti+.5 ti+.5],yl,'--', 'LineWidth', 2.0);
                                if(tracksJoined)
                                    txt = 'tracks joined*';
                                else
                                    txt = 'tracks not joined';
                                end
                                title(sprintf('%s\ntrIDi = %d, trIDj = %d\ncorrcoef(joined track) = %.2f,corrcoef(right track) = %.2f, round %d, %s\n* tracks that are marked as joined might actually not be joined if there is another possible joining for the left track', strrep(param.tag, '_', '\_'), trIDi, trIDj, corrcoef_radius,corrcoef_radiusRj,roundCounter, txt));
                                
                                saveas(fig1, [dirDebug filesep sprintf('round%d_csRadius_trIDi=%d_trIDj=%d.fig',roundCounter,trIDi,trIDj)]);
                                printFigureToPostScript(fig1, [dirDebug filesep 'JoinTracks.ps'], 1);
                            end
                        end
                    else
                        PrintToFile(sprintf('  joined track would be too long to join trID=%d and trID=%d', trIDi, trIDj), fnDebug, 'a', 1); %1 - printToScreen
                    end
                end
            end
        end
    end

    function [T, joiningCnt] = DoTheJoining(G, trIDs, T)
        %% match each track to the closest track it can be joined with (in most cases there is only one such track)
        PrintToFile(sprintf('\n\njoinings in this round:'),fnDebug, 'a', 1); %1 - printToScreen

        M = GreedyBipartiteMatching(G);
        joiningCnt = 0;
        for i = 1 : size(G,1)
            j = find(M(i,:),1);
            if(~isempty(j))
                trIDi = trIDs(i);
                trIDj = trIDs(j);
                PrintToFile(sprintf('\ttracks %d and %d', trIDi, trIDj),fnDebug, 'a', 1); %1 - printToScreen
                
                T(T(:,trIDColIdx) == trIDj, trIDColIdx) = trIDi;
                joiningCnt = joiningCnt+1;
                
                k = find(G(i,:) < inf);
                for p = 1 : length(k)
                    if(k(p) == j)
                        continue;
                    end
                    trIDj = trIDs(k(p),1);
                    PrintToFile(sprintf('       not joining tracks %d and %d, because join above is better', trIDi, trIDj),fnDebug, 'a', 1); %1 - printToScreen
                end
            end
        end
    end

    function JoinTracksIteratively(maxDifferenceValues, considerOnlyShortTracksNotAtTheMovieBorders, considerOnlyRightTracksWithHugeInitialRadius)
        PrintToFile(sprintf('radius hysteresis = [%s] nm', sprintVector(radiusHysteresis,',','%d')), fnDebug, 'a', 1); %1 - printToScreen
        roundCounter = 0;
        joiningCnt   = 1;
        while(joiningCnt>0) %repeat as long as at least one pair of tracks has been joined
            roundCounter = roundCounter + 1;
            PrintToFile('=====================================',fnDebug, 'a', 1); %1 - printToScreen
            
            [G, trIDs]      = BuildGraph(T, maxDifferenceColumnnames, maxDifferenceValues, considerOnlyShortTracksNotAtTheMovieBorders, considerOnlyRightTracksWithHugeInitialRadius, roundCounter);
            [T, joiningCnt] = DoTheJoining(G, trIDs, T);
        end
    end


try
    ensureEmptyDirExists(dirDebug)
catch
end
fnDebug = [dirDebug filesep 'joinInfo.txt'];

T = sortrows(T,4); %sort by time
Tmax = T(end,4);

if(getDebugLevel()>=1)
    fig1 = sfigure; maximize(fig1);
end

trIDColIdx          = headerIndex(header, 'trID');
meanSigmaXY2DColIdx = headerIndex(header, 'meanSigmaXY2D'); 
[T, header]         = ComputeDerivedParameters(T, header);

diffColIdx          = headerIndexSpecialPos(header, maxDifferenceColumnnames);
differenceAll       = abs(ComputeCSPropertiesDynamics(T, header, maxDifferenceColumnnames));

if(~isempty(differenceAll))
    maxDifferenceValues = max(differenceAll,[],1);
       
    PrintToFile(sprintf('minCellDevDuration = %f minutes', param.bio.minCellDevDuration), fnDebug, 'a', 1); %1 - printToScreen
    PrintToFile(sprintf('maxCellDevDuration = %f minutes', param.bio.maxCellDevDuration), fnDebug, 'a', 1); %1 - printToScreen
    PrintToFile(sprintf('maxDifferenceColumnnames = {%s}', strList2SeparatedString(maxDifferenceColumnnames, ',')), fnDebug, 'a', 1); %1 - printToScreen
    PrintToFile(sprintf('maxDifferenceValues = [%s]', sprintVector(maxDifferenceValues,',','%f')), fnDebug, 'a', 1); %1 - printToScreen
    PrintToFile(sprintf('maxDifferenceTolerance for AllTracks  = %s', sprintVector(maxDifferenceTolerance_allTracks,',','%.1f')), fnDebug, 'a', 1); %1 - printToScreen
    PrintToFile(sprintf('maxDifferenceTolerance for ShortTracksNotAtTheMovieBorders  = %s', sprintVector(maxDifferenceTolerance_forShortTracksNotAtTheMovieBorders,',','%.1f')), fnDebug, 'a', 1); %1 - printToScreen
    PrintToFile(sprintf('maxDifferenceTolerance for RightTracksWithHugeInitialRadius = %s\n\n', sprintVector(maxDifferenceTolerance_forRightTracksWithHugeInitialRadius,',','%.1f')), fnDebug, 'a', 1); %1 - printToScreen
  
    PrintToFile(sprintf('+++++++++++++ consider all tracks +++++++++++++\n'),fnDebug, 'a', 1); %1 - printToScreen
    considerOnlyShortTracksNotAtTheMovieBorders  = 0;
    considerOnlyRightTracksWithHugeInitialRadius = 0;
    radiusHysteresis                             = radiusHysteresis_allTracks;
    maxDifferenceValues_allTracks                = maxDifferenceValues .* maxDifferenceTolerance_allTracks;
    JoinTracksIteratively(maxDifferenceValues_allTracks, considerOnlyShortTracksNotAtTheMovieBorders, considerOnlyRightTracksWithHugeInitialRadius)
    
    PrintToFile(sprintf('\n\n+++++++++++++ consider only tracks shorter than the minimum centrosome cycle duration and not at the movie borders +++++++++++++\n'),fnDebug, 'a', 1); %1 - printToScreen
    considerOnlyShortTracksNotAtTheMovieBorders  = 1;
    considerOnlyRightTracksWithHugeInitialRadius = 0;
    radiusHysteresis                             = radiusHysteresis_forShortTracksNotAtTheMovieBorders;
    maxDifferenceValues_ShortTracksNotAtTheMovieBorders = maxDifferenceValues .* maxDifferenceTolerance_forShortTracksNotAtTheMovieBorders;
    JoinTracksIteratively(maxDifferenceValues_ShortTracksNotAtTheMovieBorders, considerOnlyShortTracksNotAtTheMovieBorders, considerOnlyRightTracksWithHugeInitialRadius)

    PrintToFile(sprintf('\n\n+++++++++++++ consider only tracks where initial radius (meanSigmaXY2D) in right track > %d nm +++++++++++++\n', maxValidInitialRadius),fnDebug, 'a', 1); %1 - printToScreen
    considerOnlyShortTracksNotAtTheMovieBorders  = 0;
    considerOnlyRightTracksWithHugeInitialRadius = 1;
    radiusHysteresis                             = radiusHysteresis_forRightTracksWithHugeInitialRadius;
    maxDifferenceValues_hugeInitialRadius = maxDifferenceValues .* maxDifferenceTolerance_forRightTracksWithHugeInitialRadius;
    JoinTracksIteratively(maxDifferenceValues_hugeInitialRadius, considerOnlyShortTracksNotAtTheMovieBorders, considerOnlyRightTracksWithHugeInitialRadius)
end

if(getDebugLevel() >= 1)
    close(fig1)
end
if(isempty(filenameOut))
    varargout{1} = T;
    varargout{2} = header;
else
    fprintMatrix(filenameOut, T, header);
    varargout{1} = filenameOut;
end

if(nargin == 0)
    showTrackingMovie(filenameOut,0)
end
end
