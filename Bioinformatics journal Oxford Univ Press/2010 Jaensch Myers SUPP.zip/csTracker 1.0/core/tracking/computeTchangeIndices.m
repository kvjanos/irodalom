function tChangeIndices = computeTchangeIndices(T)
  tChangeIndices = find(diff([0;T(:,4)]));
  tChangeIndices = [tChangeIndices [tChangeIndices(2:end)-1;size(T,1)]];
end