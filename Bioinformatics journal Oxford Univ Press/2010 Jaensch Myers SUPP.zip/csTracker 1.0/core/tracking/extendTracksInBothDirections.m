function [ filenameOut, fn_back, fn_forw, fn_main, conflictCount, forbiddenEdges] = extendTracksInBothDirections( workingDir, filenameInMainTracks, filenameInAllCandidates, objectsNotToBeRejected, objectsToBeRejected,forbiddenEdges,theoreticalMaxVelo3D, theoreticalMaxVelo2D, skipIfFileoutExists )
%filenameInMainTracks       - the name of the file containing the tracks to be extended
%filenameInAllCandidates    - the name of the file containing the
%                             candidates including all candidates that are
%                             part of the given tracks
%
%also see: graphBasedTracking, extendTracks, extendTracksInBothDirections_ResolveBFConflicts

if(nargin == 0)
    workingDir = [baseDir filesep 'SPD5-YFP2_multicell\workingDir\1'];
    workingDir = [baseDir filesep 'yTUB-GFP1_long2\workingDir\1'];
    workingDir = [baseDir filesep 'SPD5-YFP12_WT_multicell\workingDir\1'];
    workingDir = [baseDir filesep 'SPD2-GFP_WT_long2\workingDir\1'];
    workingDir = [baseDir filesep 'SPD5-YFP2_multicell\workingDir\1'];
    workingDir = [baseDir filesep 'SPD2-GFP_WT_long1\workingDir\1'];
    
    filenameInMainTracks  = 'tr_trSpltInc_noOvertr_noNoiseTr.txt'; 
    filenameInAllCandidates = finalCandidatesFile();
    
    setDebugLevel(1)
end

[filenameInMainTracks, filenameOut ] = initProcessingStep( workingDir, filenameInMainTracks, '*extTr', mfilename );
if(exist('skipIfFileoutExists','var') && skipIfFileoutExists && exist(filenameOut, 'file'))
    fn_back = [];
    fn_forw = [];
    return
end
if(~exist('objectsNotToBeRejected','var'))
    objectsNotToBeRejected = [];
end
if(~exist('objectsToBeRejected','var'))
    objectsToBeRejected = [];
end

if(~exist('theoreticalMaxVelo3D','var'))
    theoreticalMaxVelo3D = [];
end
if(~exist('theoreticalMaxVelo2D','var'))
    theoreticalMaxVelo2D = [];
end


global tmp_currentInputFilenames

if(~isempty(forbiddenEdges))
    forbiddenEdges_b = forbiddenEdges(forbiddenEdges(:,3) < 0,:);
else
    forbiddenEdges_b = [];
end
if(~isempty(forbiddenEdges))
    forbiddenEdges_f = forbiddenEdges(forbiddenEdges(:,3) > 0,:);
else
    forbiddenEdges_f = [];
end

clearHistogram()
[fn_back, T_back, header_back] = extendTracks(workingDir, filenameInMainTracks, filenameInAllCandidates, -1, objectsNotToBeRejected, objectsToBeRejected, forbiddenEdges_b, theoreticalMaxVelo3D, theoreticalMaxVelo2D);

%exhange edges modify the mains tracks ==> get the current main tracks from
%the backward extended tracking results instead of using the original main
%tracks
T_main = T_back(T_back(:,headerIndex(header_back, 'trDirection')) == 0,:); %note: T_main may have tracks with gaps!
T_main = AssignNewTrackIDsForTracksWithGaps( T_main, header_back );
fn_main_backExt = [workingDir filesep getFilenameWithoutExtension(fn_back) '_remainingMainTr.txt'];
fprintMatrix(fn_main_backExt,T_main, header_back);

clearHistogram()
[fn_forw, T_forw, header_forw]  = extendTracks(workingDir, fn_main_backExt, filenameInAllCandidates, +1, objectsNotToBeRejected, objectsToBeRejected, forbiddenEdges_f, theoreticalMaxVelo3D, theoreticalMaxVelo2D);

tmp_currentInputFilenames{1} = fn_back;
tmp_currentInputFilenames{2} = fn_forw;
[T_ext, header_ext, T_main, header_main, conflictCount, forbiddenEdges] = MergeBFTracks(T_back, header_back, T_forw, header_forw);
fprintMatrix(filenameOut, T_ext, header_ext);

fn_main = [workingDir filesep getFilenameWithoutExtension(filenameOut) '_mainTr.txt'];
fn_main = strReplaceMultipleOccurringSubstringByNumber( fn_main, '_extTr_mainTr');

fprintMatrix(fn_main, T_main, header_main);

if(nargin == 0)
    showTrackingMovie(filenameOut,0, 'insets');
    %showTrackingMovie(fn_back,0);
    %showTrackingMovie(fn_forw,0);
    
end

%% for debugging purposes only: save back- and forward extension results and
%% visualize them as tracking movies
% fn_back = [workingDir filesep getFilenameWithoutExtension(filenameInMainTracks) '_backExt.txt'];
% fn_forw = [workingDir filesep getFilenameWithoutExtension(filenameInMainTracks) '_forwExt.txt'];
% fprintMatrix(fn_back, T_back,header_back);
% fprintMatrix(fn_forw, T_forw,header_forw);
% showTrackingMovie(fn_back,0);
% showTrackingMovie(fn_forw,0);



