function [ fn_fig, fn_ps ] = timeplotOfTracks( varargin )
fprintf('%s\n',mfilename);
%                  timeplotOfTracks(filenameIn)
%                  timeplotOfTracks(workingDir, filenameIn)
%fn_fig          = timeplotOfTracks(filenameIn)
%[fn_fig, fn_ps] = timeplotOfTracks(workingDir, filenameIn)
%[fn_fig, fn_ps] = timeplotOfTracks(workingDir, filenameIn, param, value, ...)
%                  timeplotOfTracks(T, header)
%[fn_fig, fn_ps] = timeplotOfTracks(T, header, param, value, ...)

%
% params:
% psFile  - filename or '.' (=automatic filename)
% figFile - filename or '.' (=automatic filename)

if(nargin == 0)
    varargin{1} = [baseDir filesep 'yTUB-GFP1_long4\workingDir\1\tr_trSplt_noNoiseTr_extTr.txt'];
    varargin{1} = [baseDir filesep 'yTUB-GFP1_long5\workingDir\1\tr_trSplt_noNoiseTr_pairs_trTree_GFit3D_Seg_cName_NEBD_bgLevel.txt'];
    varargin{1} = [baseDir filesep 'yTUB-GFP1_WT_8cellstage\workingDir\1\tr_trSplt_noNoiseTr_extTr_noOvertr.txt'];
    varargin{1} = [baseDir filesep 'SPD2-GFP1_WT_8to16cellstage\workingDir\1\' completeTracksFile() ];
    varargin{1} = [baseDir filesep 'RSA1-GFP1_WT_8to16cellstage\workingDir\1\' 'tracksComplete_icfGFit2D_GFit3D_bgLevel_pairs_trTree.txt' ];
    varargin{1} = [baseDir filesep 'yTUB-GFP24_WT_1to8cellstage\workingDir\8\' 'tracksComplete_pairs_trTree_side_cName.txt' ];
end

[fn_ps, found, varargin]   = getVarargin(varargin, 'psFile', [], 1);  %1=remove entry
[fn_fig, found, varargin]  = getVarargin(varargin, 'figFile', [], 1); %1=remove entry

global param;
[T, header, filenameIn] = processInput(varargin);
T = sortrows(T,4); %sort by time

try
    [T, header] = ComputeTimeRelativeToNEBD(T, header);
catch
end

if(nargout>=1 && isempty(fn_fig))
    fn_fig = '.';
end
if(nargout>=2 && isempty(fn_ps))
    fn_ps = '.';
end


if(strcmp(fn_ps, '.'))
    if(isempty(filenameIn))
        fn_ps = makeFilenameUnique([myTempDir filesep sprintf('timeplotOfTracks_%s.ps',param.tag)]);
    else
        fn_ps = [fileparts(filenameIn) filesep 'timeplotOfTracks_' getFilenameWithoutExtension(filenameIn) '.ps'];
    end
end
if(strcmp(fn_fig, '.'))
    if(isempty(filenameIn))
        fn_fig = makeFilenameUnique([myTempDir filesep sprintf('timeplotOfTracks_%s.fig',param.tag)]);
    else
        fn_fig = [fileparts(filenameIn) filesep 'timeplotOfTracks_' getFilenameWithoutExtension(filenameIn) '.fig'];
    end
end

trIDColIdx          = headerIndex(header, 'trID');
NEBDColIdx          = headerIndex(header, 'NEBD', 'none');
normTimeColIdx      = headerIndex(header, 'normTime', 'none');
cellIDColIdx        = headerIndex(header, 'cellID', 'none');
treeDepthColIdx     = headerIndex(header, 'treeDepth', 'none');
parentTrIDColIdx    = headerIndex(header, 'parentTrID', 'none');
validColIdx         = headerIndex(header, 'valid', 'none');

if(cellIDColIdx > 0)
    T = sortrows(T,[cellIDColIdx,4]);
end

unique_TrIDs = uniquePreserveOrder(T(:,trIDColIdx));


fig1 = figure;
maximize(fig1);

y = 0;
colors = {'r','g','b','m','y',[.5 .5 1.0]};
trID2y = [];
max_t = max(T(:,4));
for i = 1 : length(unique_TrIDs)
    trID = unique_TrIDs(i);
    R = T(T(:,trIDColIdx)==trID,:);
    csIdentifier = getCentrosomeIdentifier(R(1,:), header, 'AlwaysAddTrID', 1, 'SideDimensionLength', 1, 'Separator', ', ');
    if(validColIdx>0)
        valid = unique(R(:,validColIdx));
        valid = valid(end);
    else
        valid = 1;
    end
    
    hold on
    y = y + 10;
    trID2y(end+1,:) = [trID y];
    t1 = R(1,4);
    t2 = R(end,4);
    if(treeDepthColIdx > 0)
        treeDepth = R(1,treeDepthColIdx);
        if(treeDepth < 0)
            treeDepth = 0;
        end
    else
        treeDepth = 0;
    end
    color = colors{mod(treeDepth, length(colors))+1};
    if(valid)
        lineStyle = '-';
    else
        lineStyle = ':';
    end
    plot([t1 t2],[y y],[lineStyle 'o'],'Color',color,'LineWidth',3);
    text(t1, y+3, sprintf('%s',csIdentifier));
    
    if(NEBDColIdx > 0)
        NEBD = unique(T(T(:,trIDColIdx) == trID, NEBDColIdx));
        plot(NEBD, y, 'dk', 'MarkerSize', 9,'LineWidth',2);
        t1NEBD = R(1,normTimeColIdx);
        t2NEBD = R(end,normTimeColIdx);
        text(t1, y, sprintf('%d sec',t1NEBD));
        text(t2, y, sprintf('%d sec',t2NEBD));
    end
    
end
if(max_t > 1)
    xlim([1, max_t]);
end
%% connect paired centrosomes by a small bar and display cellID
if(cellIDColIdx > 0)
    for i = 1 : size(trID2y,1)
        trIDi = trID2y(i,1);
        yi   =  trID2y(i,2);
        cellID = unique(T(T(:,trIDColIdx) == trIDi, cellIDColIdx));
        if(cellID <= 0)
            continue
        end
        trIDs = unique(T(T(:,cellIDColIdx) == cellID, trIDColIdx));
        trIDj = trIDs(trIDs ~= trIDi);
        if(isempty(trIDj))
            continue
        end
        j     = find(trID2y(:,1) == trIDj);
        yj    = trID2y(j,2);
        
        ti1 = min(T(T(:,trIDColIdx) == trIDi, 4));
        tiN = max(T(T(:,trIDColIdx) == trIDi, 4));
        tj1 = min(T(T(:,trIDColIdx) == trIDj, 4));
        tjN = max(T(T(:,trIDColIdx) == trIDj, 4));
        
        t1 = max(ti1,tj1);
        tN = min(tiN,tjN);
        t  = mean([t1,tN]);
        
        if(parentTrIDColIdx > 0)
            parentTrID = unique(T(T(:,cellIDColIdx) == cellID, parentTrIDColIdx));
        else
            parentTrID = -2;
        end
        plot([t t],[yi,yj],'k-','LineWidth',3)
        text(t,mean([yi,yj]),sprintf('cellID = %d --> %d',cellID, parentTrID));
        
    end
end
xlabel('frame #');
ylim([0, y+10]);
title(sprintf('%s: %s, %s',datestr(clock),strrep(param.tag,'_','\_'),strrep(getFilenameWithExtension(filenameIn),'_','\_')));
set(gca,'XGrid','on')
% set(gca,'XMinorGrid','on')
% set(gca,'XColor',[.7 .7 .7]);

if(~isempty(fn_ps))
    prepareFigureForPrint(fig1);
    print(sprintf('-f%d',fig1),'-dpsc2','-append', fn_ps);
end
if(~isempty(fn_fig))
    saveas(fig1, fn_fig);
end
