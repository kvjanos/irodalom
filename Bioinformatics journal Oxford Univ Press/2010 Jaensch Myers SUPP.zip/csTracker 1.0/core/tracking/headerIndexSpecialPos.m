function [ colIdx ] = headerIndexSpecialPos(header, colNames )
%see also: headerIndexSpecial, headerIndex, ComputeRowDifference

colIdx = headerIndexSpecial(header, colNames, 'pos2D', -98, 'pos3D', -99); 
