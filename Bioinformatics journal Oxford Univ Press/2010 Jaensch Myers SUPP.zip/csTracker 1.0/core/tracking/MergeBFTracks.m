function [ varargout ] = MergeBFTracks( varargin )
% merges the backward and forward extended trajectories into one solution
%
% syntax: [T_merged, header_merged, T_main, header_main, conflictCount, forbiddenEdges] = MergeBFTracks(Tb, headerb, Tf, headerf)
%         [filenameOut_merged,      filenameOut_main,    conflictCount, forbiddenEdges] = MergeBFTracks(fullPathFilenameIn_b, fullPathFilenameIn_f)
%         [filenameOut_merged,      filenameOut_main,    conflictCount, forbiddenEdges] = MergeBFTracks(directory, filenameIn_b, filenameIn_f)
%
% output: T_merged, header_merged / filenameOut_merged - merged backward/forward tracks
%         T_main, header_main / filenameOut_main       - remaining main tracks in the merged result
%         conflictCount           - number of conflicting edges that were
%                                   removed by the merging procedure
%         forbiddenEdges          - list of edges to be removed in the next tracking round
%                                   column format: [objID1, objID2, trDirection, matchingCost, t1]
%                                   (note: objID1 is at the earlier timepoint t1)
%
% see also: extendTracksInBothDirections, extendTracksInBothDirections_ResolveBFConflicts

preventCoreTrackJoinings = 1;
explicitlyRemoveRadiusHystersisEdges = ~preventCoreTrackJoinings;

global tmp_currentInputFilenames;
if(length(varargin) == 3)
    varargin{2} = addDirectoryToFilename(varargin{1}, varargin{2});
    varargin{3} = addDirectoryToFilename(varargin{1}, varargin{3});
    varargin(1) = [];
end

if(length(varargin) == 2)
    if(nargout > 4)
        error('wrong number of output arguments');
    end
    [T1, header1] = loadList(varargin{1});
    [T2, header2] = loadList(varargin{2});
    
    filenameOut_merged   = [getPathAndFilenameWithoutExtension(varargin{2}) '_merged.txt'];
    filenameOut_main     = [getPathAndFilenameWithoutExtension(varargin{2}) '_mergedMain.txt'];
    workingDir    = fileparts(varargin{1});
    loadGlobalParams(workingDir);
    
    tmp_currentInputFilenames = varargin(1:2);
elseif(length(varargin)==4)
    if(nargout ~= 6)
        error('wrong number of output arguments');
    end
    T1      = varargin{1};
    header1 = varargin{2};
    T2      = varargin{3};
    header2 = varargin{4};
else
    error('wrong number of input arguments');
end
global param;

FindMultipleTrackAssignments(T1,header1, {}, 'error');
FindBrokenTracks(T1, header1, 'error' );
FindMultipleTrackAssignments(T2,header2, {}, 'error');
FindBrokenTracks(T2, header2, 'error' );

radiusHysteresis = param.ap.radiusHysteresis; %[300 350];

Gb = BuildGraphAsEdgeListFromTrackingTable(T1, header1); %backward tracks
Gf = BuildGraphAsEdgeListFromTrackingTable(T2, header2); %forward tracks

%merge edges between the same objects (non-conflicting)
G = MergeEdgeLists(Gb,Gf); checkConsistency_edgeList(G);

%we now have tracks that may split or merge
%remove every such fork
[G, conflictCount, forbiddenEdges] = RemoveConflicts(G);  checkConsistency_edgeList(G);

[G_test, conflictCount_test] = RemoveConflicts(G);
if(conflictCount_test > 0)
    error('there are still conflicts in G');
end

if(conflictCount==0 && preventCoreTrackJoinings)
    G = RemoveCoreTrackJoiningEdges(G);  checkConsistency_edgeList(G);
end

[T, header] = BuildTrackingTableFromEdgeList(G,T1,header1,T2,header2);

G_main = G(G(:,4) == 0, :); %all core edges
[T_main, header_main] = BuildTrackingTableFromEdgeList(G_main,T1,header1,T2,header2);

if(explicitlyRemoveRadiusHystersisEdges)
    %remove radius hystersis edges (may have been introduced by the merging procedure)
    T = RemoveRadiusHystersisEdges(T, header, radiusHysteresis);
end

FindMultipleTrackAssignments(T,header,{},'error');
FindBrokenTracks(T, header, 'error');
FindMultipleTrackAssignments(T_main,header_main,{},'error');
FindBrokenTracks(T_main, header_main, 'error' );

if(nargout == 6)
    varargout{1} = T;
    varargout{2} = header;
    varargout{3} = T_main;
    varargout{4} = header_main;
    varargout{5} = conflictCount;
    varargout{6} = forbiddenEdges;
elseif(nargout == 4 || nargin == 0)
    fprintMatrix(filenameOut_merged,T,header);
    fprintMatrix(filenameOut_main,T_main,header_main);
    if(nargin == 0)
        showTrackingMovie(filenameOut_merged,0);
        showTrackingMovie(filenameOut_main,0);
    end
    
    varargout{1} = filenameOut_merged;
    varargout{2} = filenameOut_main;
    varargout{3} = conflictCount;
    varargout{4} = forbiddenEdges;
    
else
    error('wrong number of output arguments');
end
end

function [T, header] = BuildTrackingTableFromEdgeList(G, Tb, headerb, Tf, headerf)


P = getPathsFromEdgeList(G); %P is a list of edge index lists
H = [Tb;Tf];

T = [];
header = headerb;

trIDColIdx          = headerIndex(header, 'trID');
objIDColIdx         = headerIndex(header, 'objID');
trDirectionColIdx   = headerIndex(header, 'trDirection');
matchingCostColIdx  = headerIndex(header, 'matchingCost');

for i = 1 : length(P)
    edgeIndexSequence = P{i};
    edgeSequence      = G(edgeIndexSequence,:);
    trID = i;
    for j = 1 : size(edgeSequence,1)
        objID               = edgeSequence(j,1);
        matchingCost        = edgeSequence(j,3);
        edgeTrDirection     = edgeSequence(j,4);
        trDirection         = edgeSequence(j,5); %the vertex' tracking direction
        
        insertObject(objID, matchingCost, edgeTrDirection, trDirection, trID);
        
        %check if last edge in sequence is terminating, if not insert obj2 as well
        if(j == size(edgeSequence,1))
            objID2 = edgeSequence(j,2);
            if(objID2 > 0)
                insertObject(objID2, -1, edgeTrDirection, edgeTrDirection, trID);
            end
        end
    end
end

    function insertObject(objID, matchingCost, edgeTrDirection, trDirection, trID)
        ix_obj = find(H(:,objIDColIdx) == objID);
        if(isempty(ix_obj))
            error('objID %d not found in union of backward and forward object list',objID);
        end
        
        R = H(ix_obj, :);
        if(size(R,1) == 1)
            if(edgeTrDirection == 2)
                t = R(1,4);
                error('only one entry found for objID %d with edgeTrDirection = 2, t = %d',objID, t);
            end
        elseif(size(R,1) == 2)
            R = R(1,:);
        elseif(size(R,1) > 2)
            error('more than two entries for objID %d, t = %d',objID, t);
        end
        
        R(matchingCostColIdx)   = matchingCost;
        R(trDirectionColIdx)    = trDirection;
        R(trIDColIdx)           = trID;
        T = [T;R];
    end
end

function [G] = RemoveCoreTrackJoiningEdges(G)
%remove extension edges that join two core tracks

P = getPathsFromEdgeList(G); %P is a list of edge index lists
for i = 1 : length(P)
    edgeIndexSequence = P{i};
    edgeDirections    = G(edgeIndexSequence,4);
    
    %find transitions from direction 0 to non-zero
    d = edgeDirections ~= 0;
    leftIdx  = findPattern(d, [0 1]'); % transitions from core edge to extension edge
    rightIdx = findPattern(d, [1 0]'); % transitions from extension edge to core edge
    
    if(~isempty(leftIdx) && ~isempty(rightIdx) && rightIdx(1) < leftIdx(1))
        rightIdx(1) = [];
    end
    if(~isempty(leftIdx) && ~isempty(rightIdx) &&  leftIdx(end) > rightIdx(end))
        leftIdx(end) = [];
    end
    
    if(abs(length(leftIdx)-length(rightIdx)) > 1)
        error('length of the left and the right index array can only differ by 1');
    end
    
    for j = 1 : length(leftIdx)
        if(j > length(rightIdx))
            break
        end
        a = leftIdx(j)+1;
        b = rightIdx(j);
        
        edgesInOverlapRegion    = G(edgeIndexSequence(a:b),:)
        matchingCosts           = edgesInOverlapRegion(:,3);
        [maxCost, maxCostIdx]   = max(matchingCosts);
        maxCostIdx = 1;
        ix_delete               = maxCostIdx + a - 1;
        edgeIdx_delete          = edgeIndexSequence(ix_delete);
        
        edge_toBeDeleted = G(edgeIdx_delete,:);
        
        %update tracking directions in the overlap region
        G(edgeIndexSequence(a:ix_delete-1),4)    = +1; %edge tracking direction
        G(edgeIndexSequence(a+1:ix_delete),5)    = +1; %vertex tracking direction
        G(edgeIndexSequence(ix_delete+1:b),4)    = -1; %edge tracking direction
        G(edgeIndexSequence(ix_delete+1:b),5)    = -1; %vertex tracking direction
        
        %delete edge by making it a terminating edge:
        G(edgeIdx_delete,2) = -1; %objID2
        G(edgeIdx_delete,3) = -1; %matching cost
        G(edgeIdx_delete,4) = G(edgeIdx_delete,5); %edgeTrDirection = vertexTrDirection
    end
end
end

function A = GetTableEntries(T, rowIndices, columnIndices)
A = zeros(length(rowIndices), length(columnIndices));
for i = 1 : length(rowIndices)
    r = rowIndices(i);
    if(r > 0)
        A(i,:) = T(r,columnIndices);
    else
        A(i,:) = -1;
    end
end
end

function [objIdxMap_b, objIdxMap_f] = fillUpWithZeros(objIdxMap_b, objIdxMap_f)
%make sure that there is a zero-entry also for objIDs greater the
%maximum objID in the respective object index map

if(length(objIdxMap_b) < length(objIdxMap_f))
    objIdxMap_b = [objIdxMap_b; zeros(length(objIdxMap_f)-length(objIdxMap_b),1)];
elseif(length(objIdxMap_f) < length(objIdxMap_b))
    objIdxMap_f = [objIdxMap_f; zeros(length(objIdxMap_b)-length(objIdxMap_f),1)];
end
end

function objIdxMap = mapObjectIndices(T, objIDColIdx)
objIDs      = T(:,objIDColIdx);
objIdxMap   = zeros(length(objIDs),1);
for i = 1 : length(objIDs)
    objIdxMap(objIDs(i)) = i;
end
end

function objectIndexSequence = getTableRowIndicesOfObjectsAlongPath(G, edgeIndexSequence, objIdxMap)
objIDs = G(edgeIndexSequence, 1);
objectIndexSequence = objIdxMap(objIDs);
end


function T = RemoveRadiusHystersisEdges(T, header, radiusHystersis)
%find violations of the radius hysteresis condition and remove the edge
%with the highest matching cost
%
% example: radius hysteresis = (2,5)
%
%       trajectory:
%       r = 1234568|44332|111233455
%           -----------------------
%       t =       a       b
%
%       looking from the left:  radius hystersis at timepoint b
%       looking from the right: radius hystersis at timepoint a
%       ==> find the edge between a and b with the highest weight and
%           remove it to remove the radius hysteresis

objIDColIdx         = headerIndex(header, 'objID');
trIDColIdx          = headerIndex(header, 'trID');
radiusColIdx        = headerIndex(header, 'meanSigmaXY2D');
matchingCostColIdx  = headerIndex(header, 'matchingCost');
nextFreeTrID        = max(T(:,trIDColIdx)) + 1;

trIDs_to_analyze = unique(T(:, trIDColIdx));

while(~isempty(trIDs_to_analyze))
    E = clusterTable(T, trIDColIdx);
    T = [];
    for i = 1 : length(E)
        R = E{i};
        trID = R(1, trIDColIdx);
        if(ismember(trID, trIDs_to_analyze))
            trIDs_to_analyze(trIDs_to_analyze == trID) = [];
            maxRadius = 0;
            for k = 1 : size(R,1)
                radius_k = R(k,radiusColIdx);
                if(maxRadius > radiusHystersis(2) && radius_k < radiusHystersis(1))
                    rightIdx = k;
                    leftIdx  = rightIdx;
                    while(leftIdx > 1 && R(leftIdx,radiusColIdx) <= radiusHystersis(2))
                        leftIdx = leftIdx - 1;
                    end
                    
                    matchingCost        = R(:, matchingCostColIdx);
                    maxMatchingCostIdx  = index1DOfMax(matchingCost, [leftIdx rightIdx-leftIdx]);
                    
                    if(maxMatchingCostIdx < size(R,1))
                        R(maxMatchingCostIdx+1:end, trIDColIdx) = nextFreeTrID;
                        nextFreeTrID = nextFreeTrID + 1;
                        
                        t1 = R(maxMatchingCostIdx, 4);
                        t2 = R(maxMatchingCostIdx+1, 4);
                        objID1 = R(maxMatchingCostIdx, objIDColIdx);
                        objID2 = R(maxMatchingCostIdx+1, objIDColIdx);
                        trIDs_to_analyze = [trIDs_to_analyze;unique(R(:,trIDColIdx))];
                    end
                    break
                end
                maxRadius = max(maxRadius, radius_k);
            end
        end
        T = [T;R];
    end
end
end

function [G, conflictCount, forbiddenEdges] = RemoveConflicts(G)
% conflictCount     - number of conflicting edges (exchange edges are not
%                     considered conflicts)
% forbiddenEdges    - list of edges to be removed in the next tracking round
%                     column format: [objID1, objID2, trDirection, matchingCost, t1] (note: objID1 at the earlier timepoint t1)
clusters        = clusterTable(G, 6); %cluster by time
forbiddenEdges  = [];
G               = [];
conflictCount   = 0;
for tix = 1 : length(clusters)
    Gt_edges  = clusters{tix};
    time1     = Gt_edges(1,6);
    
    % delete all terminating edges for which a non-terminating edge with
    % the same source exists
    deleteIdx = [];
    for i = 1:size(Gt_edges,1)
        objID2_i = Gt_edges(i,2);
        if(objID2_i <= 0) %edge_i is terminating
            objID1_i = Gt_edges(i,1);
            for j = 1:size(Gt_edges,1)
                objID1_j = Gt_edges(j,1);
                objID2_j = Gt_edges(j,2);
                if(objID2_j > 0 && objID1_j == objID1_i)
                    %edge j is not terminating and has the same source
                    %vertex as edge i
                    deleteIdx(end+1) = i;
                end
            end
        end
    end
    Gt_edges(deleteIdx,:) = [];
    deleteIdx = [];
    
    % convert edge list to matrix representation
    objID_sources = unique(Gt_edges(:,1));
    objID_targets = unique(Gt_edges(:,2));
    Gt = ones(length(objID_sources), length(objID_targets))*inf;
    p  = zeros(length(objID_sources), length(objID_targets));
    for j = 1 : size(Gt_edges,1)
        objID_s     = Gt_edges(j,1);
        objID_t     = Gt_edges(j,2);
        w           = Gt_edges(j,3);
        if(objID_t > 0) %edge is not a terminating edge
            ix_source   = (objID_sources==objID_s);
            ix_target   = (objID_targets==objID_t);
            Gt(ix_source,ix_target) = w;
            p(ix_source,ix_target)  = j;
        end
    end
    
    % resolve conflicts
    Mt = Hungarian2(Gt);
    
    % all edges that need to be removed
    Ut = double((Gt < inf) & ~Mt);
    
    showGraph(Gt, 'conflict graph');
    showMatching(Mt, 'bipartite matching');
    showMatching(Ut, 'unmatched edges');
    
    % re-convert matrix representation to edge list representation
    ix_matched      = [];
    ix_unmatched    = [];
    for s_unmatched = 1 : size(Ut,1)
        t_unmatched = find(Ut(s_unmatched,:),1);
        if(~isempty(t_unmatched))
            t_matched = find(Mt(s_unmatched,:),1);
            s_matched = find(Mt(:,t_unmatched),1);
            
            if(~isempty(t_matched))
                ix_matched(end+1)   = p(s_unmatched,t_matched);
                ix_unmatched(end+1) = p(s_unmatched,t_unmatched);
            end
            if(~isempty(s_matched))
                ix_matched(end+1)   = p(s_matched,t_unmatched);
                ix_unmatched(end+1) = p(s_unmatched,t_unmatched);
            end
        end
    end
    
    ix_conflictingEdges = unique([ix_matched(:) ix_unmatched(:)], 'rows');
    
    if(any(ix_conflictingEdges(:,1) == ix_conflictingEdges(:,2)))
        error('edge in conflict with itself');
    end
    
    % go through all conflicting edge pairs
    indices_forbiddenEdges = [];
    for i = 1 : size(ix_conflictingEdges,1)
        ix_m                = ix_conflictingEdges(i,1);
        ix_u                = ix_conflictingEdges(i,2);
        edge_m              = Gt_edges(ix_m,:);
        edge_u              = Gt_edges(ix_u,:);
        edgeTrDirection_m   = edge_m(4);
        edgeTrDirection_u   = edge_u(4);
        objID1_m            = edge_m(1);
        objID2_m            = edge_m(2);
        objID1_u            = edge_u(1);
        objID2_u            = edge_u(2);
        weight_m            = edge_m(3);
        weight_u            = edge_u(3);
        time1               = edge_m(6);
        
        deleteIdx(end+1)    = ix_u;
        conflictCount       = conflictCount + 1;
        
        if(edgeTrDirection_m == 0 && edgeTrDirection_u ~= 0)
            %core track in one direction modified, in the other direction not modified
            %==> remove the new extension edge instead of the core edge!
            %note: this situation should not occur in practice
        elseif(edgeTrDirection_m ~= 0 && edgeTrDirection_u == 0)
            %core track in one direction modified, in the other direction not modified
            %==> remove the core edge
        else
            if(~(ismember(edgeTrDirection_m, [-1,1]) && ismember(edgeTrDirection_u, [-1,1])))
                error('conflicting edges must have tracking direction +1 or -1: t=%d, edgeTrDirection_m=%d, edgeTrDirection_u=%d',t_i,edgeTrDirection_m,edgeTrDirection_u);
            end
            
            %add forbidded edge if it not already exists
            if(~any(indices_forbiddenEdges==ix_u))
                indices_forbiddenEdges = [indices_forbiddenEdges;ix_u];
                forbiddenEdges(end+1,:)  = Gt_edges(ix_u,[1:2, 4, 3, 6]); %objID1, objID2, edgeTrDirection, matchingCost, t1
            end
        end
        
        %note: core edges that are replaced by exchange edges are not added
        %to the set of forbidden edges because in the next iteration we
        %start the induction without any replaced core edge. Hence, the
        %extension whose core edge was removed is not forced to make the same choice as in the this iteration
    end
    Gt_edges(deleteIdx,:) = [];
    G = [G;Gt_edges];
end

    function showMatching(M, titleTxt)
        if(getDebugLevel() >= 2)
            M_ = M;
            M_(M == 0) = inf;
            showGraph(M_,titleTxt);
        end
    end
    function showGraph(Graph, titleTxt)
        if(getDebugLevel() >= 2)
            
            this_objID_sources = objID_sources;
            this_objID_targets = objID_targets;
            
            
            fig1=sfigure;maximize(fig1);
            labelsSources = cell(length(this_objID_sources),1);
            labelsTargets = cell(length(this_objID_targets),1);
            for ii = 1 : length(this_objID_sources)
                labelsSources{ii} = sprintf('objID=%d', this_objID_sources(ii));
            end
            for ii = 1 : length(this_objID_sources)
                labelsTargets{ii} = sprintf('objID=%d', this_objID_targets(ii));
            end
            drawBipartiteGraph(Graph, inf, labelsSources, labelsTargets);
            title(sprintf('t: %d ==> %d\n%s',time1, time1+1, titleTxt));
            %printFigureToPostScript(fig1,fnDebugPS, 1);
        end
    end

end

function G = MergeEdgeLists(Gb,Gf)
%merge the two edge lists into one
%edges that occur in both lists will be merged and their tracking
%directions updated

Gb = sortrows(Gb, 6); %sort by time
Gf = sortrows(Gf, 6); %sort by time

G = Gb;
n0 = size(G,1);
for i = 1 : size(Gf,1)
    objID1_f = Gf(i,1);
    objID2_f = Gf(i,2);
    t_f      = Gf(i,6);
    isEdgePresentInBackwardTracks = 0;
    for j = 1 : n0
        t_b      = G(j,6);
        if(t_b > t_f)
            break
        end
        
        objID1_b = G(j,1);
        objID2_b = G(j,2);
        
        if(objID1_f == objID1_b && objID2_f == objID2_b)
            %edge is present in the backward tracks
            isEdgePresentInBackwardTracks = 1;
            edgeTrDirection_b = G(j,4);
            edgeTrDirection_f = Gf(i,4);
            %             t                 = G(j,6);
            
            if(edgeTrDirection_b == 0 && edgeTrDirection_f == 0)
                %core edge
                G(j, 3) = mean([G(j,3) Gf(i,3)]);
            elseif(edgeTrDirection_b == -1 && edgeTrDirection_f == +1)
                %extension edge, backward and forward agree
                G(j, 4) = 2; %edgeTrDirection == 2: -1 and +1
                G(j, 5) = 2; %vertexTrDirection == 2: -1 and +1
                G(j, 3) = mean([G(j,3) Gf(i,3)]); % matching cost
            elseif(edgeTrDirection_b == 0 && edgeTrDirection_f == 1)
                G(j, 4) = 0; %edgeTrDirection
                G(j, 5) = 0; %vertexTrDirection
                G(j, 3) = mean([G(j,3) Gf(i,3)]); % matching cost
            elseif(edgeTrDirection_b == -1 && edgeTrDirection_f == 0)
                G(j, 4) = 0; %edgeTrDirection
                G(j, 5) = 0; %vertexTrDirection
                G(j, 3) = mean([G(j,3) Gf(i,3)]); % matching cost
            elseif(edgeTrDirection_b == +1)
                error('undefined situation: backward edge with tracking direction +1');
            elseif(edgeTrDirection_f == -1)
                error('undefined situation: forward edge with tracking direction -1');
            else
                error('undefined situation: edgeTrDirection_b = %d and edgeTrDirection_f = %d', edgeTrDirection_b, edgeTrDirection_f);
            end
            
            break
        end
    end
    if(~isEdgePresentInBackwardTracks)
        %edge is not present in the backward tracks ==> add the forward edge
        G(end+1,:) = Gf(i,:);
    end
end
end

function G = BuildGraphAsEdgeListFromTrackingTable(T, header)
%       1       2        3               4                    5              6
%G = [objID1 objID2 matchingCost edgeTrackingDirection obj1TrackingDirection t1]  (note: t1+1 = t2)
trIDColIdx          = headerIndex(header, 'trID');
objIDColIdx         = headerIndex(header, 'objID');
trDirectionColIdx   = headerIndex(header, 'trDirection');
matchingCostColIdx  = headerIndex(header, 'matchingCost');
meanSigmaXY2DColIdx = headerIndex(header, 'meanSigmaXY2D');

T = sortrows(T, 4); %sort by time
G = [];
for i = 1 : size(T,1)
    time_i  = T(i,4);
    trID_i  = T(i, trIDColIdx);
    
    vertexFound = 0;
    for j = i+1 : size(T,1)
        time_j = T(j,4);
        if(time_j > time_i+1)
            break
        end
        
        trID_j  = T(j, trIDColIdx);
        if(trID_i == trID_j)
            vertexFound = 1;
            break;
        end
    end
    if(~vertexFound)
        j = -1;
    end
    
    trDirection_i   = T(i, trDirectionColIdx);
    objID_i         = T(i, objIDColIdx);
    radius_i        = T(i, meanSigmaXY2DColIdx);
    matchingCost    = T(i, matchingCostColIdx); %matching cost is stored in the earlier vertex
    
    if(j > 0)
        trDirection_j   = T(j, trDirectionColIdx);
        objID_j         = T(j, objIDColIdx);
        time_j          = T(j, 4);
        radius_j        = T(j, meanSigmaXY2DColIdx);
        
        if(time_i + 1 ~= time_j)
            error('edge between non-succesive timepoints: time_i = %d, time_j = %d',time_i, time_j);
        end
        if(trID_i ~= trID_j)
            error('track-IDs are not equal: trID_i = %d, trID_j = %d', trID_i, trID_j);
        end
    else
        trDirection_j   = +3; %edge to dummy sink-object
        objID_j         = -1;
        matchingCost    = -1;
        time_j          = -1;
        radius_j        = -1;
    end
    
    if(    trDirection_i == -1 && trDirection_j == -1)
        edgeTrDirection = -1;
    elseif(trDirection_i == -1 && trDirection_j == 0)
        edgeTrDirection = -1;
    elseif(trDirection_i == 0 && trDirection_j == -1)
        edgeTrDirection = -1;
    elseif(trDirection_i == +1 && trDirection_j == +1)
        edgeTrDirection = +1;
    elseif(trDirection_i == +1  && trDirection_j == 0)
        edgeTrDirection = +1;
    elseif(trDirection_i == 0  && trDirection_j == +1)
        edgeTrDirection = +1;
    elseif(trDirection_i == 0  && trDirection_j == 0)
        edgeTrDirection = 0;
    elseif(trDirection_i == 0  && trDirection_j == +3)
        edgeTrDirection = 0;
    elseif(trDirection_i == 1  && trDirection_j == +3)
        edgeTrDirection = +1;
    else
        error('undefined situation: trDirection_i == %d (t=%d,trID=%d) and trDirection_j == %d (t=%d,trID=%d)',trDirection_i,time_i,trID_i,trDirection_j,time_j,trID_j);
    end
    
    G(end+1,:) = [objID_i objID_j matchingCost edgeTrDirection trDirection_i time_i radius_i radius_j];
end
checkConsistency_edgeList(G);
end

function P = getPathsFromEdgeList(G)

edgeVisited = zeros(size(G,1),1);
P           = {};
for i = 1 : size(G,1)
    if(~edgeVisited(i))
        edgeIndexSequence = getPathFromEdgeList(G, i);
        edgeVisited(edgeIndexSequence) = 1;
        P{end+1} = edgeIndexSequence;
    end
end
end

function edgeIndexSequence = getPathFromEdgeList(G, startEdgeIdx)
edgeIndexSequence(1)    = startEdgeIdx;
edgeIdx                 = startEdgeIdx;

N = size(G,1);
while(G(edgeIdx, 2) > 0) %while edge is not a terminating one
    objID_next  = G(edgeIdx,2);
    t_next      = G(edgeIdx,6) + 1;
    
    found = 0;
    for edgeIdx = edgeIdx+1 : N
        t = G(edgeIdx,6);
        if(t > t_next)
            break
        end
        objID = G(edgeIdx,1);
        if(objID == objID_next)
            found = 1;
            break
        end
    end
    if(found)
        edgeIndexSequence(end+1) = edgeIdx;
    else
        break; %next edge might not be found if there is no terminating edge for the track
    end
end
end

function checkConsistency_edgeList(G)
if(any(G(:,1) <= 0))
    error('objID <= 0 is first objID1-column');
end

ixTerminating = G(:,2) <= 0;
if(any(G(ixTerminating,3) ~= -1))
    error('terminating edge with weight ~= -1');
end
if(any(G(~ixTerminating,3) < 0))
    error('non-terminating edge with weight < 0');
end
end

function ix = findPattern(a, p)
%find pattern p in a
ix = [];
for i = 1 : length(a) - length(p) + 1
    if(all(a(i:(i+length(p)-1)) == p))
        ix(end+1) = i;
    end
end
end


