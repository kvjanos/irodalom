function [ W ] = makeEdgeWeightsPositive( W )
if(iscell(W))
    minW = inf;
    for i = 1 : length(W)
        G = W{i};
        minW = min(minW, min(G(:)));
    end
    if(minW <= 0)
        for i = 1 : length(W)
            W{i} = W{i} - minW + .000000000001;
        end
    end    
else
    minW = min(W(:));
    if(minW <= 0)
        W = W - minW + .000000000001;
    end
end