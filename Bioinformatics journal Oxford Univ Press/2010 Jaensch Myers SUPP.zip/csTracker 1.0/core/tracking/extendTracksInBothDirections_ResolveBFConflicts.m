function [ filenameOut, fn_back, fn_forw ] = extendTracksInBothDirections_ResolveBFConflicts( workingDir, filenameIn, filenameInAllCandidates,objectsNotToBeRejected, objectsToBeRejected, skipIfFileoutExists )
%filenameIn                 - the name of the file containing the tracks to be extended
%filenameInAllCandidates    - the name of the file containing the
%                             candidates including all candidates that are
%                             part of the given tracks
%
%also see: graphBasedTracking, extendTracks, extendTracksInBothDirections

global param;
useMaxVelocityDependingOnCentrosomeNumber = 0;

if(nargin == 0)
    workingDir  = [baseDir filesep 'yTUB-GFP5_WT_1to8cellstage\workingDir\2'];
    workingDir = [baseDir filesep 'yTUB-GFP24_WT_1to8cellstage\workingDir\8'];
    workingDir = [baseDir filesep 'SPD2-GFP2_WT_8to16cellstage\workingDir\8'];
    workingDir = [baseDir filesep 'yTUB-GFP1_long3\workingDir\8'];
    workingDir = [baseDir filesep 'RSA1-GFP2_WT_4to8cellstage\workingDir\8']; 
    workingDir = [baseDir filesep 'yTUB-GFP4_WT_8to16cellstage\workingDir\8'];
    workingDir = [baseDir filesep 'RSA1-GFP1_WT_8to16cellstage\workingDir\1'];
   
    filenameIn  = 'MainTr.txt';
    filenameInAllCandidates = finalCandidatesFile();
    setDebugLevel(1)
end

[filenameIn, filenameOut ] = initProcessingStep( workingDir, filenameIn, '*extTrNoBFC', mfilename );
if(exist('skipIfFileoutExists','var') && skipIfFileoutExists && exist(filenameOut, 'file'))
    fn_back = [];
    fn_forw = [];
    return
end
if(~exist('objectsNotToBeRejected','var'))
    objectsNotToBeRejected = [];
end
if(~exist('objectsToBeRejected','var'))
    objectsToBeRejected = [];
end

skipIfFileoutExists = 0;

fn_mainTracks = filenameIn;

if(useMaxVelocityDependingOnCentrosomeNumber)
    [theoreticalMaxVelo3D, theoreticalMaxVelo2D] = TheoreticalMaxVelocity( workingDir, fn_mainTracks );
else
    theoreticalMaxVelo3D = [];
    theoreticalMaxVelo2D = [];
end

forbiddenEdges  = []; 
conflictCount   = 1;
itCounter       = 0;
fn_ext_main     = fn_mainTracks;

while(conflictCount > 0)
    itCounter = itCounter + 1;
    if(itCounter > 50)
        error('iteration counter > 50');
    end
    fprintf('%m: iteration %d',mfilename,itCounter);
    [fn_ext, fn_back, fn_forw, fn_ext_main, conflictCount, forbiddenEdges_thisIteration] = extendTracksInBothDirections(workingDir, fn_ext_main, filenameInAllCandidates, objectsNotToBeRejected, objectsToBeRejected, forbiddenEdges, theoreticalMaxVelo3D, theoreticalMaxVelo2D,  skipIfFileoutExists);
    forbiddenEdges = [forbiddenEdges;forbiddenEdges_thisIteration];    
end

copyfile(fn_ext, filenameOut, 'f');
deleteFileIfExists(fn_ext);

if(nargin == 0)
    FindBrokenTracks(workingDir, filenameOut, 'error');
    FindMultipleTrackAssignments( workingDir, filenameOut, {}, 'error')
    showTrackingMovie(filenameOut);
end

end