function [Matching, CostWithForbiddenEdges, CostWithoutForbiddenEdges] = OptBipartiteMatchingWithoutForbiddenEdges(G, F)
% computes a minimum-weight bipartite matching that includes no forbidden
% edges
%
% input: G - MxN weight matrix, inf indicates no edge
%        F - MxN boolean matrix indicating the forbidden edges
%

% find the connected components of G, compute a bipartite matching for each
% connected component separately and combine them to obtain the overall solution

isGraphBipartite = 1;
[leftVertexGroup,rightVertexGroup] = ConnectedGraphComponents(G < inf, 'weakly', isGraphBipartite);

N = length(leftVertexGroup);

Matching                    = zeros(size(G));
CostWithForbiddenEdges      = 0;
CostWithoutForbiddenEdges   = 0;
for i = 1 : N
    A = leftVertexGroup{i};
    B = rightVertexGroup{i};
    
    Gi = G(A,B);
    Fi = F(A,B);
    
   [Matching_i, CostWithForbiddenEdges_i, CostWithoutForbiddenEdges_i] = OptBipartiteMatchingWithoutForbiddenEdges_helper(Gi, Fi);
    
    
    Matching(A,B)               = Matching_i;
    CostWithForbiddenEdges      = CostWithForbiddenEdges    + CostWithForbiddenEdges_i;
    CostWithoutForbiddenEdges   = CostWithoutForbiddenEdges + CostWithoutForbiddenEdges_i;
end
end



function [Matching, CostWithForbiddenEdges, CostWithoutForbiddenEdges, C] = OptBipartiteMatchingWithoutForbiddenEdges_helper(G, F)
%computes a minimum bipartite matching that includes no forbidden edges
%
% input: G - MxN weight matrix, inf indicates no edge
%        F - MxN boolean matrix indicating the forbidden edges
%
% ouput: Matching                  - minimum bipartite matching that includes no
%                                    forbidden edges
%        CostWithForbiddenEdges    - cost of the matching before the
%                                    forbidden edges have been removed
%        CostWithoutForbiddenEdges - cost of the matching after the
%                                    forbidden edges have been removed
%                                    (i.e. the cost of 1. output 'Matching')
%        C                         - the matching cost in each iteration
%
% approach: We let G(1) = G, the given graph that may include forbidden
% edges. In each iteration i we compute for G(i) a minimum-weight matching
% M(i) and its matching cost C(i). If there are forbidden edges in M(i)
% we remove these and continue with the next iteration. Otherwise, we stop
% iterating, determine i* = argmin(C(i)) and let M(i*) with any forbidden
% edge removed be our optimal matching.
%

G_org                   = G;
idx                     = 0;
M                       = {};
C                       = [];
ix_matchedAndForbidden  = {};

while(1)
    idx = idx + 1;
    
    %compute a matching for the graph that includes forbidden edges
    [M{idx}, C(idx)] = Hungarian2(G);
%     [M{idx}, C(idx)] = GreedyBipartiteMatching(G);
    
    %remove the forbidden edges in M
    ix_matchedAndForbidden{idx} = find(F(:) & M{idx}(:));
    
    %if there are no forbidden edges in the optimal matching, then we have
    %found what we are looking for
    if(isempty(ix_matchedAndForbidden{idx}))
        break
    end
    
    %remove from G all matched forbidden edges
    G(ix_matchedAndForbidden{idx}) = inf;
    
    if(idx > 999)
        if(idx > 9999)
                error('too many iterations in %s', mfilename);
        end
    end
end

[minCost, minCostIdx] = min(C);

Matching = M{minCostIdx};
ix_minCost_matchedAndForbidden = ix_matchedAndForbidden{minCostIdx};

Matching(ix_minCost_matchedAndForbidden) = 0;
CostWithForbiddenEdges                   =  minCost;
CostWithoutForbiddenEdges                =  sum(G_org(Matching>0));

end