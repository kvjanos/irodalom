function differences = ComputeCSPropertiesDynamics( T, header, colNames, relativeDifferences, zStretchingCorrection )
%COMPUTECSPROPERTIESDYNAMICS computes for the given column names the
%differences of each centrosome from one timepoint to the next (requires
%tracking results), tracks with ID <= 0 will be ignored
%
% input:
%   colNames may either be a cell array of strings (including elements 'pos2D' and 'pos3D') 
%   or a single string, in case of 'pos3D' and 'pos2D', the position
%   differences will be computed via computing the velocity and leaving out
%   the 0-velocity of the first timepoint of a centrosome
%
%   relativeDifferences =    length(colNames) vector or single value
%                            if true, computes the difference relative to the earlier timepoint,
%                                  i.e. (f(t)-f(t+1)) / f(t) where f(t) is the feature value at time point t
%
%output: differences    is a N x length(colNames) matrix containing the (signed) differences of
%                       the respective columns from one timepoint to the next of a centrosome as
%                       column vectors
%
%see also: MeanAndStdDev_CSDynamics_FromTracks

if(nargin < 4)
    relativeDifferences = 0;
end

if(nargin < 5)
    zStretchingCorrection = 1.0;
end

if(ischar(colNames))
    str = colNames;
    colNames = {str};
end

colIdxSpecial = headerIndexSpecialPos(header, colNames);

if(length(colIdxSpecial) == 1 && length(colIdxSpecial) > 1)
    relativeDifferences = repmat(relativeDifferences, 1, length(colIdxSpecial));
end

%check that 2D and 3D position differences are not relative differences
relDiffColIdx = find(relativeDifferences);
for i = 1 : length(relDiffColIdx)
    if(any(strcmpi(colNames(relDiffColIdx), 'pos2D')))
        error('difference in pos2D cannot be relative')
    end
    if(any(strcmpi(colNames(relDiffColIdx), 'pos3D')))
        error('difference in pos3D cannot be relative')
    end
end


T = sortrows(T,4); %sort by time

trIDColIdx = headerIndex(header,'trID');
T = T(T(:,trIDColIdx)>0,:);
uniqueTrIDs = unique(T(:,trIDColIdx));

differences = [];
for trID = uniqueTrIDs'
    R = T(T(:,trIDColIdx) == trID,:);
    if(size(R,1)>1)
        d = ComputeRowDifference( R, colIdxSpecial, zStretchingCorrection );
        if(~isempty(relDiffColIdx))
            for i = 1 : size(R,1)-1
                d(i,relDiffColIdx) = d(i,relDiffColIdx) ./ min(R(i,colIdxSpecial(relDiffColIdx)),R(i+1,colIdxSpecial(relDiffColIdx)));
            end
        end
        differences = [differences;d];
    end
end

end

% 
% 
% if(ischar(colNames))
%     differences  = ComputeCSPropertiesDynamics_helper( T, header, colNames, relativeDifferences );
% else
%     idx_pos2D = find(strcmpi('pos2D', colNames));
%     idx_pos3D = find(strcmpi('pos3D', colNames));
%     
%     allCol    = 1 : length(colNames);
%     if(~isempty(idx_pos2D))
%         allCol(allCol==idx_pos2D) = [];
%     end
%     if(~isempty(idx_pos3D))
%         allCol(allCol==idx_pos3D) = [];
%     end
%     
%     differences(:,allCol) = ComputeCSPropertiesDynamics_helper( T, header, colNames(allCol),relativeDifferences, zStretchingCorrection);
%     if(~isempty(idx_pos2D))
%         differences(:,idx_pos2D)  = ComputeCSPropertiesDynamics_helper( T, header, colNames{idx_pos2D}, relativeDifferences, zStretchingCorrection);
%     end
%     if(~isempty(idx_pos3D))
%         differences(:,idx_pos3D)  = ComputeCSPropertiesDynamics_helper( T, header, colNames{idx_pos3D}, relativeDifferences, zStretchingCorrection);
%     end
% 
% end
% 
% end
% 
% function [ differences ] = ComputeCSPropertiesDynamics_helper( T, header, colNames, relativeDifferences, zStretchingCorrection )
% %COMPUTECSPROPERTIESDYNAMICS computes for the given column names the
% %differences of each centrosome from one timepoint to the next (requires
% %tracking results), tracks with ID <= 0 will be ignored
% %
% %colNames may either be a cell array of strings or one of the single
% %strings ['pos3D','pos2D'], in case of 'pos3D' and 'pos2D', the position
% %differences will be computed via computing the velocity and leaving out
% %the 0-velocity of the first timepoint of a centrosome
% %
% %output: differences    is a N x length(colNames) matrix containing the (signed) differences of
% %                       the respective columns from one timepoint to the next of a centrosome as
% %                       column vectors
% %
% %
% 
% T = sortrows(T,4); %sort by time
% 
% trIDColIdx = headerIndex(header,'trID');
% T = T(T(:,trIDColIdx)>0,:);
% uniqueTrIDs = unique(T(:,trIDColIdx));
% 
% for trID = uniqueTrIDs'
%     R = T(T(:,trIDColIdx) == trID,:);
%     if(size(R,1)>1)
%         d = ComputeRowDifference( T, colIdxSpecial, zStretchingCorrection );
%         d = diff(R(:,colIdx));
%         if(relativeDifferences)
%             for i = 1 : size(R,1)-1
%                 d(i,:) = d(i,:) ./ min(R(i,colIdx),R(i+1,colIdx));
%             end
%         end
%         differences = [differences;d];
%     end
% end
% 
% 
% if(ischar(colNames) && strcmpi(colNames, 'pos3D'))
%     differences = ComputePositionChanges('velo3D');
% elseif(ischar(colNames) && strcmpi(colNames,'pos2D'))
%     differences = ComputePositionChanges('velo2D');
% else
%     colIdx = headerIndex(header, colNames);
%     differences = [];
%     for trID = uniqueTrIDs'
%         R = T(T(:,trIDColIdx) == trID,:);
%         if(size(R,1)>1)
%             d = diff(R(:,colIdx));
%             if(relativeDifferences)
%                 for i = 1 : size(R,1)-1
%                     d(i,:) = d(i,:) ./ min(R(i,colIdx),R(i+1,colIdx));
%                 end
%             end
%             differences = [differences;d];
%         end
%     end
% end
% 
% function distances = ComputePositionChanges(dimension) %nested function
%     %dimension: either 2 or 3
%     
%     distances = [];
%     for trID = uniqueTrIDs'
%         R = T(T(:,trIDColIdx) == trID,:);
%         thisD = realDistance(R(1:end-1,1:dimension),R(2:end,1:dimension),zStretchingCorrection);
%         distances = [distances;thisD]; 
%     end
% end

