function [ T ] = AssignNewTrackIDsForTracksWithGaps( T, header )

trIDColIdx = headerIndex(header, 'trID');

nextFreeTrID = max(T(:,trIDColIdx))+1;

E = clusterTable(T, trIDColIdx);
T = [];
for i = 1 : length(E)
    R = E{i};
    R = sortrows(R,4); %sort by time
    
    %find gaps
    d    = diff(R(:,4));
    gaps = find(d>1);
    
    %assign new trID
    for j = 1 : length(gaps)
        R(gaps(j)+1:end,trIDColIdx) = nextFreeTrID;
        nextFreeTrID = nextFreeTrID + 1;
    end
    T = [T;R];
end

end

