function [ varargout ] = FilterTracksByLengthOnCompleteTracks( varargin )
%filter all tracks not at the movie start or end and shorter than half the
%minimum cell cycle duration

if(nargin == 0)
    workingDir = [baseDir filesep 'SPD2-GFP3_WT_4to8cellstage\workingDir\9'];
    filenameIn = 'candidates3D_noTooClPlane_mexHat_GFit2D_noTooCl3D.txt';
    
    workingDir = [baseDir filesep 'SPD5-YFP11_WT_multicell\workingDir\8'];
    filenameIn = 'MainTr_extTrNoBFC_joinTr.txt';
    
    varargin{1} = workingDir;
    varargin{2} = filenameIn;
end
fprintf('%s\n',mfilename);

global param;
[T, header, filenameIn, filenameOut] = processInput(varargin, 'noShortTr');
if(isempty(T))
    varargout{1} = filenameOut;
    return;
end

minCellCycleDurationInFrames = floor(param.bio.minCellDevDuration * 60 / param.frameInterval);
minTrackLengthInFrames = ceil(.5*minCellCycleDurationInFrames);

[T, header] = FilterTracksByLength(T, header, 'minTrackLength',minTrackLengthInFrames, 'minTrackLengthAtMovieStart', 1, 'minTrackLengthAtMovieEnd',1, 'units', 'frames');

if(isempty(filenameOut))
    varargout{1} = T;
    varargout{2} = header;
else
    fprintMatrix(filenameOut, T, header);
    varargout{1} = filenameOut;
end