function [ filenameOut ] = makeTrackingMovie( workingDir, filenameIn, filenameOut, skipIfFileoutExists, varargin )
%input: workingDir
%       filenameIn
%       filenameOut {optional}          - may be empty
%       skipIfFileoutExists {optional}
%       varargin                        -  'showTrID' (0|1|2) 0: never,1:always, 2: only if centrosome name is not available
%                                          'showObjID', (0|1)
%                                          'saveSingleImages', (0|1)
%                                          'showParentID', (0|1)
%                                          'showCellID', (0|1)
%                                          'showMovieTag', (0|1)
%                                          'showTrackLines', (0|1)
%                                          'showOutsideEmbryoFlag', (0|1)
%                                          'showNothing', (0|1) [don't show any object information]
%                                          'useDifferentLineStyleForExtendedTrackParts', (0|1)
%                                          'displayParameter', an arbitrary column name
%                                          'trIDs', list of track IDs to show in movie
%                                          'replaceCSPatchByCenterImage', (0|1)
%                                          'clippingImageSource', ('none'|'maxPrj'|'centerImg')
%                                          'firstFrame', frame# {default: 1}
%                                          'lastFrame',  frame# {default: max frame number}
%                                          'frameRate',  images/sec
%                                          'magnification', this time the actual image size
%                                          'openMovie', (0|1)
%

fprintf('%s\n',mfilename);

global param;
filenameIn = initProcessingStep( workingDir, filenameIn );
setImageSource('type','smoothed');

vararginList                = getVarargin(varargin, 'vararginList', {});
if(~isempty(vararginList))
    varargin = [varargin vararginList];
end

showObjects                 = getVarargin(varargin, 'showObjects', 1);
showTrID                    = getVarargin(varargin, 'showTrID', 1); %0: never,1:always, 2: only if centrosome name is not available
showObjID                   = getVarargin(varargin, 'showObjID', 0);
saveSingleImages            = getVarargin(varargin, 'saveSingleImages', 0);
showParentID                = getVarargin(varargin, 'showParentID', 0);
showCellID                  = getVarargin(varargin, 'showCellID', 1);
showSideName                = getVarargin(varargin, 'showSideName', 1);
showOutsideEmbryoFlag       = getVarargin(varargin, 'showOutsideEmbryoFlag', 1);
showMovieTag                = getVarargin(varargin, 'showMovieTag', 1);
showTrackLines              = getVarargin(varargin, 'showTrackLines', 0); %0: no track lines, 1: one colored track lines, 2: track lines with black middle stripe to distinguish paired tracks that will have the same color otherwise
showEmbryoContour           = getVarargin(varargin, 'showEmbryoContour', 0); %see also: FindEmbroContourInMaxProjection
embryoContourColor          = getVarargin(varargin, 'embryoContourColor', [.6 .6 .6]);
lineWidthTrackLines         = getVarargin(varargin, 'lineWidthTrackLines', 2.5);
showNothing                 = getVarargin(varargin, 'showNothing', 0);
showNEBD                    = getVarargin(varargin, 'showNEBD', 1);
maxNumberOfNEBDLines        = getVarargin(varargin, 'maxNumberOfNEBDLines', 5);
showNEBDForNamedCellsOnly   = getVarargin(varargin, 'showNEBDForNamedCellsOnly', 1);
showFilenameIn              = getVarargin(varargin, 'showFilenameIn', 1);
ColorNamedCSOnly            = getVarargin(varargin, 'ColorNamedCSOnly', 0);
defaultCircleColor          = getVarargin(varargin, 'defaultCircleColor', []);
useDifferentLineStyleForExtendedTrackParts = getVarargin(varargin, 'useDifferentLineStyleForExtendedTrackParts', 1);
displayParameter            = getVarargin(varargin, 'displayParameter', []);
displayParameterFormat      = getVarargin(varargin, 'displayParameterFormat', '%.1f');
replaceCSPatchByCenterImage = getVarargin(varargin, 'replaceCSPatchByCenterImage', 0); %0 - no, 1 - yes, always, 2 - only if images are not zipped (make normal movie), 3 - only if images are not zipped (abort making movie)
clippingImageSource         = getVarargin(varargin, 'clippingImageSource', 'none');
openMovie                   = getVarargin(varargin, 'openMovie', 0);
trIDs                       = getVarargin(varargin, 'trIDs', []); % show only tracks with these trIDs
columnsShowAsInvalid        = getVarargin(varargin, 'columnsShowAsInvalid', {});
firstFrame                  = getVarargin(varargin, 'firstFrame', 1);
lastFrame                   = getVarargin(varargin, 'lastFrame', -1);
frameRate                   = getVarargin(varargin, 'frameRate', 10);
magnification               = getVarargin(varargin, 'magnification', 1.1);
skipFramesWhereNoCentrosomePresent = getVarargin(varargin, 'skipFramesWhereNoCentrosomePresent', 0);
csqlWhereClause             = getVarargin(varargin, 'csqlWhereClause', []);
markerRadiusColName         = getVarargin(varargin, 'markerRadiusColName', []);
my_colormap                 = getVarargin(varargin, 'colormap', []); %empty, 'green'
outputType                  = getVarargin(varargin, 'outputType', 'mov'); %'mov', 'tif'
imshowBorder                = getVarargin(varargin, 'imshowBorder', 'tight');
projectionType              = getVarargin(varargin, 'projectionType', 'max');
additionalImageSources      = getVarargin(varargin, 'additionalImageSources', {}); %list of image source types to be max-projected with the main channel
minMaxStretchlim = getVarargin(varargin, 'minMaxStretchlim', []);
if(strcmpi(projectionType, 'mean'))
    maxIntensityFactor          = getVarargin(varargin, 'maxIntensityFactor', 1.5);
else
    maxIntensityFactor          = getVarargin(varargin, 'maxIntensityFactor', 8);
end



if(nargin < 3 || isempty(filenameOut))
    [path name] = fileparts(filenameIn);
    if(replaceCSPatchByCenterImage)
        name = [name '_withInsets'];
    end
    filenameOut =  fullfile(path,[name '.' outputType]);
end

if(exist('skipIfFileoutExists','var') && skipIfFileoutExists && exist(filenameOut, 'file'))
    return
end


deleteFileIfExists(filenameOut);

clippingRadius = 2*ceil(param.r2/param.resolution);
clippingSize   = [2*clippingRadius+1, 2*clippingRadius+1];
saveClippings  = ~strcmpi(clippingImageSource, 'none');
if(replaceCSPatchByCenterImage)
    clippingImageSource = 'centerImg';
end

if(saveClippings)
    [path name] = fileparts(filenameIn);
    dirOutClippings = [path filesep 'trackClippings_' name];
    ensureEmptyDirExists(dirOutClippings);
end

[T, header] = loadList(filenameIn);
try
    [T, header] = ComputeTimeRelativeToNEBD(T, header);
    normTimeColIdx  = headerIndex(header,'normTime','none' );
    
    [T,header] = ComputeDerivedParameters(T,header);
catch
end

if(~isempty(csqlWhereClause))
    [ColnameOpValue, LogicConnector]  = csql_parseWhereClause(csqlWhereClause);
    exprWhere = csql_makeWhereExpression(ColnameOpValue, LogicConnector);
    expr = sprintf('T = T(%s,:)',exprWhere);
    evalc(expr);
end

NEBDColIdx              = headerIndex(header,'NEBD','none' );
trIDColIdx              = headerIndex(header,'trID', 'none' );
trDirectionColIdx       = headerIndex(header,'trDirection', 'none' );
cellNameColIdx          = headerIndex(header,'cellName', 'none' );
sideColIdx              = headerIndex(header,'side', 'none' );
cellIDColIdx            = headerIndex(header,'cellID', 'none' );
parentTrIDColIdx        = headerIndex(header,'parentTrID', 'none' );
treeDepthColIdx         = headerIndex(header,'treeDepth' ,'none');
validColIdx             = headerIndex(header,'valid' ,'none');
collapseCLColIdx        = headerIndex(header,'collapseCL', 'none' );
outsideEmbryoFlagColIdx = headerIndex(header, 'outsideEmbryoFlag', 'none');
objIDColIdx             = headerIndex(header,'objID');
displayParameterColIdx  = headerIndex(header, displayParameter);
if(isempty(displayParameterColIdx))
    displayParameterColIdx = 0;
end
if(isempty(markerRadiusColName))
    markerRadiusColIdx = -1;
else
    markerRadiusColIdx = headerIndex(header, markerRadiusColName, 'none');
end
if(isempty(columnsShowAsInvalid))
    columnsShowAsInvalidColIdx = [];
else
    columnsShowAsInvalidColIdx = headerIndex(header, columnsShowAsInvalid, 'none');
    columnsShowAsInvalidColIdx = columnsShowAsInvalidColIdx(columnsShowAsInvalidColIdx>0);
end

if(~isempty(T))
    T = sortrows(T, 4); %sort by time ==> important, because the movie is made frame by frame, not track by track
end

if(strcmpi(projectionType, 'max'))
    maxPrj = loadMaxProjection();
elseif(strcmpi(projectionType, 'mean'))
    maxPrj = loadMeanProjection();
else
    error('unknown projection type: %s', projectionType)
end

if(showEmbryoContour)
    [embryoMask, fn_embryoMask, embryoContourCoordinates] = loadEmbryoMask('original:contour coordinates');
    clear 'embryoMask';
end

for i = 1 : length(additionalImageSources)
    try
        setImageSource('type', additionalImageSources{i});
        maxPrj_dapi  = loadMaxProjection();
        for t = 1 : size(maxPrj,3)
            maxPrj(:,:,t) = max(maxPrj(:,:,t), maxPrj_dapi(:,:,t));
        end
    catch ME
        fprintf('catched the following error:\n');
        fprintf('----------------------------\n');
        printDebugStack(ME);
    end
end

if(~isempty(minMaxStretchlim))
    LOW_HIGH = stretchlim(maxPrj(:,:,ceil(size(maxPrj,3)/2)),minMaxStretchlim);
    minI = LOW_HIGH(1);
    maxI = LOW_HIGH(2);
else    for i = 1 : 5 : size(maxPrj,3)
        borderWidth = 30;
        meanBorderIntensity(i) = mean(IntensitiesAtBorders(maxPrj(:,:,i), borderWidth));
    end
    minI = 2*mean(meanBorderIntensity(:)); %min(maxPrj(:));
    maxI = max(minI*1.1,mean(maxPrj(:))*maxIntensityFactor);
end

if(markerRadiusColIdx <= 0)
    radius  = ceil(param.r2/param.resolution);
    circ0   = plot_circle(0,0,radius,'bresenham');
else
    if(any(T(:,markerRadiusColIdx) > 100))
        factor_markerRadius = param.resolution;
    else
        factor_markerRadius = 1;
    end
end
fig1 = figure;

if(trIDColIdx > 0 && ~isempty(T))
    uniqueTrID = unique(T(:,trIDColIdx));
else
    uniqueTrID = [];
end

uniqueTimes = unique(T(:,4));
isTracked = trIDColIdx > 0 && (length(uniqueTimes)== 1 || length(uniqueTrID) < size(T,1));
clippings = cell(1,length(uniqueTrID));

if(strcmpi(outputType, 'mov'))
    InitMovie(filenameOut,magnification*[size(maxPrj,2),size(maxPrj,1)],frameRate);
else
    setFigureSize( fig1, magnification*[size(maxPrj,2),size(maxPrj,1)]);
end
if(lastFrame <= 0)
    lastFrame = size(maxPrj,3);
end

if(ischar(my_colormap) && strcmpi(my_colormap, 'green'))
    N = 256;
    map_green(:,2) = [0:(N-1)]' / (N-1);
    map_green(:,1) = 0;
    map_green(:,3) = 0;
    
    my_colormap = map_green;
    circ_colors = {'w',[.6 .6 1.0],'m',[.2 .2 1.0], 'r', [1.0 .63 0]};
else
    circ_colors = {'y','w','c','m','g',[.3 .3 1.0]};
end

lastFrame = min(lastFrame, size(maxPrj,3));
for t = firstFrame : lastFrame
    if(~isempty(T))
        R = T(T(:,4) == t,:);
    else
        R = [];
    end
    if(skipFramesWhereNoCentrosomePresent && isempty(R))
        continue;
    end
    I = maxPrj(:,:,t);
    clf(fig1)
    if(replaceCSPatchByCenterImage)
        I0 = zeros(size(maxPrj,1),size(maxPrj,2));
    end
    for i = 1 : size(R,1)
        if(isTracked)
            trID = R(i,trIDColIdx);
            if(~isempty(trIDs) && ~any(trIDs==trID))
                continue;
            end
        else
            trID = R(i,objIDColIdx);
        end
        x = R(i,1);
        y = R(i,2);
        z = R(i,3);
        
        if(~strcmpi(clippingImageSource, 'none'))
            if(strcmpi(clippingImageSource, 'maxPrj'))
                img = I;
            elseif(strcmpi(clippingImageSource, 'centerImg'))
                %replaceCSPatchByCenterImage: 1 - always, 2 - only if
                %images are not zipped (make normal movie), 3 - only if images are not zipped (abort making movie)
                img = loadImages(z,t, 'returnEmptyIfImagesAreZipped',replaceCSPatchByCenterImage>1);
                if(isempty(img))
                    if(replaceCSPatchByCenterImage==2) %only if images are not zipped (make normal movie)
                        fprintf('not replacing centrosomes patch by center image. images are zipped\n');
                        img = I;
                    elseif(replaceCSPatchByCenterImage==3) %only if images are not zipped (abort making movie)
                        fprintf('aborting making tracking movie. images are zipped\n');
                        return
                    end
                end
            else
                error(['unknown clipping image source: ' clippingImageSource] );
            end
            
            [clipping, idxROI] = imcropCentered3(img,round([y,x]),clippingRadius);
            if(replaceCSPatchByCenterImage)
                patchMaxPrj = I(idxROI(1):idxROI(2),idxROI(3):idxROI(4));
                avgIntMaxPrj = medianIntensityAtBorders(patchMaxPrj,2);
                avgIntCntImg = medianIntensityAtBorders(clipping,2);
                clippingAdjusted = clipping*(avgIntMaxPrj/avgIntCntImg);
                I0(idxROI(1):idxROI(2),idxROI(3):idxROI(4)) = max(I0(idxROI(1):idxROI(2),idxROI(3):idxROI(4)), clippingAdjusted);
            end
            
            if(saveClippings)
                clipping_embedded = embedMatrix(clipping, clippingSize);
                idx_TrID = find(uniqueTrID==trID);
                stack = clippings{idx_TrID};
                stack(:,:,end+1) = clipping_embedded;
                clippings{idx_TrID} = stack;
            end
        end
    end
    if(replaceCSPatchByCenterImage)
        I1 = I;
        I1(I0>0) = I0((I0>0));
        I = max(I,I1);
    end
    
    
    
    imshow(I,[minI,maxI],'Border',imshowBorder,'InitialMagnification','fit');
    if(~isempty(my_colormap))
        colormap(my_colormap);
    end
    hold on
    
    if(showEmbryoContour)
        C = embryoContourCoordinates{t};
        plot(C(:,2),C(:,1), '-', 'Color', embryoContourColor);
    end
    
    if(trIDColIdx > 0)
        R = sortrows(R, trIDColIdx);
    end
    if(cellIDColIdx>0)
        cellIDCounter = zeros(max(R(:,cellIDColIdx)),1); %counter for how often a cellID has been touched, used for track line drawing
    end
    
    for i = 1 : size(R,1)
        if(isTracked)
            trID = R(i,trIDColIdx);
            if(~isempty(trIDs) && ~any(trIDs==trID))
                continue;
            end
        else
            trID = R(i,objIDColIdx);
        end
        objID = R(i,objIDColIdx);
        x = R(i,1);
        y = R(i,2);
        
        if(markerRadiusColIdx > 0)
            radius  = R(i,markerRadiusColIdx) / factor_markerRadius;
            circ0   = plot_circle(0,0,radius,'bresenham');
        end
        circ = circ0;
        circ(:,1) = circ0(:,1) + x;
        circ(:,2) = circ0(:,2) + y;
        success_cellName = 0;
        
        if(isempty(defaultCircleColor))
            circ_color = circ_colors{mod(trID,length(circ_colors))+1};
        else
            circ_color = defaultCircleColor;
        end
        
        
        
        
        if(cellNameColIdx > 0)
            try
                numCellName = R(i,cellNameColIdx);
                cellID      = R(i,cellIDColIdx);
                numSideName = R(i,sideColIdx);
                if(cellID > 0)
                    circ_color  = circ_colors{mod(cellID-1,length(circ_colors))+1};
                else
                    if(ColorNamedCSOnly)
                        circ_color  = [.7 .7 .7];
                        lineWidthTrackLines = 1.5;
                    else
                        circ_color  = circ_colors{mod(trID-1,length(circ_colors))+1};
                    end
                end
                cellName    = numericCellnameToCellname(numCellName);
                sideName    = numericSidenameToSidename(numSideName);
                
                if(showTrID==1)
                    idText      = [cellName sprintf(' (%s)\n(%d)',sideName(1), trID)];
                elseif(showObjID==1)
                    idText      = [cellName sprintf(' (%s) [%d]',sideName(1), objID)];
                else
                    if(showSideName)
                        idText      = [cellName sprintf(' (%s)',sideName(1))];
                    else
                        idText      = cellName;
                    end
                end
                if(~showNothing)
                    text(x+radius+3,y,idText,'color',circ_color);
                end
                success_cellName = 1;
            catch
                %printDebugStack(lasterror)
                success_cellName = 0;
            end
        end
        if(~showNothing)
            
            if(~success_cellName)
                if(displayParameterColIdx > 0)
                    text(x-5,y+radius+8,sprintf(displayParameterFormat,R(i,displayParameterColIdx)),'color',circ_color);
                end
                if(showTrID>=1)
                    if(showObjID)
                        text(x+radius+3,y-3,sprintf('%d\n[%d]',trID,objID),'color',circ_color,'FontSize',8);
                    else
                        text(x+radius+3,y,sprintf('%d',trID),'color',circ_color);
                    end
                else
                    if(showObjID)
                        text(x+radius+3,y,sprintf('%d',objID),'color',circ_color);
                    end
                end
            else
                if(displayParameterColIdx > 0)
                    text(x-5,y+radius+8,sprintf(displayParameterFormat,R(i,displayParameterColIdx)),'color',circ_color);
                else
                    if(showObjID)
                        if(showTrID)
                            text(x-5,y+radius+8,sprintf('obj = %d',objID),'color',circ_color);
                        else
                            text(x+radius+3,y,sprintf('%d',objID),'color',circ_color);
                        end
                    end
                end
                
            end
        end
        if(cellIDColIdx>0 && showCellID && ~showNothing)
            text(x-radius-10,y-5,sprintf('%d',R(i,cellIDColIdx)),'color',circ_color);
        end
        if(parentTrIDColIdx>0 && showParentID && ~showNothing)
            text(x-5,y-radius-8,sprintf('p = %d',R(i,parentTrIDColIdx)),'color',circ_color);
        end
        
        
        lineStyle = '-';
        if(collapseCLColIdx > 0 && R(i,collapseCLColIdx) > 0)
            lineStyle = ':';
        end
        if(useDifferentLineStyleForExtendedTrackParts)
            if(trDirectionColIdx > 0 && R(i,trDirectionColIdx) == -1)
                lineStyle = ':';
            end
            if(trDirectionColIdx > 0 && R(i,trDirectionColIdx) == +1)
                lineStyle = '-.';
            end
            if(trDirectionColIdx > 0 && R(i,trDirectionColIdx) == +2)
                lineStyle = '--';
            end
        end
        if(validColIdx > 0 && R(i,validColIdx) == 0 || ~isempty(columnsShowAsInvalidColIdx) && any(R(i,columnsShowAsInvalidColIdx)==0))
            circ_color = [.5 .5 .5];
            lineStyle = ':';
        end
        if(~showNothing)
            if(showObjects)
                plot(circ(:,1),circ(:,2), lineStyle,'LineWidth',1.2, 'Color', circ_color);
            end
            if(showOutsideEmbryoFlag && outsideEmbryoFlagColIdx > 0 && R(i,outsideEmbryoFlagColIdx) > 0)
                plot(x,y-radius, 'rx','MarkerSize',9);
            end
        end
        if(showTrackLines && ~showNothing)
            Rprev = T(T(:,4) <= t & T(:,trIDColIdx) == trID,:);
            if(size(Rprev, 1) > 1)
                plot(Rprev(:,1),Rprev(:,2), '-', 'Color', circ_color, 'LineWidth', lineWidthTrackLines);
                if(cellIDColIdx > 0 && showTrackLines==2)
                    cellID = Rprev(1, cellIDColIdx);
                    if(cellID > 0)
                        if(cellIDCounter(cellID) > 0)
                            if(lineWidthTrackLines > 1)
                                plot(Rprev(:,1),Rprev(:,2), '-', 'Color', 'k', 'LineWidth', 1);
                            else
                                warning('cannot middle stripe in track line, because the track line has only width = 1');
                            end
                        end
                        cellIDCounter(cellID) = cellIDCounter(cellID) + 1;
                    end
                end
                plot(Rprev(:,1),Rprev(:,2), '.', 'Color', 'k', 'MarkerSize',3);
            end
        end
    end
    
    strTime = sprintf('frame# %d',t);
    if(~isempty(R) && ~showNothing)
        if(normTimeColIdx>0 && showNEBD)
            
            %             strTime = sprintf('%d sec (relative to NEBD)',R(1,normTimeColIdx));
            if(cellNameColIdx > 0)
                colIdxCells = cellNameColIdx;
            else
                colIdxCells = cellIDColIdx;
            end
            uniqueCellID = unique(R(:,colIdxCells));
            cnt = 0;
            for cellID = uniqueCellID'
                cnt = cnt + 1;
                C = R( find(R(:,colIdxCells) == cellID,1,'first'), :);
                if(cellNameColIdx <= 0 || showNEBDForNamedCellsOnly && C(cellNameColIdx) <= 0)
                    continue;
                end
                normTime = C(normTimeColIdx);
                frNEBD   = C(NEBDColIdx);
                if(cnt <= maxNumberOfNEBDLines)
                    strTime = [strTime sprintf('\n%03d sec (NEBD in %s at fr# %d)',normTime, getCellIdentifier(C,header),frNEBD)];
                else
                    if(cnt == maxNumberOfNEBDLines+1)
                        strTime = [strTime sprintf('\n...')];
                    else
                        break
                    end
                end
            end
        else
            strTime = [strTime sprintf('\n%.0f sec',(R(1,4)*param.frameInterval))];
        end
    end
    strTime = fillUpWithNewLines(strTime, 8);
    text(10,80,strTime,'Color',[.8 .8 .8]);
    
    try
        strInfo = '';
        if(displayParameterColIdx>0)
            strInfo = [strInfo sprintf('%s\n', strrep(displayParameter,'_','\_'))];
        else
            strInfo = [strInfo sprintf('\n')];
        end
        if(showMovieTag)
            strInfo = [strInfo sprintf('%s\n',strrep(param.tag,'_','\_'))];
        else
            strInfo = [strInfo sprintf('\n')];
        end
        if(~showNothing && showFilenameIn)
            strInfo = [strInfo sprintf('%s\n',strrep(getFilenameWithoutExtension(filenameIn),'_','\_'))];
        else
            strInfo = [strInfo sprintf('\n')];
        end
        
        
        text(5,size(maxPrj,1)-20,strInfo,'FontSize',9, 'Color','white');
    catch
    end
    figure(fig1);
    if(strcmpi(outputType, 'mov'))
        MakeQTMovie('addfigure',fig1);
    elseif(strcmpi(outputType, 'tif'))
        Iscreen = frame2im(getframe());
        imwrite(Iscreen, filenameOut, 'Compression', 'none', 'WriteMode', 'append');
    end
    
    
    
    if(saveSingleImages)
        fn = [workingDir filesep 'trackingMovies' filesep getFilenameWithoutExtension(filenameOut) sprintf('_t=%03d.fig',t)];
        ensureDirExists(fn);
        saveas(fig1, fn);
    end
end
if(strcmpi(outputType, 'mov'))
    FinishMovie();
end
close(fig1);

if(saveClippings)
    for i = 1 : length(clippings)
        stack = clippings{i};
        stack = stack(:,:,2:end);
        fn = [dirOutClippings filesep sprintf('clipping_trID=%03d.tif',uniqueTrID(i))];
        WriteStackAsMultiTIFF(im2uint16(stack),fn);
    end
end

if(openMovie)
    winopen(filenameOut);
end

end

function str = fillUpWithNewLines(str, N_lines)
% adds empty lines to the given string such that the total number of lines equals N_lines
nl = sprintf('\n');
cnt = length(strfind(str, nl))+1;

for i = 1 : (N_lines-cnt)
    str = [str nl];
end
end

function avgI = meanIntensityAtBorders(img, borderWidth)
%computes the mean intensity of the pixels at the image border with
%given border width

if(nargin < 2)
    borderWidth = 1;
end
%top border
border = img(1:borderWidth,1:end);
sumI   = sum(border(:));
n      = numel(border);

%bottom border
border = img(end-borderWidth+1:end,1:end);
sumI   = sumI + sum(border(:));
n      = n + numel(border);

%left border
border = img(borderWidth+1:end-borderWidth,1:borderWidth);
sumI   = sumI + sum(border(:));
n      = n + numel(border);

%right border
border = img(borderWidth+1:end-borderWidth,end-borderWidth+1:end);
sumI   = sumI + sum(border(:));
n      = n + numel(border);

avgI   = sumI / n;
end

function intensities = IntensitiesAtBorders(img, borderWidth)
%computes the median intensity of the pixels at the image border with
%given border width

if(nargin < 2)
    borderWidth = 1;
end
%top border
border = img(1:borderWidth,1:end);
intensities = border(:);

%bottom border
border = img(end-borderWidth+1:end,1:end);
intensities = [intensities;border(:)];

%left border
border = img(borderWidth+1:end-borderWidth,1:borderWidth);
intensities = [intensities;border(:)];

%right border
border = img(borderWidth+1:end-borderWidth,end-borderWidth+1:end);
intensities = [intensities;border(:)];
end

function medianI = medianIntensityAtBorders(img, borderWidth)
%computes the median intensity of the pixels at the image border with
%given border width

if(nargin < 2)
    borderWidth = 1;
end
medianI = median(IntensitiesAtBorders(img, borderWidth));
end