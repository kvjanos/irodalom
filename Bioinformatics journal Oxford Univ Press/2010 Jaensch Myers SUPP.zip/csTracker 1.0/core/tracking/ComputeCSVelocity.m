function [ T_ext, header ] = ComputeCSVelocity( T, header)

global param;
trIDColIdx = headerIndex(header, 'trID');
[header, velo3DColIdx]  = addHeaderEntry(header, 'velo3D');
[header, velo2DColIdx]  = addHeaderEntry(header, 'velo2D');
[header, veloxColIdx]   = addHeaderEntry(header, 'velox');
[header, veloyColIdx]   = addHeaderEntry(header, 'veloy');
[header, velozColIdx]   = addHeaderEntry(header, 'veloz');
[header, minveloColIdx] = addHeaderEntry(header, 'minveloSingleDim');
[header, internalFrameNoColIdx] = addHeaderEntry(header, 'internalFrameNo');


T_ext = [];
resVector = [param.resolution,param.resolution,param.zResolution];
trIDs = unique(T(:,trIDColIdx));

T(:,velo3DColIdx) = 0;
T(:,velo2DColIdx) = 0;
T(:,veloxColIdx) = 0;
T(:,veloyColIdx) = 0;
T(:,velozColIdx) = 0;
T(:,minveloColIdx) = 0;
T(:,internalFrameNoColIdx) = 0;

%ascending IDs for later re-sort
T(:,end+1) = 1 : size(T,1);
T = sortrows(T,4); %sort by time

for trID = trIDs'
    R = T(T(:,trIDColIdx) == trID,:);       
    resVectorRep = repmat(resVector, size(R,1), 1); 
    R(:,velo3DColIdx) = sqrt(sum((diff([R(1,1:3);R(:,1:3)]).* resVectorRep).^2,2)) / param.frameInterval;
    R(:,velo2DColIdx) = sqrt(sum((diff([R(1,1:2);R(:,1:2)]).* resVectorRep(:,1:2)).^2,2)) / param.frameInterval;
    R(:,veloxColIdx) = abs(diff([R(1,1);R(:,1)]).* resVectorRep(:,1)) / param.frameInterval;
    R(:,veloyColIdx) = abs(diff([R(1,2);R(:,2)]).* resVectorRep(:,2)) / param.frameInterval;
    R(:,velozColIdx) = abs(diff([R(1,3);R(:,3)]).* resVectorRep(:,3)) / param.frameInterval;
    R(:,minveloColIdx) = min(R(:,[veloxColIdx,veloyColIdx,velozColIdx]),[],2);
    R(:,internalFrameNoColIdx) = [1:size(R,1)]';
    
    T_ext = [T_ext;R];
end

T_ext = sortrows(T_ext,size(T_ext,2));
T_ext(:,end) = [];