function [T, header] = ComputeTreeDepth(T, header)
%computes for each track its depth in the tracking tree, requires field
%'parentTrID', also see parentTrack
fprintf('%s\n',mfilename); 

trIDColIdx                  = headerIndex(header, 'trID');
parentTrIDColIdx            = headerIndex(header, 'parentTrID');
[header, treeDepthColIdx]   = addHeaderEntry(header, 'treeDepth');

trID2parentTrID     = unique(T(:,[trIDColIdx,parentTrIDColIdx]),'rows');
trID2treeDepth      = [];

for i = 1 : size(trID2parentTrID,1)
    trID = trID2parentTrID(i,1);
    parentTrID = trID;
    
    depth = 0;
    while(parentTrID > 0)
        parentTrID = trID2parentTrID(trID2parentTrID(:,1) == parentTrID,2);
        depth = depth + 1;
    end
    if(parentTrID == 0)
        trID2treeDepth(end+1,:) = [trID, depth];
    else
        trID2treeDepth(end+1,:) = [trID, -1];
    end
end

if(size(trID2parentTrID,1) ~= size(trID2treeDepth,1))
    error('tree depth was not determined for all trackIDs');
end

for i = 1 : size(trID2treeDepth,1)
    trID = trID2treeDepth(i,1);
    T(T(:,trIDColIdx) == trID,treeDepthColIdx) = trID2treeDepth(i,2);
end
