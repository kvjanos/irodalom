function [theoreticalMaxVelo3D, theoreticalMaxVelo2D, fn_fig_velo3D, fn_fig_velo2D] = TheoreticalMaxVelocity( workingDir, filenameIn, fnStub_fig)
%computes theoretical maximum velocity in 2D and 3D based on the assumption
%that from one frame to the next a centrosome cannot move a greater
%distance than half the size of a cell. the number of cells is estimated from
%the maximum number of centrosomes tracked simultaneously up to the current
%frame.


%input: workingDir, filenameIn
%       fnStub_fig  - provide a filename stub such as [workingDir filesep 'theoreticalMaxVelo']
%                     to save the plots produced by this function


global param
filenameIn = initProcessingStep( workingDir, filenameIn );

if(nargin < 3)
    fnStub_fig = [];
end
if(nargin == 0)
    fnStub_fig = getFullPath([param.relPathDebug filesep 'TheoreticalMaxVelocity'], 'theoreticalMaxVelo');
end


[T, header] = loadList(filenameIn);
[T, header] = ComputeDerivedParameters(T, header);

velo2DColIdx = headerIndex(header, 'velo2D');
velo3DColIdx = headerIndex(header, 'velo3D');
trIDColIdx   = headerIndex(header, 'trID');

[uniqueT, counts]=countOccurrences(T(:,4));

N_centrosomes = runningAggregation(counts,@max);
%N_centrosomes = ceil(N_centrosomes/2)*2; %always an even number!

fig_csNumber = sfigure; plot(uniqueT, N_centrosomes, 'o-');

N_cells = ceil(N_centrosomes / 2);

% L2D = norm(param.embryoDimension(1:2)*1000);
% L3D = norm(param.embryoDimension*1000);
% theoreticalMaxVelo2D = multiplier*repmat(L2D,length(N_centrosomes),1)./N_centrosomes / param.frameInterval;
% theoreticalMaxVelo3D = multiplier*repmat(L3D,length(N_centrosomes),1)./N_centrosomes  / param.frameInterval;

L2D = max(param.embryoDimension(1:2)*1000);
L3D = max(param.embryoDimension*1000);
theoreticalMaxVelo2D = repmat(L2D,length(N_centrosomes),1)./N_cells / param.frameInterval;
theoreticalMaxVelo3D = repmat(L3D,length(N_centrosomes),1)./N_cells  / param.frameInterval;

% theoreticalMaxVelo3D(N_cells <= inf) = 150;
% theoreticalMaxVelo3D(N_cells <= 8) = 200;
% theoreticalMaxVelo3D(N_cells <= 4) = 350;
% theoreticalMaxVelo2D = theoreticalMaxVelo3D;

% a_init = param.embryoDimension(1)/2*1000;
% b_init = param.embryoDimension(2)/2*1000;
% c_init = param.embryoDimension(3)/2*1000;
% 
% V_init      = (4/3)*pi()*a_init*b_init*c_init;
% V_overTime  = V_init ./ N_cells;
% prod_t      =  (3/4)* V_overTime / pi();
% rb = a_init/b_init;
% rc = a_init/c_init;
% a_t = (prod_t*rb*rc).^(1/3);
% L3D = a_t;
% theoreticalMaxVelo3D = L3D / param.frameInterval;

% A_init      = pi()*a_init*b_init;
% A_overTime  = A_init ./ N_cells;
% prod_t      =  A_overTime / pi();
% rb = a_init/b_init;
% a_t = (prod_t*rb).^(1/2);
% L2D = 2*a_t;

% theoreticalMaxVelo2D = L2D / param.frameInterval;

% L2D = max(param.embryoDimension(1:2)*1000);
% L3D = max(param.embryoDimension(1:3)*1000);
% 
% theoreticalMaxVelo2D = repmat(L2D,length(N_centrosomes),1)./N_cells / param.frameInterval;
% theoreticalMaxVelo3D = repmat(L3D,length(N_centrosomes),1)./N_cells / param.frameInterval;


param.ap.minMaxVelo2D = 150;
param.ap.minMaxVelo3D = 150;

theoreticalMaxVelo2D = max(theoreticalMaxVelo2D, param.ap.minMaxVelo2D);
theoreticalMaxVelo3D = max(theoreticalMaxVelo3D, param.ap.minMaxVelo3D);

% ensure that each time point has an entry (there may be time points where no centrosome is tracked)
if(uniqueT(end) < param.lastTimepoint)
    uniqueT(end+1) = param.lastTimepoint;
    theoreticalMaxVelo2D(end+1) = theoreticalMaxVelo2D(end);
    theoreticalMaxVelo3D(end+1) = theoreticalMaxVelo3D(end);
end
frames = 1 : param.lastTimepoint;
if(length(frames)>1)
    theoreticalMaxVelo2D = interp1(uniqueT,theoreticalMaxVelo2D,frames,'nearest');
    theoreticalMaxVelo3D = interp1(uniqueT,theoreticalMaxVelo3D,frames,'nearest');
end

E2D = AggregateXGroupsOutlier(T(:,[4, velo2DColIdx]), @max);
E3D = AggregateXGroupsOutlier(T(:,[4, velo3DColIdx]), @max);

%% max-velocity per time point
fig_velo3D = sfigure; plot(frames, theoreticalMaxVelo3D, 'rd-');
hold on;
plot(E3D(:,1),E3D(:,2), 'k--');
title(sprintf('velocity 3D: %s', strrep(param.tag, '_', '\_')));
xlabel('frame #')
ylabel('velocity [nm/s]')
for i = 1 : length(E3D(:,1))
    t       = E3D(i,1);
    maxVelo = E3D(i,2);
    
    trID = unique(T(T(:,4) == t & T(:,velo3DColIdx) == maxVelo, trIDColIdx));
    text(t,maxVelo, sprintf('%d',trID), 'color',[.5 .5 1.0]);
end


fig_velo2D = sfigure; plot(frames, theoreticalMaxVelo2D, 'ro-'); hold on
plot(E2D(:,1),E2D(:,2), 'k--');
title(sprintf('velocity 2D: %s', strrep(param.tag, '_', '\_')));
xlabel('frame #')
ylabel('velocity [nm/s]')
for i = 1 : length(E3D(:,1))
    t       = E2D(i,1);
    maxVelo = E2D(i,2);
    
    trID = unique(T(T(:,4) == t & T(:,velo2DColIdx) == maxVelo, trIDColIdx));
    text(t,maxVelo, sprintf('%d',trID), 'color',[.5 .5 1.0]);
end

if(~isempty(fnStub_fig))
    fn_fig_velo3D = [fnStub_fig '3D.fig'];
    fn_fig_velo2D = [fnStub_fig '2D.fig'];
    fn_fig_csNumber = [fileparts(fn_fig_velo2D) filesep 'centrosome number over time.fig'];
    ensureDirExists(fn_fig_velo3D);
    saveas(fig_velo3D, fn_fig_velo3D);
    saveas(fig_velo2D, fn_fig_velo2D);
    saveas(fig_csNumber, fn_fig_csNumber);
end
end

