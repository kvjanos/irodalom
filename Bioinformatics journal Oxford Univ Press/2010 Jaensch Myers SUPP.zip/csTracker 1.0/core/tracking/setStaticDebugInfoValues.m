function setStaticDebugInfoValues()

global debugInfo__;
debugInfo__.numReasonToReason = {'radius hysteresis','no reverse match','reverse match too expensive'};

end

