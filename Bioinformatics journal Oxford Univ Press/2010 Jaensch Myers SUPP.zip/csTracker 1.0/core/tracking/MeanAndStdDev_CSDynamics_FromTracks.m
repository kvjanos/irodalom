function [ change_mean, change_stddev, differences ] = MeanAndStdDev_CSDynamics_FromTracks( T, header, colNames, relativeDifferences, zStretchingCorrection)
% mean and standard deviation for frame-to-frame-differences for each column in the same
% order as in colNames
%
% colNames must be a cell array of strings (not a single string)
% 
% input:
% colNames            = as string list like {'totalInt2D','meanSigmaXY2D','ratioRingScore', 'innerRingScore', 'gaussMult2D'};
% relativeDifferences = if true, computes the difference relative to the earlier timepoint,
%                                i.e. (f(t)-f(t+1)) / f(t) where f(t) is the feature value at time point t
%                                maybe a logical vector with length(colNames) elements or a single value
%
if(nargin < 4 || isempty(relativeDifferences))
    relativeDifferences = 0;
end
if(nargin < 5)
    zStretchingCorrection = 1.0;
end
global param;

change_mean   = zeros(1, length(colNames));
change_stddev = zeros(1, length(colNames));

if(length(relativeDifferences) == 1 && length(colNames) > 1)
    relativeDifferences = repmat(relativeDifferences, 1, length(colNames));
end

for i = 1 : length(colNames)
    colName = colNames{i};
    D = ComputeCSPropertiesDynamics( T, header, colName, relativeDifferences(i),zStretchingCorrection);
    if(isempty(D))
        change_mean   = []; 
        change_stddev = []; 
        differences   = [];
    else
    differences(:,i) = D;
    change_mean(i)   = mean(differences(:,i),1); 
    change_stddev(i) = std(differences(:,i),0,1);
    addToHistogram(differences(:,i), [param.tag ' frame-to-frame differences of ' colName]);
    end
end