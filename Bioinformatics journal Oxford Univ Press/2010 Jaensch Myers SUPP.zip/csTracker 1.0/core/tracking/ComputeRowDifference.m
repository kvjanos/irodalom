function [ D ] = ComputeRowDifference( T, colIdxSpecial, zStretchingCorrection )
%computes the difference of the columns with the specified indices
%
% D = [row(2)-row(1), row(3)-row(2), ..., row(n)-row(n-1)]
%
% index -98 stands for the 2D distance
% index -99 stands for the 3D distance
%
% see also: headerIndexSpecialPos
%

if(nargin < 3)
    zStretchingCorrection = 1.0;
end

idx = find(colIdxSpecial > 0);

D(:,idx) = diff(T(:,colIdxSpecial(idx)));

if(length(idx) < length(colIdxSpecial))
    
    idxPos2D = find(colIdxSpecial==-98);
    if(~isempty(idxPos2D))
        D(:,idxPos2D) = RealDistance(T(1:end-1,1:2),T(2:end,1:2), zStretchingCorrection);
    end
        
    idxPos3D = find(colIdxSpecial==-99);
    if(~isempty(idxPos3D))
        D(:,idxPos3D) = RealDistance(T(1:end-1,1:3),T(2:end,1:3), zStretchingCorrection);
    end
end
