function [ filenameOut ] = FilterNoiseTracks( workingDir, filenameIn, skipIfFileoutExists )


if(nargin == 0)
    workingDir = [baseDir filesep 'SPD2-GFP_WT_long5\workingDir\1'];
    workingDir = [baseDir filesep 'SPD5-YFP10_WT_multicell\workingDir\1'];
    workingDir = [baseDir filesep 'yTUB-GFP3_WT_8to16cellstage\workingDir\1'];
    filenameIn  = 'tr_trSpltInc_noOvertr.txt';
    
    workingDir = [baseDir filesep 'Histone-GFP1_WT_multicell\workingDir\2'];
    filenameIn  = 'tr.txt';
    setDebugLevel(1)
end

global param;
[filenameIn, filenameOut,dirDebug ] = initProcessingStep( workingDir, filenameIn, '*noNoiseTr',mfilename );
if(exist('skipIfFileoutExists','var') && skipIfFileoutExists && exist(filenameOut, 'file'))
    return
end
%% --------------parameter settings -----------------------------

parameters = {'meanSigmaXY2D','intensityRatio','fittedxcorrValue'};

%2xlength(parameters) matrix, first row lower threshold, second row higher
%threshold, columns corresponds to entries in array 'parameters'
thresholdMatrix         = [inf inf inf;   %low threshold:  and-connection
                          250 1.8 inf];  %high threshold: or-connection

minTrackLength           = 3;
minTrackLengthAtMovieEnd = 2;
trackLengthUnits         = 'frames';

min_Time_vs_Radius_CorrelationCoefficient = 0; % ==> object radius must increase over time
min_Time_vs_Radius_CorrelationCoefficient = -1;
averagingWindowSize = 3; %frames

[T, header] = loadList(filenameIn);
[T, header] = ComputeDerivedParameters(T, header);
colIdx      = headerIndex(header,parameters);
trIDColIdx  = headerIndex(header,'trID');
meanSigmaXY2DColIdx     = headerIndex( header, 'meanSigmaXY2D');

T = sortrows(T, [trIDColIdx, 4]); %sort by trID and time

%filter short tracks
[T, header] = FilterTracksByLength( T, header, 'minTrackLength', minTrackLength, 'minTrackLengthAtMovieEnd', minTrackLengthAtMovieEnd, 'units', trackLengthUnits );

uniqueTrIDs = unique(T(:,trIDColIdx))';
if(getDebugLevel >= 1)
    fig1 = figure; hold on;
end
fn_debug = deleteFileIfExists([dirDebug filesep 'FilteredTracks.ps']);
for trID = uniqueTrIDs
    indexIntoT = T(:,trIDColIdx) == trID;
    R = T(indexIntoT, :);
    X = R(:,colIdx);
    %     if(size(R,1) < averagingWindowSize)
    %         X = [X;repmat(X(end,:),averagingWindowSize-size(R,1),1)]; %pad last row n-times to compute a useful average
    %         %for very short tracks at the end of the movie
    %     end
    runningAvg      = runningAverage(X, min(averagingWindowSize,length(X)));
    maxValues       = max(runningAvg,[],1);
    aboveThreshold  = [maxValues;maxValues] >= thresholdMatrix; %first row:  above respective lower threshold,
                                                                %second row: above respective higher threshold
    
    allAboveLowerThreshold  = min(aboveThreshold(1,:)) == 1;
    oneAboveHigherThreshold = max(aboveThreshold(2,:)) == 1;
    
    time     = R(:,4);
    csRadius = R(:,meanSigmaXY2DColIdx);
    corrcoef_ = corrcoef([time,csRadius]);
    corrcoef_ = corrcoef_(end,1); %usually corrcoef_(end,1) means corrcoef_(2,1), but if there is only one value it indexes to corrcoef_(1,1)!
    
    if((~allAboveLowerThreshold && ~oneAboveHigherThreshold) || corrcoef_ < min_Time_vs_Radius_CorrelationCoefficient)
        T(indexIntoT,:) = [];
        sfigure(fig1);
        for i = 1 : length(colIdx)
            clf(fig1)
            plot(time, runningAvg(:,i), '-o'); hold on
            thr = thresholdMatrix(1,i);
            plot(xlim, [thr thr], '-r');
            thr = thresholdMatrix(2,i);
            plot(xlim, [thr thr], '-g');
            ylabel(sprintf([parameters{i} '(smoothed over %d frames)'],averagingWindowSize));
            
            if(strcmpi(parameters{i},'meanSigmaXY2D'))
                title(sprintf('%s, trID = %d, corrcoef = %.2f', strrep(param.tag, '_', '\_'),trID,corrcoef_))
            else
                title(sprintf('%s, trID = %d', strrep(param.tag, '_', '\_'),trID))
            end
            printFigureToPostScript(fig1, fn_debug, 1);
        end
    end
end
FindBrokenTracks( T, header );
fprintMatrix(filenameOut, T, header);
if(nargin == 0)
    showTrackingMovie(filenameOut,0)
end
end

