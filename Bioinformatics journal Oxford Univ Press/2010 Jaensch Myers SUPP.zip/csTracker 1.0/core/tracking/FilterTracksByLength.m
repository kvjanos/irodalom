function [ varargout ] = FilterTracksByLength( varargin )


if(nargin == 0)
    workingDir = [baseDir filesep 'SPD2-GFP3_WT_4to8cellstage\workingDir\9'];
    filenameIn = 'candidates3D_noTooClPlane_mexHat_GFit2D_noTooCl3D.txt';
    
    workingDir = [baseDir filesep 'SPD2-GFP2_WT_4to8cellstage\workingDir\9'];
    filenameIn = 'candidates3D_noTooClPlane_mexHat_GFit2D.txt';

        
    varargin{1} = workingDir;
    varargin{2} = filenameIn;

    varargin{end+1} = 'minTrackLength';
    varargin{end+1} = 3;
    
    varargin{end+1} = 'minTrackLengthAtMovieStart';
    varargin{end+1} = 2;

    varargin{end+1} = 'minTrackLengthAtMovieEnd';
    varargin{end+1} = 2;
    
    varargin{end+1} = 'units';
    varargin{end+1} = 'frames';
    
end
fprintf('%s\n',mfilename);

units                       = getVarargin(varargin, 'units', 'frames');
minTrackLength              = getVarargin(varargin, 'minTrackLength', 3);
minTrackLengthAtMovieStart  = getVarargin(varargin, 'minTrackLengthAtMovieStart', minTrackLength);
minTrackLengthAtMovieEnd    = getVarargin(varargin, 'minTrackLengthAtMovieEnd', minTrackLength);

global param;
[T, header, filenameIn, filenameOut] = processInput(varargin, 'noShortTr');
if(isempty(T))
    varargout{1} = filenameOut;
    return;
end

if(strcmpi(units, 'minutes'))
    minTrackLength              = floor((minTrackLength             * 60) / param.frameInterval);
    minTrackLengthAtMovieEnd    = floor((minTrackLengthAtMovieEnd   * 60) / param.frameInterval);
    minTrackLengthAtMovieStart  = floor((minTrackLengthAtMovieStart * 60) / param.frameInterval);
end

trIDColIdx = headerIndex(header, 'trID');

%determine track lengths
[uniqueTrIDs, trackLengths]     = countOccurrences(T(:,trIDColIdx));
[uniqueTrIDs2_TrackEnds]        = AggregateXGroups(T(:,trIDColIdx),T(:,4),@max);
[uniqueTrIDs2_TrackStarts]      = AggregateXGroups(T(:,trIDColIdx),T(:,4),@min);

%filter short tracks
tracksLongEnoughIdx = trackLengths >= minTrackLength | (uniqueTrIDs2_TrackEnds(:,2) == param.lastTimepoint & trackLengths >= minTrackLengthAtMovieEnd) | (uniqueTrIDs2_TrackStarts(:,2) == 1 & trackLengths >= minTrackLengthAtMovieStart);
T = T(ismember(T(:,trIDColIdx),uniqueTrIDs(tracksLongEnoughIdx)),:);

if(isempty(filenameOut))
    varargout{1} = T;
    varargout{2} = header;
else
    fprintMatrix(filenameOut, T, header);
    varargout{1} = filenameOut;
end