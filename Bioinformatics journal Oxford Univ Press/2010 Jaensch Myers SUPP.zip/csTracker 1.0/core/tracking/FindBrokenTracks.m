
function FindBrokenTracks( varargin )
%
% syntax: FindBrokenTracks(workingDir, filenameIn)
%         FindBrokenTracks(workingDir, filenameIn, 'warning')
%         FindBrokenTracks(workingDir, filenameIn, 'error')
%         FindBrokenTracks(T, header)
%         FindBrokenTracks(T, header, 'warning')
%         FindBrokenTracks(T, header, 'error')

if(nargin == 0)
    workingDir = [baseDir filesep 'yTUB-GFP1_WT_8cellstage\workingDir\1'];
    filenameIn = 'tr_newZScoreRel_trSpltInc_noOvertr_noNoiseTr_extTr_noOvertr.txt';
    filenameIn = 'tr_newZScoreRel_trSpltInc_noOvertr_noNoiseTr_extTr_noOvertr_joinTr.txt';
    filenameIn = 'tr_newZScoreRel_trSpltInc_noOvertr_noNoiseTr_extTr_noOvertr_joinTr.txt';
    
    varargin{1} = workingDir;
    varargin{2} = filenameIn;
    varargin{3} = 'warning';
end

if(ischar(varargin{1}))
    workingDir = varargin{1};
    filenameIn = addDirectoryToFilename(workingDir,varargin{2});
    [T, header] = loadList(filenameIn);
else
    T = varargin{1};
    header = varargin{2};
end

if(length(varargin) > 2)
    errorOrWarning = varargin{3};
else
    errorOrWarning = 'warning';
end

func = str2func(errorOrWarning);

trIDColIdx = headerIndex(header, 'trID');
uniqueTrIDs = unique(T(:,trIDColIdx));

for trID = uniqueTrIDs'
    R = T(T(:,trIDColIdx) == trID, :);
    R = sortrows(R, 4); %sort by time
    diffTime = diff(R(:,4));
    breaks = find(diffTime - 1 > 1);
    if(~isempty(breaks))
        for i = 1 : length(breaks)
            func('there is a break in track %d at frame #%d',trID, R(breaks(i),4));
        end
    end
    doubleAssignments = find(diffTime == 0);
    if(~isempty(doubleAssignments))
        for i = 1 : length(doubleAssignments)
            func('there is a double assignment in track %d at frame #%d',trID, R(doubleAssignments(i),4));
        end
    end
end