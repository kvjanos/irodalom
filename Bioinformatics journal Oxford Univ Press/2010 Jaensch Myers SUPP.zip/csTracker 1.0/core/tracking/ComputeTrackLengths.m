function T = ComputeTrackLengths(T, trIDColIdx, trLengthColIdx)
    [uniqueTrIDs, TrIDCount] = countOccurrences(T(:,trIDColIdx));
    if(uniqueTrIDs(1) == -1)
        TrIDCount(1) = 1;
    end

    for i = 1 : size(T,1)
        T(i, trLengthColIdx) = TrIDCount(uniqueTrIDs(:) == T(i,trIDColIdx));
    end
end