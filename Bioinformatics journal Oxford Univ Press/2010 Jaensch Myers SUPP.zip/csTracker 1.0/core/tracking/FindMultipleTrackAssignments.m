function FindMultipleTrackAssignments( T_or_workingDir, header_or_filenameIn, displayColumns, errorOrWarning )
%FINDMULTIPLETRACKASSIGNMENTS finds multiple occurring objIDs

if(nargin < 3)
    displayColumns = {};
end
if(nargin < 4)
    errorOrWarning = 'warning';
end

if(ischar(T_or_workingDir))
    workingDir = T_or_workingDir;
    filenameIn = header_or_filenameIn;
    filenameIn = addDirectoryToFilename(workingDir, filenameIn);
    [T, header] = loadList(filenameIn);
else
    T       = T_or_workingDir;
    header  = header_or_filenameIn;
end

objIDColIdx = headerIndex(header, 'objID');

displayColumns  = [{'objID' 'trID' } displayColumns];
displayColIdx   = headerIndex(header, displayColumns, 'none');
displayColumns  = displayColumns(displayColIdx>0);
displayColIdx   = displayColIdx(displayColIdx>0);

[uniqueObjID, count] = countOccurrences(T(:,objIDColIdx));
index = count>1;
multipleOccurringObjIDs = uniqueObjID(index);

if(~isempty(multipleOccurringObjIDs))
    if(strcmpi(errorOrWarning,'error'))
        fprintf(sprintf('The following objIDs occur multiple times:'));
        fprintf('%s\n',strList2SeparatedString(displayColumns, sprintf('\t')));
        T(ismember(T(:,objIDColIdx),multipleOccurringObjIDs),displayColIdx)
        error('multiple track assignments found. see error message above');
    else
        warning(sprintf('The following objIDs occur multiple times:'));
        fprintf('%s\n',strList2SeparatedString(displayColumns, sprintf('\t')));
        T(ismember(T(:,objIDColIdx),multipleOccurringObjIDs),displayColIdx)
    end
end