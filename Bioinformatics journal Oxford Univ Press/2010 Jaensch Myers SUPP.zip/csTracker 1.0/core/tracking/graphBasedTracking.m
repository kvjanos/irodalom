function [ filenameOut ] = graphBasedTracking( workingDir, filenameIn, objectsNotToBeRejected, objectsToBeRejected, theoreticalMaxVelo3D, theoreticalMaxVelo2D, skipIfFileoutExists, opName, intensityRatios_, alphas_, conflictResolvingStrategy_, dimmerObjectSuppressionRange_ )
fprintf('%s\n',mfilename);
%also see: extendTracks, extractMainTrajectories

if(nargin < 3)
    objectsNotToBeRejected = [];
end
if(nargin < 4)
    objectsToBeRejected    = [];
end
if(nargin < 5)
    theoreticalMaxVelo3D   = [];
end

global param;

if(~exist('opName','var'))
    opName = 'tr';
end

[filenameIn, filenameOut, dirDebug ] = initProcessingStep( workingDir, filenameIn, ['>' opName], ['*' mfilename] ); %the '>' symbol means: start new filename instead of appending the op-name
if(exist('skipIfFileoutExists','var') && skipIfFileoutExists && exist(filenameOut, 'file'))
    return
end

%% algorithm parameters
minTrackLength          = 5; %use only tracks that are at least this long (in number of frames) to compute the spatial and appearance distance statistics
useRelativeDifferences  = 1; %use "(f1-f2) / min(f1,f2)" as appearance distance measure
radiusHysteresis        = param.ap.radiusHysteresis; %[300 350];

strategyForRemovingRadiusHysteresisEdges = 'beforeBipartiteMatching'; % 'optimal','beforeBipartiteMatching','afterBipartiteMatching'
conflictResolvingStrategy       = 'noConflictEdges'; %'combinedOnly', 'distanceOnly', 'minRadiusVariance', 'noConflictEdges'

intensityRatios                 = 1.5 : .05 : 2.0;
alphas                          =  .4 : .1 : .9;
param.maxSpeed                  = 300;
minimizeNumberOfTracks          = 0; %selects among the minimum conflict configuration with highest alpha the one with minimum number of tracks
dimmerObjectSuppressionRange    = 0; %nm %suppress any dimmer object closer than 'dimmerObjectSuppressionRange'

if(exist('intensityRatios_','var') && ~isempty(intensityRatios_))
    intensityRatios = intensityRatios_;
end
if(exist('alphas_','var') && ~isempty(alphas_))
    alphas = alphas_;
end
if(exist('conflictResolvingStrategy_','var') && ~isempty(conflictResolvingStrategy_))
    conflictResolvingStrategy = conflictResolvingStrategy_;
end
if(exist('dimmerObjectSuppressionRange_','var') && ~isempty(dimmerObjectSuppressionRange_))
    dimmerObjectSuppressionRange = dimmerObjectSuppressionRange_;
end

%% velocity / max-distance settings
if(isempty(theoreticalMaxVelo3D))
    theoreticalMaxVelo3D = repmat(param.maxSpeed, 1, param.lastTimepoint);
end
if(isempty(theoreticalMaxVelo2D))
    theoreticalMaxVelo2D = repmat(param.maxSpeed, 1, param.lastTimepoint);
end
actualMaxVelo3D = min(theoreticalMaxVelo3D,param.maxSpeed);
actualMaxVelo2D = min(theoreticalMaxVelo2D,param.maxSpeed);

if(getDebugLevel() >= 1)
    fig1 = sfigure;
    plot(actualMaxVelo3D, 'o-k', 'DisplayName', '3D','LineWidth', 3), hold on
    plot(actualMaxVelo2D, 'x-r', 'DisplayName', '2D','LineWidth', 2)
    xlabel('frame #'), ylabel('velocity [nm/sec]'), legend('show')
    title(sprintf('actual max allowed velocity\n%s',strrep(param.tag,'_','\_')));
    fn_fig = [dirDebug filesep 'maxVelocity.fig'];
    saveas(fig1, fn_fig);
end

maxAllowedDistance3D = (actualMaxVelo3D * param.frameInterval);
maxAllowedDistance2D = (actualMaxVelo2D * param.frameInterval);
fprintf('maxSpeed = %.0f nm/s\nframeInterval = %f s\n',param.maxSpeed, param.frameInterval);

[T, header] = loadList(filenameIn);
[T, header] = ComputeDerivedParameters(T, header);
T = sortrows(T, 4); %sort by time

[header, trIDColIdx, columnHasBeenAdded, T ] = addHeaderEntry( header, 'trID', -1, T );
objIDColIdx             = headerIndex( header, 'objID');
intensityRatioColIdx    = headerIndex( header, 'intensityRatio');
meanSigmaXY2DColIdx     = headerIndex( header, 'meanSigmaXY2D');

csAppearanceParameterForConflicts       = 'meanSigmaXY2D';
csAppearanceParameterForConflictsColIdx = headerIndex(header,csAppearanceParameterForConflicts);

csAppearanceParameter           = {'meanSigmaXY2D','totalInt2D'};
csAppearanceWeights             = [     1               1      ];
csAppearanceWeights             = csAppearanceWeights' / sum(csAppearanceWeights);
csAppearanceParameterColIdx     = headerIndex(header,csAppearanceParameter);

[header, trLengthColIdx] = addHeaderEntry( header, 'trLength' );
[header, trDirectionColIdx, columnHasBeenAdded, T] = addHeaderEntry( header, 'trDirection', 0, T );

T_org = T;

if(~isfield(param,'rejectOutsideEmbryoCandidates') || param.rejectOutsideEmbryoCandidates)
    outsideEmbryoFlagColIdx = headerIndex(header, 'outsideEmbryoFlag', 'none');
    if(outsideEmbryoFlagColIdx > 0)
        T_org = T_org(T_org(:,outsideEmbryoFlagColIdx) == 0,:);
    end
end

%suppress any dimmer near-by object
if(dimmerObjectSuppressionRange>0)
    [T_org, header] = FilterDenselySpacedObjects( T_org, header, 'qualityColName', 'intensityRatio', 'd0', dimmerObjectSuppressionRange, 'n0', 0);
end

conflictCount = zeros(length(intensityRatios),length(alphas));
trackCount    = zeros(length(intensityRatios),length(alphas));
FinalMatchingGraph = cell(length(intensityRatios),length(alphas));

intensityRatioIdx = 0; %note, this is not the column index of "intensityRatio", but the index for the intensityRatios array
candidates = {};

for intensityRatio = intensityRatios
    alpha = 0;
    intensityRatioIdx = intensityRatioIdx + 1;
    
    T = T_org(T_org(:,intensityRatioColIdx) >= intensityRatio | ismember(T_org(:,objIDColIdx), objectsNotToBeRejected),:);
    T = T(~ismember(T(:,objIDColIdx), objectsToBeRejected),:);
    if(isempty(T))
        conflictCount(intensityRatioIdx,:)  = 8888888;
        trackCount(intensityRatioIdx,:)     = 0;
        continue
    end
    %     T(:,rowIdxColIdx)   = 1:size(T,1);
    T(:,trIDColIdx)     = 1:size(T,1);
    candidates{intensityRatioIdx} = T;
    N = size(T,1)
    minIntensityRatio = min(T(:,intensityRatioColIdx))
    
    tChangeIndices = computeTchangeIndices(T);
    frameCount = size(tChangeIndices,1);
    
    DAG_spatialDist = cell(1, frameCount-1);
    
    %build the DAG
    for i = 1 : frameCount-1
        thisFirstIndex = tChangeIndices(i,1);
        thisLastIndex =  tChangeIndices(i,2);
        nextFirstIndex = tChangeIndices(i+1,1);
        nextLastIndex  = tChangeIndices(i+1,2);
        
        A = thisFirstIndex:thisLastIndex;
        B = nextFirstIndex:nextLastIndex;
        G_spatialDist = ones(length(A), length(B)) * inf;
        
        for a = 1: length(A)
            h = A(a);

            for b = 1:length(B)
                k = B(b);
                dist3D = RealDistance(T(h,1:3),T(k,1:3));
                dist2D = RealDistance(T(h,1:2),T(k,1:2));
                if(T(k,4)-T(h,4) == 1 && dist3D <= maxAllowedDistance3D(i) && dist2D <= maxAllowedDistance2D(i))
                    G_spatialDist(a,b) = RealDistance(T(h,1:3),T(k,1:3),1);
                end
            end
        end
        
        DAG_spatialDist{i}.G = G_spatialDist;
        DAG_spatialDist{i}.S = A; %row index in T for the sources
        DAG_spatialDist{i}.T = B; %row index in T for the targets
    end
    
    if(getDebugLevel() >= 1)
        labelsAll  = cell(1,size(T,1));
        for ii = 1 : size(T,1)
            labelsAll{ii} = sprintf('%d (%d)\n(%.2f)', T(ii,objIDColIdx),ii, T(ii,csAppearanceParameterColIdx));
        end
        if(getDebugLevel() >= 2)
            if(frameCount <= 15)
                figure,drawMultiPartiteGraph(DAG_AdjMatrix, tChangeIndices,labelsAll, DAG_spatialDist);
                title(sprintf('spatial distance DAG'));
                
                %             figure,drawMultiPartiteGraph(DAG_AdjMatrix, tChangeIndices,labelsAll, DAG_appearanceChange);
                %             title(sprintf('intensity distance DAG'));
            end
        end
    end
    
    GlobalMatchingGraph_distanceOnly = TrackingByBipartiteMatching(DAG_spatialDist);
    
    if(getDebugLevel() >= 2 && frameCount <= 15)
        figure,drawMultiPartiteGraph(GlobalMatchingGraph_distanceOnly, tChangeIndices,labelsAll);
        title(sprintf('global matching graph, distance-only based'));
    end
    
    T(:,trIDColIdx) = AssignTrackIDs(GlobalMatchingGraph_distanceOnly, size(T,1));
    T = ComputeTrackLengths(T, trIDColIdx, trLengthColIdx);
    
    [T, header] = ComputeCSVelocity(T, header);
    
    if(getDebugLevel() >= 2)
        fn = [dirDebug filesep sprintf('tracks_spatialDistanceOnly_intRatio=%.2f.txt',intensityRatio)];
        fprintMatrix(fn, T, header);
        if(getDebugLevel() >= 2)
            makeTrackingMovie(workingDir, fn, [], 0, 'showObjID', 1, 'showTrID', 1);
        end
    end
    
    %filter out noise tracks
    T_tracked = T(T(:,trLengthColIdx)>=minTrackLength,:);
    if(isempty(T_tracked))
        T_tracked = T(T(:,trLengthColIdx)>=3,:);
        if(isempty(T_tracked))
            warning('No tracks with at least %d timepoints founds. Means and standard deviations cannot be computed.', minTrackLength);
            penaltyConflictCnt = 10000;
        else
            warning('No tracks longer than %d found. Means and standard deviations will be computed from all tracks with at least 3 time points',minTrackLength);
            penaltyConflictCnt = 1000;
        end
    else
        penaltyConflictCnt = 0;
    end
    if(~isempty(T_tracked))
        %% compute mean appearance change of the (almost correctly) tracked centrosomes
        [mean_CSAppearanceChange, stddev_CSAppearanceChange]  = MeanAndStdDev_CSDynamics_FromTracks(T_tracked, header, csAppearanceParameter, useRelativeDifferences );
        [mean_pos3DChange, stddev_pos3DChange]  = MeanAndStdDev_CSDynamics_FromTracks(T_tracked, header, {'pos3D'} , 0 );
        
        %% build the centrosome appearance change DAG
        
        DAG_appearanceChange_normalized = DAG_spatialDist;
        DAG_spatialDist_normalized      = DAG_spatialDist;
        for i = 1 : frameCount-1
            G = DAG_spatialDist{i}.G;
            A = DAG_spatialDist{i}.S;
            B = DAG_spatialDist{i}.T;
            
            G_appearanceChange_normalized = ones(size(G)) * inf;
            G_spatialDist_normalized      = ones(size(G)) * inf;
            
            for a = 1: length(A)
                h = A(a);
                for b = 1:length(B)
                    k = B(b);
                    if(G(a,b) < inf)
                        csAppearanceChange = (T(k,csAppearanceParameterColIdx)-T(h,csAppearanceParameterColIdx)); %it must be later timepoint - earlier point, not vice versa!!! compare with how 'diff' computes differences
                        if(useRelativeDifferences)
                            csAppearanceChange = csAppearanceChange ./ min(T(h,csAppearanceParameterColIdx),T(k,csAppearanceParameterColIdx));
                        end
                        G_appearanceChange_normalized(a,b) = abs((csAppearanceChange - mean_CSAppearanceChange) ./ stddev_CSAppearanceChange) * csAppearanceWeights;
                        csPositionChange = RealDistance(T(k,1:3), T(h,1:3));
                        G_spatialDist_normalized(a,b) = csPositionChange ./ stddev_pos3DChange;
                        
                    end
                end
            end
            DAG_appearanceChange_normalized{i}.G = G_appearanceChange_normalized;
            DAG_spatialDist_normalized{i}.G      = G_spatialDist_normalized;
        end
        
        
        
        %% track again using combined weights with different weighting factors
        alphaIdx = 0;
        for alpha = alphas
            alphaIdx = alphaIdx + 1;
            fprintf('alpha = %f\n',alpha);
            
            %combine normalized measures (z-score)
            DAG_combinedWeights = DAG_spatialDist_normalized;
            for i = 1 : length(DAG_spatialDist_normalized)
                G_spatialDist_normalized        = DAG_spatialDist_normalized{i}.G;
                G_appearanceChange_normalized   = DAG_appearanceChange_normalized{i}.G;
                if(alpha==0)
                    G_combinedWeights = G_spatialDist_normalized;
                elseif(alpha == 1)
                    G_combinedWeights = G_appearanceChange_normalized;
                else
                    G_combinedWeights = (1-alpha)*G_spatialDist_normalized + alpha * G_appearanceChange_normalized;
                end
                G_combinedWeights = makeEdgeWeightsPositive(G_combinedWeights);
                DAG_combinedWeights{i}.G = G_combinedWeights;
            end
            GlobalMatchingGraph_combinedWeighted = TrackingByBipartiteMatching(DAG_combinedWeights);
            
            if(getDebugLevel() >= 2)
                T(:,trIDColIdx) = AssignTrackIDs(GlobalMatchingGraph_combinedWeighted, size(T,1));
                fn = [dirDebug filesep sprintf('tracks_combinedWeights_intRatio=%.2f_alpha=%.2f.txt',intensityRatio, alpha)];
                fprintMatrix(fn, T, header);
            end
            
            thisFinalMatchingGraph = GlobalMatchingGraph_distanceOnly; %initialize main tracks with distance-only tracking results
            if(strcmpi(conflictResolvingStrategy, 'noConflictEdges'))
                for f = 1 : frameCount-1
                    M_distanceOnly      = GlobalMatchingGraph_distanceOnly{f}.G;
                    M_combinedWeighted  = GlobalMatchingGraph_combinedWeighted{f}.G;
                    M_final             = thisFinalMatchingGraph{f}.G;
                    
                    for source = 1 : size(M_combinedWeighted,1)
                        for target = 1 : size(M_combinedWeighted,2)
                            if(xor(M_distanceOnly(source,target),M_combinedWeighted(source,target)))
                                M_final(source,target) = 0;
                                conflictCount(intensityRatioIdx,alphaIdx) = conflictCount(intensityRatioIdx,alphaIdx)+1;
                            end
                        end
                    end
                    thisFinalMatchingGraph{f}.G = M_final;
                    if(length(thisFinalMatchingGraph{f}.S) ~= size(thisFinalMatchingGraph{f}.G,1))
                        error('number of entries in S is not equal to the number of rows in G at index = %d',f);
                    end
                    if(length(thisFinalMatchingGraph{f}.T) ~= size(thisFinalMatchingGraph{f}.G,2))
                        error('number of entries in T is not equal to the number of columns in G at index = %d',f);
                    end
                end
            else
                conflict_matrix = GlobalMatchingGraph_combinedWeighted;
                for i = 1 : length(DAG_spatialDist_normalized)
                    conflict_matrix{i}.G = abs(GlobalMatchingGraph_combinedWeighted{i}.G - GlobalMatchingGraph_distanceOnly{i}.G);
                end
                
                if(getDebugLevel() >= 2 && frameCount <= 15)
                    %figure,drawMultiPartiteGraph(DAG_AdjMatrix, tChangeIndices,labelsAll, DAG_combinedWeights);
                    %title(sprintf('normalized intensity weighted distance DAG, alpha = %f',alpha));
                    
                    figure,subplot(2,2,1:2),drawMultiPartiteGraph(GlobalMatchingGraph_combinedWeighted, tChangeIndices,labelsAll);
                    title(sprintf('normalized intensity weighted global matching graph, alpha = %f',alpha));
                elseif(getDebugLevel() >= 2)
                    figure; %for the conflict_matrix
                end
                
                frameCount = size(tChangeIndices,1);
                
                dl = 1; %debugging level for console / text file output
                fn_conflictInfo = [dirDebug filesep sprintf('conflict info_intensityRatio=%.2f_alpha = %.2f.txt',intensityRatio,alpha)];
                deleteFileIfExists(fn_conflictInfo);
                
                
                for f = 1 : frameCount-1
                    %f => f+1
                    
                    M_distanceOnly      = GlobalMatchingGraph_distanceOnly{f}.G;
                    M_combinedWeighted  = GlobalMatchingGraph_combinedWeighted{f}.G;
                    M_final             = thisFinalMatchingGraph{f}.G;
                    C = conflict_matrix{f}.G; %conflict matrix for frame f to f+1
                    A = conflict_matrix{f}.S;
                    B = conflict_matrix{f}.T;
                    
                    isGraphBipartite = 1;
                    [leftVertexGroup,rightVertexGroup] = ConnectedGraphComponents(C,'weakly', isGraphBipartite);
                    for i = 1 : length(leftVertexGroup)
                        U = leftVertexGroup{i};
                        V = rightVertexGroup{i};
                        if(length(U) + length(V) > 1) %connected component consists of more than one vertex
                            conflictCount(intensityRatioIdx,alphaIdx) = conflictCount(intensityRatioIdx,alphaIdx)+1;
                            
                            if(getDebugLevel() >= 1)
                                PrintToFile_debug(sprintf('there is a conflict involving the following vertices (frame# %d):',T(A(1),4)), fn_conflictInfo, [], 1, dl);
                                for u = U
                                    printToFile_debug(sprintf('    trID = %03d, objID = %05d',T(A(u),trIDColIdx),T(A(u),objIDColIdx)), fn_conflictInfo, [], 1, dl);
                                end
                                for v = V
                                    printToFile_debug(sprintf('    trID = %03d, objID = %05d',T(B(v),trIDColIdx),T(B(v),objIDColIdx)), fn_conflictInfo, [], 1, dl);
                                end
                            end
                            
                            if(length(U) >= length(V)) %use the larger set of vertices to extract the paths ==> ToDo: think about a situation where this is not sufficient
                                X = A(U);
                            else
                                X = B(V);
                            end
                            
                            idx = 1;
                            var_distOnlyWeights = zeros(length(X),1);
                            var_combinedWeights = zeros(length(X),1);
                            for x = X
                                if(length(U) >= length(V))
                                    %find the paths going through u, go one frame back and two forward
                                    path_distOnlyWeights = extractPartialPath(GlobalMatchingGraph_distanceOnly,x,f-1,1,2);
                                    path_combinedWeights = extractPartialPath(GlobalMatchingGraph_combinedWeighted,x,f-1,1,2);
                                else
                                    %find the paths going through v, go two frames back and one forward
                                    path_distOnlyWeights = extractPartialPath(GlobalMatchingGraph_distanceOnly,x,f,2,1);
                                    path_combinedWeights = extractPartialPath(GlobalMatchingGraph_combinedWeighted,x,f,2,1);
                                end
                                
                                %compute the variances of the resp. cs property along the extracted paths
                                var_distOnlyWeights(idx) = var(getCSProperty(path_distOnlyWeights));
                                var_combinedWeights(idx) = var(getCSProperty(path_combinedWeights));
                                idx = idx + 1;
                            end
                            %use the sum of variances of all paths as a measure of smoothness
                            sum_var_distOnlyWeights = sum(var_distOnlyWeights);
                            sum_var_combinedWeights = sum(var_combinedWeights);
                            
                            if(strcmpi(conflictResolvingStrategy, 'minRadiusVariance'))
                                if(sum_var_distOnlyWeights > sum_var_combinedWeights)
                                    %change the matching in the final matching graph from the
                                    %distance-only based version to the combined weights based option
                                    %for this conflict
                                    printToFile_debug('resolving conflict by choosing the combined weights option', fn_conflictInfo, [], 1, dl);
                                    M_final(U,V) = M_combinedWeighted(U,V);
                                else
                                    %otherwise leave as is, distance-only based is default
                                    printToFile('resolving conflict by choosing the distance-only weights option', fn_conflictInfo, [], 1);
                                end
                            elseif(strcmpi(conflictResolvingStrategy, 'noConflictEdges'))
                                printToFile('avoiding conflict (no edge between the conflicted vertices)', fn_conflictInfo, [], 1);
                                M_final(U,V) = repmat(0,length(U),length(V));
                            elseif(strcmpi(conflictResolvingStrategy, 'distanceOnly'))
                                printToFile('resolving conflict by choosing the distance-only weights option', fn_conflictInfo, [], 1);
                                M_final = M_distanceOnly;
                            elseif(strcmpi(conflictResolvingStrategy, 'combinedOnly'))
                                printToFile_debug('resolving conflict by choosing the combined weights option', fn_conflictInfo, [], 1, dl);
                                M_final = M_combinedWeighted;
                            else
                                error('unknown conflict resolving strategy %s',conflictResolvingStrategy);
                            end
                            printToFile_debug('-----------------------------------------------------', fn_conflictInfo, [], 1, dl);
                        end
                    end
                    thisFinalMatchingGraph{f}.G = M_final;
                    if(length(thisFinalMatchingGraph{f}.S) ~= size(thisFinalMatchingGraph{f}.G,1))
                        error('number of entries in S is not equal to the number of rows in G at index = %d',f);
                    end
                    if(length(thisFinalMatchingGraph{f}.T) ~= size(thisFinalMatchingGraph{f}.G,2))
                        error('number of entries in T is not equal to the number of columns in G at index = %d',f);
                    end
                end
            end
            
            
            conflictCount(intensityRatioIdx,alphaIdx)       = conflictCount(intensityRatioIdx,alphaIdx) + penaltyConflictCnt;
            FinalMatchingGraph{intensityRatioIdx,alphaIdx}  = thisFinalMatchingGraph;
            
            T(:,trIDColIdx) = AssignTrackIDs(thisFinalMatchingGraph, size(T,1));
            trackCount(intensityRatioIdx,alphaIdx) = numel(unique(T(:,trIDColIdx)));
            
            if(getDebugLevel() >= 2)
                if(frameCount <= 15)
                    figure,drawMultiPartiteGraph(thisFinalMatchingGraph, tChangeIndices,labelsAll);
                    title(sprintf('final matching graph, intensityRatio = %.2f, alpha = %.2f',intensityRatio,alpha));
                end
            end
        end
    else %no tracks >= 3 from distance-only based tracking
        conflictCount(intensityRatioIdx,:) = 999999;
        alphaIdx = 0;
        for alpha = alphas
            alphaIdx = alphaIdx + 1;
            FinalMatchingGraph{intensityRatioIdx,alphaIdx} = GlobalMatchingGraph_distanceOnly;
        end
    end
end



%find the tracking result with minimum number of conflicts
%choose the minimal one with highest alpha and lowest intensityRatio if more
%than one minimum exists
%highest alphas means highest confidence that the tracking is correct
%lowest intensityRatio means the tracks are longer

%in the conflict count matrix this means to find the minimum which is right most, top most

conflictCount_org   = conflictCount;
trackCount_org      = trackCount;

conflictCount
trackCount
minConflictCount = min(conflictCount(:))

trackCount(conflictCount > minConflictCount) = inf;
minTrackCntInMinConflictConf = min(trackCount(trackCount(:)>0));

if(minimizeNumberOfTracks)
    conflictCount(trackCount > minTrackCntInMinConflictConf) = inf;
end

minIndices = find(conflictCount==minConflictCount)';
minRow = inf;
maxCol = -inf;
for minIdx = minIndices(:)'
    [i,j] = ind2sub(size(conflictCount),minIdx);
    if(j>maxCol)
        maxCol = j;
        minRow = i;
    elseif(j==maxCol && i<minRow)
        minRow = i;
    end
end
[minRow, maxCol]

FinalMatchingGraph = FinalMatchingGraph{minRow, maxCol};

fn = [dirDebug filesep 'conflict count matrix.txt'];
fprintThisDebugInfo(fn, minimizeNumberOfTracks, alphas, intensityRatios, conflictCount_org, conflictCount, trackCount_org, trackCount, minConflictCount, minTrackCntInMinConflictConf, alphas(maxCol),intensityRatios(minRow))

if(isempty(candidates))
    T =  [];
else
    T =  candidates{minRow};
    T(:,trIDColIdx) = AssignTrackIDs(FinalMatchingGraph, size(T,1));
    T = ComputeTrackLengths(T, trIDColIdx, trLengthColIdx);
    [T, header] = ComputeCSVelocity( T, header );
end
fprintMatrix(filenameOut, T, header);
if(nargin == 0)
    makeTrackingMovie(workingDir, filenameOut,[],0,'showObjID',1,'openMovie',1, 'magnification',1.2);
    theoreticalMaxVelocity(workingDir, filenameOut);
end
if(getDebugLevel() >= 2)
    showTrackingMovie(filenameOut,0);
    if(frameCount < 15)
        figure, drawMultiPartiteGraph(FinalMatchingGraph,computeTchangeIndices(T),labelsAll)
        title('the final matching graph');
    end
end

    function M = TrackingByBipartiteMatching(DAG_WeightMatrix) %nested function
        
        M = cell(size(DAG_WeightMatrix));
        for i = 1 : length(DAG_WeightMatrix)
            M{i}.G = zeros(size(DAG_WeightMatrix{i}.G));
            M{i}.S = DAG_WeightMatrix{i}.S;
            M{i}.T = DAG_WeightMatrix{i}.T;
        end
        
        frameCount = size(tChangeIndices,1);
        
        frame = [];
        costs = [];
        T(:,trIDColIdx) = (1:size(T,1))';
        
        %do the linking on a frame by frame basis
        for i = 1 : frameCount-1
            %build a bipartite graph, i.e. the subgraph of the DAG
            %containing frames i and i+1
            G = DAG_WeightMatrix{i}.G;
            A = DAG_WeightMatrix{i}.S;
            B = DAG_WeightMatrix{i}.T;
            time1 = T(A(1),4);

            
            %identify edges that violate the radius hysteresis
            F = false(size(G));
            for s = 1 : length(A)
                %get the maximum radius in the source track
                idxSource   = A(s);
                trIDSource  = T(idxSource, trIDColIdx);
                R           = T(T(:,trIDColIdx) == trIDSource & T(:,4) <= time1,:);
                maxCSRadiusSourceTrack = max(R(:,meanSigmaXY2DColIdx));
                if(maxCSRadiusSourceTrack <= radiusHysteresis(2))
                    continue
                end
                
                % - source s fullfils the first condition of the radius hysteresis criterion
                % - now check for each target connected to s whether it fulfills
                %   the second condiition of the radius hysteresis criterion
                for t = 1 : length(B)
                    if(G(s,t) < inf)
                        idxTarget       = B(t);
                        radiusTarget    = T(idxTarget, meanSigmaXY2DColIdx);
                        if(radiusTarget < radiusHysteresis(1))
                            %mark the edge as forbidden edge
                            F(s,t) = true;
                        end
                    end
                end
            end
            if(any(strcmpi(strategyForRemovingRadiusHysteresisEdges, {'beforeBipartiteMatching'} )))
                G(F) = inf;
            end
            
            if(strcmpi(strategyForRemovingRadiusHysteresisEdges,'optimal'))
                %compute a minimum sum distance matching that includes no forbidden edges
                [BipartiteMatching, CostWithForbiddenEdges, Cost] = OptBipartiteMatchingWithoutForbiddenEdges(G,F);
            else
                %compute a minimum sum distance matching by means of the Hungarian algorithm
                [BipartiteMatching, Cost] = Hungarian2(G);
            end
            
            if(any(strcmpi(strategyForRemovingRadiusHysteresisEdges, {'afterBipartiteMatching'} )))
                BipartiteMatching(F) = 0;
            end
            
            frame(end+1) = time1;
            s = sum(BipartiteMatching(:));
            if(s > 0)
                costs(end+1) = Cost / s;
            else
                costs(end+1) = 0;
            end
            
            %update global matching graph
            M{i}.G = BipartiteMatching;
            
            %update track-IDs
            trIDsSources = T(A,trIDColIdx);
            trIDsTargets = T(B,trIDColIdx);
            trIDsTargets_updated = updateTrackIDs(BipartiteMatching, trIDsSources, trIDsTargets);
            T(B,trIDColIdx) = trIDsTargets_updated;
            
            if(getDebugLevel() >= 2)
                for ii = 1 : length(A)
                    labelsA{ii} = sprintf('%d:%d', T(A(ii),objIDColIdx), T(A(ii),trIDColIdx));
                end
                for ii = 1 : length(B)
                    labelsB{ii} = sprintf('%d:%d', T(B(ii),objIDColIdx), T(B(ii),trIDColIdx));
                end
                figure,drawBipartiteGraph(G, inf, labelsA, labelsB);
                title(sprintf('t: %d ==> %d',T(A(1),4), T(B(1),4)));
                for hh = 1:size(G,1)
                    for kk = 1:size(G,2)
                        if(G(hh,kk)<inf)
                            fprintf('%d ==> %d: %.4f\n',T(A(hh),objIDColIdx), T(B(kk),objIDColIdx), G(hh,kk));
                        end
                    end
                end
                fprintf('\n');
                figure,drawBipartiteGraph(BipartiteMatching, 0, labelsA, labelsB);
                title(sprintf('t: %d ==> %d',T(A(1),4), T(B(1),4)));
            end
        end
        
        if(getDebugLevel >= 2)
            fig1 = figure;
            plot(frame, costs, 'o-');
            xlabel('frame#');
            ylabel('matching cost per edge');
            title(sprintf('%s',strrep(param.tag, '_', ' ')));
            fn = [dirDebug filesep sprintf('matchingCost_intensityRatio=%.1f_alpha=%.2f.fig',intensityRatio,alpha)];
            saveas(fig1, fn);
            close(fig1);
            
            T_DAG   = [];
            T_match = [];
            
            for i = 1 : length(DAG_WeightMatrix)
                G = DAG_WeightMatrix{i}.G;
                BipartiteMatching = M{i}.G;
                A = DAG_WeightMatrix{i}.S;
                B = DAG_WeightMatrix{i}.T;
                for s = 1 : size(G,1)
                    objID_s = T(A(s),objIDColIdx);
                    for t = 1 : size(G,2)
                        objID_t = T(B(t),objIDColIdx);
                        if(G(s,t) < inf)
                            T_DAG(end+1,:) = [objID_s, objID_t, G(s,t)];
                        end
                        if(BipartiteMatching(s,t) == 1)
                            T_match(end+1,:) = [objID_s, objID_t, G(s,t)];
                        end
                    end
                end
            end
            fn = [dirDebug filesep sprintf('DAG_intensityRatio=%.1f_alpha=%.2f.txt',intensityRatio,alpha)];
            header_DAG = createHeader('objID1','objID2','weight');
            fprintMatrix(fn, T_DAG, header_DAG);
            
            fn = [dirDebug filesep sprintf('Match_intensityRatio=%.1f_alpha=%.2f.txt',intensityRatio,alpha)];
            header_match = createHeader('objID1','objID2','weight');
            fprintMatrix(fn, T_match, header_match);
            
        end
    end

    function prop = getCSProperty(path) %nested function
        %the path may contain zeros
        prop = zeros(1,length(path));
        
        for kk = 1 : length( path )
            if(path(kk)>=1)
                prop(kk) = T(path(kk),csAppearanceParameterForConflictsColIdx);
            end
        end
    end

end %of main function

function trIDsTargets = updateTrackIDs(M_, trIDsSources, trIDsTargets)
%M - single bipartite graph

for t = 1 : size(M_,2)
    s = find(M_(:,t), 1);
    if(~isempty(s))
        trIDsTargets(t) = trIDsSources(s);
    end
end
end

function labeling = AssignTrackIDs(MatchingGraph,objCount)
%MatchingGraph - series of bipartite graphs

if(isempty(MatchingGraph))
    labeling = 1:objCount;
else
    M1 = MatchingGraph{1}.G;
    labeling = 1 : size(M1,1);
    nextFreeID = labeling(end)+1;
    for m = 1 : length(MatchingGraph)
        M_ = MatchingGraph{m}.G;
        A = MatchingGraph{m}.S;
        B = MatchingGraph{m}.T;
        
        for t = 1 : size(M_,2)
            s = find(M_(:,t), 1);
            if(isempty(s))
                labeling(B(t)) = nextFreeID;
                nextFreeID = nextFreeID + 1;
            else
                labeling(B(t)) = labeling(A(s));
            end
        end
    end
end

labeling = labeling(:);

if(length(labeling) ~= objCount)
    error('Error in assigning track-IDs. Number of track-IDs is different from the number of objects.');
end
end

function path = extractPartialPath(MatchingGraph, v, f, lookBackCount, lookAheadCount)
% MatchingGraph  - global mataching global (cell array of graphs)
% v              - global index of the resp. vertex
% f              - the frame number where v is target (i.e. v is at frame f+1)
% lookBackCount  - how many frames to walk back
% lookAheadCount - how many frames to walk forward
%

if(f<1)
    lookBackCount = lookBackCount+f-1;
    f = 1;
end

path = zeros(1,lookBackCount+1+lookAheadCount);
path(lookBackCount+1) = v;

B = MatchingGraph{f}.T;
v = find(v == B);

fb = f;
u = v;
for i = 1 : lookBackCount
    %find the backward correspondence of u
    if(fb < 1)
        break
    end
    
    M_ = MatchingGraph{fb}.G;
    A  = MatchingGraph{fb}.S;
    u = find(M_(:,u),1);
    
    if(~isempty(u))
        path(lookBackCount+1-i) = A(u);
    else
        break;
    end
    fb = fb - 1;
end

fv = f + 1;
u = v;
for i = 1 : lookAheadCount
    %find the forward correspondence of u
    
    if(fv > length(MatchingGraph))
        break
    end
    
    M_ = MatchingGraph{fv}.G;
    B  = MatchingGraph{fv}.T;
    
    u = find(M_(u,:),1);
    if(~isempty(u))
        path(lookBackCount+1+i) = B(u);
    else
        break;
    end
    fv = fv + 1;
end
end

function fprintThisDebugInfo(fn, minimizeNumberOfTracks, alphas, intensityRatios, conflictCount_org, conflictCount, trackCount_org, trackCount, minConflictCnt, minTrackCntInMinConflictConf, selectedAlpha, selectedThreshold)
fid = fopen(fn, 'w+t');

fprintf(fid, 'minimizeNumberOfTracks = %d\n\n',minimizeNumberOfTracks);

txt = sprintf('\nmin conflict count = %d\nselected alpha = %f\nselected intensityRatio = %f\n\n',minConflictCnt,selectedAlpha, selectedThreshold);
fprintf(fid, '%s\n',txt);

fprintMatrixWithLabels(fid, 'conflict count', intensityRatios, alphas, conflictCount_org);
fprintf(fid, 'min conflict count = %d\n',minConflictCnt);
fprintf(fid, '\n\n');
fprintMatrixWithLabels(fid, 'track count', intensityRatios, alphas, trackCount_org);
fprintf(fid, '\n\n');
fprintMatrixWithLabels(fid, 'track count at min conflict count configurations', intensityRatios, alphas, trackCount);
fprintf(fid, 'min track count at min conflict configurations = %d\n',minTrackCntInMinConflictConf);
fprintf(fid, '\n\n');
fprintMatrixWithLabels(fid, 'conflict count at min track count configurations', intensityRatios, alphas, conflictCount);
fprintf(fid, '\n\n');

fclose(fid);
end

function fprintMatrixWithLabels(fid, txtTitle, rowLabels, columnLabels, M)
fprintf(fid, '%s\n', txtTitle);

X = [0 columnLabels(:)'; [rowLabels(:) M]];

for i = 1 : size(X,1)
    for j = 1 : size(X,2)
        fprintf(fid, '%f', X(i,j));
        if(j < size(X,2))
            fprintf(fid, '\t');
        else
            fprintf(fid, '\n');
        end
    end
end

end

