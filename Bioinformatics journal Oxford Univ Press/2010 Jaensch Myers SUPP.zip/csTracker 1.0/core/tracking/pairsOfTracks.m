function [ filenameOut ] = pairsOfTracks( workingDir, filenameIn, skipIfFileoutExists )
%Assigns a cellID to centrosomes. Each cell is assumed to have two centrosomes.

%minOverlapDuration specifies the minimum duration the two centrosomes must appear together
minOverlapDuration = 6; %8%minutes

%two centrosomes must come at least this close in order to be considered a pair
maxAllowedMinDistance = 12000; %nanometer

%two centrosomes must move away from each other at least this distance in order to be considered a pair
minAllowedMaxDistance = 6000; %nanometer

%spindle must get longer over time
minSlope_spindleLengthOverTime = 0;

fprintf('%s\n',mfilename); 
if(nargin == 0)
    workingDir = [baseDir filesep 'yTUB-GFP11_FOG1_RNAi_Zyg1(it29)_2to4cellstage\workingDir\1'];
    filenameIn = 'tracksComplete_GFit3D_bgLevel_csRc.txt';
    setDebugLevel(2)
end
global param;
[filenameIn, filenameOut, dirDebug ] = initProcessingStep( workingDir, filenameIn, 'pairs',mfilename );
if(exist('skipIfFileoutExists','var') && skipIfFileoutExists && exist(filenameOut, 'file'))
    return
end

if(isfield(param, 'isMultiCell') && param.isMultiCell == 0)
    minSlope_spindleLengthOverTime = -inf; %don't care about spindle length over time slope in one-cell embryos
end

[T, header] = loadList(filenameIn);
[T, header] = ComputeDerivedParameters(T, header);
[header, cellIDcolIdx] = addHeaderEntry(header, 'cellID');
trIDColIdx = headerIndex(header,'trID');
validColIdx = headerIndex(header,'valid');
meanSigmaXY2DColIdx = headerIndex(header,'meanSigmaXY2D');

N = size(T,1);
T = sortrows(T,[trIDColIdx,4]);
t_max = max(T(:,4));

ix_valid = T(:,validColIdx) == 1;

firstFrame = AggregateXGroups(T(ix_valid,trIDColIdx),T(ix_valid,4), @min); %1st col: trID, 2nd col: frame# (t)
lastFrame  = AggregateXGroups(T(ix_valid,trIDColIdx),T(ix_valid,4), @max); %1st col: trID, 2nd col: frame# (t)
uniqueTrIDs = firstFrame(:,1);

if(getDebugLevel >= 2)
    fig1 = sfigure;
    maximize(fig1);
    prepareFigureForPrint(fig1);
    filenameDebug_ps = [dirDebug filesep 'pairDistances.ps'];
    deleteFileIfExists(filenameDebug_ps);
    
    filenameDebug_ps_width = [dirDebug filesep 'cs_width.ps'];
    deleteFileIfExists(filenameDebug_ps_width);
end

if(length(uniqueTrIDs) == 1) %only one centrosome in entire movie
    T(:,cellIDcolIdx) = 1;
else
    table = [];
    
    %find pairs
    minOverlap = round(minOverlapDuration*60 / param.frameInterval);
    averagingWindowSize = 3;
    G = ones(length(uniqueTrIDs))*inf;
    G_all = zeros(length(uniqueTrIDs));
    accu_D = [];
    for i = 1 : length(uniqueTrIDs)-1
        for j = i + 1 : length(uniqueTrIDs)
            t_first = max(firstFrame(i,2),firstFrame(j,2));
            t_last  = min(lastFrame(i,2), lastFrame(j,2)); 
            overlap = t_last - t_first;

            if(overlap >= minOverlap)            
                Ri = T(T(:,trIDColIdx) == uniqueTrIDs(i) & T(:,4) >= t_first & T(:,4) <= t_last, :);
                Rj = T(T(:,trIDColIdx) == uniqueTrIDs(j) & T(:,4) >= t_first & T(:,4) <= t_last, :);
                dist = RealDistance(Ri(:,1:3),Rj(:,1:3));
                distAvg = runningAverage(dist,averagingWindowSize);
                
                frames = Ri(:,4);
                time = frames * param.frameInterval;
                width_csi = Ri(:,meanSigmaXY2DColIdx);
                width_csj = Rj(:,meanSigmaXY2DColIdx);
                
                sizeDiff = abs(width_csi-width_csj);
                sizeDiff = sizeDiff(1:max(1,end-4));
                avgSizeDiff = mean(sizeDiff(1:ceil(.8*end)));
                
                %correlation coeffienct
                r = corrcoef([time,distAvg]);
                r = r(end,1);
                
                %linear fit through "spindle length"
                p  = polyfit(time,distAvg,1);
                slope = p(1);
                pv = polyval(p,time);
                
                Dmin = min(distAvg);
                DfirstHalfAvg = mean(distAvg(1:ceil(.5*end)));
                Dmax = max(distAvg);
                accu_D = [accu_D Dmin];
                
                table(i,j,1)   = Dmin;               %min dist
                table(i,j,2)   = slope;              %of lineare fit
                table(i,j,3)   = avgSizeDiff;
                table(i,j,4)   = Rj(end,4) == t_max; %end of movie
                table(i,j,5)   = overlap;
                
                G_all(i,j) = DfirstHalfAvg*avgSizeDiff;
                               
                if(Dmin <= maxAllowedMinDistance && Dmax >= minAllowedMaxDistance && slope > minSlope_spindleLengthOverTime) %cs mus come close enough and spindle must get longer over time
                    G(i,j) = G_all(i,j);   
                    G(j,i) = G_all(i,j);
                end
                if(getDebugLevel >= 2)
                    sfigure(fig1);
                    clf(fig1);
                    %subplot(2,2,1)
                    ax(1) = gca;
                    plot(time,dist,':');
                    xlabel('time [s]');
                    ylabel('cs center distance [nm]');
                    hold on
                    plot(time,distAvg,'-');
                    plot(time,pv,'-k','LineWidth',2,'DisplayName','lin. fit');
                    plot(time([1,end]), [maxAllowedMinDistance, maxAllowedMinDistance], ':r', 'DisplayName', 'maxAllowedMinDistance');
                    title(sprintf('%s\ntrID %d ==> trID %d, corr = %.2f, slope = %.2f, avgSizeDiff = %.0f',strrep(param.tag,'_',' '),uniqueTrIDs(i),uniqueTrIDs(j),r, slope, avgSizeDiff));
                    yl = ylim;
                    if(yl(2) < 35000) %nanometer
                        yl(2) = 35000;
                    end
                    ylim([0 yl(2)]);
                    
                    hold on;
                    ax(2) = axes('Position',get(gca,'Position'),'XAxisLocation','bottom','YAxisLocation','right','Color','none','XMinorTick','on');
                    hold on
                    plot(time,width_csi,'-g');
                    plot(time,width_csj,'-g');
                    plot(time(1:length(sizeDiff)),sizeDiff,':g','LineWidth',2);                    
                    ylabel('meanSigmaXY2D');
                    

                    print(sprintf('-f%d',fig1),'-dpsc2','-append', filenameDebug_ps)
                    
                    %width vs width graph
                    clf(fig1);
                    %correlation coeffienct
                    rWidth = corrcoef([width_csi,width_csj]);
                    rWidth = rWidth(2,1);
                    subplot(1,2,1)
                    plot(width_csi, width_csj, 'o');
                    title(sprintf('%s, trID %d ==> trID %d, corrcoef = %.3f',strrep(param.tag,'_',' '),uniqueTrIDs(i),uniqueTrIDs(j),rWidth));
                    xlabel(sprintf('meanSigmaXY2D trID=%03d',uniqueTrIDs(i)));
                    ylabel(sprintf('meanSigmaXY2D trID=%03d',uniqueTrIDs(j)));
                    axis equal
                    axis square
                    subplot(1,2,2)
                    h = length(width_csi)-1;
                    %plot(-h:h,xc);

                                        
                    print(sprintf('-f%d',fig1),'-dpsc2','-append', filenameDebug_ps_width)
                end
            end            
        end    
    end
    if(getDebugLevel < 3 && exist('fig1','var'))
        close(fig1);
    end
    
    if(getDebugLevel >= 3)
        figure, hist(accu_D), title('histogram of min centrosome distance');
    end
    T(:, cellIDcolIdx) = 0;
    if(isempty(G))
        warning('The matching graph is empty. No centrosome pairs found.');
    else   
%         Matching = Hungarian2(G);
        Matching = GreedyBipartiteMatching(G);
        
        %find unmatched centrosomes
        unmatch_idxi = find(1-sum(Matching,2));       
        
        if(~isempty(unmatch_idxi))
            matchedAvgSizeDiff = [];
            for i = 1 : size(Matching, 1)
                j = find(Matching(i,:),1);
                if(~isempty(j) && i < j)
                    matchedAvgSizeDiff(end+1) = table(i,j,3);
                    fprintf('%2d <==> %2d\n', uniqueTrIDs(i),uniqueTrIDs(j));
                end
            end
            meanMatchedAvgSizeDiff = mean(matchedAvgSizeDiff);
            
            %extend G by edges with weight minDist (as before) that fullfil
            %the following conditions:
            %(0. don't care about the slope of the lin. fit anymore)
            % 1. the overlap time must be greater than minOverlap (as before)
            % 2. the track pair must end at the end of the movie (otherwise for no reason 
            %    the slope of the lin. fit of a real pair could be negative)
            % 3. the average size diff of the centrosomes must be less than
            %    the mean average size diff of the pairs that have been matched above
            %
            for k = 1 : length(unmatch_idxi)-1
                i = unmatch_idxi(k);
                for w = k+1 : length(unmatch_idxi)
                    j = unmatch_idxi(w);
                    if(size(table,1) >= i && size(table,2) >= j && table(i,j,5) >= minOverlap)
                        Dmin = table(i,j,1); %min dist
                        if(table(i,j,4) == 1 && table(i,j,3) <= meanMatchedAvgSizeDiff && Dmin <= maxAllowedMinDistance) %track pair is at end of movie && avgSizeDiff < meanMatchedAvgSizeDiff
                            G(i,j) = G_all(i,j); %same edge weights as above
                            G(j,i) = G_all(i,j); %same edge weights as above
                        end
                    end
                end
            end           
            
            %match again with extended graph
            Matching = GreedyBipartiteMatching(G);
        
        end
        
        if(getDebugLevel>=3)
            try
                figure;
                subplot(1,2,1), drawBipartiteGraph(G,inf,uniqueTrIDs,uniqueTrIDs);
                subplot(1,2,2), drawBipartiteGraph(Matching,0,uniqueTrIDs,uniqueTrIDs);
                graph = [[0 uniqueTrIDs(:)']; [uniqueTrIDs(:) G]];
                fprintMatrix([dirDebug filesep 'distanceMatrix.txt'], graph);
            catch
                printDebugStack(lasterror);
            end
        end

        cellID = 1;
        for i = 1 : size(Matching, 1)
            j = find(Matching(i,:),1);
            if(~isempty(j) && i < j)
                fprintf('%d <==> %d\n',uniqueTrIDs(i),uniqueTrIDs(j));
                addToHistogram(G(i,j),'weights of matched edges, pairsOfTracks');
                T(T(:,trIDColIdx) == uniqueTrIDs(i), cellIDcolIdx) = cellID;
                T(T(:,trIDColIdx) == uniqueTrIDs(j), cellIDcolIdx) = cellID;
                cellID = cellID + 1;
            end
        end
    end
end
T = sortrows(T,[4, trIDColIdx]);
fprintMatrix(filenameOut, T, header);
if(nargin == 0)
    showTrackingMovie(filenameOut,0)
end






