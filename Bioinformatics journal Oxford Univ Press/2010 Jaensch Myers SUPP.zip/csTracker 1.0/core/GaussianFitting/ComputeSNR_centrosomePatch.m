function [SNR] = ComputeSNR_centrosomePatch(patch, innerRadius, outerRadius, center)
% background must be subtracted in patch image!
% see also: ComputeSNR, ComputeSNR_fullCentrosomeImage


if(nargin < 4)
    center = ceil(size(patch)/2);
end
maskSignal      = MakeRingPattern( size(patch), innerRadius, 1, 0, center );
maskBackground  = MakeRingPattern( size(patch), outerRadius, 0, 1, center );

%     Ioverlay  = OverlayMask(I, maskSignal);
%     Ioverlay  = OverlayMask(Ioverlay, maskBackground);
%     figure, subplot(1,2,1), imshow(maskSignal,[]), subplot(1,2,2), imshow(maskBackground,[]);
%     figure, imshow(Ioverlay,[]);

SNR = ComputeSNR(patch, maskSignal, maskBackground);
end