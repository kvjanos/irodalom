function [SNR] = ComputeSNR_fullCentrosomeImage(I, pos, radius, background)
%I          - full sized centrosome image
%pos        - [y,x]
%radius     - absolute radius of the centrosome
%background - background intensity level

% see also: ComputeSNR_centrosomePatch, ComputeSNR

patch   = imcropCentered3(I, round(pos), ceil(2*radius)) - background;
%   figure, imshow(I,[]); figure, mesh(patch); colormap hsv
SNR     = ComputeSNR_centrosomePatch(patch, ceil(.5*radius), ceil(1.1 * radius));
end