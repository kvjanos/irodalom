function txt = printFittingParameters(paramNames, p)
txt = [];
for k = 1 : length(paramNames)
    txt = [txt sprintf('%s = %f',strrep(paramNames{k},'_','\_'),p(k))];
    if(mod(k,2) == 0 && k < length(paramNames))
        txt = [txt sprintf('\n')];
    elseif(k < length(paramNames))
        txt = [txt ', '];
    end
end
end