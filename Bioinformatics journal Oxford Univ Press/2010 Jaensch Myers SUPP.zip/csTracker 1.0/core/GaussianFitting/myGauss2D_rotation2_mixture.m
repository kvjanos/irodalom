function F = myGauss2D_rotation2_mixture( p, data )
%         1       2        3          4        5        6        7        8        9        10        11        12      13
% p = [meanx(1) meany(1) sigmax(1) sigmay(1) cMult(1) alpha(1) meanx(2) meany(2) sigmax(2) sigmay(2) cMult(2) alpha(2) cAdd]
%
% data is the grid-matrices of X and Y put next to each other

if(nargin == 0)
  %         1       2        3          4        5        6        7        8        9        10        11        12      13
  % p = [meanx(1) meany(1) sigmax(1) sigmay(1) cMult(1) alpha(1) meanx(2) meany(2) sigmax(2) sigmay(2) cMult(2) alpha(2) cAdd]
    p = [  50      50         3         1.3        1        12       20       20        6         3        1.3      90      .2];
    [X, Y] = meshgrid(1:100,1:100);
    data = [X Y];
end

X = data(:,1:size(data,2)/2);     %X is a matrix of the size of the I image to be fitted
Y = data(:,size(data,2)/2+1:end); %Y is a matrix of the size of the I image to be fitted

sin_alpha1 = sind(p(6));
cos_alpha1 = cosd(p(6));
sin_alpha2 = sind(p(12));
cos_alpha2 = cosd(p(12));

dX1 = (X-p(1));
dY1 = (Y-p(2));
dX2 = (X-p(7));
dY2 = (Y-p(8));

F1 = p(5)  *  exp(-.5*((cos_alpha1*dX1-sin_alpha1*dY1).^2/p(3)^2+(sin_alpha1*dX1+cos_alpha1*dY1).^2/p(4)^2));
F2 = p(11) *  exp(-.5*((cos_alpha2*dX2-sin_alpha2*dY2).^2/p(9)^2+(sin_alpha2*dX2+cos_alpha2*dY2).^2/p(10)^2)); 

F = F1 + F2 + p(13);
%F is a matrix of the size of the I image to be fitted
end