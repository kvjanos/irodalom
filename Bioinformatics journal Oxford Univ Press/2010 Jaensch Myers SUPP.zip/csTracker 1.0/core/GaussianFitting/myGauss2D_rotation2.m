function F = myGauss2D_rotation2( p, data )
    % myGauss2D(x,y) = Gauss2D(x,y) * cMult + cAdd
    % p = [meanx meany sigmax sigmay cMult cAdd alpha]
    %data is the grid-matrices of X and Y put next to each other
    
    if(nargin == 0)
        p = [50 50 6 13 .6 .3 25];
        [X, Y] = meshgrid(1:100,1:100);
        data = [X Y];
        
    end

    X = data(:,1:size(data,2)/2);     %X is a matrix of the size of the I image to be fitted
    Y = data(:,size(data,2)/2+1:end); %Y is a matrix of the size of the I image to be fitted

    sin_alpha = sind(p(7));
    cos_alpha = cosd(p(7));
    dX = (X-p(1));
    dY = (Y-p(2));
    
   F = p(5) *  exp(-.5*((cos_alpha*dX-sin_alpha*dY).^2/p(3)^2+(sin_alpha*dX+cos_alpha*dY).^2/p(4)^2)) + p(6); %F is a matrix of the size of the I image to be fitted
end