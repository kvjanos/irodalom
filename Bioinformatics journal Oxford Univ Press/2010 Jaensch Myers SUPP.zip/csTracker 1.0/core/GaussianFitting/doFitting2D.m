function [H_2D, idxRoi_2D, p_2D, imageOfFit] = doFitting2D(I, x0, y0, clippingRadiusOrIdxROI, rc, fittingFunc, initialGuess, lb, ub, ignoreCenterRegionOnSecondFit, dynamicROIFactor, maxROIRadius, maxPositionDisplacement, forcePeakAtMaxIntensity)
%applies the given fitting function
%
% input:
%  I                        - the image to be fitted (a full size image, not only a
%                                                     ROI containing a centrosome!!!)
%  x0                       - initial guess for mean_x
%  y0                       - initial guess for mean_y
%  clippingRadiusOrIdxROI   - 'auto' or an index-ROI (miny,maxy,minx,maxx) on which the fit will be performed
%                             if 'auto' two fits will be performed. first fit on ROI with radius rc around
%                             (x0,y0) ==> (mx,sx,my,sy), second fit on ROI with radius
%                             "dynamicROIFactor*(sx, sy)" around (mx, my)
%  rc                       - radius of the intial ROI used if clippingRadiusOrIdxROI = 'auto'
%  initialGuess             - initial guess or []
%  lb                       - lower bound or 'auto'
%  ub                       - upper bound or 'auto'
%  ignoreCenterRegionOnSecondFit -  * on the second fit a series of sized circular areas
%                                     at the image center will be ignored by the fitting process
%                                   * the area that results in the smallest sigma-values will be the final fit
%                                   * clippingRadiusOrIdxROI must be 'auto'
%                                   * the fitting function must have the ability to do a weighted fit
%
%
% output:
%  H_2D         - the image ROI on which the fit has been performed
%  idxRoi_2D    - the index-ROI (miny,maxy,minx,maxx) on which the fit has been performed
%  p_2D         - the fitting parameters [(1)meanx (2)meany (3)sigmax (4)sigmay (5)cMult (6)cAdd (7)avgResNorm]
%  imageOfFit   - an image of the fitted function, size(imageOfFit) == size(H_2D)
%
if(nargin < 7)
    initialGuess = [];
end
if(nargin < 8)
    lb = 'auto';
    ub = 'auto';
end
if(nargin < 10 || isempty(ignoreCenterRegionOnSecondFit))
    ignoreCenterRegionOnSecondFit = 'no';
end
if(nargin < 11 || isempty(dynamicROIFactor))
    dynamicROIFactor = 4;
end
if(nargin < 12 || isempty(maxROIRadius))
    maxROIRadius = [inf inf];
end
if(nargin < 13)
    maxPositionDisplacement = [];
end
if(nargin < 14)
    forcePeakAtMaxIntensity = 0;
end



if(~strcmpi(ignoreCenterRegionOnSecondFit, 'no') && (~ischar(clippingRadiusOrIdxROI) || ~strcmpi(clippingRadiusOrIdxROI, 'auto')))
    error('ignoreCenterRegionOnSecondFit requires clippingRadiusOrIdxROI to be ''auto''');
end

if(length(clippingRadiusOrIdxROI) < 2)
    clippingRadiusOrIdxROI(2) = clippingRadiusOrIdxROI(1);
end
if(length(maxROIRadius) < 2)
    maxROIRadius(2) = maxROIRadius(1);
end

if(isempty(maxPositionDisplacement))
    r = 3;
    [y0_clipping,x0_clipping] = index2DOfMax(I,[x0-r, y0-r, 2*r+1, 2*r+1]);
else
    y0_clipping = y0;
    x0_clipping = x0;
end


if(strcmpi(clippingRadiusOrIdxROI,'auto'))
    thisClippingRadiusOrIdxROI = [rc rc];
else
    thisClippingRadiusOrIdxROI = clippingRadiusOrIdxROI;
end

if(length(thisClippingRadiusOrIdxROI) == 2)
    [H_2D_1, idxRoi_2D_1] = imcropCentered3(I, [y0_clipping, x0_clipping], thisClippingRadiusOrIdxROI);
else
    H_2D_1 = I(thisClippingRadiusOrIdxROI(1):thisClippingRadiusOrIdxROI(2),thisClippingRadiusOrIdxROI(3):thisClippingRadiusOrIdxROI(4));
    idxRoi_2D_1 = thisClippingRadiusOrIdxROI;
end

W = [];
[p_2D_1, resNorm_1_2D, RESIDUAL_1, imageOfFit_1] = fittingFunc(H_2D_1,idxRoi_2D_1,initialGuess,lb, ub, W, maxPositionDisplacement,forcePeakAtMaxIntensity);

if(strcmpi(clippingRadiusOrIdxROI,'auto'))
    sigmaX = p_2D_1(3);
    sigmaY = p_2D_1(4);
    if(~isempty(maxPositionDisplacement))
        maxPositionDisplacement = max([sigmaX sigmaY]);
    end
    if(p_2D_1(5) <= 0)
        %warning('first 2D fit returned negative multiplication factor (cMult), t = %d, z = %d, x = %d, y = %d\n',t,z,x0,y0);       p_2D_1(1) = x0;
        warning('first 2D fit returned negative multiplication factor (cMult)');
        p_2D_1(1) = x0;
        p_2D_1(2) = y0;
    end
    
    %fit a second time using a clipping with radius dynamicROIFactor*max(sigmaY, sigmaX)
    radius_roi      = ceil(dynamicROIFactor*max(sigmaY, sigmaX));
    radius_roi(2)   = radius_roi(1);
    radius_roi      = min(radius_roi, maxROIRadius);
    
    [H_2D, idxRoi_2D] = imcropCentered3(I, round(p_2D_1([2,1])), radius_roi);
    
    initialGuess = p_2D_1;
    if(strcmpi(ignoreCenterRegionOnSecondFit, 'byMinimumSigma'))
        radius = 1:ceil(2*max(sigmaY, sigmaX));
        sx = zeros(length(radius),1);
        sy = zeros(length(radius),1);
        r_ix = 1;
        for r = radius
            W = makeRingPattern(size(H_2D), r, 0, 1);
            [p_2D, resNorm_2D, RESIDUAL, imageOfFit] = fittingFunc(H_2D,idxRoi_2D,initialGuess,lb, ub, W);
            
            p_2D_w{r_ix} = p_2D;
            resNorm_2D_w{r_ix} = resNorm_2D;
            RESIDUAL_w{r_ix} = RESIDUAL;
            imageOfFit_w{r_ix} = imageOfFit;
            sx(r_ix) = p_2D(3);
            sy(r_ix) = p_2D(4);
            r_ix = r_ix + 1;
            
            %             H_2D_w = H_2D .* W;
            %             figure, imshow(H_2D_w, []); title(sprintf('r = %d',r ))
        end
        mean_sx_sy = mean([sx, sy],2);
        [min_sigma, min_idx] = min(mean_sx_sy);
        
        p_2D = p_2D_w{min_idx};
        resNorm_2D = resNorm_2D_w{min_idx};
        RESIDUAL = RESIDUAL_w{min_idx};
        imageOfFit = imageOfFit_w{min_idx};
        
        %         figure, plot(radius, sx, '-rx'), hold on, plot(radius, sy, '-ko');
    elseif(strcmpi(ignoreCenterRegionOnSecondFit, 'byRadialIntensityProfile'))
        dist2int = radialIntensityProfile(H_2D,[],'distanceFunction', 'Euclidean','aggFunctionHandle', @mean);
        intensitySmoothed = smooth( dist2int(:,2),5,'moving');
        [maxInt, idx_maxInt] = max(intensitySmoothed);
        [minInt, idx_minInt] = min(intensitySmoothed);
        radius = ceil(dist2int(idx_maxInt,1));
        
        %         intensityHalf = (maxInt-minInt)*.67+minInt;
        %         intensityHalfIdx = find(intensitySmoothed<=intensityHalf, 1, 'first');
        %         radius = ceil(dist2int(intensityHalfIdx,1));
        %         radius = 0;
        %
        if(getDebugLevel()>=2)
            figure, plot(dist2int(:,1),dist2int(:,2),'-k'); hold on
            plot(dist2int(:,1),intensitySmoothed,'-ob');
            plot([radius radius], ylim, ':r');
        end
        
        W = MakeRingPattern(size(H_2D), radius, 0, 1);
        [p_2D, resNorm_2D, RESIDUAL, imageOfFit] = fittingFunc(H_2D,idxRoi_2D,initialGuess,lb, ub, W);
    else
        W = [];
        [p_2D, resNorm_2D, RESIDUAL, imageOfFit] = fittingFunc(H_2D,idxRoi_2D,initialGuess,lb, ub, W, maxPositionDisplacement, forcePeakAtMaxIntensity);
    end
else
    H_2D            = H_2D_1;
    idxRoi_2D       = idxRoi_2D_1;
    p_2D            = p_2D_1;
    resNorm_2D      = resNorm_1_2D;
    RESIDUAL        = RESIDUAL_1;
    imageOfFit      = imageOfFit_1;
end
if(length(resNorm_2D) == 2)
    gSNR = resNorm_2D(2);
    resNorm_2D(2) = [];
else
    gSNR = -1;
end
p_2D(end+1) = 1000000 * resNorm_2D / numel(H_2D); %avgResNorm_2D

% Gauss peak center is outside the image
if(p_2D(1) < 1 || p_2D(1) > size(I,2) || p_2D(2) < 1 || p_2D(2) > size(I,1)) 
    p_2D(1:2)   = [x0,y0];
    p_2D(3:end) = 0.0001;
end

%% compute normalized residual
if(iscell(imageOfFit))
    imfit = imageOfFit{1};
else
    imfit = imageOfFit;
end

maxI = min(min(H_2D(:)), min(imfit(:)));
minI = max(max(H_2D(:)), max(imfit(:)));

H_2D_norm  = (H_2D-minI)/(maxI-minI);
imfit_norm = (imfit-minI)/(maxI-minI);

resNorm_normalized = sum((H_2D_norm(:)-imfit_norm(:)).^2) / numel(H_2D);
p_2D(end+1) = resNorm_normalized;

%% put in SNR value
p_2D(end+1) = gSNR;
end