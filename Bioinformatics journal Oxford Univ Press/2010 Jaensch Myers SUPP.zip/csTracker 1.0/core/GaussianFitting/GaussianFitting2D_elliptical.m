function [ filenameOut ] = GaussianFitting2D_elliptical( workingDir, filenameIn, skipIfFileoutExists, varargin )
% fit elliptical 2D Gaussian on detected objects
%
% see also: DisplayGaussianFitting2D

fprintf('%s\n',mfilename);

allowMixtureFit             = getVarargin(varargin,  'allowMixtureFit', 1 );
skipPositiveSigmaXEntries   = getVarargin(varargin,  'skipPositiveSigmaXEntries', 0 ); %in a second run of this function after re-calculating the z-coordinate of each object only the objects with field 'sigmaX2D' <= 0 will be Gaussian fitted again
zRangeForMaxprojection      = getVarargin(varargin,  'zRangeForMaxprojection', [] );

global param;
loadGlobalParams(workingDir);

fn_matlab_LinearIntensityProfile = [];
maxPositionDisplacement = param.ap.myGauss2DFit.maxPositionDisplacement;

%objects with mexican hat radius below this value will be considered small
%small objects are allowed to refine their position only within half the mexican hat radius
mexHatRadius_smallObject                 = 800 / param.resolution;
maxDistanceTwoCloseSmallObjects          = -1; %nm  ==> try mixture fit also if sigma-ratio is not too large
minSigmaRatioForGaussianMixtureFitTry    = 1.4;
minSigmaRatioForGaussianMixtureFitAccept = 1.7;
maxMinSigmaForGaussianMixtureFit         = 450 / param.resolution;
maxDistance_MixtureFitPeaksCentroid_to_SinglePeak = 2000 / param.resolution; %centroid of the two peaks must be not further away from single peak than this number 


fittingMode             = 'singleGaussianRotated';
updateFittingManager    = 1;
update2DPostion         = 1;
prefix                  = '';
fittingFnct         = @myGauss2DFit_rotation;
fittingMixtureFnct  = @myGauss2DFit_rotation2_mixture;
paramNames    = {'meanX2D','meanY2D','sigmaX2D','sigmaY2D','gaussMult2D','gaussAdd2D','rho','avgResNorm2D','normResNorm2D','gSNR','fromMixtureFit','roi_miny','roi_maxy','roi_minx','roi_maxx','peakBGRatio','gIntensityRatio'};
xIdx            = 1;
yIdx            = 2;
sigmaxIdx       = 3;
sigmayIdx       = 4;
peakIdx         = 5;
backgroundIdx   = 6;

x1Idx            = 1;
y1Idx            = 2;
sigmax1Idx       = 3;
sigmay1Idx       = 4;
x2Idx            = 7;
y2Idx            = 8;
sigmax2Idx       = 9;
sigmay2Idx       = 10;
gauss1_Idx       = [1 2 3 4  5  13  6];
gauss2_Idx       = [7 8 9 10 11 13 12];
peakBGRatioIdx   = find(strcmpi(paramNames, 'peakBGRatio'));
meanIntensityToBackgroundRatioIdx = find(strcmpi(paramNames, 'gIntensityRatio'));

if(~isempty(zRangeForMaxprojection))
    fittingMode             = 'singleGaussianRotatedOnMaxPrj';
    updateFittingManager    = 1;
    update2DPostion         = 0;
    prefix                  = 'maxprj_';
end

[filenameIn, filenameOut, dirDebug ] = initProcessingStep( workingDir, filenameIn, ['*' strRemovePostfix(prefix,'_') 'GFit2D'], sprintf('%s_%s',mfilename,fittingMode) );
if(exist('skipIfFileoutExists','var') && skipIfFileoutExists && exist(filenameOut, 'file'))
    return
end
setImageSource('type','raw');

rc = round( param.r2 / param.resolution ); %initial clipping radius
clippingRadius = 'auto';
dynamicROIFactor  = 4;
maxClippingRadius = inf;

[T,header] = loadList(filenameIn);
T = sortrows(T, [4,3]);

trIDColIdx              = headerIndex(header, 'trID', 'none'); %trID will be used to generate useful filenames for the fitting visualization files
objIDColIdx             = headerIndex(header, 'objID'); %objID will be used to generate useful filenames for the fitting visualization files
fittedxcorrSigmaColIdx  = headerIndex(header, 'fittedxcorrSigma', 'none');

colIdx = [];
for k = 1 : length(paramNames)
    paramNames{k} = [prefix paramNames{k}];
    [header, colIdx(k),wa,T] = addHeaderEntry(header, paramNames{k}, -1, T);
end

[header, totalInt2DGaussianNumericColIdx]       = addHeaderEntry(header, [prefix 'totalInt2DGaussianNumeric']); %the numeric total intensity under the Gaussian
[header, totalInt2DImageNumericColIdx]          = addHeaderEntry(header, [prefix 'totalInt2DImageNumeric']); %the numeric total intensity of the image (background-offset is subtracted, so background should average to zero)
[header, totalInt2DMaxIntNormalizedColIdx]      = addHeaderEntry(header, [prefix 'totalInt2DMaxIntNormalized']); %the numeric total intensity of the image (background-offset is subtracted, so background should average to zero)
[header, totalInt2DCenterIntNormalizedColIdx]   = addHeaderEntry(header, [prefix 'totalInt2DCenterIntNormalized']); %the numeric total intensity of the image (background-offset is subtracted, so background should average to zero)

if(exist('skipPositiveSigmaXEntries','var') && skipPositiveSigmaXEntries)
    %update only if value in sigmax column is negative
    sigmaxColIdx = headerIndex(header, paramNames{sigmaxIdx});
    T_all = T;
    idx_update = T(:, sigmaxColIdx) < 0;
    T            = T_all( idx_update,:);
    T_notUpdated = T_all(~idx_update,:);
    fprintf('%d of %d entries will not be updated\n',size(T_notUpdated,1),size(T_all,1));
else
    T_notUpdated = [];
end


imgCnt = [];

if(getDebugLevel >= 2)
    T = T(ismember(T(:,headerIndex(header, 'objID')), objIDs_debugLevel2),:);
    updateFittingManager = 0;
    %     setDebugLevel(1)
end

N = size(T,1);

fn_matlab_FittingManager = [workingDir filesep 'GaussianFitting.mat'];
if(exist(fn_matlab_FittingManager, 'file') && updateFittingManager)
    load(fn_matlab_FittingManager); %loads variable 'fittingManager'
else
    fittingManager = {};
end

if(getDebugLevel >= 1)
    fig1 = sfigure;
    maximize(fig1);
end

if(fittedxcorrSigmaColIdx > 0)
    distanceDimension           = 3;
    flag_ignoreObject           = T(:,fittedxcorrSigmaColIdx) > mexHatRadius_smallObject;
    [ T, header ]               = ComputeDistanceToNearestCS(T, header, flag_ignoreObject, distanceDimension);
    dist3DToNearestObjColIdx    = headerIndex(header, 'dist3DToNearestObj');
end

lastT = -1;
for i = 1 : N
    x = T(i,1);
    y = T(i,2);
    x0 = round(x);
    y0 = round(y);
    z = T(i,3);
    t = T(i,4);
    objID           = T(i,objIDColIdx);
    dist3DToNearestSmallObj = T(i,dist3DToNearestObjColIdx);
    if(fittedxcorrSigmaColIdx > 0)
        mexHatRadius    = T(i,fittedxcorrSigmaColIdx);
    else
        mexHatRadius = inf;
    end
    
    if(lastT ~= t)
        fprintf('%t = d / %d\n', t , T(N,4));
        allZinThisT = unique(round(T(T(:,4)==t,3)));
        if(~isempty(zRangeForMaxprojection))
            allZinThisT = getZPlanesForMaxPrjRange( allZinThisT, zRangeForMaxprojection, param.zCount );
        end
        stack = loadPartialFrame([allZinThisT allZinThisT], t, 'full' );
        waitbar(i/N,mfilename);
    end
    lastT = t;
    if(~isempty(zRangeForMaxprojection))
        thisAllZ = getZPlanesForMaxPrjRange( z, zRangeForMaxprojection, param.zCount );
        partialstack = stack(:,:,thisAllZ);
        I = max(partialstack, [], 3);
    else
        I = stack(:,:,z);
    end
    

    %% fit 2D Gaussian on plane z (middle of centrosome in z direction)
    
    if(mexHatRadius <= mexHatRadius_smallObject)
        thisMaxPositionDisplacement = max(1,ceil(mexHatRadius/2));
        thisClippingRadius = rc;
    else
        thisMaxPositionDisplacement = maxPositionDisplacement;
        thisClippingRadius = clippingRadius;
    end
    
    %do fitting on plane z with 'auto' clipping size (big objects) / rc (small objects)
    ignoreCenterRegionOnSecondFit   = 'no';
    forcePeakAtMaxIntensity         = 0;
    [H_2D, idxRoi_2D, p_2D, imageOfFit] = doFitting2D(I, x0, y0, thisClippingRadius, rc, fittingFnct,[], 'auto', 'auto', ignoreCenterRegionOnSecondFit, dynamicROIFactor, maxClippingRadius, thisMaxPositionDisplacement, forcePeakAtMaxIntensity);
    
    sigmaxy         = p_2D([sigmaxIdx, sigmayIdx]);
    sigma_ratio     = max(sigmaxy) / min(sigmaxy);
    resNorm         = p_2D(end-2);
    
    smallCloseObjectExists = dist3DToNearestSmallObj < maxDistanceTwoCloseSmallObjects;
    
    if(allowMixtureFit)
        fromMixtureFit = 0;
        % do Gaussian mixture fit if indicated
        if((smallCloseObjectExists || sigma_ratio >= minSigmaRatioForGaussianMixtureFitTry) && min(sigmaxy) <= maxMinSigmaForGaussianMixtureFit)
            
            fromMixtureFit = 1;
            [H_2D_gm, idxRoi_2D_gm, p_2D_gm, imageOfFit_gm] = doFitting2D(I, x0, y0, ceil(dynamicROIFactor*max(sigmaxy)), rc, fittingMixtureFnct);
            
            if(getDebugLevel() >= 2)
                figure, displayFit(H_2D_gm, imageOfFit_gm{1});
            end
            
            p0 = p_2D([xIdx, yIdx]); %position of the Gaussian in the single-Gaussian fit
            p1 = p_2D_gm([x1Idx, y1Idx]); %position of the 1st Gaussian
            p2 = p_2D_gm([x2Idx, y2Idx]); %position of the 2nd Gaussian
            
            %compute distance between p0 and the mean of two new peaks ==>
            %distance should be small
            distPeaks = norm(p0-mean([p1;p2]));
                 
            sigmaxy1 = p_2D_gm([sigmax1Idx, sigmay1Idx]); %sigmas of the 1st Gaussian
            sigmaxy2 = p_2D_gm([sigmax2Idx, sigmay2Idx]); %sigmas of the 2nd Gaussian
            sigma_max = max([sigmaxy1 sigmaxy2]);
            
            sigma_ratio1 = max(sigmaxy1) / min(sigmaxy1);
            sigma_ratio2 = max(sigmaxy2) / min(sigmaxy2);
            resNorm_gm = p_2D_gm(end-2);
            
            %use Gaussian mixture fit if:
            %  1. norm of the residual got smaller
            %  2. both sigma ratios got smaller
            %  3. distance between 1-Gaussian peak and the centroid of 2-Gaussian peaks is small
            if(resNorm_gm < resNorm && ...
                    sigma_max    <= maxMinSigmaForGaussianMixtureFit && ...
                    sigma_ratio1 < minSigmaRatioForGaussianMixtureFitAccept && ...
                    sigma_ratio2 < minSigmaRatioForGaussianMixtureFitAccept && ...
                    (smallCloseObjectExists || ...
                    sigma_ratio1 < sigma_ratio && ...
                    sigma_ratio2 < sigma_ratio) && ...
                    distPeaks < maxDistance_MixtureFitPeaksCentroid_to_SinglePeak)
                
                H_2D        = H_2D_gm;
                idxRoi_2D   = idxRoi_2D_gm;
                
                %use the fit of the peak which is closer to the initial position
                if(norm([x0 y0]-p1) < norm([x0 y0]-p2))
                    p_2D = p_2D_gm([gauss1_Idx end-2:end]);
                    imageOfFit = imageOfFit_gm{2};
                else
                    p_2D = p_2D_gm([gauss2_Idx end-2:end]);
                    imageOfFit = imageOfFit_gm{3};
                end
                fromMixtureFit = 2;
            end
        end
    else
        fromMixtureFit = -1;
    end
    p_2D(end+1) = fromMixtureFit;
    
    y_center = min(size(I,1),max(1, p_2D(yIdx)));
    x_center = min(size(I,2),max(1, p_2D(xIdx)));
    
    
    if(~isempty(fn_matlab_LinearIntensityProfile))
        if(~exist('LinearIntensityProfileContainer', 'var'))
            LinearIntensityProfileContainer = {};
        end
        
        pos             = p_2D([1,2]);
        alpha           = p_2D(7);
        majorAxisLength = 4*max(p_2D([3,4]));
        minorAxisLength = 4*min(p_2D([3,4]));
        bg              = p_2D(6);
        [ Lx, Lmean, Lmax, H, patch ] = LinearIntensityProfile( I, pos, alpha,majorAxisLength ,minorAxisLength,bg  );
        lip.objID   = objID;
        lip.x       = Lx;
        lip.Lmean   = Lmean;
        lip.Lmax    = Lmax;
        lip.H       = H;
        lip.patch   = patch;
        LinearIntensityProfileContainer{end+1} = lip;
    end
    
    if(iscell(imageOfFit))
        imageOfFitList = imageOfFit;
        
        imageOfFit = imageOfFitList{1};
        imageListOfSubFits = imageOfFitList(2:end);
    else
        imageListOfSubFits = {};
    end
    
    background = p_2D(backgroundIdx);
    gaussianWithoutBG                       = imageOfFit - background;
    imageWithoutBG                          = H_2D - background;
    totalInt2D_gaussian_numeric             = sum(gaussianWithoutBG(:));
    totalInt2D_image_numeric                = sum(imageWithoutBG(:));
    
    imageWithoutBGCenterIntensityNormalized = imageWithoutBG / (I(round(y_center),round(x_center))-background);
    imageWithoutBGMaxIntensityNormalized    = imageWithoutBG / max(imageWithoutBG(:));
    
    T(i, totalInt2DCenterIntNormalizedColIdx)   = sum(imageWithoutBGCenterIntensityNormalized(:));
    T(i, totalInt2DMaxIntNormalizedColIdx)      = sum(imageWithoutBGMaxIntensityNormalized(:));
    T(i, totalInt2DGaussianNumericColIdx)       = totalInt2D_gaussian_numeric;
    T(i, totalInt2DImageNumericColIdx)          = totalInt2D_image_numeric;
    
    if(getDebugLevel >= 1)
        if(trIDColIdx > 0)
            trID = T(i,trIDColIdx);
            if(length(imgCnt) >= trID)
                imgCnt(trID) = imgCnt(trID) + 1;
            else
                imgCnt(trID) = 1;
            end
        else
            trID = objID;
        end
        
        if(getDebugLevel >= 2)
            fig1 = sfigure;
            maximize(fig1);
        end
        
        clf(fig1) %clear figure
        subplot(2,2,[1 3]);
        txt = printFittingParameters(paramNames(1:length(p_2D)), p_2D);
        
        displayFit(H_2D, imageOfFit, txt, [], 'centerCoordinateSystem', 1 );
        axis square
        
        zl1 = zlim;
        ax1 = gca;
        
        %show x-profile
        subplot(2,2,2), hold on,
        profile_H_2D       = H_2D(ceil(end/2),1:end);
        profile_imageOfFit = imageOfFit(ceil(end/2),1:end);
        x_coord = 1:length(profile_H_2D);
        
        x_coord = x_coord-x_coord(ceil(end/2));
        x_coord = x_coord+p_2D(1);
        x_coord = x_coord-x_coord(ceil(end/2));
        
        plot(x_coord,profile_H_2D, '-k', 'LineWidth', 2.5);
        plot(x_coord,profile_imageOfFit, '--r', 'LineWidth', 1.5);
        
        if(isempty(imageListOfSubFits))
            subplot(2,2,4), imshow(imadjust(H_2D),[]);
            title('image fitted');
        else
            subplot(2,2,4);
            displayFit(imageListOfSubFits{1}, imageListOfSubFits{2},'fit decomposition' );
            axis square
            zl2 = zlim;
            zlim([min(zl1(1),zl2(1)), max(zl1(2), zl2(2))]);
            zlim(ax1,[min(zl1(1),zl2(1)), max(zl1(2), zl2(2))]);
        end
        colormap('hsv');
        try
            set(gcf,'name', sprintf('t=%d, trID = %d, objID = %04d, %s',t, trID, objID, param.tag));
        catch
            printDebugStack(lasterror);
        end
        
        stub = sprintf('_trID=%03d_t=%03d_objID=%05d',trID,t,objID);
        saveas(fig1, [dirDebug filesep 'fitting2DViz' stub '.fig']);
        
        if(getDebugLevel() >= 2)
            writeTIFF(im2uint16(H_2D), [dirDebug filesep 'imageClipping' stub '.tif']);
            writeTIFF(im2uint16(imageOfFit), [dirDebug filesep 'fitting2DClipping' stub '.tif']);
            for k = 1 : length(imageListOfSubFits)
                writeTIFF(im2uint16(imageOfFitList{k}), [dirDebug filesep sprintf('fitting2D_sub%d_Clipping',k) stub '.tif']);
            end
            writeTIFF(im2uint16(max(0,H_2D-background)), [dirDebug filesep 'fitting2DClippingMinuscAdd' stub '.tif']);
        end
    end
    
    positionUpdated = 0;
    if(update2DPostion)
        %update x,y position
        T(i,1) = x_center;
        T(i,2) = y_center;
        positionUpdated = 1;
    end
    
    if(positionUpdated)
        peak = p_2D(peakIdx)+p_2D(backgroundIdx);
    else
        patch_radius = 1;
        patch = imcropCentered(I, round(T(i,2)), round(T(i,1)), patch_radius);
        peak = mean(patch(:));
    end
    
    bg = p_2D(backgroundIdx);
    peakBGRatio = peak / bg;
    
    %compute mean-illumination-to-background-ratio
    radiusG = 2*sqrt(p_2D(sigmaxIdx)*p_2D(sigmayIdx));
    dim 	= 2*ceil(radiusG)+1;
    ringPattern                     = MakeRingPattern([dim,dim],max(1,round(radiusG)),1,0);
    sumInnerRingPattern             = sum(ringPattern(:));
    meanIntensity                   = ComputeCorrelationScore(I, ringPattern, round(T(i,2)), round(T(i,1))) / sumInnerRingPattern;
    meanIntensityToBackgroundRatio  = meanIntensity / bg;
    
    %data from 2D fit
    p_2D_idxRoi_2D                                    = [p_2D, idxRoi_2D];
    p_2D_idxRoi_2D(peakBGRatioIdx)                    = peakBGRatio;
    p_2D_idxRoi_2D(meanIntensityToBackgroundRatioIdx) = meanIntensityToBackgroundRatio;
    
    for k = 1 : length(paramNames)
        T(i,colIdx(k)) = p_2D_idxRoi_2D(k);
    end
    
    if(updateFittingManager)
        [fit, fitIdx] = findManagerEntry(fittingManager, objID);
        if(isempty(fit))
            fit.objID = objID;
            fitIdx    = length(fittingManager) + 1;
        end
        fit.(fittingMode).Io                    = H_2D;
        fit.(fittingMode).If                    = imageOfFit;
        fit.(fittingMode).imageListOfSubFits    = imageListOfSubFits;
        fit.(fittingMode).p                     = p_2D_idxRoi_2D;
        fit.(fittingMode).paramNames            = paramNames;
        fittingManager{fitIdx} = fit;
    end
end
waitbar();
if(~isempty(T_notUpdated))
    T = [T;T_notUpdated];
    T = sortrows(T,4);
end

fprintMatrix(filenameOut, T, header);
if(updateFittingManager)
    save(fn_matlab_FittingManager, 'fittingManager');
end
if(exist('LinearIntensityProfileContainer', 'var'))
    save(fn_matlab_LinearIntensityProfile, 'LinearIntensityProfileContainer');
end
if(nargin == 0)
    %     makeTrackingMovie(workingDir, filenameOut, [], 0, 'showObjID',1,'openMovie',1)
end
end

function [fit, idx] = findManagerEntry(fittingManager, objID)
for i = 1 : length(fittingManager)
    if(fittingManager{i}.objID == objID)
        fit = fittingManager{i};
        idx = i;
        return
    end
end
fit = [];
idx = -1;
end