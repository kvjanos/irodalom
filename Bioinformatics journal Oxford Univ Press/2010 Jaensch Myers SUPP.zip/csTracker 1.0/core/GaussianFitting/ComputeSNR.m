function [SNR, r, signalMean, noise, signal, bg] = ComputeSNR(I, maskSignal, maskBackground)
% see also: ComputeSNR_centrosomePatch, ComputeSNR_fullCentrosomeImage

signal = I(maskSignal(:)>0);
bg     = I(maskBackground(:)>0);

if(isempty(signal))
    signal = 0;
end
if(isempty(bg))
    bg = 0;
end
signalMean  = mean(signal);
noise       = std(bg);
r           = signalMean/noise;
SNR = 20*log10(r);

if(isnan(r))
    error('signalMean/noise = NaN');
end
if(isnan(SNR))
    error('SNR = NaN');
end
end