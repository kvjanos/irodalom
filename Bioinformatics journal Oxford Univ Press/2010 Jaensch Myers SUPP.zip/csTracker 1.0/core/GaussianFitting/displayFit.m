function displayFit(image, imageOfFit, titleText, fittingParameters, varargin )

%any parameter maybe empty

%displace the image so that its center is at the origin of the coordinate system
centerCoordinateSystem  = getVarargin( varargin, 'centerCoordinateSystem', 0 );

%displays a ring around the Gaussian fit indicating theradius of the centrosome
%values: 'auto'       ==> radius will be 2*meanSigmaXY, requires the imageOfFit and the fittingParameters
%         > 0         ==> ring with this radius will be displayed
%         0 or 'off'  ==> no ring will be displayed

displayImageOfFit       = getVarargin( varargin, 'displayImageOfFit', 1 ); 
displayRingRadius       = getVarargin( varargin, 'displayRingRadius', 'auto' ); 
warnings                = getVarargin( varargin, 'warnings', 'off' ); 
thirdImage              = getVarargin( varargin, 'thirdImage', [] ); 
fontSize                = getVarargin( varargin, 'Fontsize', 9 ); 




if(~isempty(image) && ~isempty(imageOfFit))
    if(size(image,2) ~= size(imageOfFit,2) || size(image,1) ~= size(imageOfFit,1))
        error('image and imageOfFit must have the same size or be empty');
    end
end



colormap('hsv');
grid('on');

if(~isempty(image))
    siz = size(image);
else
    siz = size(imageOfFit);
end
 
if(centerCoordinateSystem)
    w = floor(siz(2) / 2);
    h = floor(siz(1) / 2);
    [X, Y] = meshgrid(-w:w,-h:h);
    center = [0,0];
else
    w = max(siz(2), siz(2));
    h = max(siz(1), siz(1));
    [X, Y] = meshgrid(1:w,1:h);
    center = [w,h]/2;
end

if(~isempty(image) && any(size(image) ~= size(X)))
    warning(sprintf('size of grid [%d,%d] does not match size of the image [%d,%d]. truncating the grid',size(X),size(image)));
    X = X(1:size(image, 1),1:size(image,2));
    Y = Y(1:size(image, 1),1:size(image,2));
end

if(~isempty(image))
    surf(X,Y,image,'EdgeLighting','flat','FaceLighting','none',...
        'LineWidth',1.0,...
        'FaceColor','none',...
        'FaceAlpha',0.9);
end

holdWasOn = 1;
if(~ishold)
    holdWasOn = 0;
    hold on
end

if(~isempty(imageOfFit))
    
    if(displayImageOfFit)
        surf(X,Y,imageOfFit,'LineStyle','none','FaceColor','interp','FaceAlpha',0.7);
%         surf(X,Y,imageOfFit,'LineStyle','none','FaceColor','interp','FaceAlpha',1);
    end
    
    if(ischar(displayRingRadius))
        if(strcmpi(displayRingRadius, 'auto'))
            if(nargin >= 4 && ~isempty(fittingParameters))
                ringRadius = 2*mean(fittingParameters(3:4));
            else
                ringRadius = 0;
                if(~strcmpi(warnings, 'off'))
                    warning('fitting parameters are required for auto ring radius. cannot display ring')
                end
            end
        else
            ringRadius = 0;
        end
    else
        ringRadius = displayRingRadius;
    end
    if(ringRadius > 0)

        yAtMeanRadius = [];
        if(ceil(siz(2)/2+ringRadius) <= siz(2))
            yAtMeanRadius(end+1)     = imageOfFit(ceil(siz(1)/2),ceil(siz(2)/2+ringRadius));
        end
        if(ceil(siz(2)/2-ringRadius) > 0)
            yAtMeanRadius(end+1)     = imageOfFit(ceil(siz(1)/2),ceil(siz(2)/2-ringRadius));
        end
        if(ceil(siz(1)/2+ringRadius) <= siz(1))
            yAtMeanRadius(end+1)     = imageOfFit(ceil(siz(1)/2+ringRadius),ceil(siz(2)/2));
        end
        if(ceil(siz(1)/2-ringRadius) > 0)
            yAtMeanRadius(end+1)     = imageOfFit(ceil(siz(1)/2-ringRadius),ceil(siz(2)/2));
        end 
        
        if(~isempty(yAtMeanRadius))
            yAtMeanRadius   = mean(yAtMeanRadius);
        
            [Xcy,Ycy,Zcy] = MakeCylinder(ringRadius,center,.003,yAtMeanRadius);
             surf(Xcy,Ycy,Zcy,...
            'EdgeLighting','flat',...
            'FaceLighting','flat',...
            'LineWidth',1.0,...
            'FaceColor','r',...
            'EdgeColor','none',...
            'FaceAlpha',1)

            [Xcy,Ycy,Zcy] = MakeCylinder(ringRadius,center,.001,yAtMeanRadius);
             surf(Xcy,Ycy,Zcy,...
            'EdgeLighting','flat',...
            'FaceLighting','flat',...
            'LineWidth',1.0,...
            'FaceColor','y',...
            'EdgeColor','none',...
            'FaceAlpha',1)
        end

    end
    
end

if(~isempty(thirdImage))
    surf(X,Y,thirdImage,...
        'EdgeLighting','flat',...
        'EdgeColor',[.8 0 .4],...
        'FaceLighting','phong',...
        'LineWidth',1.0,...
        'FaceColor','red',...
        'FaceAlpha',0.3);
end

if(~centerCoordinateSystem)
    yl = ylim;
    ylim([0 , yl(2)]);
end
if(nargin >= 4 && ~isempty(fittingParameters))
    str = '';
    if(length(fittingParameters) == 6)
        str = sprintf('\nmean = (%.1f,%.1f), sigma = (%.2f,%.2f), cMult = %.5f, cAdd = %.5f',fittingParameters);
    elseif(length(fittingParameters) == 7)
        str = sprintf('\nmean = (%.1f,%.1f), sigma = (%.2f,%.2f), cMult = %.5f, cAdd = %.5f, rho = %.1f',fittingParameters);
    elseif(length(fittingParameters) == 8)
        str = sprintf('\nmean = (%.1f,%.1f), sigma = (%.2f,%.2f), cMult = %.5f, cAdd = %.5f, avgRes = %.3f, fromMixtureFit = %d',fittingParameters);
    end
    titleText = [titleText str];
end

if(nargin >= 3 && ~isempty(titleText))
    title(sprintf('%s\n(mesh = image, colored surface = fit)',titleText), 'FontSize', fontSize);
end

if(~holdWasOn)
    hold off
end
view([-37.5 6.0]);