function [ varargout ] = EstimateCsRadiusFromGaussianFitAndRawData( varargin )
% determines the cs-radius as the width in a radial intensity profile at
% 2*sigma of the Gaussian fit

if(nargin == 0)
    workingDir =  [baseDir filesep 'yTUB-GFP27_WT\workingDir\1'];
    workingDir =  [baseDir filesep 'yTUB-GFP14_WT_2to4cellstage\workingDir\1'];
    workingDir =  [baseDir filesep 'yTUB-GFP1_WT_1to8cellstage\workingDir\1'];
    workingDir =  [baseDir filesep 'SPD2-GFP1_T233A_T232S\workingDir\1'];
    workingDir =  [baseDir filesep 'yTUB-GFP50_WT\workingDir\1'];
    workingDir =  [baseDir filesep 'beads1_100nm_onSlide\workingDir\1'];
    workingDir = [baseDir filesep 'SPD5-YFP_16hrsdevelopment\workingDir\1'];
    workingDir = [baseDir filesep 'RSA1-GFP2_16hrsdevelopment\workingDir\1'];
    

    workingDir = [baseDir filesep 'RSA1-GFP5_WT_4to8cellstage\workingDir\1'];
    filenameIn  = finalTrackingFile();

    workingDir = [baseDir filesep 'SPD2-GFP2_yTUB-Alexa617_WT_1cellstage_notDeconvolved\workingDir\1'];
    filenameIn  = finalCandidatesFile();
    setDebugLevel(3);
    
    varargin{1} = workingDir;
    varargin{2} = filenameIn;
end
fprintf('%s\n',mfilename);


[ zRangeForMaxprojection, keyFound, varargin ] = getVarargin(varargin,  'zRangeForMaxprojection', [], 1 );


strGaussFnct            = 'myGauss2D_rotation2';
if(isempty(zRangeForMaxprojection)) % compute radial intensity on brightest plane
    prefix                  = '';
    gaussBackgroundColname  = 'gaussAdd2D';
    angleColname            = 'rho';
    gaussColNames           = {'meanX2D','meanY2D','sigmaX2D','sigmaY2D','gaussMult2D','gaussAdd2D','rho'};
else  % compute radial intensity on maximum projection
    prefix  = 'maxprj_';
    gaussBackgroundColname  = 'maxprj_gaussAdd2D';
    angleColname            = 'maxprj_rho';
    gaussColNames           = {'maxprj_meanX2D','maxprj_meanY2D','maxprj_sigmaX2D','maxprj_sigmaY2D','maxprj_gaussMult2D','maxprj_gaussAdd2D','maxprj_rho'};
end

global param;
[T, header, filenameIn, filenameOut, dirDebug] = processInput(varargin, ['*' strRemovePostfix(prefix,'_') 'csRc'], strRemovePostfix([mfilename '_' strRemovePostfix(prefix,'_')], '_'));
if(isempty(T))
    varargout{1} = filenameOut;
    return;
end


% zRangeForMaxprojection  = 0;
% strGaussFnct            = 'myGauss2D_rotation2';
% gaussBackgroundColname  = 'rf_gaussAdd2D';
% angleColname            = 'rf_rho';
% gaussColNames           = {'rf_meanX2D','rf_meanY2D','rf_sigmaX2D','rf_sigmaY2D','rf_gaussMult2D','rf_gaussAdd2D','rf_rho'};


setImageSource('type','raw');
[header, csRadiusCorrectedColIdx]            = addHeaderEntry(header, [prefix 'csRadiusCorrected_circleEquiv']);
[header, csRadiusCorrected_meanAxisColIdx]   = addHeaderEntry(header, [prefix 'csRadiusCorrected_meanAxis']);
[header, csRadiusCorrected_majorAxisColIdx]  = addHeaderEntry(header, [prefix 'csRadiusCorrected_majorAxis']);
[header, csRadiusCorrected_minorAxisColIdx]  = addHeaderEntry(header, [prefix 'csRadiusCorrected_minorAxis']);
[header, SNRColIdx]                          = addHeaderEntry(header, [prefix 'SNR']);

objIDColIdx          = headerIndex(header, 'objID');
gaussColIdx          = headerIndex(header, gaussColNames);
fromMixtureFitColIdx = headerIndex(header, 'fromMixtureFit','none');

sigmaX2DColIdx  = gaussColIdx(3);
sigmaY2DColIdx  = gaussColIdx(4);

if(getDebugLevel() >= 2)
%     [T, header] = ComputeDerivedParameters(T, header);
    T = T(ismember(T(:,headerIndex(header, 'objID')), [304]),:);
%     T = T(ismember(T(:,headerIndex(header, 't')), [47]),:);
%     T = T(ismember(T(:,headerIndex(header, 'normTime')), [-540]),:);
end
%  T = T(ismember(T(:,headerIndex(header, 't')), [1:70]),:);

if(getDebugLevel() >= 1)
    fig1 = sfigure; maximize(fig1);
end
N = size(T,1)
T = sortrows(T,4); %sort by time
lastT = -1;

if(isempty(angleColname))
    gaussFitColIdx_angle = -1;
else
    gaussFitColIdx_angle = find(strcmpi(gaussColNames, angleColname));
end
radiusAggregationFunctions = {@(x)(max(x,[],2)), @(x)(min(x,[],2)), @(x)(mean(x,2)), @(x)(sqrt(prod(x,2)))};
for i = 1 : N
    x = T(i,1);
    y = T(i,2);
    z = T(i,3);
    t = T(i,4);
    objID = T(i, objIDColIdx);
    if(lastT ~= t)
        fprintf('%t = d / %d\n', t , T(N,4));
        
        allZinThisT = unique(round(T(T(:,4)==t,3)));
        if(~isempty(zRangeForMaxprojection))
            allZinThisT = getZPlanesForMaxPrjRange( allZinThisT, zRangeForMaxprojection, param.zCount );
        end
        stack = loadPartialFrame([allZinThisT allZinThisT], t, 'full' );
        waitbar(i/N,mfilename);
    end
    lastT = t;
    
    if(length(zRangeForMaxprojection)>1)
        this_zRangeMaxProjection = getZPlanesForMaxPrjRange( z, zRangeForMaxprojection, param.zCount );
        I = max(stack(:,:,this_zRangeMaxProjection), [], 3);
    else
        I = stack(:,:,z);
    end
    
    sigma = T(i,[sigmaX2DColIdx sigmaY2DColIdx]);
    ROIFactor   = 4;
    sigmaFactor = 2;
    pGaussFit = T(i,gaussColIdx);
    
    if(fromMixtureFitColIdx>0 && T(i,fromMixtureFitColIdx)==2) %don't correct radius if gaussian fitting comes from mixture fit
        for j = 1 : length(radiusAggregationFunctions)
            f = radiusAggregationFunctions{j};
            csRadiusCorrected(j) = sigmaFactor*f(sigma);
        end
    else
        if(gaussFitColIdx_angle > 0)
            alpha = pGaussFit(gaussFitColIdx_angle);
        else
            alpha = 0;
        end
        
        pos = pGaussFit(1:2);
        [csRadiusCorrected] = EstimateRadius(I, pos, sigma,alpha, ROIFactor, sigmaFactor, pGaussFit, strGaussFnct, radiusAggregationFunctions);
    end
    
    T(i, csRadiusCorrected_majorAxisColIdx) = csRadiusCorrected(1)*param.resolution;
    T(i, csRadiusCorrected_minorAxisColIdx) = csRadiusCorrected(2)*param.resolution;
    T(i, csRadiusCorrected_meanAxisColIdx)  = csRadiusCorrected(3)*param.resolution;
    T(i, csRadiusCorrectedColIdx)           = csRadiusCorrected(4)*param.resolution;
    
    background =  T(i,gaussColIdx(strcmpi(gaussColNames, gaussBackgroundColname)));
    SNR = ComputeSNR_fullCentrosomeImage(I, [y x], csRadiusCorrected(3), background);
    T(i, SNRColIdx) = SNR;
    
end
waitbar();
try
    if(getDebugLevel()<2)
        close(fig1)
    end
catch
end

if(isempty(filenameOut))
    varargout{1} = T;
    varargout{2} = header;
else
    fprintMatrix(filenameOut, T, header);
    varargout{1} = filenameOut;
end



    function [csRadiusCorrected, patch] = EstimateRadius(I, pos, sigma, alpha, ROIFactor, sigmaFactor, pGaussFit, strGaussFnct, radiusAggregationFunctions)
        x0 = round(pos(1));
        y0 = round(pos(2));

        dx = x0 - pos(1);
        dy = y0 - pos(2);
        
        if(abs(dx) > 1)
            error('abs(dx) > 1 ');
        end
        if(abs(dy) > 1)
            error('abs(dy) > 1 ');
        end
        
        radiusPatch = max(5,ceil(ROIFactor*max(sigma)));
        [patch, idxROI] = imcropCentered(I,y0,x0,radiusPatch+1);
        
        [X,Y] = meshgrid((idxROI(3):idxROI(4)),(idxROI(1):idxROI(2)));
        
        if(strcmpi(strGaussFnct, 'myGauss2D'))
            %use the x,y-coordinate as center of the Gaussian fit!
            %(for some blobs the (meanx, meany)-position has been rejected as
            %the center position of the gaussian fit)
            imageOfFit = myGauss2D(pGaussFit,[X,Y]);
            ratio_minorAxis_majorAxis = 1;
        elseif(strcmpi(strGaussFnct, 'myGauss2D_rotation2'))
            imageOfFit = myGauss2D_rotation2(pGaussFit,[X,Y]);
            ratio_minorAxis_majorAxis = min(sigma) / max(sigma);
        else
            error('unknown strGaussFnct: %s',strGaussFnct)
        end
        
        center = [pos(1);pos(2)]-[idxROI(3);idxROI(1)]+1;
        radii = 0 : .5 : max(3,4*max(sigma));
        distInterpolation = .5;
        
        
        P_image = ellipticalRadialIntensityProfile(patch,      center, ratio_minorAxis_majorAxis, alpha, radii, distInterpolation);
        P_fit   = ellipticalRadialIntensityProfile(imageOfFit, center, ratio_minorAxis_majorAxis, alpha, radii, distInterpolation);
        
        
        % translate the images sub-pixel accurately such that the blob
        % center is in the image center
        patch      = interp2(X,Y,patch,X-dx,Y-dy);
        imageOfFit = interp2(X,Y,imageOfFit,X-dx,Y-dy);
        
        patch       = patch(2:end-1,2:end-1);
        imageOfFit  = imageOfFit(2:end-1,2:end-1);
        
        csRadiusCorrected = zeros(1,length(radiusAggregationFunctions));
        for ix_agg = 1 : length(radiusAggregationFunctions)
            aggFunc = radiusAggregationFunctions{ix_agg};
            radiusFromGaussian = aggFunc(sigma);

            Dist2Intensity_image(:,1) = aggFunc(P_image(:,1:2));
            Dist2Intensity_fit(:,1)   = aggFunc(P_fit(:,1:2));
            Dist2Intensity_image(:,2) = P_image(:,3);
            Dist2Intensity_fit(:,2)   = P_fit(:,3);
            %         Dist2Intensity_image = radialIntensityProfile( patch, ceil(size(patch)/2), 'distanceFunction', 'Euclidean','integerDistances');
            %         Dist2Intensity_fit   = radialIntensityProfile( imageOfFit, ceil(size(patch)/2), 'distanceFunction', 'Euclidean','integerDistances');
            %         %         Dist2Intensity_image = radialIntensityProfile( patch, ceil(size(patch)/2), 'distanceFunction', 'Manhattan');
            %         %         Dist2Intensity_fit   = radialIntensityProfile( imageOfFit, ceil(size(patch)/2), 'distanceFunction', 'Manhattan');
            %         %         Dist2Intensity_image(:,1) = Dist2Intensity_image(:,1) / ((1+sqrt(2))/2);
            %         %         Dist2Intensity_fit(:,1) = Dist2Intensity_fit(:,1) / ((1+sqrt(2))/2);
            %
            span = 1;
            Dist2Intensity_image(:,3) = smooth(Dist2Intensity_image(:,2),span,'rloess');
            %         Dist2Intensity_image(:,3) = Dist2Intensity_image(:,2);
            
            xfit = sigmaFactor*radiusFromGaussian;
            try
            yfit = interp1(Dist2Intensity_fit(:,1),Dist2Intensity_fit(:,2),xfit);
            [ xraw_all ] = findArgument( Dist2Intensity_image(:,[1,3]), yfit);
            catch
                xraw_all = [];
                printDebugStack(lasterror)
            end
            if(isempty(xraw_all))
                csRadiusCorrected(ix_agg) = xfit;
                correctionInPixels = 0;
                xraw = [];
                warning('bad fit for object %d at t = %d. could not find intersection in raw data at gaussian intensity level',objID,t);
                badFit = 1;
            else
                diffx = abs(xraw_all - xfit);
                [minxdiff, minxdiffIdx] = min(diffx);
                xraw = xraw_all(minxdiffIdx);
                correctionInPixels = xraw_all(minxdiffIdx) - xfit;
                csRadiusCorrected(ix_agg) = xraw;
                badFit = 0;
            end
            
            if(getDebugLevel()>=1 && ix_agg <= length(radiusAggregationFunctions))
                if(getDebugLevel()>=2 && i < 20)
                    fig1 = sfigure; maximize(fig1);
                else
                    clf(fig1) %clear figure
                end
                subplot(2,2,[1,3]), hold on
                plot(Dist2Intensity_image(:,1),Dist2Intensity_image(:,2),'-k');
                plot(Dist2Intensity_image(:,1),Dist2Intensity_image(:,3),'--b', 'LineWidth', 1.5);
                plot(Dist2Intensity_fit(:,1),Dist2Intensity_fit(:,2),'-r');
                yl = ylim();
                plot( [xfit xfit],yl, ':m', 'LineWidth', 1.5);
                plot( [0, xfit], [yfit, yfit], ':m', 'LineWidth', 1.5);
                for k = 1 : length(xraw_all)
                    plot( [xraw_all(k), xraw_all(k)], [yl(1), yfit], '--k', 'LineWidth', 1.0);
                end
                if(~isempty(xraw))
                    plot( [xraw, xraw], yl, '-k', 'LineWidth', 2);
                end
                
                correctionInPercent = 100*correctionInPixels / xfit;
                title(sprintf('objID = %d, t = %d, correction = %.2f pixels (%.1f %%)\nradius aggregation = %s\ngaussian radius = %f, corrected radius = %f',objID,t, correctionInPixels,correctionInPercent, func2str(aggFunc), xfit, csRadiusCorrected(ix_agg)));
                axis square
                
                %show 3D fitting visualization
                subplot(2,2,4), hold on,
                txt = printFittingParameters(gaussColNames, pGaussFit);
                displayFit(patch, imageOfFit, txt );
                axis square
                
                %show 1D profile
                subplot(2,2,2), hold on,
                profile_patch = patch(ceil(end/2),:);
                x_coord = 1:length(profile_patch);
                x_coord = x_coord-x_coord(ceil(end/2));
                
                plot(x_coord,profile_patch, '-k', 'LineWidth', 2.5);
                sigmax = sigma(1);
                
                g1 = Gauss1D( x_coord, 0, sigmax );
                g1 = g1 / max(g1) * pGaussFit(5) + pGaussFit(6);
                plot(x_coord,g1, ':r', 'LineWidth', 1.5);
                
                f = sigmaFactor;
                plot( f*[sigmax,sigmax],ylim, ':m', 'LineWidth', 1.5);
                plot(-f*[sigmax,sigmax],ylim, ':m', 'LineWidth', 1.5);
                plot( f*[radiusFromGaussian,radiusFromGaussian],ylim, '--m', 'LineWidth', 1.0);
                plot(-f*[radiusFromGaussian,radiusFromGaussian],ylim, '--m', 'LineWidth', 1.0);
                if(~isempty(xraw))
                    plot( [xraw xraw],ylim, '-k', 'LineWidth', 1.5);
                    plot(-[xraw,xraw],ylim, '-k', 'LineWidth', 1.5);
                end
                axis square
                title('x-profile');
                
                
                try
                    cs = getCentrosomeIdentifier(T(i,:), header, 'Separator',' ', 'AlwaysAddTrID',1,  'AlwaysAddObjID',1, 'InludeDimension',1);
                    if(badFit)
                        set(gcf,'name', sprintf('bad fit: t=%d, %s, %s',t, cs, param.tag));
                    else
                        set(gcf,'name', sprintf('t=%d, %s, %s',t, cs, param.tag));
                    end
                catch
                    printDebugStack(lasterror);
                end
                
                fn_debug = [dirDebug filesep sprintf('correction_t=%03d_objID=%05d.fig',t,objID)];
                saveas(fig1, fn_debug);
            end
        end
        
    end
end




    %see ellipticalRadialIntensityProfile.m
%     function P = ComputeEllipticalIntensityProfile(I, center, ratio_minorAxis_majorAxis, alpha, radii, distInterpolation)
%         %input: I:                          - image with a spot
%         %       center                      - center of the spot 
%         %       ratio_minorAxis_majorAxis   - minor axis length divided by major axis length
%         %       alpha                       - orientation of the spot in degree
%         %       radii                       - vector of radii at which to compute the mean intensity along the ellipse
%         %       distInterpolation           - distance of readout points on the ellipse
%         
%         %output: P(:,1) - major axis length
%         %        P(:,2) - minor axis length
%         %        P(:,3) - mean intensity
%         center = center(:);
%         cosAlpha = cosd(-alpha);
%         sinAlpha = sind(-alpha);
%         R = [cosAlpha -sinAlpha
%             sinAlpha  cosAlpha];
%         
%         P = zeros(length(radii), 2);
%         r_ix = 1;
%         for r = radii(:)'
%             a = r;
%             b = ratio_minorAxis_majorAxis * r;
%             if(r == 0)
%                 p = center;
%             else
%                 w = ((a-b)/(a+b))^2;
%                 u = pi()*(a+b)*(1+3*w/(10+sqrt(4-3*w)));
%                 s = 2*pi()*distInterpolation / u;
%                 t_all = 0 : s : (2*pi());
%                 
%                 ix = 1;
%                 p = zeros(2, length(t_all));
%                 for k = t_all
%                     p(:,ix) = R*[a*cos(k);b*sin(k)]+center;
%                     ix = ix + 1;
%                 end
%                 if(getDebugLevel() >= 3)
%                     figure(1017); clf
%                     imshow(I,[]); hold on
%                     plot(p(1,:),p(2,:), 'xr');
%                 end
%             end
%             intensitiesOnEllipse = interp2(I,p(1,:),p(2,:));
%             P(r_ix,1) = a;
%             P(r_ix,2) = b;
%             P(r_ix,3) = mean(intensitiesOnEllipse);
%             r_ix = r_ix + 1;
%         end
%     end
