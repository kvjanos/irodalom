function p = imageSequenceProperties( directory )

global pathHomeDir;

fileList = fileListMaxExtention(directory);
[n, name, ext] = numberOfEndingDigitsInString(fileList(1).name,1);
firstFullFilename = fullfile(directory, fileList(1).name);

p.imageSequence.numberOfDigits = n;
p.imageSequence.indexFormattingString = digitFormattingString( n );
p.imageSequence.filenameStub        = name(1:end-n);
p.imageSequence.filenameExt         = ext;
p.imageSequence.filenameCount       = length(fileList);
p.imageSequence.relPath             = getChildPath(fileparts(firstFullFilename), pathHomeDir);
p.imageSequence.firstFilename       = fileList(1).name;
p.imageSequence.firstIndex          = sscanf(name(end-n+1:end),'%f') ;
p.isStackMultiImage = 0;
p.imageInfo = imfinfo(firstFullFilename);

p.totalImageCount = p.imageSequence.filenameCount;
p.imageWidth = p.imageInfo.Width;
p.imageHeight = p.imageInfo.Height;




