function stack = loadTimepoints( t )
%LOADTIMEPOINTS Loads all images of the given time point(s) as double data
global param;

N = length(t);
z  = 1:param.imgSource.zCount;

t_all = [];
z_all = [];
for i=1:N
    t_all = [t_all, repmat(t(i), 1, length(z))];
    z_all = [z_all, z];
end

stack = loadImages(z_all,t_all);