function [ I ] = imreadGray( filename, frameNumber )
if(nargin == 1 || frameNumber == 1)
    I = imread(filename);
else
    I = imread(filename, frameNumber);
end
if(size(I,3) > 1)
    I = rgb2gray(I);
end
    