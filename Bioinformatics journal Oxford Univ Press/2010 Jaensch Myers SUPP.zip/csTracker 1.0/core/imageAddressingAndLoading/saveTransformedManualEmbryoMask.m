function fn = saveTransformedManualEmbryoMask( mask )

% see also: loadTransformedManualEmbryoMask, specifyManualEmbryoMask,
%           loadManualEmbryoMask, saveManualEmbryoMask
%           

global pathHomeDir;
fn = [pathHomeDir filesep 'manualEmbryoMaskTransformed.tif'];
if(~isempty(mask))
    imwrite(im2uint8(mask>0),fn, 'Compression','none');
end

end

