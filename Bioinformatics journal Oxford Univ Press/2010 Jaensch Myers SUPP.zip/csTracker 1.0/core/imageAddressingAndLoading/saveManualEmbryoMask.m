function fn = saveManualEmbryoMask( mask )
% see also: loadManualEmbryoMask, specifyManualEmbryoMask
%           saveTransformedManualEmbryoMask, loadTransformedManualEmbryoMask

global pathHomeDir;
fn = [pathHomeDir filesep 'manualEmbryoMask.tif'];
if(~isempty(mask))
    imwrite(im2uint8(mask>0),fn, 'Compression','none');
end

end

