function imgIdx = firstImageIndexOfTimepoint( t )

         imgIdx = convertToImageIndex( 1,t );

