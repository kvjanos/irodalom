function [ t,z ] = convertToTimeAndZ( imgIdx )

global param;
t = ceil(imgIdx / param.zCount);
z = mod(imgIdx-1, param.zCount)+1;

end

