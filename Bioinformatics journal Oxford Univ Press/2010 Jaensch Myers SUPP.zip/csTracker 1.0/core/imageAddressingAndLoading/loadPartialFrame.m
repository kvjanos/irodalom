function [ stack, idx2z, z2idx, n ] = loadPartialFrame(Zranges, t, mode ) %Zranges = [zMin_1 zMax_1; ...;zMin_n zMax_n] 
%LOADPARTIALFRAME loads all slice of frame t contained in Zranges
%mode if either "full" or "partially"
%"full" means a stack with param.zCount images will be return, but only the
%specified images are actually loaded, all other slices are zeros
%"partially" means a stack of the specified images are returned without
%zero slices
%n is the number of slices loaded

global param;

if(nargin < 3)
    mode = 'partially';
end

allZ = [];
for i = 1 : size(Zranges,1)
    allZ = [allZ Zranges(i,1):Zranges(i,2)];
end
idx2z = unique(allZ);
n = length(idx2z);

if(strcmpi(mode,'partially'))
    allT = repmat(t,1,length(idx2z));
    stack = loadImages(idx2z, allT);

    z2idx = zeros(1,max(idx2z));

    i = 1;
    for z = idx2z
        z2idx(z) = i;
        i = i + 1;
    end
elseif(strcmpi(mode,'full'))
    stack = zeros(param.imgSource.imageHeight, param.imgSource.imageWidth, param.zCount);
    for z = idx2z
        stack(:,:,z) = loadImages(z, t);
    end
    idx2z = 1 : param.zCount;
    z2idx = idx2z;
else
    erorr('unknown mode');
end



