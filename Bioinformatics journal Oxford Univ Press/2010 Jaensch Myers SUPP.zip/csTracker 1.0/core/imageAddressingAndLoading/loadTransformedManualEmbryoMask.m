function [ manualEmbryoMask, fn ] = loadTransformedManualEmbryoMask(  )
% see also: saveTransformedManualEmbryoMask, specifyManualEmbryoMask,
%           loadManualEmbryoMask, saveManualEmbryoMask
%           

global pathHomeDir;

fn = [pathHomeDir filesep 'manualEmbryoMaskTransformed.tif'];
if(~exist(fn, 'file'))
    manualEmbryoMask = [];
else
    manualEmbryoMask = imread(fn) > 0;
end


end

