function [ maxPrj, t ] = loadMaxProjection(firstFrame, lastFrame)

global param;

if(nargin == 0)
    %maxPrj = im2double(loadImStack(param.pathMaxPrj));
    [maxPrj,t] = imreadStackDouble(param.pathMaxPrj);
else
%    maxPrj = im2double(loadImStack(param.pathMaxPrj, firstFrame, lastFrame));
    [maxPrj,t] = imreadStackDouble(param.pathMaxPrj,firstFrame:lastFrame);
end