function [ manualEmbryoMask, fn ] = loadManualEmbryoMask(  )
% see also: saveManualEmbryoMask, specifyManualEmbryoMask,
%           saveTransformedManualEmbryoMask, loadTransformedManualEmbryoMask

global pathHomeDir;

fn = [pathHomeDir filesep 'manualEmbryoMask.tif'];
if(~exist(fn, 'file'))
    manualEmbryoMask = [];
else
    manualEmbryoMask = imread(fn) > 0;
end


end

