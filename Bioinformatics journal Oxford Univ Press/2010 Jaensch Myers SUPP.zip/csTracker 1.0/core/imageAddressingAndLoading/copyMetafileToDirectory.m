function copyMetafileToDirectory( dir )
global param;

try
    copyfile(getFullPath(param.metadataFilename), dir, 'f');
catch
    warning('the metadata file could not be found or copied.');
end