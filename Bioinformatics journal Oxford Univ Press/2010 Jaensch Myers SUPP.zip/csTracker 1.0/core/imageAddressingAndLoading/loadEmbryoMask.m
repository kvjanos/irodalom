function varargout = loadEmbryoMask( type, updateEmbryoDimensionInProperties )
%type: 'original', 'convex hull', 'original:contour coordinates', 'convex hull:contour coordinates'

% [embryoMask, fn_mask] = loadEmbryoMask('original' {, updateEmbryoDimensionInProperties})
% [embryoMask, fn_mask] = loadEmbryoMask('convex hull'{, updateEmbryoDimensionInProperties})
% [embryoMask, fn_mask, contourCoordinates] = loadEmbryoMask('original:contour coordinates'{, updateEmbryoDimensionInProperties})
% [embryoMask, fn_mask, contourCoordinates] = loadEmbryoMask('convex hull:contour coordinates'{, updateEmbryoDimensionInProperties})
%
% output: embryoMask         - binary stack
%         fn_mask            - filename of the loaded image containing the embryo mask
%         contourCoordinates - a circular list (N x 2, C(1,:)=C(end,:)) of the (row,column)-coordinates
%                              of the embryo's contour, in the order of appearence

if(nargin < 2)
    updateEmbryoDimensionInProperties = 0;
end

global param;
try
    output = load(type);
catch
    workingDir = getFullPath(param.relPathWorkingDir);
    FindEmbroContourInMaxProjection(workingDir, updateEmbryoDimensionInProperties);
    output = load(type);
end

for i = 1 : length(output)
    varargout{i} = output{i};
end


    function output = load(type) %nested function
        % {embryoMask, fn_mask} = load('original')
        % {embryoMask, fn_mask} = load('convex hull')
        % {embryoMask, fn_mask, contourCoordinates} = load('original:contour coordinates')
        % {embryoMask, fn_mask, contourCoordinates} = load('convex hull:contour coordinates')
        
        [start_idx, end_idx, extents, matches, tokens, names, splits] = regexp(type, ':');
        type =  strtrim(splits{1});
        computeContourCoord = length(splits)>1;
        
        if(strcmpi(type, 'original'))
            fn_mask = getFullPath(param.relPathEmbryoContour2DMaxPrjOriginal);
        elseif(any(strcmpi(type, {'convex hull','convexhull'})))
            fn_mask = getFullPath(param.relPathEmbryoContour2DMaxPrjConvexHull);
        else
            error('unknown embryo mask type: %s', type);
        end
        
        embryoMask   = loadImStack(fn_mask);
        output{1}    = embryoMask;
        output{2}    = fn_mask;
        if(computeContourCoord)
            contourCoordinates = cell(size(embryoMask,3),1);
            for t = 1 : size(embryoMask,3)
                contourCoordinates{t}   = contour_following(embryoMask(:,:,t));
            end
            output{3} = contourCoordinates;
        end
    end

end

