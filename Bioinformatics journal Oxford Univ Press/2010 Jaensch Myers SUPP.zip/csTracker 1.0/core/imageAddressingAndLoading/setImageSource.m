function imgSource = setImageSource( varargin )
%
% input: a fullpath filename of an xml-file 
%                      or 
%        a sequence of key/value pairs e.g. {'type', 'raw'} 
%        the key must be a field of the imagingParams
%        (the special case {'type', 'original'} loads the original images)
%                      or 
%        an image source structure as returned by this function
%
%                
%           
% appends the structure to the global params under fieldname 'imgSource'
% and also returns the imgSource structure

global param;
global pathHomeDir;

if(length(varargin) == 2 && strcmpi('type', varargin{1}) && strcmpi('original', varargin{2}))
    [props, filenameLoaded] = loadProperties();
    fn = [fileparts(filenameLoaded) filesep props.MTSPropsFilename];
    mtsProps = xml_read(fn);
    imgSource = mtsProps;
    imgSource.isMultiTIFF = 1;
    imgSource.directory = fileparts(fn);
    param.imgSource = imgSource;
    return
elseif(length(varargin)==1 && ischar(varargin{1})) %varargin{1} = xml-filename 
    imgSource = loadImagingParams(varargin{1});
    allOk = 1;
elseif(length(varargin)==1 && isstruct(varargin{1})) %varargin{1} = image source structure
    imgSource = varargin{1};
    allOk = 1;
else %  a sequence of key/value pairs e.g. {'type', 'raw'} 
    D = dir(pathHomeDir);
    for i = 1 : length(D)
        if(D(i).isdir && ~strStartsWith(D(i).name,'.'))
            directory = D(i).name;
            try
                imgSource = loadImagingParams( directory );
                allOk = 1;
                for j = 1 : 2 : length(varargin)
                    if(~strcmpi(imgSource.(varargin{j}), varargin{j+1}))
                        allOk = 0;
                        break;
                    end
                end
                if(allOk)
                    break;
                end

            catch
               allOk = 0;
            end
        end
    end
end

if(allOk)
    imgSource.isMultiTIFF = 0;
    param.imgSource = imgSource;
    
%     if(~exist(imgSource.imageSequence.firstFullFilename,'file'))
%         dirImages = fileparts(imgSource.imageSequence.firstFullFilename);
%         D = dir([dirImages filesep '*.zip']);
%         if(isempty(D))
%             error('neither first image file "%s" nor any zip-file could be found in "%s"', imgSource.imageSequence.firstFullFilename, dirImages);
%         else
%             if(length(D) == 1)
%                 fnZip = [dirImages filesep D(1).name];
%                 fprintf('unzipping %s...\n',fnZip);
%                 unzip(fnZip, dirImages);
%             else
%                 error('more than one zip-file found in %s',dirImages);
%             end
%         end
%          if(~exist(imgSource.imageSequence.firstFullFilename,'file'))
%              error('could not recreate image series in "%s", first filename should be "%s"',dirImages,imgSource.imageSequence.firstFullFilename);
%          end
%     end
    
    
    setPathMaxProjection( );
    setPathMeanProjection( );
    
else
    error('no appropriate image source found: %s',strList2SeparatedString(varargin,', '));
end
end



function setPathMaxProjection( )
    global param;

    pathMaxPrj = [getFullPath(param.imgSource.imageSequence.relPath) filesep 'maxProjection'];
    pathMaxPrjSearchPattern = [pathMaxPrj filesep '*max*.tif'];

    D = dir(pathMaxPrjSearchPattern);

    if(isempty(D))
        warning('The max projection file could not be found. Was looking for %s',pathMaxPrjSearchPattern);
        return
    end

    param.pathMaxPrj = [pathMaxPrj filesep D(1).name];

    if(~exist(param.pathMaxPrj, 'file'))
        warning('The max projection file could not be found. Was looking for %s',pathMaxPrjSearchPattern);
    end
end

function setPathMeanProjection( )
    global param;

    pathMeanPrj = [getFullPath(param.imgSource.imageSequence.relPath) filesep 'meanProjection'];
    pathMeanPrjSearchPattern = [pathMeanPrj filesep '*mean*.tif'];

    D = dir(pathMeanPrjSearchPattern);

    if(isempty(D))
        param.pathMeanPrj = [];
    else
        param.pathMeanPrj = [pathMeanPrj filesep D(1).name];
    end
end
