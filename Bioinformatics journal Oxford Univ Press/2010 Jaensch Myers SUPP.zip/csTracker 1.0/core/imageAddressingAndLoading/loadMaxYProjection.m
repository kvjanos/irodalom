function [ maxYPrj, fn_maxyprj ] = loadMaxYProjection(varargin)
%
% call: loadMaxYProjection()                [loads the max-y projection only 'maxYPrj.tif']
%       loadMaxYProjection('csPositions')   [loads the max-y projection with cs positions 'maxYPrjBrightestPlane.tif']
%       loadMaxYProjection('getFilenameOnly') [ensures that the y-max projection exists, but returns only the filename of it]
%
% see also: DisplayBrightestPlaneOnMaxYProjection, ComputeIntensityProjection



global param;

withCSPositions = getVarargin(varargin, 'csPositions', 0, 0, 'single');
getFilenameOnly = getVarargin(varargin, 'getFilenameOnly', 0, 0, 'single');

if(withCSPositions)
    fn_maxyprj = getFullPath( param.relPathWorkingDir, 'maxYPrjBrightestPlane.tif' );
else
    fn_maxyprj = getFullPath( param.relPathWorkingDir, 'maxYPrj.tif' );
end

if(~exist(fn_maxyprj, 'file'))
    workingDir = fileparts(fn_maxyprj);
    if(withCSPositions)
        try
            fn_maxyprj = DisplayBrightestPlaneOnMaxYProjection(workingDir, finalTrackingFile());
            
        catch
            fn_maxyprj = ComputeIntensityProjection(workingDir, 'max', 'y', 'raw');
        end
    else
        fn_maxyprj = ComputeIntensityProjection(workingDir, 'max', 'y', 'raw');
    end
end
if(getFilenameOnly)
    maxYPrj = [];
else
    maxYPrj = im2double(loadImStack(fn_maxyprj));
end