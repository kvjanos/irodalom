function [ maxPrj ] = loadMeanProjection(firstFrame, lastFrame)

global param;

if(isempty(param.pathMeanPrj))
   fn = ComputeMeanZProjection([],param.imgSource);
   param.pathMeanPrj = fn;
   saveGlobalParams();
end

if(nargin == 0)
    maxPrj = im2double(loadImStack(param.pathMeanPrj));
else
    maxPrj = im2double(loadImStack(param.pathMeanPrj, firstFrame, lastFrame));
end