function [filename, internalFrameNo, iminfo, fileIndex, imCount] = frame2Imagefilename( imgIdx )
    global param;

    if(isfield(param, 'isStackMultiImage') && param.isStackMultiImage == 1)
    
        error('multi-TIFF is not supported');
%         i=1;    
%         while imgIdx > param.imageCountCumul{i}
%             i = i + 1;
%         end
%         filename = param.pathImages{i}; 
%         if(i > 1)
%             internalFrameNo = imgIdx - param.imageCountCumul{i-1};
%         else
%             internalFrameNo = imgIdx;
%         end
% 
%         iminfo  = param.imageInfo(i);
%         imCount = param.imageCount{i};
%         fileIndex = i;

    else
        p = param.imgSource.imageSequence;
        imgIdx          = imgIdx - p.firstIndex + 1;
        filename        = [p.absPath filesep p.filenameStub sprintf(p.indexFormattingString,imgIdx) p.filenameExt];  
        internalFrameNo = 1;
        iminfo          = param.imgSource.imageInfo(1);
        fileIndex       = imgIdx;
        imCount         = 1;        
    end
end
