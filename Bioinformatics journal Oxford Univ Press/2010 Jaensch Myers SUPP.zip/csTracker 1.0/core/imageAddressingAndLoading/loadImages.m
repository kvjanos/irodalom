function stack = loadImages( z, t, varargin )
global param;

returnEmptyIfImagesAreZipped = getVarargin(varargin,'returnEmptyIfImagesAreZipped',0,1);

N = length(z);
if(length(t) ~= N)
    error('the vectors z and t must have the same length');
end


imgSource = param.imgSource;
if(isfield(imgSource, 'imageSequence') && ~exist(imgSource.imageSequence.firstFullFilename,'file'))
    dirImages = fileparts(imgSource.imageSequence.firstFullFilename);
    D = dir([dirImages filesep '*.zip']);
    if(isempty(D))
        error('neither first image file "%s" nor any zip-file could be found in "%s"', imgSource.imageSequence.firstFullFilename, dirImages);
    else
        if(length(D) == 1)
            fnZip = [dirImages filesep D(1).name];
            if(returnEmptyIfImagesAreZipped)
                fprintf('zipped images found (%s), but will not unzip. returning empty stack.\n',fnZip);
                stack = [];
                return
            else
                fprintf('unzipping %s...\n',fnZip);
                unzip(fnZip, dirImages);
            end
        else
            error('more than one zip-file found in %s',dirImages);
        end
    end
     if(~exist(imgSource.imageSequence.firstFullFilename,'file'))
         error('could not recreate image series in "%s", first filename should be "%s"',dirImages,imgSource.imageSequence.firstFullFilename);
     end
end




if(param.imgSource.isMultiTIFF)
    stack = im2double(imreadFromMTS(param.imgSource, param.imgSource.directory, z, t));
else
    %pre-allocate memory
    stack = zeros(param.imgSource.imageHeight, param.imgSource.imageWidth, N, 'double');
    
    for i = 1 : N
        [filename, internalFrameNo] = frame2Imagefilename((t(i) - 1) * param.imgSource.zCount + z(i));
        stack(:,:,i) = im2double(imreadGray(filename,internalFrameNo));
    end
end


