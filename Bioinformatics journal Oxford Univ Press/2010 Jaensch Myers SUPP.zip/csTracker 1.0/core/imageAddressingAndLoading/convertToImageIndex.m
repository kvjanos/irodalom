function [ imgIdx ] = convertToImageIndex( z,t )
%if z is empty, the indices for all images in frame t will be calculated


global param;
if(isempty(z))
    z = 1:param.zCount;
end
imgIdx = (t-1)*param.zCount+z;
