function [ cellID2displacement ] = SortCellsByTimeUsingSpindleLength( T, header, cellIDs )

if(nargin == 0)
   workingDir = [baseDir filesep 'RSA1-GFP4_WT_8to16cellstage\workingDir\1'];
   filenameIn = finalTrackingFile();
   [T, header] = loadList(addDirectoryToFilename(workingDir, filenameIn));
   
   validColIdx  = headerIndex(header, 'valid');
   cellIDColIdx = headerIndex(header, 'cellID');
   cellIDs = unique(T(T(:,validColIdx)==1 & T(:,cellIDColIdx)>0,cellIDColIdx));
end

cellIDs = cellIDs(:);
spindleLenMidZColIdx    = headerIndex(header, 'spindleLenMidZ');
cellIDColIdx            = headerIndex(header, 'cellID');
trIDColIdx              = headerIndex(header, 'trID');

Frame   = cell(length(cellIDs),1);
SpinLen = cell(length(cellIDs),1);
for i = 1 : length(cellIDs)
    cellID = cellIDs(i);
    trIDs = unique(T(T(:,cellIDColIdx) == cellID, trIDColIdx));
    idx_trID1 = T(:,trIDColIdx) == trIDs(1);
    t             = T(idx_trID1,4);
    spindleLength = T(idx_trID1,spindleLenMidZColIdx);
    
    t = t(spindleLength>0);
    spindleLength = spindleLength(spindleLength>0);
    
    Frame{i} = t;
    SpinLen{i} = spindleLength;
end
interpolationInterval = .25; %frames
allowScaling = 1;
N = length(Frame);
displacementMatrix = zeros(N,N);

for i = 1 : N-1
    for j = i+1 : N
        %use debugLevel == 2 for visualization
        [x2_aligned, y2_aligned, displacement ]= AlignCurves_autoMaxDisplacement(Frame{i},SpinLen{i},Frame{j},SpinLen{j}, interpolationInterval,allowScaling);
        displacementMatrix(i,j) =  displacement;
        displacementMatrix(j,i) = -displacement;
    end
end
sum_displacement = sum(displacementMatrix,2);
cellID2displacement = [cellIDs, sum_displacement];
cellID2displacement = sortrows(cellID2displacement,2); %cell-IDs sorted by time

end

