function makeImageSequenceFromMultiTIFF(dirIn, files, filenameOut, roiBeforeRotating, angle,roiAfterRotating, bitDepthEffective, bitDepthOut )
%MAKEIMAGESEQUENCEFROMMULTITIFF 
%writes the images of an image stack as individual files, also croppes the
%images if a ROI is specefied
% 
% dirIn ==> where the input files are
% files ==> list of filenames of multi-TIFFs (with or without path, in the latter case
% dirIn will be ignored)
% filenameOut ==> complete filename with path and extension (determines
% image format), an index number will be added to the actual filenames
% bitDepthEffective ==> the bit depth of your image data (maybe less than
% the actual bit depth of the image files)
% bitDepthOut ==> desired output bit depth


[dirOut, nameOut, ext] = fileparts(filenameOut);


%%

ensureDirExists(dirOut);
disp('writing image sequence...');

bundledRotationBuffer = 100; %max number of images put into a 3D array to speed up image rotation ==> don't risk out-of-memory exception!!!
N = length(files);
c = 0;
for i = 1 : N
    waitbar(1/N);
    filenameIn = addDirectoryToFilename(dirIn , files{i});
    imageInfo = imfinfo(filenameIn);
    bitDepthActual = imageInfo.BitDepth;
    fprintf('%s: %d images\n',files{i},length(imageInfo));
    
    [idx, imgChunks] = chunks( 1:length(imageInfo), bundledRotationBuffer );
    
    for k = 1 : length(imgChunks)
        thisChunk = imgChunks{k};
        stack = loadImStack(filenameIn, thisChunk(1), thisChunk(end), imageInfo);
        if(~isempty(roiBeforeRotating))
            stack = imcrop2(stack,roiBeforeRotating);
        end
        if(angle ~= 0)
                stack = stackRotate(stack,angle,'bicubic');
        end
        if(~isempty(roiAfterRotating))
            stack = imcrop2(stack,roiAfterRotating);
        end
        for j = 1:size(stack,3)
            c = c + 1;

            if(bitDepthActual == bitDepthOut)
                I = stack(:,:,j);
            else
                I = ConvertImageBitDepth(stack(:,:,j), bitDepthEffective, bitDepthActual, bitDepthOut);
            end
            filename = [dirOut filesep nameOut sprintf('%05d',c) ext];

            if(strcmpi(ext,'.tif'))
                writeTIFF(I, filename);
            elseif(strcmpi(ext,'.jpg'))
                writeJPEG(I, filename);
            else
                imwrite(I, filename); 
            end

        end
    end
end
waitbar();