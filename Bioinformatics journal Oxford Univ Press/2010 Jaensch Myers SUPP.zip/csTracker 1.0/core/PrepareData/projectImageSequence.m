function projectImageSequence( firstFilenameIn, filenameOut, zCount, prjFunc )

[files, dirIn] = fileListOfFirstFile(firstFilenameIn);

ensureDirExists(fileparts(filenameOut));
deleteFileIfExists(filenameOut);
N = length(files);
disp('computing projection...\n');

z = 1;

for i = 1:N
    filename = [dirIn filesep files{i}];
    if(i == 1)
        iminfo = imfinfo(filename);
        bits = iminfo.BitDepth;
        SEQ  = zeros(iminfo.Height,iminfo.Width,zCount);
    end
    
    SEQ(:,:,z) = imread(filename);
    z = z + 1;
    
    if(z > zCount)
        switch prjFunc
            case 'max'
                img = max(SEQ,[],3); 
            case 'sum'
                img = sum(SEQ,3); 
            case 'mean'
                img = mean(SEQ,3);                
            case 'median'
                img = median(SEQ,3);
        end
        if(bits == 8)
            img = uint8(img); %do not use 'im2uint8' here, would lead to incorrect conversion
        else
            img = uint16(img); %do not use 'im2uint16' here, would lead to incorrect conversion 
        end    
                
        imwrite(img, filenameOut, 'Compression', 'none', 'WriteMode', 'append');
        z = 1;
    end
end
