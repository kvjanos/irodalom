function [ roi, angle_, marginApplied, roiOnImage ] = FindEmbryoROIFromStack( stack, maxMaxPrj, margin, rotateImages, cropImages, segmentationAlgorithm, resolution, embryoDimension, manualEmbryoMask, t, z)
%
% input: stack                  - containing embryo images
%        maxMaxPrj              - max-max-projection of entire movie, used for
%                                 visualization, maybe empty
%        margin                 - a scalar value by which the roi will be bigger in all
%                                 directions than the actual embryo roi found in the images
%        rotateImages           - 1 ==> rotate images by computed orientation of the embryo
%        cropImages             - 1 ==> crop images to the embryo ROI
%        segmentationAlgorithm  - 'thresholdingOnSingleImages', 'watershedOnStack'
%        resolution             - image resolution in x/y
%        embryoDimension        - expected length and width of the embryo (microns)
%        manualEmbryoMask       - manually specifies embryo mask, maybe empty
%        t, z                   - the time and z-coordinates of the images
%                                 given in 'stack' (needed for debugging output only)


% see also: FindEmbryoContourInStack, prepareImageStack

if(isempty(manualEmbryoMask))
    fn_debug = [getDebugDir() filesep 'debuginfo.txt'];
    
    fprintf('segmenting images to find embryo ROI...\n');
    PrintToFile(sprintf('selected images for segmentation:\n\tt = [%s]\n\tz = [%s]', sprintVector(t,',','% 3d'), sprintVector(z,',','% 3d')), fn_debug, 'a', 1);

    [ stackMask, stackOverlay, shapeFactor, angle_, area_ ] = FindEmbryoContourInStack( stack, segmentationAlgorithm);
    
    %expected embryo area = area of ellipse:
    expectedEmbryoArea_pixels = pi*prod(embryoDimension)/4 * (1000 / resolution)^2;
    PrintToFile(sprintf('expectedEmbryoArea_pixels = %.f', expectedEmbryoArea_pixels), fn_debug, 'a', 1);
    PrintToFile(sprintf('embryoDimension = %d x %d', embryoDimension(1),embryoDimension(2)), fn_debug, 'a', 1);


    areaOkIdx = area_ > expectedEmbryoArea_pixels/2 & expectedEmbryoArea_pixels < 2*expectedEmbryoArea_pixels;
    median_shapeFactor = median(shapeFactor(areaOkIdx));
    
    PrintToFile(sprintf('length(areaOkIdx) = %d', length(areaOkIdx)), fn_debug, 'a', 1);
    
    
    idx = find(shapeFactor >= median_shapeFactor & areaOkIdx);
    if(isempty(idx))
        PrintToFile(sprintf('no regions with appropriate area and shape factor found'), fn_debug, 'a', 1);
        if(~any(areaOkIdx))
            PrintToFile(sprintf('no regions with appropriate area found...ignoring area properties'), fn_debug, 'a', 1);
            median_shapeFactor = median(shapeFactor);
            idx = find(shapeFactor >= median_shapeFactor);
        else
            PrintToFile(sprintf('ignoring shape factor, using only regions with appropriate area'), fn_debug, 'a', 1);
            idx = find(areaOkIdx);
        end
    end
    if(isempty(idx))
        error('no valid embryo contour found. bad image or bug in algorithm???');
    end
    stackMask    = stackMask(:,:,idx);
    angle_       = angle_(idx);
    
    mask  = max(stackMask, [], 3) > 0;
    mask  = imfill(mask,'holes'); %fill holes
else %manual embryo mask specified
    mask   = manualEmbryoMask > 0;
    rp     = regionprops(bwlabel(mask), 'Orientation');
    angle_ = rp.Orientation;
end
% since the angle range is (-90, 90] we cannot directly compute the mean of
% an angle vector like this: [-89,-87,88,89,89,-89]
% ==> convert the negative angle to positive ones
absAngle = abs(angle_);
if(all(absAngle > 45 & absAngle <= 90))
    idxNegativeAngles = find(angle_ < 0);
    if(length(idxNegativeAngles) < length(angle_)) %at least one positive and one negative angle are present
        angle_(idxNegativeAngles) = angle_(idxNegativeAngles) + 180;
    end
    
end

%leave out the smallest and largest values
angle_ = sort(angle_);
if(length(angle_)>=5)
    angle_ = angle_(3:end-2);
elseif(length(angle_)>=3)
    angle_ = angle_(2:end-1);
end

angle_ = mean(angle_);
if(abs(angle_) < 2)
    angle_ = 0;
end
if(~rotateImages)
    angle_ = 0;
end

if(angle_ ~= 0)
    mask_rot = imrotate(mask,-angle_,'bicubic');
else
    mask_rot = mask;
end

if(cropImages)
    [idxRoi, roi] = getEnclosingROI(mask_rot, margin);
    marginApplied = margin;
else
    idxRoi          = [];
    roi             = [];
    marginApplied   = [];
end
if(getDebugLevel >= 1)
    try
        filenameDebug = [getDebugDir filesep 'maxMaxPrj.tif'];
        writeTIFF(im2uint16(maxMaxPrj), filenameDebug);
    catch
        printDebugStack(lasterror)
    end
end
if(nargout > 2 || getDebugLevel >= 2)
    
    if(isempty(maxMaxPrj))
        maxMaxPrj = zeros([size(stack,1), size(stack,2)]);
        maxGray = .25;
    else
        maxGray = max(maxMaxPrj(:));
    end
    roiOnImage = imrotate(maxMaxPrj,-angle_,'bicubic');
    if(~isempty(idxRoi))
        roiOnImage(idxRoi(1),idxRoi(3):idxRoi(4)) = maxGray;
        roiOnImage(idxRoi(2),idxRoi(3):idxRoi(4)) = maxGray;
        roiOnImage(idxRoi(1):idxRoi(2),idxRoi(3)) = maxGray;
        roiOnImage(idxRoi(1):idxRoi(2),idxRoi(4)) = maxGray;
    end
    roiOnImage = OverlayMask(roiOnImage, mask_rot);
end

end

function [idxRoi, roi] = getEnclosingROI(bw_Image, margin)
onPixelIdxList = find(bw_Image);
[Y,X] = ind2sub(size(bw_Image), onPixelIdxList);

maxY = max(Y);
maxX = max(X);
minY = min(Y);
minX = min(X);

idxRoi = [max(1,minY-margin),min(size(bw_Image,1),maxY + margin), max(1,minX-margin), min(size(bw_Image,2),maxX+margin)];
roi = indexROIToStandardROI(idxRoi);
end