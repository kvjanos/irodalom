function [dirRawImageSequence, dirSmoothedImageSequence, stoppedAfterComputingMaxProjection] = prepareImageStackMultiColor( firstMultiTIFFFile)

% prepares a movie for tracking
% - input is a multi-TIFF stack, can consist of multiple files that all have
%   the same file name apart from an image series numbering at the end
% - for movies with only one color channel the method 'prepareImageStack'
%   will directly be called on 'firstMultiTIFFFile'
% - for movie with more than one color channel:
%   * the movie will be split into seperate files, one for each color channel
%   * the properties file must specify how to handle the color channels with an entry of the following form:
%     = 	<colorChannels>
%               <item><name>main</name><wavelength>488</wavelength></item>
%               <item><name>red</name><wavelength>640</wavelength></item>
%           </colorChannels>
%   * the main channel will be directly handled by 'prepareImageStack'
%   * for all other channels an image sequence from the multiTIFF stack in
%     the raw format will be created with the same initial-ROI, ROI and
%     angle as the main channel
%
% see also: prepareImageStack, prepareImageStack_batch


maxPrjFolderName = 'maxProjection'; %this folder name is assumed in main.m to locate the max-projection

global pathHomeDir;
pathHomeDir             = fileparts(firstMultiTIFFFile);
[properties, fn_props]  = loadProperties();

fn_props_org = [getPathAndFilenameWithoutExtension(fn_props) '_org.xml'];
if(~exist(fn_props_org, 'file'))
    copyfile(fn_props,fn_props_org);
end

% find meta file from first image file
[metadata] = tryReadSpinningDiskMetaFile( fileparts(firstMultiTIFFFile));

if(~isfield(metadata, 'wavelength') || length(metadata.wavelength) == 1)
    [dirRawImageSequence, dirSmoothedImageSequence, stoppedAfterComputingMaxProjection] = prepareImageStack(firstMultiTIFFFile);
else
    % split color channels into separate tiff-stacks
    [fnStacksOrg, fnStacksNew] = SplitStackByColorChannels(metadata.pathMetadataFile);
    
    [wavelength_mainColorChannel, otherColorChannels] = getColorChannelInfo(properties);
    
    
    
    % do all the preparation for the main channel
    for c = 1 : length(fnStacksNew)
        if(fnStacksNew{c}.wavelength == wavelength_mainColorChannel) %% main channel
            [dirRawImageSequence, dirSmoothedImageSequence, stoppedAfterComputingMaxProjection] = prepareImageStack(fnStacksNew{c}.listOfImageFiles{1});
        end
    end
    
    % add the other channel(s)
    for c = 1 : length(fnStacksNew)
        for i = 1 : length(otherColorChannels)
            cc = otherColorChannels{i};
            if(fnStacksNew{c}.wavelength == cc.wavelength)
                properties = loadProperties( ); %load properties separately ==> needed in saveImagingParams to remove redundant fields
                imgSource = setImageSource('type','raw');
                
                dirImageSequence_red = [fileparts(imgSource.imageSequence.absPath) filesep 'raw_' cc.name];
                fn_RedImSeq = [dirImageSequence_red filesep imgSource.imageSequence.filenameStub '_' cc.name imgSource.imageSequence.filenameExt];
                makeImageSequenceFromMultiTIFF([], fnStacksNew{c}.listOfImageFiles, fn_RedImSeq, properties.initialROI, -imgSource.angle, imgSource.ROI, imgSource.effectiveBitDepth, imgSource.imageInfo.BitDepth );
                
                imgSource_red = imgSource;
                imgSource_red.type = ['raw_' cc.name] ;
                imgSource_red.maxGrayValueCroppedStack = -1;
                
                %copy meta file
                 if(~isempty(metadata.pathMetadataFile))
                    [mdpath, mdname, ext] = fileparts(metadata.pathMetadataFile);
                    copyfile(metadata.pathMetadataFile,[dirImageSequence_red filesep mdname ext]);
                 end
                
                imgSource_red = catstruct(imgSource_red,imageSequenceProperties(dirImageSequence_red));
                
                %write imagingParams
                saveImagingParams(dirImageSequence_red, imgSource_red, properties);
                imgSource_red = setImageSource('type',imgSource_red.type);
                
                % compute max projection of red channel stack
                fprintf('computing max projection of red channel stack\n');
                filenameMaxPrj = [dirImageSequence_red filesep maxPrjFolderName filesep imgSource_red.imageSequence.filenameStub '_maxProjection' '.tif'];
                projectImageSequence(imgSource_red.imageSequence.firstFullFilename, filenameMaxPrj, imgSource_red.zCount, 'max' );
            end
        end
    end
end

end

function [wavelength_main, otherColorChannels] = getColorChannelInfo(properties)
cc = structArray2CellArray(properties.colorChannels);
otherColorChannels = {};
for i = 1 : length(cc)
    cc_i = cc{i};
    if(strcmpi(cc_i.name, 'main'))
        wavelength_main = cc_i.wavelength;
    else
        otherColorChannels{end+1} = cc_i;
    end
end

end