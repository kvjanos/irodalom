function listMovieDir = prepareImageStack_batch(firstFilenamesOrMovieDirs)
%also see: prepareImageStack

%% convert movie dir to firstTiffFile
regEx_imageSeriesNumbering = '_t[0-9]{4}'; %format of the numbering for multi-file image stacks
firstFilenames = cell(size(firstFilenamesOrMovieDirs));
for i = 1 : length(firstFilenamesOrMovieDirs)
    fullPathMovieDir = firstFilenamesOrMovieDirs{i};
    if(isdir(fullPathMovieDir))
        [bdir,mDir] = fileparts(fullPathMovieDir);
        fn_metadata = [fullPathMovieDir filesep mDir '.txt']; %metadata file is expected to have the same name as the containing folder
        if(~exist(fn_metadata, 'file'))
            error('%s could not be found',fn_metadata);
        end
        [fnTiffs, stub] = GetAllTiffFilesFromMetadatafile( fn_metadata, regEx_imageSeriesNumbering );
        fnTiffs = sort(fnTiffs);
        firstFilenames{i} = fnTiffs{1};
    else
        firstFilenames{i} = firstFilenamesOrMovieDirs{i};
    end
end

%% check if all files exist
for i = 1 : length(firstFilenames)
    if(~exist(firstFilenames{i},'file'))
        error('file "%s" not found',firstFilenames{i});
    end
end

%% do the processing
fn_error = [myTempDir filesep sprintf('error_%s.log',mfilename)];
listMovieDir = {};
for i = 1 : length(firstFilenames)
    try
        close all;
        setDebugLevel(1);
        fn = firstFilenames{i};
        movieDir = fileparts(fn);
        propFilename = [movieDir filesep 'properties.xml'];
        if(~exist(propFilename, 'file'))
            p.objective  = 'water (new SD)';
            p.movieGroup = 'undefined movie group';
            xml_write(propFilename,p);
            warning('Properties file not found in %s. Creating standard properties.', movieDir);
        end
        prepareImageStackMultiColor(firstFilenames{i});
        listMovieDir = [listMovieDir movieDir];
    catch
        PrintToFile(sprintf('%s: prepareImageStack not successful for %s',datestr(clock),fn),fn_error,[],1);
        printDebugStack(lasterror,0,fn_error);
    end
end

