function projectMultiTIFFFolder( firstFilenameIn, filenameOut, zCount, prjFunc )

[files, dirIn] = fileListOfFirstFile(firstFilenameIn);

deleteFileIfExists(filenameOut);
N = length(files);
disp('computing projection...\n');
for i = 1:N
   files{i}
   Projection([dirIn filesep files{i}], filenameOut, zCount, prjFunc);
end
