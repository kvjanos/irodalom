function [dirRawImageSequence, dirSmoothedImageSequence, stoppedAfterComputingMaxProjection] = prepareImageStack( firstMultiTIFFFile )
%also see: prepareImageStackMultiColor, prepareImageStack_batch, MakeFoldersForMovies
%          specifyManualEmbryoMask


bitDepthOut = []; %8, 16 ==> fixed value or [] ==> the actual bitdepth of the org. images will be used;
imageTypeOut = '.tif'; %make sure to include the dot
askUserForROI = 0;

global pathHomeDir;
pathHomeDir        = fileparts(firstMultiTIFFFile);
[rootDir, homeDir] = fileparts(pathHomeDir);

roi = []; %empty roi (==> user will be asked later to draw a roi) ==> automatic roi

maxPrjFolderName = 'maxProjection'; %this folder name is assumed in main.m to locate the max-projection

if(~isempty(roi))
    warning('fixed roi!!!!!!!!!!!!!!!!!!!!!!!');
end
dirOut = pathHomeDir;
ensureDirExists(dirOut);

[dirIn, name, ext] = fileparts(firstMultiTIFFFile);
if(isempty(name) || isempty(ext))
    error('full file name required, not only a directory (%s)',firstMultiTIFFFile);
end
nameStub = strRemovePostfix(stripOffEndingNumber(name),'_');
setDebugDir([dirIn filesep 'debug_' sprintf('%s',mfilename)]);

properties                  = loadProperties();
metadata                    = readFieldsFromSpinningDiskMetaFile(dirIn, properties)
properties.tag              = homeDir; %use the name of the directory containing the original image files as tag
properties.homeDir          = homeDir;
properties.metadataFilename = getFilenameWithExtension(metadata.pathMetadataFile);
properties = catstruct(properties, metadata);
properties = rmfieldIfExists(properties,'pathMetadataFile');
imagingParams = metadata;

if(~isfield(properties, 'cropImages'))
    properties.cropImages = 1;
end
if(~isfield(properties, 'rotateImages'))
    properties.rotateImages = 1;
end
if(~isfield(properties,'initialROI'))
    properties.initialROI = [];
end
if(~isfield(properties,'findChipROI'))
    properties.findChipROI = 0;
end
if(~isfield(properties,'specifyManualEmbryoMask'))
    properties.specifyManualEmbryoMask = 0;
end
if(~isfield(properties,'segmentationAlgorithmEmbryoROI'))
    properties.segmentationAlgorithmEmbryoROI = 'thresholdingOnSingleImages'; %thresholdingOnSingleImages, watershedOnStack
end
if(~isfield(properties, 'mfileAlgorithmParameters'))
    properties.mfileAlgorithmParameters = 'ap_centrosomesDefault';
end
if(~isfield(properties,'embryoDimension'))
    [param_ap,param_bio ] = eval(properties.mfileAlgorithmParameters);
    properties.embryoDimension = param_bio.embryoDimension;
end


if(~isempty(properties.initialROI)) %ensure that not both - initial ROI and chip ROI - are active
    properties.findChipROI = 0;
end


% compute the multiTIFF sequence properties for later image addressing
MTSPropsFilename = [fileparts(firstMultiTIFFFile) filesep 'MultiTIFFSeqProps.xml'];
if(nargin > 0 || ~exist(MTSPropsFilename, 'file'))
    MTSProps = MultiTIFFSequenceProperties(firstMultiTIFFFile, properties.zCount);
    xml_write(MTSPropsFilename, MTSProps);
    properties.MTSPropsFilename = getFilenameWithExtension(MTSPropsFilename);
    saveProperties(properties); %save here already, so code below can safely call 'setImageSource'
else
    MTSProps = xml_read(MTSPropsFilename);
end
if(isempty(bitDepthOut))
    bitDepthOut = MTSProps.imageInfo.BitDepth;
end
if(imagingParams.effectiveBitDepth > bitDepthOut)
    imagingParams.effectiveBitDepth = bitDepthOut;
end

%max projection of original images
zCount = metadata.zCount;
fn_orgMaxPrj = [dirIn filesep nameStub '_maxProjection.tif'];
if(nargin > 0 || ~exist(fn_orgMaxPrj, 'file'))
    projectMultiTIFFFolder(firstMultiTIFFFile, fn_orgMaxPrj, zCount, 'max');
end

manualEmbryoMask = loadManualEmbryoMask( );

if(properties.specifyManualEmbryoMask && isempty(manualEmbryoMask))
    fn_orgMeanPrj = [dirIn filesep nameStub '_meanProjection.tif'];
    if(nargin > 0 || ~exist(fn_orgMeanPrj, 'file'))
        projectMultiTIFFFolder(firstMultiTIFFFile, fn_orgMeanPrj, zCount, 'mean');
    end

    stoppedAfterComputingMaxProjection = 1;
    dirRawImageSequence = [];
    dirSmoothedImageSequence = [];
    fprintf('please execute specifyManualEmbryoMask(''%s'') and call run_all_batch (or: run_all_fromHomeDir) again\n',pathHomeDir);
    return
else
    stoppedAfterComputingMaxProjection = 0;
end
maxPrj = imreadStackDouble(fn_orgMaxPrj,[],'Nmax',100);

%max projection of max projection ==> 2D image ==> used to let the user define a ROI
maxMaxPrj = Projection2(maxPrj,'max');
LOW_HIGH = stretchlim(maxMaxPrj);

clear 'maxPrj';

%determine overall max gray value of original stack
imagingParams.maxGrayValueOriginalStack = max(maxMaxPrj(:));

if(~isempty(properties.initialROI))
    properties.initialROI(3) = min(size(maxMaxPrj,2) - properties.initialROI(1) + 1, properties.initialROI(3));
    properties.initialROI(4) = min(size(maxMaxPrj,1) - properties.initialROI(2) + 1, properties.initialROI(4));
end

marginApplied = [];

if(isempty(roi))
    if(askUserForROI)
        disp('Please, define a ROI containing the embryo. Make sure to leave some margin around the embryo. When finished right click on one of the nodes and select "create mask".');
        [BW,xi,yi] = roipoly(imadjust(maxMaxPrj, LOW_HIGH, []));
        roi = round([min(xi), min(yi),max(xi)-min(xi)+1, max(yi)-min(yi)+1]);
        angle = 0;
        properties.initialROI = [];
    else
        margin = 40;
        
        if(~isempty(properties.initialROI))
            maxMaxPrj_forROIfinding = imcrop2(maxMaxPrj,properties.initialROI);
            chipROI = [];
        else
            if(properties.findChipROI)
                %find borders of the CCD-chip
                minMargin = 10;
                maxMargin = 70;
                [chipROI, image_outsideROIFilled] = FindChipROI( maxMaxPrj, minMargin, maxMargin );
                maxMaxPrj_forROIfinding = image_outsideROIFilled;
            else
                maxMaxPrj_forROIfinding = maxMaxPrj;
                chipROI = [];
            end
        end
        maxMaxPrj_forROIfinding = imadjust(maxMaxPrj_forROIfinding);
        
       
        if(~isempty(manualEmbryoMask))
            properties.initialROI = [];
        end
        
        [ roi, angle, marginApplied, roiOnImage] = findEmbryoROI_helper(maxMaxPrj_forROIfinding, margin, chipROI, properties.initialROI, properties.rotateImages, properties.cropImages, properties.segmentationAlgorithmEmbryoROI, properties.resolution, properties.embryoDimension, manualEmbryoMask);
        
        %update embryo dimension ==> if cropped image is smaller than given
        %embryo dimension then overwrite by the size of the image minus the margin
        if(isempty(roi))
            imgWidth  = size(maxMaxPrj_forROIfinding,2);
            imgHeight = size(maxMaxPrj_forROIfinding,1);
        else
            imgWidth  = roi(3);
            imgHeight = roi(4);
        end
        properties.embryoDimension(1) = min(properties.embryoDimension(1), round((imgWidth-1.5*margin)*properties.resolution/1000));
        properties.embryoDimension(2) = min(properties.embryoDimension(2), round((imgHeight-1.5*margin)*properties.resolution/1000));
        
        roi
        angle
        fig1 = figure; imshow(roiOnImage,[]);
        title(sprintf('%s',strrep(strrep(pathHomeDir,'\','\\'),'_','\_')));
        saveas_debug( fig1, [dirIn filesep 'automaticROI.fig'], 1 )
    end
else
    warning('fixed roi!!!!!!!!!!!!!!!!!!!!!!!');
    angle = 0;
end

TransformAndSaveManualEmbryoMask(manualEmbryoMask, properties.initialROI, -angle, roi);

%save list of multiTIFF files as image sequence, crop and rotate them
files = fileListOfFirstFile(firstMultiTIFFFile);
relPathToRawImageSequence = 'raw';
dirRawImageSequence = [pathHomeDir filesep relPathToRawImageSequence];
fn_RawImSeq = [dirRawImageSequence filesep nameStub '_cropped' imageTypeOut];
makeImageSequenceFromMultiTIFF(dirIn, files, fn_RawImSeq, properties.initialROI, -angle, roi, metadata.effectiveBitDepth, bitDepthOut );
imagingParams.ROI           = roi;
imagingParams.angle         = angle;
imagingParams.marginApplied = marginApplied;

%determine overall max gray value of cropped stack
imagingParams.maxGrayValueCroppedStack = max(maxMaxPrj(:));

%determine image sequence properties (needed for image addressing)
imagingParams = catstruct(imagingParams,imageSequenceProperties(dirRawImageSequence));


if(~isempty(metadata.pathMetadataFile))
    [mdpath, mdname, ext] = fileparts(metadata.pathMetadataFile);
    copyfile(metadata.pathMetadataFile,[fileparts(fn_RawImSeq) filesep mdname ext]);
end

%write imagingParams
imagingParams.type = 'raw';
saveImagingParams(relPathToRawImageSequence, imagingParams, properties);
imagingParams = loadImagingParams(relPathToRawImageSequence);

properties.totalImageCount = imagingParams.totalImageCount;
if(~mod(properties.totalImageCount, properties.zCount) == 0)
    error('The total number of images (%d) is not divisible by the number of z-planes (%d)',imagingParams.totalImageCount,imagingParams.zCount);
end
saveProperties(properties);

%% compute max projection of cropped and rotated stack
fprintf('computing max projection of cropped and rotated stack\n');
filenameMaxPrjCropped = [fileparts(fn_RawImSeq) filesep maxPrjFolderName filesep nameStub '_cropped_maxProjection.tif'];
projectImageSequence(imagingParams.imageSequence.firstFullFilename, filenameMaxPrjCropped, properties.zCount, 'max' );

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

%% smooth images and save in new folder
fprintf('smoothing stack');
[dirRawImageSequence, nameStubCropped ext] = fileparts( fn_RawImSeq );
relPathToSmoothedImageSequence = 'smoothed';
dirSmoothedImageSequence = [pathHomeDir filesep relPathToSmoothedImageSequence];
filenameSmoothedSequence  = [dirSmoothedImageSequence filesep nameStubCropped '_smoothed' ext ];
setImageSource('type','raw');
preprocessingGaussianSmoothing3D(dirRawImageSequence, filenameSmoothedSequence, bitDepthOut);

if(~isempty(metadata.pathMetadataFile))
    [mdpath, mdname, ext] = fileparts(metadata.pathMetadataFile);
    copyfile(metadata.pathMetadataFile,[dirSmoothedImageSequence filesep mdname ext]);
end

% determine image sequence properties (needed for image addressing)
imagingParams = catstruct(imagingParams,imageSequenceProperties(dirSmoothedImageSequence));

%write imagingParams
imagingParams.type = 'smoothed';
saveImagingParams(relPathToSmoothedImageSequence, imagingParams, properties);
imagingParams = loadImagingParams(relPathToSmoothedImageSequence);

%compute max projection of smoothed stack
fprintf('computing max projection of smoothed stack\n');
smoothedMaxPrjFilename = [dirSmoothedImageSequence filesep maxPrjFolderName filesep nameStub '_cropped_smoothed_maxProjection.tif'];
projectImageSequence(imagingParams.imageSequence.firstFullFilename, smoothedMaxPrjFilename, properties.zCount, 'max' );

%print path to image sequence directories to a file
fn_listDirImageSequence = [baseDir filesep 'listDirImageSequence.txt'];
listDirImageSequence = {dirRawImageSequence, dirSmoothedImageSequence};
for i = 1 : length(listDirImageSequence)
    fprintf('%s\n',listDirImageSequence{i});
    try
        PrintToFile(listDirImageSequence{i}, fn_listDirImageSequence, 'a');
    catch
    end
end
end

function mask = TransformAndSaveManualEmbryoMask(mask, initialROI, angle, ROI)
if(isempty(mask))
    return
end

if(~isempty(initialROI))
    mask = imcrop2(mask,initialROI);
end
if(angle ~= 0)
    mask = stackRotate(mask,angle,'bicubic');
end
if(~isempty(ROI))
    mask = imcrop2(mask,ROI);
end
saveTransformedManualEmbryoMask(mask);
end

function [ roi, angle,marginApplied, roiOnImage] =  findEmbryoROI_helper(maxMaxPrj, margin, chipROI, initialROI, rotateImages, cropImages, segmentationAlgorithmEmbryoROI, resolution, embryoDimension, manualEmbryoMask)

if(~isempty(manualEmbryoMask))
    stack = [];
else
    imgSource = setImageSource('type','original');
    fprintf('loading images to find embryo ROI...\n');
    T = imgSource.tCount;
    
    Nmax = 45;
    step = max(1,ceil(T / Nmax));
    t = 1 : step : T;
    

    if(length(t) < 3)
        z = repmat(ceil(imgSource.zCount/2), [1, length(t)]);
    else
        rl = 2/5;
        ru = 3/5;
        zmin = ceil(imgSource.zCount*rl);
        zmax = floor(imgSource.zCount*ru);
        z = round(interp1([t(1) t(ceil(end/2)) t(end)],[zmin zmax zmin],t));
    end
    
    stack = loadImages(z,t);
    if(nargin >= 3 && ~isempty(chipROI))
        if(chipROI(1) ~= 0 || chipROI(3) ~= size(stack,2))
            error('chipROI is expected to cover the whole image width');
        end
        %replace out-of-chip region by mean intensities of the pixelCount/2 brightest pixels
        for i = 1 : size(stack, 3)
            ymin = chipROI(2);
            ymax = chipROI(4)+ymin-1;
            I = stack(:,:,i);
            intensitiesSorted = sort(I(:));
            avgInt = mean(intensitiesSorted(ceil(length(intensitiesSorted)/2):end));
            I(1:ymin,  :) = avgInt;
            I(ymax:end,:) = avgInt;
            stack(:,:,i) = I;
        end
    end
    if(nargin >= 4 && ~isempty(initialROI))
        stack = imcrop2(stack, initialROI);
    end
end

[ roi,angle,marginApplied, roiOnImage ] = FindEmbryoROIFromStack(stack, maxMaxPrj, margin, rotateImages, cropImages, segmentationAlgorithmEmbryoROI, resolution, embryoDimension(1:2), manualEmbryoMask,t,z);
end

