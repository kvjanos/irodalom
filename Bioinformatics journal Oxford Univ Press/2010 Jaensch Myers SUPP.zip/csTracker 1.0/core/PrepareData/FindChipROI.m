function [ roi, image_outsideROIFilled ] = FindChipROI( maxMaxPrj, minMargin, maxMargin )
%FINDCHIPROI finds the two horizonal lines caused by the camera chip 

resizingFactor = .25;
maxMaxPrj_small = imresize(maxMaxPrj,resizingFactor);
minMargin = round(minMargin*resizingFactor);
maxMargin = round(maxMargin*resizingFactor);
sumPrj = sum(medfilt2(maxMaxPrj_small,[5,5]),2);
dx = abs([0;derivativeOfVector(sumPrj(:));0]);
max_derivative_idx_top = index1DOfMax(dx,[minMargin maxMargin-minMargin+1]);
max_derivative_idx_bottom = index1DOfMax(dx,[length(dx)-maxMargin+1 length(dx)-minMargin]);

ymin = round(max_derivative_idx_top/resizingFactor);
ymax = round(max_derivative_idx_bottom/resizingFactor);

roi = [0 ymin size(maxMaxPrj,2) ymax-ymin+1];

if(nargout > 1)
    intensitiesSorted = sort(maxMaxPrj(:));
    avgInt = mean(intensitiesSorted(ceil(length(intensitiesSorted)/2):end));
    image_outsideROIFilled = maxMaxPrj;
    image_outsideROIFilled(1:ymin,  :) = avgInt;
    image_outsideROIFilled(ymax:end,:) = avgInt;
end
%croppedMaxmaxPrj = imcrop2(maxMaxPrj,roi);
if(getDebugLevel >= 1)
    fig1 = sfigure;
    croppedMaxmaxPrj = imadjust(image_outsideROIFilled);
    I_border = imadjust(maxMaxPrj);
    I_border(ymin-1,:)  = 1;
    I_border(ymin,:)    = 1;
    I_border(ymin+1,:)  = 1;
    I_border(ymax-1,:)  = 1;
    I_border(ymax,:)    = 1;
    I_border(ymax+1,:)  = 1;
    subplot(1,3,1);
    plot(1:length(sumPrj), sumPrj, 'DisplayName', 'sum projection along rows'); title('sum projection along rows of maxmax projection image');
    hold on
    plot(1:length(dx), dx ,':','DisplayName','Derivate');
    plot(max_derivative_idx_top,sumPrj(max_derivative_idx_top), 'o');
    plot(max_derivative_idx_bottom,sumPrj(max_derivative_idx_bottom), 'o');
    %legend('show');
    subplot(1,3,2);
    imshow(croppedMaxmaxPrj,[]), title('filled maxmax projection');
    subplot(1,3,3);
    imshow(I_border,[]), title('ROI on maxmax projection');
    saveas_debug(fig1, [getDebugDir filesep 'chipROI.fig'],1); %try-catch block included
    if(getDebugLevel < 2)
        close(fig1);
    end
end