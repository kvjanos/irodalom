function preprocessingGaussianSmoothing3D(imSequenceDir, filenameOut, bitDepthOut) 

%filenameOut - includes directory and the full filename but without
%numbering, e.g. E:\data\SPD5\imageSeq\SPD5_WT.jpg

[dirOut name ext]  = fileparts(filenameOut);
try
    ensureEmptyDirExists(dirOut);
catch
    ensureDirExists(dirOut);
end

global param;
p = param.imgSource;
namestub = strRemovePostfix(name, '_');

%PhD Thesis: Algorithms for detection and tracking of objects with
%super-resolution in 3D Fluorescence Microscopy, page 12 and 58
sigmaXY = 0.21 * p.emissionWavelength / p.NA / p.resolution;
sigmaZ  = 0.66 * p.emissionWavelength * p.refractiveIndex / p.NA^2 / p.zResolution;

fprintf('sigmaXY = %f pixels, sigmaZ = %f pixels\n',sigmaXY,sigmaZ);

kernel = GaussKernel3D([5,5,5],[sigmaXY,sigmaXY,sigmaZ]);

c = 1;
Tmax = p.imageSequence.filenameCount / p.zCount;
for t = 1 : Tmax
    fprintf('timepoint %d / %d\n', t,Tmax);
    stack = loadTimepoints(t);
    stack = imfilter(stack, kernel, 'replicate');
    for z = 1 : p.zCount
        if(strcmpi(ext,'.jpg'))
            writeJPEG(stack(:,:,z), [dirOut filesep namestub '_' sprintf(p.imageSequence.indexFormattingString,c) ext], bitDepthOut);
        else
            writeTIFF(stack(:,:,z), [dirOut filesep namestub '_' sprintf(p.imageSequence.indexFormattingString,c) ext], bitDepthOut);
        end
        c = c + 1;
    end
end 