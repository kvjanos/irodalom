function firstFilenames = MakeFoldersForMovies( directoryWithMovies, dirOut )
%MAKEFOLDERSFORMOVIES searches the given directory for movies and creates a
%folder for each movie. The folder name is the same as the name of the
%meta-file (txt file). If an image file has no ending number, 't0000' will
%be appended to the filename
%
% output: firstFilenames contains for each created folder the full name of
% the first image file
%
%also see: prepareImageStack_batch, prepareImageStack


imgFileExt = '.tif'; %make sure to include the dot

propertiesFilename = [directoryWithMovies filesep 'properties.xml'];
props = xml_read (propertiesFilename);
if(isfield(props, 'tag'))
    props = rmfield(props, 'tag'); %remove the tag-field
end

metaFiles = dir([directoryWithMovies filesep '*.txt']);
N = length(metaFiles);
firstFilenames = cell(1, N);
for i = 1 : N
    metafilename = [directoryWithMovies filesep metaFiles(i).name]
    nameStub     = getFilenameWithoutExtension(metafilename);
    dirName      = [dirOut filesep nameStub];
   
    
    imgFiles = dir([directoryWithMovies filesep nameStub '*' imgFileExt]);
   
    if(~isempty(imgFiles))
        ensureDirExists(dirName);
        %copy metafile
        movefile_fast(metafilename, dirName);

        %save the properties file
        xml_write([dirName filesep getFilenameWithExtension(propertiesFilename)],props);

        %copy image files
        minNumber = inf;
        for j = 1 : length(imgFiles)

            fn = [directoryWithMovies filesep imgFiles(j).name];

            [ stub, numberOfDigits, theNumber, formattingString ] = stripOffEndingNumber( getFilenameWithoutExtension(fn) );

            if(numberOfDigits == 0)
                newFilename = [dirName filesep nameStub '_t0000' getExtension(fn)];
            else
                newFilename = [dirName filesep getFilenameWithExtension(fn)];
            end
            movefile_fast(fn, newFilename);

            [ stub, numberOfDigits, theNumber ] = stripOffEndingNumber( getFilenameWithoutExtension(newFilename) );
            if(theNumber < minNumber)
                minNumber = theNumber;
                firstFilenames{i} = newFilename;
            end
        end
    else
        warning('file "%s" has been ignored',metafilename);
    end
end

filenameOut = [directoryWithMovies filesep 'firstFilenames.txt'];
deleteFileIfExists(filenameOut);
bdir = baseDir();
for i = 1 : N
    fn = firstFilenames{i};
    
    if(strStartsWith(fn, bdir))
        fn = [strrep(fn, [bdir filesep], '[baseDir filesep ''') ''']'];
    elseif(~strStartsWith(fn, ''''))
        fn = ['''' fn ''''];
    end
    
    fprintf('%s\n',fn);
    try
        PrintToFile(sprintf('%s',fn), filenameOut, 'a');
    catch
    end
end
