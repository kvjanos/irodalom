function [ firstMultiTiffFile ] = findFirstMultiTIFFFile( directory )

D = dir([directory filesep '*.tif']);

if(isempty(D))
    firstMultiTiffFile = [];
else
    files = sort(valuesFromStructureArray(D, 'name'));
    firstMultiTiffFile = [directory filesep files{1}];
end