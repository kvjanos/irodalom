function [ filenameOut_convexHull, filenameOut_original ] = FindEmbroContourInMaxProjection(workingDir, updateEmbryoDimensionInProperties, skipIfFileoutExists )
% computes an embryo mask as the convex hull of a watershed segmention on
% the maximum projection
%
% see also: FindEmbryoContourInSingleImage_watershed, EstimateBackgroundLevel, MarkOutsideEmbryoCandidates
fprintf('%s\n',mfilename);

specifyInitialMarkerManually = 0;
if(nargin == 0)
   
    workingDir = [baseDir filesep 'yTUB-GFP13_Zyg1ts\workingDir\1'];
    workingDir = [baseDir filesep 'SPD2-GFP_WT_long4\workingDir\1'];
    workingDir = [baseDir filesep 'SPD5-YFP9_WT_multicell\workingDir\1'];
    workingDir = [baseDir filesep 'SPD5-YFP1_multicell\workingDir\1'];
    workingDir = [baseDir filesep 'yTUB-GFP1_long2\workingDir\1'];
    workingDir = [baseDir filesep 'yTUB-GFP3_WT_4to8cellstage\workingDir\9'];
    workingDir = [baseDir filesep 'Histone-GFP2_WT_multicell\workingDir\1'];
    workingDir = [baseDir filesep 'Beads-GFP1 WT\workingDir\1'];
    workingDir = [baseDir filesep 'yTUB-GFP1_ANI2_24hrsRNAi_4to8cellstage\workingDir\1'];
    workingDir = [baseDir filesep 'yTUB-GFP5_ANI2_24hrsRNAi_1to2cellstage\workingDir\1'];
    workingDir = [baseDir filesep 'yTUB-GFP21_ANI2_24hrsRNAi_2to4cellstage\workingDir\1'];
    workingDir = [baseDir filesep 'yTUB-GFP24_WT_1to8cellstage\workingDir\1'];
    updateEmbryoDimensionInProperties = 0;
    specifyInitialMarkerManually      = 0;
end 

global param;
loadGlobalParams(workingDir);
dirDebug    = makeDebuggingFolder(mfilename);
filenameOut_convexHull = [workingDir filesep 'embryoContour2D_convexHull.tif'];
filenameOut_original   = [workingDir filesep 'embryoContour2D_original.tif'];
if(exist('skipIfFileoutExists','var') && skipIfFileoutExists && exist(filenameOut_original, 'file') && exist(filenameOut_convexHull, 'file'))
    return
end
if(~exist('updateEmbryoDimensionInProperties','var'))
    updateEmbryoDimensionInProperties = 0;
end

deleteFileIfExists(filenameOut_original);
deleteFileIfExists(filenameOut_convexHull);
fn_Ioverlay_embryoContourConvexHull = deleteFileIfExists([dirDebug filesep 'embryoContour2D_convexHull.tif']);
fn_Ioverlay_embryoContour           = deleteFileIfExists([dirDebug filesep 'embryoContour2D_original.tif']);
fn_Ioverlay_initialMarker           = deleteFileIfExists([dirDebug filesep 'embryoContour2D_initialMarker.tif']);

setImageSource('type','smoothed');

maxPrj = loadMaxProjection();
fillBlackCorners = 1;
[embryoMask, Ioverlay_initialMarker,limitsEmbryoArea_pixels, markerOk] = FindEmbryoContourInStack_watershed(maxPrj, fillBlackCorners,  param.embryoDimension(1:2), param.resolution, specifyInitialMarkerManually);
writeTIFF(im2uint16(Ioverlay_initialMarker),fn_Ioverlay_initialMarker);

axesLengths = zeros(size(embryoMask,3),2);

for i = 1 : size(embryoMask,3)
    fprintf('.');
    I = maxPrj(:,:,i);
    embryoRegion = embryoMask(:,:,i);
    S = regionprops(uint8(embryoRegion), 'ConvexHull', 'Area', 'MajorAxisLength','MinorAxisLength');
    if(~isempty(S))
        if(S.Area >= limitsEmbryoArea_pixels(1))
            embryoRegionConvexHull = poly2mask(S.ConvexHull(:,1),S.ConvexHull(:,2),size(I,1),size(I,2));
            if(S.Area <= limitsEmbryoArea_pixels(2))
                axesLengths(i,:) = [S.MajorAxisLength S.MinorAxisLength];
            end
        else
            embryoRegionConvexHull = ones(size(I)); %area < lower limit ==> make the entire image embryo region
        end
    else
        embryoRegionConvexHull = zeros(size(I));
    end
    embryoRegionConvexHull = bwmorph(embryoRegionConvexHull, 'dilate', 2);
    
    imwrite(im2uint8(embryoRegionConvexHull), filenameOut_convexHull, 'Compression', 'none', 'WriteMode', 'append');
    imwrite(im2uint8(embryoRegion),           filenameOut_original,   'Compression', 'none', 'WriteMode', 'append');

    I_overlay = OverlayMask(I, embryoRegionConvexHull,0, 'black');
    imwrite(im2uint16(I_overlay), fn_Ioverlay_embryoContourConvexHull, 'Compression', 'none', 'WriteMode', 'append');

    lineWidth = 1;
    reduceToContour = 1;
    I_overlay = OverlayMask(I, embryoRegion, 0, 'black',reduceToContour,lineWidth);
    imwrite(im2uint16(I_overlay), fn_Ioverlay_embryoContour, 'Compression', 'none', 'WriteMode', 'append');
end
fprintf('\n');

if(updateEmbryoDimensionInProperties)
    axesLengths(axesLengths(:,1) == 0,:) = [];
    axesLengths = mean(axesLengths);
    param.embryoDimension(1:2) = round(axesLengths * param.resolution / 1000);
    properties = loadProperties( );
    properties.embryoDimension = param.embryoDimension;
    saveProperties(properties);
end

param.relPathEmbryoContour2DMaxPrjOriginal   = getRelativePath(filenameOut_original);
param.relPathEmbryoContour2DMaxPrjConvexHull = getRelativePath(filenameOut_convexHull);
saveGlobalParams();

end
