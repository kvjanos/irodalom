function [  T, header ] = ComputeTimeRelativeToNEBD(  T, header )
%COMPUTETIMERELATIVETONEBD computes the time in seconds from the frame
%numbers with NEBD being zero seconds

global param;

NEBDColIdx = headerIndex(header, 'NEBD','none');
if(NEBDColIdx > 0)
    [header, normTimeColIdx] = addHeaderEntry(header, 'normTime');
    T(:,normTimeColIdx) = (T(:,4) - T(:,NEBDColIdx))*param.frameInterval;
    
end

timeZeroFrameColIdx = headerIndex(header, 'timeZeroFrame','none');
if(timeZeroFrameColIdx > 0)
    [header, zeroTimeColIdx] = addHeaderEntry(header, 'zeroTime');
    T(:,zeroTimeColIdx) = (T(:,4) - T(:,timeZeroFrameColIdx))*param.frameInterval;
end

