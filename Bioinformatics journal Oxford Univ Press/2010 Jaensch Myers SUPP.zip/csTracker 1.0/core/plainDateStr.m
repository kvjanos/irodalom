function str = plainDateStr(dateVector) 
str = datestr(dateVector, 'yyyy_mm_dd_HH_MM_SS');