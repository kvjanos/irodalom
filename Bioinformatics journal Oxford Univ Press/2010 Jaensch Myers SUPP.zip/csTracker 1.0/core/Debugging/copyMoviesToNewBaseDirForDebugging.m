function copyMoviesToNewBaseDirForDebugging( sourceBaseDir, backupBaseDir, newBaseDir, movieDir )

fullpathNewMovieDir = [newBaseDir filesep movieDir];
ensureDirExists(fullpathNewMovieDir);

%properties.xml
p = loadInitProperties([sourceBaseDir filesep movieDir]);
p.debugMode = 2;
fn_props = [fullpathNewMovieDir filesep 'properties.xml'];
xml_write(fn_props, p);

%metadata
fn_source_metadata = copyMetadatafile(sourceBaseDir, newBaseDir, movieDir);

%image files
regEx_imageSeriesNumbering = '_t[0-9]{4}'; %format of the numbering for multi-file image stacks
try
    copyImageFiles(sourceBaseDir, newBaseDir, movieDir, regEx_imageSeriesNumbering);
catch ME
    if(strcmpi(ME.identifier, 'error:noImages'))
        copyImageFiles(backupBaseDir, newBaseDir, movieDir, regEx_imageSeriesNumbering);
    else
        rethrow(ME)
    end
end

end

function copyImageFiles(sourceBaseDir, newBaseDir, movieDir, regEx_imageSeriesNumbering)
fullpathSourceMovieDir  = [sourceBaseDir filesep movieDir];
fullpathNewMovieDir     = [newBaseDir filesep movieDir];
fn_source_metadata      = [fullpathSourceMovieDir filesep movieDir '.txt'];%metadata file has the same name as the containing directory
[fnTiffs, stub]         = GetAllTiffFilesFromMetadatafile( fn_source_metadata, regEx_imageSeriesNumbering );

if(isempty(fnTiffs))
    fn_zip = [fullpathSourceMovieDir filesep 'images.zip'];
    if(exist(fn_zip,'file'))
        fprintf('unzipping "%s" to %s',fn_zip, fullpathNewMovieDir);
        unzip(fn_zip, fullpathNewMovieDir);
        fprintf('done!\n');
    else
        error('error:noImages','neither the original tif files nor "images.zip" could be found in "%s"',fullpathSourceMovieDir);
    end
else
    for j = 1 : length(fnTiffs)
        fn = fnTiffs{j};
        fprintf('copying %s to %s\n', fn, fullpathNewMovieDir);
        copyfile(fn, fullpathNewMovieDir);
    end
end
end

function fn_source_metadata = copyMetadatafile(sourceBaseDir, newBaseDir, movieDir )
%metadata
fn_source_metadata  = [sourceBaseDir filesep movieDir filesep movieDir '.txt']; %metadata file has the same name as the containing directory
destination         = [newBaseDir filesep movieDir];
if(exist(fn_source_metadata, 'file'))
    fprintf('copying %s to %s\n',fn_source_metadata, destination);
    copyfile(fn_source_metadata, destination, 'f');
else
    error('metadata file "fn_metadata" not found');
end

end

function p = extractInitProperties(p_all)
p.movieGroup    = p_all.movieGroup;
p.isMultiCell   = p_all.isMultiCell;
p.objective     = p_all.objective;
p.findChipROI   = p_all.findChipROI;
if(isfield(p_all, 'subgroup'))
    p.subgroup   = p_all.subgroup;
end
end

function p = loadInitProperties(fullpathMovieDir)
%loads the properties that are necessary to start the centrosome tracker
fn_props = [fullpathMovieDir filesep 'properties.xml'];
if(exist(fn_props, 'file'))
    p_all = xml_read(fn_props);
    p = extractInitProperties(p_all);
else
    error('"properties.xml" could be found in "%s"',fullpathMovieDir);
end
end
