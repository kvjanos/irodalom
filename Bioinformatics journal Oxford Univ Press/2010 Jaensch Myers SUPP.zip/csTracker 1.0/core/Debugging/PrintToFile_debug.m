function PrintToFile_debug(text, path, permission, printToScreen, minDebugLevel)

if(nargin < 3)
    permission = 'a';
end
if(nargin < 4)
    printToScreen = 0;
end
if(nargin < 5)
    minDebugLevel = 1;
end
if(getDebugLevel() >= minDebugLevel)
    PrintToFile(text, path, permission, printToScreen)
end
end