function fprintDebugInfo( filename, text, permission )

if(nargin < 3)
    permission = 'a';
end

dir = fileparts(filename);
ensureDirExists(dir);

fid = fopen(filename, permission);
fprintf(fid,'%s\n',plainDateStr(clock));
fprintf(fid,'%s\n\n',text);
fclose(fid);