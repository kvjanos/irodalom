function clearHistogram( )
%CLEARHISTOGRAM 
%also see: addToHistogram, showHistogram


global my_histogram_collection_variable;
my_histogram_collection_variable = [];
