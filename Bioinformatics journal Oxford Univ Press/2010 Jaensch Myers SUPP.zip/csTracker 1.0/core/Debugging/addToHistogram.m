function addToHistogram( value, histogramName, callingMethod )
%ADDTOHISTOGRAM 
%also see: showHistogram, clearHistogram

if(nargin >= 3)
    histogramName = sprintf('%s (%s)',histogramName, callingMethod);
end
global my_histogram_collection_variable;
if(~exist('my_histogram_collection_variable','var') || isempty(my_histogram_collection_variable))
    my_histogram_collection_variable = hashtable;
end

if(iskey(my_histogram_collection_variable,histogramName))
    X = get(my_histogram_collection_variable,histogramName);
    X = [X;value(:)];
else
    X = value(:);
end
my_histogram_collection_variable = put(my_histogram_collection_variable, histogramName, X);
