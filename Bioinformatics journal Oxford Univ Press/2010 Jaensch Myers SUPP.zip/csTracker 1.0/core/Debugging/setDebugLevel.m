function setDebugLevel( thisDebugLevel )
%SETDEBUGLEVEL Summary of this function goes here
%   Detailed explanation goes here
global debugLevel;
debugLevel = thisDebugLevel;