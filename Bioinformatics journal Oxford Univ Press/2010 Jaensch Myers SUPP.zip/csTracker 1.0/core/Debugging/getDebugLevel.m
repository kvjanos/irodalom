function [ thisDebugLevel ] = getDebugLevel(  )
global debugLevel;
if(exist('debugLevel','var') && ~isempty(debugLevel))
   thisDebugLevel = debugLevel;
else
    thisDebugLevel = 0;
end