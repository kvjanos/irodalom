function showHistogram(dirOut, lowHighOutlier)
%SHOWHISTOGRAM displays the currently available histogram
%also see: addToHistogram, clearHistogram
global my_histogram_collection_variable;

if(nargin < 1)
    dirOut = [];
end
if(nargin < 2)
    lowHighOutlier = [];
end

if(exist('my_histogram_collection_variable','var') && ~isnumeric(my_histogram_collection_variable))
   histogramNames = keys(my_histogram_collection_variable);
   for i = 1 : length(histogramNames)
       fig1 = sfigure; maximize(fig1); hold on
       if(~isempty(lowHighOutlier))
           subplot(1,2,1), hold on
       end
       X = get(my_histogram_collection_variable,histogramNames{i});
       hist(X);
       meanX = mean(X);
       stddevX = std(X);
       yl = ylim;
       plot([meanX, meanX],[0 yl(2)],'--', 'LineWidth', 1.5);
       title(sprintf('histogram of %s, n = %d\nmean = %f, stddev = %f',strrep(histogramNames{i},'_','\_'),numel(X),meanX,stddevX));
       axis square

       if(~isempty(lowHighOutlier))
           subplot(1,2,2), hold on
           X = sort(X);
           if(all(lowHighOutlier < 1.0))
               % relative numbers
               this_lowHighOutlier = ceil(lowHighOutlier*length(X));
           else
               this_lowHighOutlier = lowHighOutlier;
           end
           X = X(this_lowHighOutlier(1)+1:end-this_lowHighOutlier(2));
           hist(X);
           meanX = mean(X);
           stddevX = std(X);
           yl = ylim;
           plot([meanX, meanX],[0 yl(2)],'--', 'LineWidth', 1.5);
           title(sprintf('histogram of %s, n = %d ([%d,%d])\nmean = %f, stddev = %f',strrep(histogramNames{i},'_','\_'),numel(X),this_lowHighOutlier(1),this_lowHighOutlier(2),meanX,stddevX));
           axis square
           
           fn_tmp = [myTempDir filesep 'z0_vs_csRadius.txt'];
           PrintToFile(sprintf('%s\t%f\t%f',histogramNames{i},meanX,stddevX), fn_tmp, 'a', 1);
       end
       
       
       
       
       if(~isempty(dirOut))
        fn = makeFilenameUnique([dirOut filesep sprintf('histogram_%s.fig', histogramNames{i})]);
        saveas(fig1, fn);
        if(length(histogramNames) > 10)
            close(fig1)
        end
       end
   end
else
    warning('no histogram data available. use function "addToHistogram" to add values');
end 