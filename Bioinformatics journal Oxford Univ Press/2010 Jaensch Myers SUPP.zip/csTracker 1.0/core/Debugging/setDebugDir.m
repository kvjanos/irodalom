function setDebugDir( thisDebugDir )
%SETDEBUGDIR Summary of this function goes here
%   Detailed explanation goes here
global globalDebugDir;
globalDebugDir = thisDebugDir;
try
    if(~isempty(globalDebugDir))
        ensureDirExists(globalDebugDir);
    end
catch
    printDebugStack(lasterror);
end