function fprintfDebug( minDebugLevel, str )

if(getDebugLevel >= minDebugLevel)
    fprintf(str);
end