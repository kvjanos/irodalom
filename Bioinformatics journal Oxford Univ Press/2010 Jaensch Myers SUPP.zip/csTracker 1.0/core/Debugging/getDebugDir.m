function [ thisDebugDir ] = getDebugDir(  )
global globalDebugDir;
if(exist('globalDebugDir','var'))
   thisDebugDir = globalDebugDir;
else
   thisDebugDir = [];
end