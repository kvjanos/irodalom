function saveas_debug( obj, filename, minDebugLevel )
if(nargin < 3)
    minDebugLevel = 1;
end
if(getDebugLevel >= minDebugLevel)
    try
        saveas(obj, filename);
    catch
        printDebugStack(lasterror)
    end
end

