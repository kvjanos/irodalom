function FindNEBD_csPairIndependent( workingDir, filenameIn )
% compute from each centrosome the minimum intensity z-projection for the
% partial stack centered at the centrosome
%
% the outout can be used to manually determine NEBD
%see also: FindNEBD

global param;
[filenameIn, filenameOut, dirDebug ] = initProcessingStep( workingDir, filenameIn, 'NEBD', sprintf('%s',mfilename) );
setImageSource('type','smoothed');

%determines the radius in which to analyze intensities
spindleLength = 10000; %nm

radius = ceil((spindleLength/2) / param.resolution);
zExtra = 3;%ceil((spindleLength/2) / param.zResolution);

[T, header] = loadList(filenameIn);

trIDColIdx   = headerIndex(header,'trID','error' );

T = sortrows(T, 4); %sort by time

tmax = max(T(:,4));
partialMinPrjStack = zeros(param.imgSource.imageHeight, param.imgSource.imageWidth, param.lastTimepoint);
partialMinPrjStack_overlay = zeros(param.imgSource.imageHeight, param.imgSource.imageWidth, param.lastTimepoint);

trIDs = unique(T(:,trIDColIdx));
fig1 = sfigure;
for trID = trIDs'
    trID
    R = T(T(:,trIDColIdx) == trID, :);
    time        = [];
    intensity   = [];
    
    for i = 1 : size(R,1)
        fprintf('.');
    end
    fprintf('\n');

    for i = 1 : size(R,1)
        fprintf('.');
        x = R(i,1);
        y = R(i,2);
        z = R(i,3);
        t = R(i,4);

        stack = loadPartialFrame([max(1,z-zExtra) min(param.zCount,z+zExtra)], t);
        I = min(stack,[],3); %partialMinPrj


        mask = MakeRingPattern( size(I), radius, 1, 0, [y x]);      

        [maskEmbryo] = FindEmbryoContourInSingleImage2( I );
        mask = min(mask, maskEmbryo);

        numberOfMinimumIntensityPixelsForAverage = round(length(find(mask(:)>0))/3);
        [I_overlay, intensitySorted] = getMinIntensities(I, mask, numberOfMinimumIntensityPixelsForAverage);
        if(i == 1)
            partialMinPrjStack         = zeros([size(I), tmax]);
            partialMinPrjStack_overlay = zeros([size(I), tmax]);
        end
        partialMinPrjStack(:,:,t) = I;
        partialMinPrjStack_overlay(:,:,t) = I_overlay;
        meanInt = mean(intensitySorted(1:numberOfMinimumIntensityPixelsForAverage));
        time        = [time t];
        intensity   = [intensity meanInt];

    end
    clf(fig1);
    plot(time, intensity,'-o');
    fprintf('\n\n');
    csIdentifier = getCentrosomeIdentifier(R(1,:), header, 'AlwaysAddTrID', 1);
    WriteStackAsMultiTIFF(im2uint16(partialMinPrjStack), [dirDebug filesep sprintf('partialMinPrj_%s.tif',csIdentifier)]);
%     WriteStackAsMultiTIFF(im2uint16(partialMinPrjStack_overlay), [dirDebug filesep sprintf('partialMinPrj_minPixels_%s.tif',csIdentifier)]);
    saveas(fig1,[dirDebug filesep sprintf('time_vs_intensity_%s.fig',csIdentifier)]);
end
end

function [I_overlay, intensitySorted ] = getMinIntensities(I, mask, numberOfMinimumIntensityPixelsForAverage)
    
    maskIdx = mask>0;
    intensitySorted = sort(I(maskIdx));   
    maxMinInt = intensitySorted(numberOfMinimumIntensityPixelsForAverage);     
    I_overlay = I;
    I_overlay(maskIdx & I <= maxMinInt) = 0;
    maskContour = bwmorph(mask,'remove'); %reduce regions to their boundaries
    I_overlay = max(I_overlay,maskContour*max(I_overlay(:)));
end
