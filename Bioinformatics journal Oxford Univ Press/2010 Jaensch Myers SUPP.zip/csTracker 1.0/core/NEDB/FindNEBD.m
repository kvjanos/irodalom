function [ filenameOut ] = FindNEBD( workingDir, filenameIn, skipIfFileoutExists, varargin )
%
% syntax: FindNEBD( workingDir, filenameIn, skipIfFileoutExists, 'ignoreNEBDInfo' )
%         FindNEBD( workingDir, filenameIn, skipIfFileoutExists )
%         FindNEBD( workingDir, filenameIn )
%
%If NEBD is manually specified in properties file, the NEBD will be added to the
%input file
%
% otherwise:
%
%Finds the NEBD by analyzing the intensity halfway between pairs of centrosomes.
%Let z(A) be the center image plane (the plane in which the peak
%intensity of the centrosome is maximal) of centrosome A and z(B) be the
%center plane of centrosome B. Let MinPrj be the minimum projection of planes ranging from
%[min(z(A),z(B))-zExtra,max(z(A),z(B))+zExtra] where zExtra is a constant. The mean intensity
%of the N (parameter 'numberOfMinimumIntensityPixelsForAverage') darkest pixels
%in a rectangular ROI reaching from A to B overlayed with a circular ROI of radius 2r (ensures that
%the ROI is always big enough) in MinPrj yields a value I(t) for each time point t.
%The NEBD is identified as the timepoint shortly before  the maximum intensity
%(parameter 'timeWindowBeforeMaxIntensity') at which the derivative of I(t) is maximal.
%
%see also: UpdateNEBD

fprintf('%s\n',mfilename);
if(nargin == 0)

    workingDir = [baseDir filesep 'yTUB-GFP2_SPD2_11hrsRNAi\workingDir\1'];
    filenameIn = finalTrackingFile();
    
    varargin   = {'ignoreNEBDInfo', 'leavePropertiesFileUnchanged', 'useEmbryoMask'};
%    varargin   = {'ignoreNEBDInfo', 'leavePropertiesFileUnchanged'};
    setDebugLevel(1);
end

global param;
global pathHomeDir;
[filenameIn, filenameOut, dirDebug ] = initProcessingStep( workingDir, filenameIn, 'NEBD', sprintf('%s',mfilename) );
if(exist('skipIfFileoutExists','var') && skipIfFileoutExists && exist(filenameOut, 'file'))
    return
end

setImageSource('type','smoothed');

%half the radius of the circular mask and half the width of the rectangular roi
radius = ceil(param.bio.radiusOfNucleus/2/param.resolution);

%minimum number of planes to be included in the minimum-intensity projection
N_planes_nucleus = ceil(param.bio.radiusOfNucleus/param.zResolution);

%this parameter is critical and has been determined emperically
timeWindowBeforeMaxIntensity = 2.5; %minutes

%the maximum intensity will be searched only in this part of the track
%the number specifying the right border is not critical and may be set to 1
%to include the track until its very end. The left border, however, is critical,
%because in some tracks the global intensity maximum appears in the beginning of the curve
%(the left border will be shifted further to the left as long as the
%intensity increases)
maxIntensitySearchRange = [.25 .9];

%move the left border of the max-intensity search range to the left as long as the intensity increases
moveLeftMaxIntensityBorderToTheLeft = 0;

%+/- this number below and above the z-range of the centrosomes
%non-critical parameter
zExtra = 0;

%this proportion of the total number of pixels in the ROI will be used to compute a mean intensity
%non-critical parameter, useful range is [.2 .7]
proportionOfPixelsForAverage = .5;

%see timeWindowBeforeMaxIntensity
nFramesBeforeMaxIntensity = ceil(timeWindowBeforeMaxIntensity * 60 / param.frameInterval);

[T, header] = loadList(filenameIn);

Tmax = max(T(:,4));

[header, NEBDColIdx] = addHeaderEntry(header, 'NEBD');
T(:,NEBDColIdx)      = -1;
trIDColIdx           = headerIndex(header,'trID','error' );
cellIDColIdx         = headerIndex(header,'cellID', 'error');
cellNameColIdx         = headerIndex(header,'cellName', 'none');


T = sortrows(T, 4); %sort by time
uniqueTrIDs = unique(T(:,trIDColIdx));
xml_NEBD = struct;

[ignoreNEBDInfo]               = getVarargin(varargin, 'ignoreNEBDInfo', 0, 0, 'single');
[leavePropertiesFileUnchanged] = getVarargin(varargin, 'leavePropertiesFileUnchanged', 0, 0, 'single');
[useEmbryoMask]                = getVarargin(varargin, 'useEmbryoMask', 0, 0, 'single');


if(useEmbryoMask)
    embryoMask = loadEmbryoMask('original');
    for t = 1 : size(embryoMask,3)
        embryoMask(:,:,t) = extractBiggestBinaryRegion(bwmorph(embryoMask(:,:,t), 'erode', 5));
    end
end

non_specific_cellnames = {'cellst8','cellst16','cellst32','cellst64'};

findNEBDautomatically = 0;
if(isfield(param, 'NEBD') && ~ignoreNEBDInfo)
    cellNameColIdx = headerIndex(header, 'cellName');
    uniqueCellNames = unique(T(:,cellNameColIdx));
    for cellName = uniqueCellNames'
        try
            if(cellName > 0)
                strCellName = numericCellnameToCellname(cellName);
                if(isfield(param.NEBD, strCellName))
                    T(T(:,cellNameColIdx) == cellName, NEBDColIdx) =  param.NEBD.(strCellName);
                else
                    if(~any(strcmpi(non_specific_cellnames, strCellName)))
                        warning('no manual NEBD defined for cell "%s"', strCellName);
                    end
                    findNEBDautomatically = 1;
                end
            end
        catch
            printDebugStack(lasterror);
        end
    end
    if(~findNEBDautomatically)
        warning('NEBD is manually defined in the properties file in %s. NEBD has not been determined automatically.',pathHomeDir);
    end
elseif(length(uniqueTrIDs) == 1)
    FindNEBD_csPairIndependent(workingDir, filenameIn);
    warning('only one centrosome found. NEBD cannot be determined automatically. Please, specify NEBD manually in properties.xml. See debug/FindNEBD_csPairIndependent for min-projection images.');
    T(:,NEBDColIdx) = 1;
else
    findNEBDautomatically = 1;
end

if(findNEBDautomatically)
    excludeIdx = T(:,cellIDColIdx) <= 0;
    T_excluded = T(excludeIdx,:);
    T = T(~excludeIdx,:); %exclude centrosomes (and noise particles) that are not assigned a cell
    
    N = size(T,1);
    
    cellID2TrID_help = unique(T(:,[cellIDColIdx, trIDColIdx]),'rows');
    cellIDs          = unique(cellID2TrID_help(:,1));
    
    cellID2TrID = zeros(length(cellIDs), 3);
    for i = 1 : size(cellID2TrID_help,1)
        cellID = cellID2TrID_help(i,1);
        trID   = cellID2TrID_help(i,2);
        if(cellID2TrID(cellID, 1) == 0)
            cellID2TrID(cellID, 1) = cellID;
            cellID2TrID(cellID, 2) = trID;
        else
            cellID2TrID(cellID, 3) = trID;
        end
    end
    
    trackPairs = zeros(length(cellIDs), 2, Tmax);
    for i = 1 : N
        cellID = T(i,cellIDColIdx);
        trID   = T(i,trIDColIdx);
        t      = T(i,4);
        if(cellID2TrID(cellID, 2) == trID)     %'left' track
            trackPairs(cellID, 1, t) = i;
        elseif(cellID2TrID(cellID, 3) == trID) %'right' track
            trackPairs(cellID, 2, t) = i;
        else
            error('trackID %d is unknown',trID);
        end
    end
    
    for cellID = cellIDs'
        NEBD = unique(T(T(:,cellIDColIdx) == cellID,NEBDColIdx));
        if(NEBD > 0) %skip if NEBD has already been assigned above from properties file
            continue;
        end
        cellID
        trackPair = squeeze( trackPairs(cellID,:,:) );
        Time = [];
        Intensity = [];
        MeanIntensityROI = [];
        SpindleLength = [];
        MeanIntensityImage = [];
        
        
        partialMinPrjStackMinPixels = zeros(param.imgSource.imageHeight, param.imgSource.imageWidth, param.lastTimepoint);
        partialMinPrjStack          = zeros(param.imgSource.imageHeight, param.imgSource.imageWidth, param.lastTimepoint);
        
        t_ix = [];
        cellIdentifier = [];
        for t = 1 : size(trackPair, 2)
            if(trackPair(1,t) > 0 && trackPair(2,t) > 0)
                t_ix = [t_ix t];
                T1 = T(trackPair(1,t),:);
                T2 = T(trackPair(2,t),:);
                cellIdentifier = getCellIdentifier(T1(1,:), header, 'IncludeDimension', 1, 'AlwaysAddCellID',1);
                 
                zPlanes = [max(1,min(T1(3),T2(3))-zExtra) min(param.zCount,max(T1(3),T2(3))+zExtra)];
                %make sure that there are enough z-planes to cover the nucleus
                while(zPlanes(2)-zPlanes(1) < N_planes_nucleus && (zPlanes(1) > 1 || zPlanes(2) < param.zCount))
                    zPlanes(1) = max(1,zPlanes(1) - 1);
                    zPlanes(2) = min(param.zCount,zPlanes(2) + 1);
                end
                
                stack = loadPartialFrame(zPlanes, t);
                
   
                I = min(stack,[],3); %partialMinPrj
                I = imsmooth(I, 3);
                
                if(getDebugLevel>=3)
                    WriteStackAsMultiTIFF(im2uint16(stack), [dirDebug filesep param.tag sprintf('_partialStack_%s_t=%d.tif',cellIdentifier,t)]);
                end
                           
                mask = getRectangleMask(T1(1:2),T2(1:2),radius, size(I));
                
                if(useEmbryoMask)
                    mask = mask & embryoMask(:,:,t);
                end
                maskIdx = mask>0;
                
                intensitySorted = sort(I(maskIdx));
                numberOfMinimumIntensityPixelsForAverage = floor(proportionOfPixelsForAverage*length(intensitySorted));
                
                for k = 1 : length(numberOfMinimumIntensityPixelsForAverage)
                    meanInt(k) = mean(intensitySorted(1:min(length(intensitySorted),numberOfMinimumIntensityPixelsForAverage(k))));
                end
                meanIntROI  = mean(intensitySorted);
                
                meanIntWholeImg = mean(I(:));
                
                if(getDebugLevel>=1)
                    maskContour = bwmorph(mask,'remove'); %reduce regions to their boundaries
                    
                    I_overlay = max(I,maskContour*max(I(:))); %ROI contour
                    I_overlay = overlayCircles(I_overlay,[T1([2,1]);T2([2,1])],2,0,3); %centrosomes
                    printOnImage_init(I_overlay);
                    text(10,30,sprintf('t = %d',t), 'Color', 'w');
                    I_overlay = printOnImage_finish(I_overlay,1);
                    
                    partialMinPrjStack(:,:,t) = I_overlay;
                    
                    maxMinInt = intensitySorted(numberOfMinimumIntensityPixelsForAverage(end));
                    I(maskIdx & I <= maxMinInt) = 0; %min intensity pixels
                    partialMinPrjStackMinPixels(:,:,t) = I_overlay;
                    
                    if(getDebugLevel >= 3)
                        img = I;
                        p = round((T1(1:3) + T2(1:3))/2);
                        sfigure, mesh(img);
                        hold on;
                        idx = find(maskIdx & img <= maxMinInt);
                        [rowIdx, colIdx] = ind2sub(size(img), idx);
                        plot3(colIdx, rowIdx, img(idx), 'or');
                        rr = 100;
                        xlim([p(1) - rr,p(1)+rr]);
                        ylim([p(2) - rr,p(2)+rr]);
                    end
                end
                
                
                dist = RealDistance( T1(1:3), T2(1:3));
                Time = [Time t];
                Intensity = [Intensity meanInt(:)];
                SpindleLength = [SpindleLength dist];
                MeanIntensityROI = [MeanIntensityROI meanIntROI];
                MeanIntensityImage = [MeanIntensityImage meanIntWholeImg];
                
            end
        end
        if(getDebugLevel>=1 && ~isempty(cellIdentifier))
            %save as 8 bit intensity scaled
            %            WriteStackAsMultiTIFF(im2uint8(imadjust(partialMinPrjStack)), [dirDebug filesep param.tag sprintf('_partialMinPrj_%s.tif',cellIdentifier)]);
            
            %save as 16 bit original scale
            partialMinPrjStack = partialMinPrjStack / max(partialMinPrjStack(:));
            WriteStackAsMultiTIFF(im2uint16(partialMinPrjStack(:,:,t_ix)),          [dirDebug filesep param.tag sprintf('_partialMinPrj_%s.tif',cellIdentifier)]);
            if(nargin == 0)
                WriteStackAsMultiTIFF(im2uint16(partialMinPrjStackMinPixels(:,:,t_ix)), [dirDebug filesep param.tag sprintf('_partialMinPrjMinIntensityPixels_%s.tif',cellIdentifier)]);
            end
        end
        if(~isempty(Time))
            
            %Intensity = mean(Intensity,1);
            Intensity = Intensity ./ repmat(MeanIntensityImage,size(Intensity,1),1);
            
            IntensityAll = Intensity;
            Intensity    = Intensity(1,:);
            
            [maxSpindleLength, ix_maxSpindleLength] = max(SpindleLength);
            
            startIdx = floor(length(Time) * maxIntensitySearchRange(1));
            stopIdx  = ceil(length(Time) * maxIntensitySearchRange(2));
%             stopIdx  = min(stopIdx, ix_maxSpindleLength);
            
            %move the startIdx to the left as long as the intensity increases
            if(moveLeftMaxIntensityBorderToTheLeft)
                while(startIdx>1)
                    if(Intensity(startIdx-1) > Intensity(startIdx))
                        startIdx = startIdx - 1;
                    else
                        break;
                    end
                end
            end
            
            [maxIntIdx] = index1DOfMax(Intensity,[startIdx,stopIdx-startIdx+1]); %seach for the maximum in the center part of the track
            derivative = derivativeOfVector(Intensity);
            derivative = [0 derivative(:)' 0] ./ (2*param.frameInterval);
            derivative2 = [diff(Intensity) 0] ./ param.frameInterval;
            
            
            
            roi = [max(1,maxIntIdx-nFramesBeforeMaxIntensity), nFramesBeforeMaxIntensity];
            [maxIncreaseIdx] = index1DOfMax( derivative, roi );
            
            NEBDAuto = Time(maxIncreaseIdx);
            T(T(:,cellIDColIdx) == cellID,NEBDColIdx) = NEBDAuto;
            
            if(cellNameColIdx > 0)
                try
                    numCellName = T(T(:,cellIDColIdx) == cellID,cellNameColIdx);
                    numCellName = numCellName(1);
                    if(numCellName > 0)
                        cellName = numericCellnameToCellname(numCellName);
                        if(~any(strcmpi(non_specific_cellnames, cellName)))
                            xml_NEBD.(cellName) = NEBDAuto;
                        end
                    end
                catch
                    printDebugStack(lasterror);
                end
            end
                        
            if(getDebugLevel>=1)
                
                %fit cubic polynomial to spindle length over time
                degree = 3;
                polynomialSL = polyfit(Time,SpindleLength,degree);
                
                if(size(IntensityAll,1) > 1)
                    fig1 = sfigure;
                    maximize(fig1);
                    hold on
                    for k = 1 : size(IntensityAll,1)
                        plot(Time, IntensityAll(k,:),'o-','MarkerSize',3,'LineWidth',2,'DisplayName',sprintf('nucleus intensity, r = %.2f',proportionOfPixelsForAverage(k)));
                        text(Time(1), IntensityAll(k,1), sprintf('%.2f',proportionOfPixelsForAverage(k)))
                    end
                    xlabel('frame number');
                    ylabel('intensity');
                    
                    fn = [dirDebug filesep sprintf('chart_intensityAll_%s.fig',cellIdentifier)];
                    saveas(fig1,fn);
                end
                
                
                fig1 = sfigure;
                maximize(fig1);
                %subplot(1,2,1);
                ax(1) = gca;
                plot(Time, Intensity,'or-','MarkerSize',3,'LineWidth',2,'DisplayName','nucleus intensity');
                hold on
                plot(Time(maxIntIdx), Intensity(maxIntIdx), 'md', 'MarkerSize', 9,'DisplayName','maximum intensity');
                plot(NEBDAuto, Intensity(maxIncreaseIdx), 'go','MarkerSize',10,'DisplayName',sprintf('NEBD = %d',NEBDAuto));
                
                MeanIntensityImage = MeanIntensityImage * (max(Intensity)/max(MeanIntensityImage));
                plot(Time, MeanIntensityImage,'go-','MarkerSize',3,'LineWidth',2,'DisplayName','mean intensity entire image (scaled)');
                MeanIntensityROI = MeanIntensityROI ./ MeanIntensityImage;
                MeanIntensityROI = MeanIntensityROI * (max(Intensity)/max(MeanIntensityROI));
                plot(Time, MeanIntensityROI,  'ko:','MarkerSize',3,'LineWidth',2,'DisplayName','mean intensity ROI (scaled)');
                
                try
                    NEBDIdx = find(Time==param.NEBD);
                    plot(Time(NEBDIdx), Intensity(NEBDIdx), 'kx','MarkerSize',10,'DisplayName',sprintf('NEBD (man.) = %d',Time(NEBDIdx)));
                catch
                end
                
                t0 = Time(roi(1));
                t1 = Time(startIdx);
                t2 = Time(stopIdx);
                if(t1==t0)
                    t1 = t1 + .05;
                end
                plot([t1 t1],ylim,'-.m','DisplayName','maximum intensity search border');
                plot([t2 t2],ylim,'-.m','DisplayName','maximum intensity search border');
                plot([t0 t0],ylim,'-.g','DisplayName','maximum derivative search border');
                xlabel('frame number');
                ylabel('intensity');
                
                
                
                hold on;
                ax(2) = axes('Position',get(gca,'Position'),'XAxisLocation','bottom','YAxisLocation','right','Color','none','XMinorTick','on');
                hold on
                
                plot(Time, SpindleLength,'kd-','MarkerSize',3,'LineWidth',2,'DisplayName','spindle length');
                plot(Time,polyval(polynomialSL,Time),'k:','DisplayName','cubic fit');
                xlabel('frame number');
                ylabel('spindle length');
                
                title(sprintf( '%s, movie: %s', strrep(cellIdentifier,'_','\_'), strrep(param.tag,'_','\_')));
                legend(ax(1),'show','Location','NorthWest');
                legend(ax(2),'show','Location','NorthEast');
                
                fn = [dirDebug filesep sprintf('chart_intensity_spindleLength_%s.fig',cellIdentifier)];
                saveas(fig1,fn);
                
                fig2 = sfigure;
                maximize(fig2);
                plot(Time, derivative, 'k-o', 'LineWidth', 2, 'DisplayName', 'derivative (x[i+1]-x[i-1])');
                hold on
                plot(Time, derivative2, 'r-x', 'LineWidth', 2, 'DisplayName', 'derivative (x[i+1]-x[i])');
                plot(Time(maxIntIdx), derivative(maxIntIdx), 'md', 'MarkerSize', 15,'DisplayName','maximum intensity');
                plot(NEBDAuto, derivative(maxIncreaseIdx), 'go','MarkerSize',15,'DisplayName',sprintf('NEBD = %d',NEBDAuto));
                plot(xlim, [0 0], '--');
                legend('show');
                xlabel('frame number');
                ylabel('derivative of nucleus intensity');
                title(sprintf( '%s, movie: %s', strrep(cellIdentifier,'_','\_'), strrep(param.tag,'_','\_')));
                
                set(gca,'XGrid','on')
                
                fn = [dirDebug filesep sprintf('chart_derivativeOfIntensity_%s.fig',cellIdentifier)];
                saveas(fig2,fn);
                
                if(getDebugLevel<2)
                    close(fig1);
                    close(fig2);
                end
            end
        end
    end
    
    try
        figures2Postscript(dirDebug,'.*\.fig',0,'NEBDcurves.ps');
    catch
    end
    
    xml_NEBD
    
    if(~isempty(fieldnames(xml_NEBD)) && ~leavePropertiesFileUnchanged)
        fn = [workingDir filesep 'NEBD.xml'];
        xml_write(fn, xml_NEBD, 'NEBD');
        
        warning('NEBD information in the properties file will be changed (%s)!!!',param.tag);
        props = loadProperties();
        props.NEBD = xml_NEBD;
        saveProperties(props);
    end
    T = [T;T_excluded];
    T = sortrows(T,4); %sort by time
end

[T, header] = ComputeTimeRelativeToNEBD(T,header);
fprintMatrix(filenameOut, T, header);

end

function [mask ] = getRectangleMask(p1,p2,halfWidth, siz)
%p1, p2 = [x,y]
%m,n    - dimension of the mask

v = (p2 - p1);
if(~any(v))
    warning(sprintf('p1 = (%.6f,%.6f) and p2 = (%.6f,%.6f) are identical',p1, p2));
    mask = zeros(siz);
else
    v = (RotationMatrix(90) * v' / norm(v))';
    
    p(1,:) =  halfWidth * v + p1;
    p(2,:) =  halfWidth * v + p2;
    p(3,:) = -halfWidth * v + p2;
    p(4,:) = -halfWidth * v + p1;
    
    mask = poly2mask(p(:,1),p(:,2), siz(1),siz(2));
end
cen         = round((p2 + p1) / 2);
circ        = plot_circle(cen(1),cen(2),2*halfWidth, 'bresenhamSolid');
positiveIdx = circ(:,1) > 0 & circ(:,1) <= size(mask,2) & circ(:,2) > 0 & circ(:,2) <= size(mask,1);
circ        = circ(positiveIdx,:);
index       = sub2ind(size(mask),circ(:,2),circ(:,1));
mask(index) = 1;
end