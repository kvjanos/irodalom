function [ fn ] = completeTracksFile(  )
%COMPLETETRACKSFILE Summary of this function goes here
%   Detailed explanation goes here

fn = 'tracksComplete.txt';
