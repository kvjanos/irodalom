function [ graph_directory ] = graphDir()
    graph_directory = [baseDir filesep '_graphs'];
end

