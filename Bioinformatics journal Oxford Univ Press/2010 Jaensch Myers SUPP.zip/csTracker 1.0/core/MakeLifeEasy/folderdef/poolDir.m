function [ pool_directory ] = poolDir(  )
%POOLDIR Summary of this function goes here
%   Detailed explanation goes here
pool_directory = ensureDirExists([baseDir filesep '_pool']);
