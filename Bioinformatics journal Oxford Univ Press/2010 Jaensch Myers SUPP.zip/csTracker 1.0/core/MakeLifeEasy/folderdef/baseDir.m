function [ directory ] = baseDir( )

dirs = {
   'I:\data\csmovies'
    };

directory = [];
for i = 1 : size(dirs,1)
    d = dirs{i,1};
    if(exist(d, 'dir'))
        directory = d;
        break;
    end
end

if(isempty(directory))
    error('Base directory could not be found!');
end
