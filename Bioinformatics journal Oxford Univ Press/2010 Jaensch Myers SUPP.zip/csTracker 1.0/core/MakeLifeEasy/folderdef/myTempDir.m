function [ tDir ] = myTempDir(  )

tDir = [baseDir filesep '_temp'];
ensureDirExists(tDir);