function [ iDir ] = idiskDir(  )

iDir = 'M:\www';
if(~exist(iDir, 'dir'))
    error('web folder "%s" does not exist',iDir);
end

end

