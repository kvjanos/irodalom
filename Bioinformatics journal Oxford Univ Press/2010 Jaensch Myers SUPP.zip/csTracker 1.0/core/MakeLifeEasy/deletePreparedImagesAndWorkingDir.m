function deletePreparedImagesAndWorkingDir(fullpathMovieDir)
    %deletes all subfolders and .fig files in 'fullpathMovieDir' and restores 'properties.xml' from 'properties_org.xml'
    D = dir(fullpathMovieDir);
    for i = 1 : length(D)
        if(D(i).isdir && ~any(strcmpi(D(i).name, {'.','..'})))
            subfolder = [fullpathMovieDir filesep D(i).name];
            rmdir(subfolder, 's');
        end
    end
    delete([fullpathMovieDir filesep '*.fig']);
    copyfile([fullpathMovieDir filesep 'properties_org.xml'],[fullpathMovieDir filesep 'properties.xml'],'f');
end
