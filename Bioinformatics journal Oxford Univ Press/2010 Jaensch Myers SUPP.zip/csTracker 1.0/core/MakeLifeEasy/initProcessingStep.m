function [filenameIn, filenameOut, dirDebug ] = initProcessingStep( workingDir, filenameIn, opName, dirDebugName )
%
%opName control symbols: '*' append op-name also if the op-name is already in the filename
%                        '>' start new filename instead of appending the op-name   
%                        ':' filenameIn = filenameOut  
%see also: processInput

global param;
loadGlobalParams(workingDir);
filenameIn  = addDirectoryToFilename(workingDir, filenameIn);
filenameOut = [];
dirDebug    = [];

if(nargin >= 3 && ~isempty(opName))
    controlSymbol = opName(1);
    if(sum(strcmp(controlSymbol,{'>','*',':'})) > 0)
        opName = opName(2:end);
    else
        controlSymbol = 'x'; %x ==> no control symbol
    end
    
    [path name ext] = fileparts(filenameIn);
    if(getDebugLevel >= 2)
        opName = [opName sprintf('DebugLevel%d',getDebugLevel)];
    end
    
    if(~isempty( strfind(name, opName)) && controlSymbol ~= '*') 
        opName2 = '';
    else
        opName2 = ['_' opName];
    end
    
    if(controlSymbol == '>')
        name = [opName ext];
    elseif(controlSymbol == ':')
        name = [name ext];
    else
        name = [name opName2 ext];
    end
    if(length(name) > 172)
        name = [opName ext];
    end
    filenameOut = fullfile(path,name);
    %filenameOut = addDirectoryToFilename(workingDir, filenameOut);
end

if(nargin >= 4 && ~isempty(dirDebugName))
    dirDebug = makeDebuggingFolder(dirDebugName);
end

