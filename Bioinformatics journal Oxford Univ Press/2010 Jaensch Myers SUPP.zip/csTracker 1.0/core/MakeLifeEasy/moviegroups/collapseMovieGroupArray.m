function [ movGroups_collapsed ] = collapseMovieGroupArray( movGroups, clusterFields )

movGroups_collapsed = collapseClusters( movGroups, clusterFields, {'workingDirList','subgroup','objective','filenameIn'});

end

