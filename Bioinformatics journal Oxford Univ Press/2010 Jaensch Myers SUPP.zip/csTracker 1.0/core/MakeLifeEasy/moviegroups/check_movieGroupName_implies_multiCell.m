function [ b, cellstage ] = check_movieGroupName_implies_multiCell( movieGroupName )

if(nargin == 0)
    movieGroupName = 'N2_WT[x]_yTUB-Alexa617_1cellstage_';
    movieGroupName = 'N2_WT[x]_yTUB-Alexa617_2cellstage_';
end

regex_cellstage = '(\d+).?cell';

[start_idx, end_idx, extents, matches, tokens, names, splits] = regexp(movieGroupName, regex_cellstage);

b = 0;
cellstage = -1;
if(~isempty(tokens))
    try
        cellstage = str2double(tokens{1}{1});
        b = cellstage > 1;
    catch
    end
end

end

