function [  ] = updateMovieGroup(  )

movieGroups = {};

oldGroupName = 'AIR1-GFP1 WT(fosmid)';
newGroupName = 'AIR1-GFP fosmid WT';

m = loadMovieGroupByName(oldGroupName);
movieGroups = [movieGroups m];

global pathHomeDir;
for i = 1 : length( movieGroups)
    movieGroup_i = movieGroups{i};
    fprintf('%d movies found in group "%s"...updating group name to "%s"\n',length(movieGroup_i.workingDirList), movieGroup_i.group, newGroupName);
    user_entry = input('press enter to continue', 's');
    if(~isempty(user_entry))
        return
    end
    for j = 1 : length(movieGroup_i.workingDirList)
        
        workingDir = movieGroup_i.workingDirList{j}
        loadGlobalParams(workingDir); % ==> sets 'pathHomeDir'
        
        fn = [pathHomeDir filesep 'properties.xml'];
        setMovieGroup(fn, newGroupName)
        fn = [pathHomeDir filesep 'properties_org.xml'];
        setMovieGroup(fn, newGroupName)
    end
end
end

function setMovieGroup(fn, groupName)
p = xml_read(fn);
p.movieGroup = groupName;
xml_write(fn,p);
end
