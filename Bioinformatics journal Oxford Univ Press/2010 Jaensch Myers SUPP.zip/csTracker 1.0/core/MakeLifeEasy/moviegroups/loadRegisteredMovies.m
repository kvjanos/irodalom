function [ movieGroups ] = loadRegisteredMovies( fn_xml, addSubGroups, workingDirNum )
%also see: saveRegisteredMovies

if(nargin < 2)
    addSubGroups = 1;
end
if(nargin < 3)
    workingDirNum = [];
end

%pref.NoCells = 0;
%movieGroups = xml_read(fn_xml, pref);

fn_matlab = [getPathAndFilenameWithoutExtension(fn_xml) '.mat'];
load(fn_matlab);

for i = 1 : length(movieGroups)
    movieGroups{i}.parentGroupname = [];
    for j = 1 : length(movieGroups{i}.workingDirList);
        movieGroups{i}.workingDirList{j}.path = eval(movieGroups{i}.workingDirList{j}.path);
        if(~isempty(workingDirNum))
            movieGroups{i}.workingDirList{j}.path = [fileparts(movieGroups{i}.workingDirList{j}.path) filesep workingDirNum];
        end
    end
end
if(addSubGroups)
    movieGroups = addSubgroups(movieGroups);
end
movieGroups = sortCellArrayByField(movieGroups, {'isMultiCell','group'});

end

function allMovieGroups = addSubgroups(allMovieGroups)
%clusters each movie group by the specified fields and adds the movies
%belonging to one cluster as new movie group with an extended group name
%to the list of movie groups

    clusterFields = {'subgroup','objective'};
    
    for i = 1 : length(allMovieGroups)
        mg = allMovieGroups{i};
        clusters = clusterCellArray(mg.workingDirList, clusterFields);
        minNumberOfUniqueValues = 1;
        %only create subgroups of fields that have more than one unique value
        clusterFieldsWithMultipleValues = {};
        for k = 1 : length(clusterFields)
            u = unique(convertToString( valuesFromCellArray(clusters, clusterFields{k})));
            if(length(u) >= minNumberOfUniqueValues)
                clusterFieldsWithMultipleValues{end+1} = clusterFields{k};
            end
        end  
        
        if(length(clusters) >= minNumberOfUniqueValues)
            for j = 1 : length(clusters)
                subMovieGroup = mg;
                clusterFieldValues = cell(1, length(clusterFieldsWithMultipleValues));
                for k = 1 : length(clusterFieldsWithMultipleValues)
                    clusterFieldValues{k} = clusters{j}.(clusterFieldsWithMultipleValues{k});
                end                
                subMovieGroup.group = [subMovieGroup.group ' (' strList2SeparatedString(clusterFieldValues, ', ', 1) ')']; %1 -> skipEmtpyEntries
                subMovieGroup.workingDirList = clusters{j}.members;
                subMovieGroup.parentGroupname = mg.group;
                allMovieGroups{end+1} = subMovieGroup;
            end
        end
        
    end
end

%     try
%         movieGroups = addNewGroupFromExistingGroups(movieGroups, {'yTUB-GFP Air1 7-8hrsRNAi',[1,3,7,10,17,19,20,22,23,24,25]}, 'low');
%         movieGroups = addNewGroupFromExistingGroups(movieGroups, {'yTUB-GFP Air1 7-8hrsRNAi',[2,4,5,6,8,9,11:16,18,21,26,27]}, 'high');
%     catch
%     end
%
%     try
%         movieGroups = addNewGroupFromExistingGroups(movieGroups, {'SPD5-YFP WT',[1:7]}, 'SPD5-YFP WT (oil)');
%         movieGroups = addNewGroupFromExistingGroups(movieGroups, {'SPD5-YFP WT',[8:15]}, 'SPD5-YFP WT (water)');
%     catch
%     end
% 
%     try
%         movieGroups = addNewGroupFromExistingGroups(movieGroups, {'SPD2-GFP WT',[1:13]}, 'SPD2-GFP WT (oil)');
%         movieGroups = addNewGroupFromExistingGroups(movieGroups, {'SPD2-GFP WT',[14:24]}, 'SPD2-GFP WT (water)');
%     catch
%     end

% function addNewGroupFromExistingGroups(allMovieGroups, whichMovies, newGroupName)
% 
%     global param;
%     m.group          = newGroupName;
%     m.workingDirList = {};
%     m.filenameIn     = [];
%     for i = 1 : length(allMovieGroups)
%         mg = allMovieGroups{i};
%         for j = 1 : 2 : length(whichMovies)
%             thisGroupname = whichMovies{j};
%             if(strcmpi(mg.group, thisGroupname))
%                 
%                 idx = whichMovies{j+1}; %the indices of the movies in this group to be loaded
%                 
%                 existingIndices = valuesFromCellArray(mg.workingDirList, 'index');
%                 tf = ismember(existingIndices, idx);
%                 m.workingDirList = [m.workingDirList, mg.workingDirList(tf)];
% 
%                 if(isempty(m.filenameIn))
%                     m.filenameIn = mg.filenameIn;
%                 elseif(~strcmpi(m.filenameIn, mg.filenameIn))
%                     error('new movie group is already assigned filenameIn "%s". Cannot assign "%s"', m.filenameIn, mg.filenameIn);
%                 end
%             end
%         end
%     end
%     for i = 1 : length(m.workingDirList)
%         loadGlobalParams(m.workingDirList{i}.path);
%         p = loadProperties();
%         p.subgroup = newGroupName;
%         saveProperties(p);
%     end
% end