function [ m ] = registeredMovies( groupname, indices, errorOrWarning, repGroupnameByMovieTag, workingDirNum )
%see also: loadRegisteredMovies, printRegisteredMovieGroups

%
%input: no input:                      - all registered movie groups as returned by 'loadRegisteredMovies'
%                                        mind the field 'workingDirList', it's originally a struct and
%                                        replaced by the 'path' entry in this function
%       otherwise:
%       groupname                      - name of the movie group to be loaded 
%       indices                        - indices of the movies in the group
%                                        to be loaded (optional, may be empty)
%       errorOrWarning                 - 'error'   ==> throws error if movie group is not found
%                                        'warning' ==> prints warning and returns empty movie group 
%       repGroupnameByMovieTag         - (0|1) ==> if only one movie of a movie group is loaded, 
%                                                  replaces the movie group name by the movie tag 
if(nargin < 3)
    errorOrWarning = 'error';
end
if(nargin < 4)
    repGroupnameByMovieTag = 0;
end
if(nargin < 5)
    workingDirNum = [];
end

fn_xml = [baseDir filesep 'registeredMovies.xml'];
if(~exist(fn_xml,'file'))
    findRegisteredMovies(baseDir);
end


global param;

if(nargin == 0)
    addSubGroups = 0;
    movieGroups = loadRegisteredMovies(fn_xml, addSubGroups,workingDirNum);
    m = movieGroups;
   for i = 1 : length(m)
        m{i}.movies         = m{i}.workingDirList;
        m{i}.workingDirList = valuesFromCellArray( m{i}.workingDirList, 'path');
   end
else
    groupname = strtrim(groupname);
    addSubGroups = 1;
    movieGroups = loadRegisteredMovies(fn_xml, addSubGroups, workingDirNum);
    for i = 1 : length(movieGroups)
        m = movieGroups{i};
        if(nargin == 0 || strcmpi(m.group,groupname))
            if(nargin >= 2 && ~isempty(indices))
                if(length(indices) > length(m.workingDirList))
                    indices = indices(1:length(m.workingDirList));
                end
                
                existingIndices = valuesFromCellArray(m.workingDirList, 'index');
                tf = ismember(existingIndices, indices);
                m.workingDirList = m.workingDirList(tf);
            end
            %remove movies that shall not be loaded
            for j = length(m.workingDirList) : -1 : 1
                if(m.workingDirList{j}.doNotLoad)
                    m.workingDirList(j) = [];
                end
            end
            m.movies         = m.workingDirList;
            m.workingDirList = valuesFromCellArray( m.workingDirList, 'path');
            
            if(repGroupnameByMovieTag && length(m.workingDirList) == 1)
                loadGlobalParams(m.workingDirList{1});
                m.group = param.tag;
            end
            return;
        end
    end

    if(strcmpi(errorOrWarning,'error'))
        error('movie group with groupname "%s" not found',groupname);
    else
        m.workingDirList    = {};
        m.filenameIn        = [];
        m.group             = [];

        if(strcmpi(errorOrWarning,'warning'))
            warning('movie group with groupname "%s" not found',groupname);
        end
    end
end