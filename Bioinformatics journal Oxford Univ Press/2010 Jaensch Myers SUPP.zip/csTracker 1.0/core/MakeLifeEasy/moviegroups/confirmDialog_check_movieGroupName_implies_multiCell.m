function confirmDialog_check_movieGroupName_implies_multiCell(movieGroupName, isMultiCell)
    b = check_movieGroupName_implies_multiCell(movieGroupName);

    user_entry = 'y';
    if(b == 1 && ~isMultiCell)
        user_entry = input(sprintf('It seems movie group "%s" is multi-cell, but isMultiCell = 0. \nDo you want to continue anyway? [y/n]',movieGroupName), 's');
    end
    if(b == 0 && isMultiCell)
        user_entry = input(sprintf('It seems movie group "%s" is one-cell, but isMultiCell = 1. \nDo you want to continue anyway? [y/n]',movieGroupName), 's');
    end

    if(~strcmpi(user_entry, 'y'))
        error('user aborted');
    end
end
