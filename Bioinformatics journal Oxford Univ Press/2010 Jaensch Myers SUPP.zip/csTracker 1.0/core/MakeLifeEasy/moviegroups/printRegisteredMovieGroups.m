function printRegisteredMovieGroups(varargin)
%prints the currently registered movie groups
%
%call: printRegisteredMovieGroups                                           - all groupnames
%      printRegisteredMovieGroups('details','groupname1','groupname2')      - all groupnames and working directories of the specified groups
%      printRegisteredMovieGroups('details')                                - all groupnames and working directories
%      printRegisteredMovieGroups('matlabcode','main_postProcessing_batch') - all groupnames and matlab
%                                                                             code for main_postProcessing_batch
%      printRegisteredMovieGroups('fid',x)      - prints the output to the file identifier x
%      
%

    [details,   b,varargin]  = getVarargin(varargin, 'details', 0, 1, 'single');
    [matlabcode,b,varargin]  = getVarargin(varargin, 'matlabcode', [], 1);
    [fid,       b,varargin]  = getVarargin(varargin, 'fid', 1);
    groupnames = varargin;
        
    fn_xml = [baseDir filesep 'registeredMovies.xml'];
    if(~exist(fn_xml,'file'))
        registerMovies(baseDir);
    end
    movieGroups = loadRegisteredMovies(fn_xml);
    if(~isempty(groupnames))
        for i = length(movieGroups):-1:1
            if(~any(strcmpi(groupnames, movieGroups{i}.group)) && ~any(strcmpi(groupnames, movieGroups{i}.parentGroupname)))
                movieGroups(i) = [];
            end
        end
    end
    for i = 1 : length(movieGroups)
        fprintf(fid,'''%s''\n',movieGroups{i}.group);
    end
    fprintf(fid,'\n\n')
    for i = 1 : length(movieGroups)
        if(isempty(movieGroups{i}.parentGroupname))
            indent = sprintf('\t');
            fprintf(fid,'%s (n=%d)\n',movieGroups{i}.group, length(movieGroups{i}.workingDirList));
        else
            indent = sprintf('\t\t');
            fprintf(fid,'\t%s {subgroup of: %s} (n=%d)\n',movieGroups{i}.group, movieGroups{i}.parentGroupname, length(movieGroups{i}.workingDirList));
        end
        if(details)
            for j = 1 : length(movieGroups{i}.workingDirList)
                fprintf(fid,'%s[%02d] %s, dz=%d nm\n',indent,movieGroups{i}.workingDirList{j}.index,movieGroups{i}.workingDirList{j}.path,movieGroups{i}.workingDirList{j}.zResolution);
            end
        end
    end
    if(~isempty(matlabcode) && strcmpi(matlabcode,'main_postProcessing_batch'))
        movieGroups = loadRegisteredMovies(fn_xml, 0); %0 - addSubGroups
        fprintf(fid,'\n\n')
        for i = 1 : length(movieGroups)
            fprintf(fid,'m = registeredMovies(''%s'');\n',movieGroups{i}.group);
            fprintf(fid,'workingDirs = [workingDirs;m.workingDirList];\n\n');
        end
    end

end