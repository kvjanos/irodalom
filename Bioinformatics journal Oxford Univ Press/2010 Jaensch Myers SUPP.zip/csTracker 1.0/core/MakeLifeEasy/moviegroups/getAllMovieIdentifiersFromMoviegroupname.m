function [movieIdentifiers] = getAllMovieIdentifiersFromMoviegroupname(movieGroupName)

if(nargin == 0)
    movieGroupName = 'AIR1-GFP fosmid XFP 11hrsRNAi';
end

try %error will error if movie group does not exist ==> catch by returning an empty cell array

    movieGroup = loadMovieGroupByName(movieGroupName);
    movieIdentifiers = cell(length(movieGroup.movies),1);
    for i = 1:length(movieGroup.movies)
        movieIdentifiers{i}.movieTag       = movieGroup.movies{i}.movieTag;
        movieIdentifiers{i}.movieNumericID = movieGroup.movies{i}.index;
    end
catch ME
    movieIdentifiers = {};
end
end