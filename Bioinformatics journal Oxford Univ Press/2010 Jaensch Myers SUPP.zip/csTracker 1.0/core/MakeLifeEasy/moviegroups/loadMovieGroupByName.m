function [ mg ] = loadMovieGroupByName( groupname, fieldsAndValues, indices, errorOrWarning, workingDirNum )

if(nargin < 2)
    fieldsAndValues = {};
end
if(nargin < 3)
    indices = [];
end
if(nargin < 4)
    errorOrWarning = 'error';
end
if(nargin < 5)
    workingDirNum = '1';
end

mg = loadMovieGroup([{'group',groupname} fieldsAndValues],{'group','subgroup','objective','filenameIn'},indices, errorOrWarning, 'workingDirNum', workingDirNum);

mg = collapseArray(mg,{'group','subgroup','objective','filenameIn'});
% %merge groups
% mg_all = mg;
% if(length(mg)>1)
%     mg = mg_all(1);
%     fnames = fieldnames(mg);
%     for i = 2 : length(mg_all)
%         mg.workingDirList = [mg.workingDirList;mg_all(i).workingDirList];
%         mg.movies = [mg.movies mg_all(i).movies];
%         
%         for j = 1 : length(fnames)
%             fname = fnames{j};
%             v = mg.(fname);
%             if(ischar(v))
%                 if(~strcmpi(v, mg_all(i).(fname)))
%                     mg.(fname) = '---';
%                 end
%             elseif(isnumeric(v) || islogical(v))
%                 if(v ~= mg_all(i).(fname))
%                     mg.(fname) = -999;
%                 end
%             end
%         end
%         
%     end
% end

fieldsToBeIncludedInGroupTag = {'subgroup','objective'};

addMovieTagText = {};
for i = 1 : length(fieldsToBeIncludedInGroupTag)
    fname = fieldsToBeIncludedInGroupTag{i};
    if(any(strcmpi(fieldsAndValues, fname)))
        if(isempty(mg.(fname)))
            addMovieTagText{end+1} = ['[no ' fname ']'];
        else
            addMovieTagText{end+1} = mg.(fname);
        end
    end
end
if(~isempty(addMovieTagText))
    mg.group = [mg.group ' (' strList2SeparatedString(addMovieTagText, ', ') ')']
end
end
