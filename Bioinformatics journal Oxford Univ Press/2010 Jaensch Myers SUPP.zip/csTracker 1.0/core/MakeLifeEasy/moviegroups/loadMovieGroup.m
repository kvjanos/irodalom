function [ movieGrp ] = loadMovieGroup(fieldsAndValues,clusterFields, varargin )
%syntax: loadMovieGroup({'fieldname1','value1',...},{fieldname1, fieldname2}, indices {optional}, ... see "getVarargin")


if(nargin < 2)
    clusterFields = {};
end

if(~isempty(varargin) &&  isnumeric(varargin{1}))
    indices = varargin{1};
    varargin(1) = [];
else
    indices = [];
end
[workingDirNum,keyFound, varargin]   = getVarargin(varargin, 'workingDirNum', '1', 1);
[filenameIn,keyFound, varargin]      = getVarargin(varargin, 'filenameIn', finalTrackingFile(), 1);
[b_error, keyFound, varargin]        = getVarargin(varargin, 'error', 1, 1, 'single');
[b_warning, keyFound, varargin]      = getVarargin(varargin, 'warning', 0, 1, 'single');
if(b_error)
    errorOrWarning = 'error';
else
    errorOrWarning = 'warning';
end

movies_all = loadAllRegisteredMovies();

if(ischar(fieldsAndValues))
    str = fieldsAndValues;
    clear 'fieldsAndValues';
    fieldsAndValues{1} = str;
end
if(mod(length(fieldsAndValues),2) ~= 0)
    fieldsAndValues = [{'group'} fieldsAndValues];
end

fnames = fieldsAndValues(1:2:end);
values = fieldsAndValues(2:2:end);

movieList = {};
for i = 1 : length(movies_all)
    m = movies_all(i);
    
    b = 1;
    for j = 1 : length(fnames)
        if(~myIsEqual(m.(fnames{j}), values{j}))
            b = 0;
            break
        end
    end
    if(b)
        m.filenameIn = filenameIn;
        m.workingDir = [baseDir filesep m.homeDir filesep 'workingDir' filesep workingDirNum];
        movieList{end+1} = m;
    end
end

if(isempty(movieList))
    if(strcmpi(errorOrWarning, 'error'))
        error(sprintf('movie group could not be loaded: %s',strList2SeparatedString(fieldsAndValues,':')));
    else
        warning('movie group could not be loaded: %s',strList2SeparatedString(fieldsAndValues,','));
    end
    movieGrp = [];
    return
end

[workingDirListSorted, numbers, ix] = sortStrListNumerically(valuesFromCellArray(movieList,'workingDir'));
movieList = movieList(ix);

for j = 1 : length(movieList)
    if(isempty(numbers))
        movieList{j}.index     = j;
    else
        movieList{j}.index     = numbers(j);
    end
end

if(~isempty(indices))
    if(all(indices < 0))
        indices_toBeRemoved = -indices;
         for j = length(movieList) : -1 : 1
            if(any(ismember(indices_toBeRemoved, movieList{j}.index)))
                movieList(j) = [];
            end
        end
    elseif(all(indices > 0))
        for j = length(movieList) : -1 : 1
            if(~any(ismember(indices, movieList{j}.index)))
                movieList(j) = [];
            end
        end
    else
        error('all indices must either be negative or positive. mixture of negative and positive indices is not allowed');
    end
end

clusters = clusterCellArray(movieList, clusterFields);

for i = 1 : length(clusters)
    ci = clusters{i};
    for j = 1 : length(clusterFields)
        mg.(clusterFields{j}) = ci.(clusterFields{j});
    end
    mg.workingDirList   = valuesFromCellArray(ci.members,'workingDir');
    mg.movies           = ci.members;
    movieGrp(i) = mg;
end

end

function b = myIsEqual(obj1, obj2)
if(ischar(obj1) && ischar(obj2))
    b = strcmpi(obj1, obj2);
else
    try
        b =  obj1 == obj2;
    catch
        b = 0;
    end
end
end

function movies_all = loadAllRegisteredMovies()
fn = [baseDir filesep 'movies_all.mat'];
if(~exist(fn,'file'))
    registerMovies(baseDir);
end
load(fn);
end
