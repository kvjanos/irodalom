function renameMovieGroup( oldName, newName )
if(nargin == 0)
    oldName = 'Zyg1ts';
    newName = 'yTUB-GFP Zyg1ts';
end
m = registeredMovies(oldName);

for i = 1 : length(m.workingDirList)
    workingDir = m.workingDirList{i}
    loadGlobalParams(workingDir);
    prop = loadProperties();
    prop.movieGroup  = newName;
    prop
    saveProperties( prop );
end
%registerMovies()