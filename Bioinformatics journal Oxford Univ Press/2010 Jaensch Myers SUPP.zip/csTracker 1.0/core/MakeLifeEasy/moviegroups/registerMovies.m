function [ movieGroups, fn_xml ] = registerMovies( searchDir )
%also see: loadRegisteredMovies, saveRegisteredMovies, registeredMovies

if(nargin == 0)
    searchDir = baseDir;
end

fprintf('%s...',mfilename);

D = dir(searchDir);
global pathHomeDir;

idx = 0;
idx_all = 0;

for i = 1 : length(D)
    if(D(i).isdir && ~any(strcmp(D(i).name,{'.','..'})) && D(i).name(1) ~= '_')
        pathHomeDir = [searchDir filesep D(i).name];
        try
             m = [];
             p = loadProperties( );
             m.group      = p.movieGroup;
            
             if(isfield(p, 'subgroup'))
                 m.subgroup = p.subgroup;
             else
                 m.subgroup = '';
             end
             
             if(isempty(m.subgroup)) %make sure 'empty string' is not represented as '[]'
                m.subgroup = '';
             end
             
             if(isfield(p, 'objective'))
                m.objective  = p.objective;
             else
                m.objective  = 'oil';
             end
             m.isMultiCell = p.isMultiCell;
             m.zResolution = p.zResolution;
             m.doNotLoad  = isfield(p, 'doNotLoad') && p.doNotLoad;

             s = m;

             m.workingDir = [pathHomeDir filesep 'workingDir\1'];
             m.filenameIn = finalTrackingFile();
             if(exist(m.workingDir, 'dir'))
                idx = idx + 1;
                movies(idx) = m;
             end
            
             s.movieTag = p.tag;
             s.homeDir  = p.homeDir;
             idx_all = idx_all + 1;
             movies_all(idx_all) = s;
        catch
            fprintf('%s\n',pathHomeDir);
            printDebugStack(lasterror)
        end
        
    end
end
fn_matlab = [searchDir filesep 'movies_all.mat'];
save(fn_matlab, 'movies_all');

clusters = clusterStructArray(movies, 'group');
for i = 1 : length(clusters)
    c = clusters{i};
    mg.group = c.group;
    
    [workingDirListSorted, numbers, ix] = sortStrListNumerically(valuesFromStructureArray(c.members,'workingDir'));
    c.members = c.members(ix);
    
    mg.workingDirList = cell(1, length(c.members));
    for j = 1 : length(c.members)
        mg.workingDirList{j}.path        = c.members(j).workingDir;
        mg.workingDirList{j}.doNotLoad   = c.members(j).doNotLoad;
        mg.workingDirList{j}.subgroup    = c.members(j).subgroup;
        mg.workingDirList{j}.objective   = c.members(j).objective;
        mg.workingDirList{j}.zResolution = c.members(j).zResolution;
        if(isempty(numbers))
            mg.workingDirList{j}.index     = j;
        else
            mg.workingDirList{j}.index     = numbers(j);
        end
    end
     
    fnList = unique(valuesFromStructureArray(c.members,'filenameIn'));
    if(length(fnList) ~= 1)
        error('filenameIn is not unique for movie group %s (%s)', mg.group, strList2SeparatedString(fnList,', '));
    end
    mg.filenameIn = fnList{1};

    isMultiCellList = unique(valuesFromStructureArray(c.members,'isMultiCell'));
    if(length(isMultiCellList) ~= 1)
        error('isMultiCell is not unique for movie group %s', mg.group);
    end
    mg.isMultiCell = isMultiCellList(1);
    movieGroups{i} = mg;
end
fn_xml = [searchDir filesep 'registeredMovies.xml'];
movieGroups = saveRegisteredMovies(fn_xml, movieGroups);
printRegisteredMovieGroups();

saveResultsToDisk = 1;
ParseAllMetafilesInBaseDir(saveResultsToDisk);
end

