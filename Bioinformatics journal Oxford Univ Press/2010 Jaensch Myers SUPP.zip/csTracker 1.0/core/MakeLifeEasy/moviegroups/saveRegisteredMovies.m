function [ movieGroups ] = saveRegisteredMovies( fn_xml, movieGroups )
% converts the workingDirs to strings enclosed in quotation marks (if not yet)
% and replaces the root-directory by 'baseDir' if applicable
%
%
%also see: loadRegisteredMovies, registerMovies, registeredMovies

bdir = baseDir;
for i = 1 : length(movieGroups)
    mg = movieGroups{i};
    for j = 1 : length(mg.workingDirList)
            d = mg.workingDirList{j}.path;
            if(strStartsWith(d, bdir))
                d = [strrep(d, [bdir filesep], '[baseDir filesep ''') ''']'];
            elseif(~strStartsWith(d, ''''))
                d = ['''' d ''''];
            end
            mg.workingDirList{j}.path = d;
    end
    movieGroups{i} = mg;
end

xml_write(fn_xml, movieGroups);

fn_matlab = [getPathAndFilenameWithoutExtension(fn_xml) '.mat'];
save(fn_matlab, 'movieGroups');