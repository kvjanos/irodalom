function [ movieGroup ] = workingDir2MovieGroup( workingDir )

if(nargin == 0)
    workingDir = [baseDir filesep 'yTUB-GFP1\workingDir\1'];
end

allMovieGroups = registeredMovies(); 
for i = 1 : length(allMovieGroups)
    mg = allMovieGroups{i};
    idx = find(strcmpi(mg.workingDirList, workingDir));
    if(~isempty(idx))
        movieGroup = mg;
        movieGroup.workingDirList = movieGroup.workingDirList(idx);
        movieGroup.movies = movieGroup.movies(idx);
    end
end

end

