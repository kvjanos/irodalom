function [ b ] = mp_objectiveNameToChipROI( objectiveName )

if(strcmpi(objectiveName, 'water (new SD)'))
    b = 0;
elseif(strcmpi(objectiveName, 'water'))
    b = 1;
elseif(strcmpi(objectiveName, 'oil'))
    b = 1;
elseif(strcmpi(objectiveName, 'dv'))
    b = 0;
elseif(strcmpi(objectiveName, 'dv_lmf'))
    b = 0;
else
    error('unknown objective "%s"',objectiveName)
end

end

