function [ resolution ] = mp_objectiveNameToResolution( objectiveName )

if(strcmpi(objectiveName, 'water (new SD)'))
    resolution = 133;
elseif(strcmpi(objectiveName, 'water'))
    resolution = 167;
elseif(strcmpi(objectiveName, 'oil'))
    resolution = 164;
elseif(strcmpi(objectiveName, 'dv'))
    resolution = 64;
elseif(strcmpi(objectiveName, 'dv_lmf'))
    resolution = 64;
else
    error('unknown objective "%s"',objectiveName)
end

end

