function [ fn ] = finalCandidatesFile(  )
    fn = 'finalCandidates.txt';
end
