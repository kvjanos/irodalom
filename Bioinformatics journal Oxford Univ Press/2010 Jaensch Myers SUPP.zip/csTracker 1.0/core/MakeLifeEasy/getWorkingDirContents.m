function getWorkingDirContents( movGrp )

if(nargin == 0)
    
    movieGroupName = {
        'yTUB-GFP WT'
        'Big1 RNAi'
        'Big1 26hrsRNAi2'
        'SPD2 9hrsRNAi'
        'PLK1 8hrsRNAi'
        'TAC1 23hrsRNAi'
        'Zyg1ts'
        'GPR2 24hrsRNAi'
        'SPD2-GFP WT'
        'Air1 7-8hrsRNAi'
        'yTUB-GFP long'
        'multi-cell'
    };

    movGrp = {};
    workingDirs = {};
    for i = 1 : length(movieGroupName)
        movGrp{i} = registeredMovies(movieGroupName{i});
        %workingDirs = [workingDirs;movGrp.workingDirList];
    end
end

fn_filelist = makeFilenameUnique([poolDir filesep 'overviewFiles.txt']);
for j = 1 : length(movGrp)
    movGrp_j = movGrp{j};
    for i = 1 : length(movGrp_j.workingDirList)
        workingDir = movGrp_j.workingDirList{i};
        %files = listFiles(workingDir, '*.txt');
        files = listFiles(workingDir, movGrp_j.filenameIn);
        printFileList(files, fn_filelist);
    end
end
winopen(fn_filelist);