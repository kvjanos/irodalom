function [ dirDebug ] = makeDebuggingFolder( dirDebugName )
%creates a debugging folder in the curretly loaded working directory
%
% input: 
% dirDebugName - name of the debugging folder (not the entire path!) 
%                use *name to create an empty debug dir with name 'name'
%
% see also: initProcessingStep, processInput
%

    if(isempty(dirDebugName))
        dirDebug = [];
        return
    end
    
    global param
    if(dirDebugName(1) == '*')
        dirDebugName = dirDebugName(2:end);
        emptyDir = 1;
    else
        emptyDir = 0;
    end
    dirDebug = [getFullPath(param.relPathDebug) filesep dirDebugName];
    if(emptyDir && getDebugLevel() >= 1)
        try
            ensureEmptyDirExists(dirDebug);
        catch
            ensureDirExists(dirDebug);
        end
    else
        ensureDirExists(dirDebug);
    end
    setDebugDir(dirDebug);

end

