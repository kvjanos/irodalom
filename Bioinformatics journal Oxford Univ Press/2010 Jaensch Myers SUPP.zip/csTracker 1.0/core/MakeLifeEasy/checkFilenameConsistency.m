function [ errorCount ] = checkFilenameConsistency( filenames, regEx_imageSeriesNumbering )
    %checks for a set of filenames whether they are all identical up to
    %identifying numbers, a image series numbering at the end of the
    %filename and the filename extension

    if(nargin == 0)
        dirIn = [baseDir filesep 'new set\4'];
        D = dir(dirIn);
        filenames = {};
        for i = 1 : length(D)
            if(~D(i).isdir)
                filenames{end+1} = D(i).name;
            end
        end
        regEx_imageSeriesNumbering = '_t[0-9]{4}';
    end
   
    %strip off file extension and image series number of each filename
    for i = 1 : length(filenames)
        fn = getFilenameWithoutExtension(filenames{i});
        [start_idx, end_idx, extents, matches, tokens, names, splits] = regexp(fn, ['(' regEx_imageSeriesNumbering ')$']);
        filenames_short{i} = splits{1};
    end
    filenames_short = sort(filenames_short);
    
    filename_short_unique = unique(filenames_short);
    [ uniqueNumbers, colIdx_uniqueNumbers ] = findNumberInSetOfStrings( filename_short_unique );
    if(isempty(uniqueNumbers))
        errorCount = 1;
        for i = 1 : length(filename_short_unique)
            fprintf('%s\n',filename_short_unique{i});
        end
        return
    end
    errorCount = 0;
    fn1 = strRemoveNumbers(filenames_short{1}, colIdx_uniqueNumbers);
    fprintf('extracted filename stub: %s\n',fn1)
    for i = 2 : length(filenames)
        fni = strRemoveNumbers(filenames_short{i}, colIdx_uniqueNumbers);
        if(~strcmp(fn1, fni))
            fprintf('"%s" not equal to \n"%s" (up to movie numbering, image series numbering and file extension)\n\n', filenames{1}, filenames{i});
            errorCount = errorCount + 1;
        end
    end
end

function [strWithoutNumbers, theNumbersAsStrings ] = strRemoveNumbers(str, matchIdx)
    %remove the number with occurrance index 'matchIdx'
    %
    %examples: 
    %  strRemoveNumbers(ab123cd4h99f, 1)     ==> abcd4h99f
    %  strRemoveNumbers(ab123cd4h99f, 2)     ==> ab123cdh99f
    %  strRemoveNumbers(ab123cd4h99f, 3)     ==> ab123cd4hf
    %  strRemoveNumbers(ab123cd4h99f, [1,3]) ==> abcd4hf
    %  strRemoveNumbers(ab123cd4h99f, 4)     ==> ab123cd4h99f
   
    
    [start_idx, end_idx, extents, matches, tokens, names, splits] = regexp(str, '\d+');
    if(nargin >= 2 && ~isempty(matchIdx))
        matchIdx = unique(min(matchIdx, length(start_idx)));
        start_idx = start_idx(matchIdx);
        end_idx   = end_idx(matchIdx);
        matches   = matches(matchIdx);
    end
    strWithoutNumbers = str;
    for i = length(start_idx) :  -1 : 1
        strWithoutNumbers(start_idx(i):end_idx(i)) = [];
    end
    theNumbersAsStrings = matches;
    
end