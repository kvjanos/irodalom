function copyWorkingFiles( workingDir, fnPattern, destination, searchSubDirectoy, searchRecursively, additionalPrefix )
%COPYWORKINGFILES copies the files specified by fnPattern (may be a regular
%expression) from the workingDir to the destination, prepends the movie tag
%to the filename if it not starts with the movie tag
%
%specify 'searchSubDirectoy' if you wish to search only in a sub directory of the working directory
%
%call:  copyWorkingFiles( workingDir, fnPattern, destination, searchSubDirectoy, searchRecursively )
%       copyWorkingFiles( workingDir, fnPattern, destination, [], searchRecursively )
%       copyWorkingFiles( workingDir, fnPattern, destination, searchSubDirectoy )
%       copyWorkingFiles( workingDir, fnPattern, destination )

if(nargin == 0)
    workingDir = [baseDir filesep 'yTUB-GFP14\cropped16bit_tif\smoothed\ImageSeq\workingDir\1'];
    destination = [myTempDir filesep 'test_copyWorkingFiles'];
    fnPattern = '.*\.avi';
    fnPattern = '.*\.mov';    
    fnPattern = '.*\..*';

    fnPattern = '.*\.txt'; %==> *.txt
    fnPattern = 'hungarianTracking_.*\.txt';
end

global param;
loadGlobalParams(workingDir);

%make sure that the pattern covers the entire filename
if(~strStartsWith(fnPattern, '\<'))
    fnPattern = [ '\<' fnPattern];
end
if(~strEndsWith(fnPattern, '\>'))
    fnPattern = [fnPattern '\>'];
end

if(nargin >= 4 && ~isempty(searchSubDirectoy))
    d = [workingDir filesep searchSubDirectoy];
else
    d = workingDir;
end
if(nargin >= 5 && ~searchRecursively)
    [Files,Bytes,fNameList] = dirr(d, fnPattern, 'name','isdir','0');
else
    [Files,Bytes,fNameList] = dirr(d, fnPattern, 'name');
end
if(nargin < 6)
    additionalPrefix = [];
end
for i = 1 : length(fNameList)
    fullFilename = fNameList{i};
    filename = getFilenameWithExtension(fullFilename);
    if(~isempty(additionalPrefix))
        filename = [additionalPrefix '_' filename];
    end
    if(~strStartsWith(filename,param.tag))
        newFullFilename = [destination filesep param.tag '_' filename];
    else
        newFullFilename = [destination filesep filename];
    end
    if(i == 1)
        ensureDirExists(destination);
    end
    copyfile(fullFilename,newFullFilename);
    fprintf('%s\n%s\n\n',fullFilename,newFullFilename);   
end

