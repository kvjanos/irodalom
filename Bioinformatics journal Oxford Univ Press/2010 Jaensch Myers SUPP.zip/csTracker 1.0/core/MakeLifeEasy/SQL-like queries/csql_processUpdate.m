function [filenameOut] = csql_processUpdate( workingDir, strUpdate, filenameOut )
%performs a sql-like update statement in the workingDir
%input: workingDir
%       strUpdate   - a single csql-update statement or a cell array of csql-update statements
%                     all update statements must refer to the same file
%       filenameOut - {optional} a filename with or without path 
%
%       example statement: UPDATE Copy_of_finalTrackingResults.txt SET cellname=7 WHERE cellID > 0
%
if(nargin == 0)
    workingDir = [baseDir filesep 'yTUB-GFP3_WT_8to16cellstage\workingDir\1'];
    strUpdate = {};
    strUpdate{end+1} = 'UPDATE Copy of finalTrackingResults.txt SET cellname=7 WHERE cellID > 0';
    strUpdate{end+1} = 'UPDATE Copy of finalTrackingResults.txt SET trID=-7 WHERE cellID > 4';
    strUpdate{end+1} = 'UPDATE Copy of finalTrackingResults.txt SET x=0 WHERE meanSigmaXY2D > 600';
end

if(ischar(strUpdate))
    listUpdateStatements = {strUpdate};
else
    listUpdateStatements = strUpdate;
end

s_update1 = parseUpdateStatement(listUpdateStatements{1});
filenameIn = addDirectoryToFilename(workingDir,s_update1.update);
if(nargin < 3 || isempty(filenameOut))
    filenameOut = filenameIn;
end
filenameOut = addDirectoryToFilename(workingDir,filenameOut);

loadGlobalParams(workingDir);
[T, header] = loadList(filenameIn);
[T, header] = ComputeDerivedParameters(T, header);
[header, validColIdx, wasAdded, T] = addHeaderEntry(header, 'valid', 1, T);

for i =  1 : length(listUpdateStatements)
    strUpdate = listUpdateStatements{i};
    s_update = parseUpdateStatement(strUpdate);
    if(~strcmpi(s_update.update, s_update1.update))
        error('all update statements in a batch must reference the same input file (%s <=> %s)',s_update.update,s_update1.update);
    end
    [goalColName, value]  = csql_parseSetClause(s_update.set);
    [ColnameOpValue, LogicConnector]  = csql_parseWhereClause(s_update.where);
    
    exprWhere = csql_makeWhereExpression(ColnameOpValue, LogicConnector);
    
    for j = 1 : length(goalColName)
        goalColIdx = headerIndex(header, goalColName{j}, 'none');
        if(goalColIdx <= 0)
            [header, goalColIdx, wa, T] = addHeaderEntry(header, goalColName{j}, 0, T);
        end
        exprUpdate = sprintf('T(%s,%d) = %s',exprWhere,goalColIdx,value{j});
        evalc(exprUpdate);
    end
end
fprintMatrix(filenameOut, T, header);
end
function [s_update]  = parseUpdateStatement(strUpdate)
[start_idx, end_idx, extents, matches, tokens, names, splits] = regexpi(strUpdate, '(update|set|where)');
s_update.update = strtrim(splits{2});
s_update.set    = strtrim(splits{3});
s_update.where  = strtrim(splits{4});
end
