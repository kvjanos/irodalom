function csql_queries()

fn = finalTrackingFile();
workingDir = [baseDir() filesep 'yTUB-GFP3_WT_8to16cellstage\workingDir\1'];
strUpdate = ['UPDATE ' fn ' SET valid = 0 WHERE cellID == 17'];
fn = csql_processUpdate( workingDir, strUpdate );
return

workingDir = [baseDir() filesep 'yTUB-GFP1_WT_8cellstage\workingDir\1'];
fn = 'tr_trSpltInc_noNoiseTr_extTr.txt';
fn = 'tr_trSpltInc_noNoiseTr_extTr_reassignMTA.txt';
fn = 'tr_trSpltInc_noNoiseTr_extTr_reassignMTA_joinTr.txt';
fn = 'tr_trSpltInc_noNoiseTr.txt';
select = ['SELECT t FROM ' fn ' WHERE trID == 90'];
R = csql_processSelect(workingDir, select)
return



workingDir = [baseDir() filesep 'SPD2-GFP2_WT_4to8cellstage\workingDir\1'];
fn = 'tracksComplete_GFit3D_Seg_bgLevel_pairs_trTree_cName_NEBD.txt';
select = ['SELECT UNIQUE cellID, NEBD FROM ' fn 'WHERE CellID > 0'];
R = csql_processSelect(workingDir, select)
return


end