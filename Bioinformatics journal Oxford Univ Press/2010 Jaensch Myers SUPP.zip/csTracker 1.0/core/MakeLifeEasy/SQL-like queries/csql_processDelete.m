function [filenameOut] = csql_processDelete( workingDir, strDelete, filenameOut )
%performs a sql-like delete statement in the workingDir
%input: workingDir
%       strDelete   - a single csql-delete statement or a cell array of csql-delete statements
%                     all delete statements must refer to the same file
%       filenameOut - {optional} a filename with or without path 
%
%       example statement: DELETE FROM Copy_of_finalTrackingResults.txt WHERE cellID < 0
%
if(nargin == 0)
    workingDir = [baseDir filesep 'SPD5-GFP1_WT_8to16cellstage\workingDir\1'];
    strDelete = {};
    strDelete{end+1} = 'DELETE FROM finalTrackingResults.txt WHERE t <= 44 & trID IN [76,77]';
    strDelete{end+1} = 'DELETE FROM finalTrackingResults.txt WHERE t IN [45,46] & trID IN [77]';
end

if(ischar(strDelete))
    listDeleteStatements = {strDelete};
else
    listDeleteStatements = strDelete;
end

s_delete1 = parseDeleteStatement(listDeleteStatements{1});
filenameIn = addDirectoryToFilename(workingDir,s_delete1.from);
if(nargin < 3 || isempty(filenameOut))
    filenameOut = filenameIn;
end
filenameOut = addDirectoryToFilename(workingDir,filenameOut);

loadGlobalParams(workingDir);
[T, header] = loadList(filenameIn);
[T, header] = ComputeDerivedParameters(T, header);

for i =  1 : length(listDeleteStatements)
    strDelete = listDeleteStatements{i};
    s_delete = parseDeleteStatement(strDelete);
    if(~strcmpi(s_delete.from, s_delete1.from))
        error('all delete statements in a batch must reference the same input file (%s <=> %s)',s_delete.from,s_delete1.from);
    end
%     [ColnameOpValue, LogicConnector]  = csql_parseWhereClause(s_delete.where);
%     exprWhere = csql_makeWhereExpression(ColnameOpValue, LogicConnector);
    exprWhere = csql_makeWhereExpressionParentheses(s_delete.where);
    exprDelete = sprintf('T(%s,:) = []',exprWhere);
    evalc(exprDelete);
end
fprintMatrix(filenameOut, T, header);
end
function [s_delete]  = parseDeleteStatement(strDelete)
[start_idx, end_idx, extents, matches, tokens, names, splits] = regexpi(strDelete, '(delete\sfrom|where)');
s_delete.from = strtrim(splits{2});
s_delete.where  = strtrim(splits{3});
end
