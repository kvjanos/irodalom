function [ColnameOpValue, LogicConnector]  = csql_parseWhereClause(strWhere)
[start_idx, end_idx, extents, matches, tokens, names, splits] = regexp(strWhere, '(\||&)');

LogicConnector = [matches {''}];
for i = 1 : length(splits)
    s = splits{i};
    [start_idx1, end_idx1, extents1, matches1, tokens1, names1, splits1] = regexpi(s, '(~=|==|<=|<|>=|>|\s(not\s)?in\s)');
    h.colName = strtrim(splits1{1});
    h.op      = strtrim(matches1{1});
    h.value   = strtrim(splits1{2});
    ColnameOpValue(i) = h;
end
end