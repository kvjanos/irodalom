function [ expr_whereClause ] = csql_makeWhereExpressionParentheses( str_whereClause )

if(nargin == 0)
    str_whereClause = '(y NOT IN [3.4,53.3] | p > 2) | ((x < 7) & ~( trID in [1,2,3] | a > 4))';
    str_whereClause = 'outsideEmbryoFlag==0 & ~(x >= 355 & x <= 375 & y >= 50 & y <= 70)';
end

[start_idx, end_idx, extents, matches, tokens, names, splits] = regexpi(str_whereClause, '\||&|\)|\(|~=|==|<=|<|>=|>|~|\s(not\s)?in\s');

i = 1;
matches_ix = 1;
expr_whereClause = '';
N = length(splits);
while(i <= N)
    si = strtrim(splits{i});
    while(matches_ix < i)
        expr_whereClause = [expr_whereClause ' ' matches{matches_ix}];
        matches_ix = matches_ix + 1;
        if(matches_ix >= N)
            break
        end
    end
    if(i >= N)
        break
    end
    
    if(isempty(si))
        expr_whereClause = [expr_whereClause ' ' matches{matches_ix}];
        i = i + 1;
        matches_ix = matches_ix+1;
    else
        colName = strtrim(splits{i});
        value   = strtrim(splits{i+1});
        op      = strtrim(matches{matches_ix});
        matches_ix = matches_ix + 1;
        
        if(strcmpi(op,'in'))
            expr = sprintf(' ismember(T(:,headerIndex(header,''%s'')), %s)',colName,value);
        elseif(strcmpi(op,'not in'))
            expr = sprintf(' ~ismember(T(:,headerIndex(header,''%s'')), %s)',colName,value);
        else
            expr = sprintf(' T(:,headerIndex(header,''%s'')) %s %s',colName,op, value);
        end
        expr_whereClause = [expr_whereClause expr];
        i = i + 2;
    end
    
end

end

