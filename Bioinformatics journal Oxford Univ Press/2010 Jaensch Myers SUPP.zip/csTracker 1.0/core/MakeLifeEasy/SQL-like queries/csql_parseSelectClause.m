function [columnNames]  = csql_parseSelectClause(strSelectClause)
    [start_idx, end_idx, extents, matches, tokens, names, columnNames] = regexp(strSelectClause, ',');
    for i = 1 : length(columnNames)
       columnNames{i} = strtrim(columnNames{i});
    end
end