function expr = csql_makeWhereExpression(ColnameOpValue, LogicConnector)
expr = '';
for i = 1:length(ColnameOpValue)
    op = ColnameOpValue(i).op;
    if(strcmpi(op,'in'))
        expr = [expr sprintf(' ismember(T(:,headerIndex(header,''%s'')), %s)',ColnameOpValue(i).colName,ColnameOpValue(i).value),LogicConnector{i}];
    elseif(strcmpi(op,'not in'))
        expr = [expr sprintf(' ~ismember(T(:,headerIndex(header,''%s'')), %s)',ColnameOpValue(i).colName,ColnameOpValue(i).value),LogicConnector{i}];
    else
        expr = [expr sprintf(' T(:,headerIndex(header,''%s'')) %s %s %s',ColnameOpValue(i).colName,op,ColnameOpValue(i).value),LogicConnector{i}];
    end
end
end