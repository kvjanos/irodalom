function [goalColName, value]  = csql_parseSetClause(strSet)
if(nargin == 0)
   strSet = 'valid = 1, cellName = 8, ABLineage = 1';
   strSet = 'valid = 1';
end

split = strsplit(strSet, ',' );
for i = 1 : length(split)
    s = strsplit(split{i}, '=' );
    goalColName{i} = strtrim(s{1});
    value{i}       = strtrim(s{2});
end

end