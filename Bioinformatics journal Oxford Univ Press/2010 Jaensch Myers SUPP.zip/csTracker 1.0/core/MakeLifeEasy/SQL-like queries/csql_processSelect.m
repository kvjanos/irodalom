function [R, header] = csql_processSelect( workingDir, strSelect, printResultToScreen, filenameOut )

if(nargin < 3)
    printResultToScreen = 0;
end
if(nargin == 0)
    workingDir = [baseDir filesep 'yTUB-GFP3_WT_8to16cellstage\workingDir\1'];
    strSelect  = 'SELECT UNIQUE CellID, NEBD FROM finalTrackingResults.txt WHERE cellID > 0';
    printResultToScreen = 1;
else
    if(nargin < 2)
        error('workingDir and select-statement required as arguments');
    end
end

if(nargin < 4)
    filenameOut = [];
end



s_select = parseSelectStatement(strSelect);

filenameIn = s_select.from;
filenameIn = addDirectoryToFilename(workingDir,filenameIn);

if(strcmpi(filenameOut, 'fnOut=fnIn'))
    filenameOut = filenameIn;
end

loadGlobalParams(workingDir);
[T, header] = loadList(filenameIn);
[T, header] = ComputeDerivedParameters(T, header);
[ T, header ] = ComputeDistanceToNearestCS( T, header, false(size(T,1), 1), 2 );

% [ColnameOpValue, LogicConnector]  = csql_parseWhereClause(s_select.where);
% exprWhere = csql_makeWhereExpression(ColnameOpValue, LogicConnector);
exprWhere = csql_makeWhereExpressionParentheses(s_select.where);

selectColNames = csql_parseSelectClause(s_select.select);

if(strcmpi(selectColNames{1},'*'))
    exprSelect = sprintf('R = T(%s,:)',exprWhere);
else
    colIdx = headerIndex(header, selectColNames);
    exprSelect = sprintf('R = T(%s,[%s])',exprWhere,sprintVector(colIdx,',','%d'));
end
evalc(exprSelect);
if(s_select.doUnique)
    R = unique(R, 'rows');
end
if(~strcmpi(selectColNames{1},'*'))
    header = strList2SeparatedString(selectColNames, sprintf('\t'));
end

if(printResultToScreen)
    for i = 1 : length(selectColNames)
    fprintf('%s\t',selectColNames{i})
    end
    fprintf('\n')
end
if(~isempty(filenameOut))
    fprintMatrix(filenameOut, R, header);
end
end

function [s_select]  = parseSelectStatement(strSelect)
    [start_idx, end_idx, extents, matches, tokens, names, splits] = regexpi(strSelect, '((select\s(unique\s)?)|from\s|where\s)');
    s_select.select = strtrim(splits{2});
    s_select.from   = strtrim(splits{3});
    s_select.where  = strtrim(splits{4});
    
    selectKeyword = matches{1};
    [start_idx, end_idx, extents, matches, tokens, names, splits] = regexpi(selectKeyword, 'unique');
    s_select.doUnique = ~isempty(matches);
end