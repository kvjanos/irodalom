function copyLogFilesToWebfolder(movieTag, subdirOnWebfolder, varargin )

catchError = getVarargin(varargin, 'catchError', 1);

fn_success  = [myTempDir filesep 'success_processing.txt'];
fn_error    = [myTempDir filesep 'error_' mfilename '.txt'];

try
    PrintToFile(sprintf('%s: %s',datestr(clock),movieTag),fn_success, 'a',1);
    webDir = [idiskDir() filesep subdirOnWebfolder];
    ensureEmptyDirExists(webDir);
    copyfile([myTempDir filesep '*.txt'], webDir);
    copyfile([myTempDir filesep '*.log'], webDir);
    copyfile([myTempDir filesep '*.ps'], webDir);
catch ME
    if(catchError)
        printToFile(sprintf('%s: %s',datestr(clock), movieTag), fn_error, 'a', 1);
        printDebugStack(ME, 0, fn_error);
    else
        rethrow(ME);
    end
end
