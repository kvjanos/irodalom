function [T, header, filenameIn, filenameOut, dirDebug, skipIfFileoutExists] = processInput(argList, opName, dirDebugName)
    %input: argList - the input arguments from the calling processing function
    %                                                      
    %       opName       - a name for the processing step, will only be used if workingDir/filenameIn is provided
    %       dirDebugName - name of the debugging folder (not the entire path!) 
    %                      use *name to create empty debug dir with name 'name'
    % call:
    %       processInput(fullfilenameIn, opName, dirDebugName)
    %       processInput(workingDir, filenameIn, opName, dirDebugName)
    %       processInput(T, header, [], dirDebugName)
    %
    % T and header will be empty if the last element in argList is '1' (skipProcessing) and filenameOut exists
    % use 'out=in' in the argList to use the input filename as output filename
    %
    % see also: initProcessingStep
    %
    global param;
    skipIfFileoutExists = 0;

    fnOutEqualsFnIn = 0;
    for i = 1 : length(argList)
        arg = argList{i};
        if(ischar(arg) && strcmpi(arg,'out=in'))
            argList(i) = [];
            fnOutEqualsFnIn = 1;
            break;        
        end
    end
    
    if(ischar(argList{1}))
        if(length(argList) == 1 || ~ischar(argList{2}))
            workingDir = fileparts(argList{1});
            filenameIn = getFilenameWithExtension(argList{1});
        elseif(length(argList) >= 2 && ischar(argList{1}) && ischar(argList{2}))
            workingDir = argList{1};
            filenameIn = argList{2};
        end
        if(nargin < 2)
            opName = [];
        end
        if(nargin < 3)
            dirDebugName = [];
        end
        [filenameIn, filenameOut, dirDebug ] = initProcessingStep( workingDir, filenameIn, opName, dirDebugName );
         if(~isempty(filenameOut) && fnOutEqualsFnIn)
            filenameOut = filenameIn;
        end
        if(islogical(argList{end}) || (isnumeric(argList{end}) && argList{end} == 1))
            skipIfFileoutExists = 1;
            if(exist(filenameOut, 'file'))
                T           = [];
                header      = [];
            else
                [T, header] = loadList(filenameIn);
            end
        else
            [T, header] = loadList(filenameIn);
        end
    else
        T            = argList{1};
        header       = argList{2};
        if(nargin >= 3)
            dirDebug = MakeDebuggingFolder(dirDebugName);
        end
        filenameOut = [];
        filenameIn  = [];
    end
    
    if(~isempty(filenameOut) && fnOutEqualsFnIn)
        filenameOut = filenameIn;
    end
end