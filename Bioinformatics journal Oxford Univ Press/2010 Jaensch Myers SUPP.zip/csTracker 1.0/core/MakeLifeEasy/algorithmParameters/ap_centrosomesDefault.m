function [ alparam, bioparam ] = ap_centrosomesDefault( )
%see also: loadGlobalParams

%% object detection by normalized cross-correlation
alparam.ObjectDetection.sigma               = [330 660 1300 2000];  %Mexican hat
alparam.ObjectDetection.scale               = [ 1  .5    .5  .25];  %Mexican hat
alparam.ObjectDetection.normxcrossThreshold = 0.70;

%% Gaussian fitting
%the center position of a spot may not be displaced by Gaussian fitting by more than these
%values in x- and y-direction respectively
alparam.myGauss2DFit.maxPositionDisplacement = [10 10]; %pixels
alparam.myGauss2DFit.minSigma = 80;   %nm
alparam.myGauss2DFit.maxSigma = 3600; %nm

%% tracking
alparam.radiusHysteresis = [300 350]; %nm   note: in the tracking algorithm we do not multiply the standard deviation of the Gaussian fit with the factor 2 but use the standard deviation directly as radius estimate

%% bio priors
bioparam.r1                 = 1600.0; %nanometers  %a radius large enough to capture most centrosomes, non-critical
bioparam.r2                 = 2400.0; %nanometers  %a radius large enough to capture virtually all centrosomes, non-critical
bioparam.rmax               = 3600.0; %nanometers  %maximum possible centrosome radius
bioparam.minCellDevDuration = 10; %minutes
bioparam.maxCellDevDuration = 45; %minutes
bioparam.radiusOfNucleus    = 4000.0; %nanometers
bioparam.embryoDimension    = [50 30 20]; %microns