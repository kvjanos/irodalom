function [  ] = cs_moveFilesBackToBatchDirectory( movieCollectionDir, deleteMovieHomeDir )
% reads the file 'firstFilenames.txt' in the movie collection directory and
% copies back the images from their current location to the movie
% collection directory
%
% see also: run_all_batch

if(nargin == 0)
    movieCollectionDir = [baseDir filesep '_new set\1'];
    deleteMovieHomeDir = 1;
end

fn = [movieCollectionDir filesep 'firstFilenames.txt'];

% open file
fid = fopen(fn,'rt');     % 'rt' means "read text"
if (fid < 0)
    error('could not open file %s',fn);
end;

%% read in the list of first filenames
firstFilenames = {};
%read line
tline = fgetl(fid);
while ischar(tline)
    if(length(tline) > 1)
        firstFilenames{end+1} = tline;
    end
    tline = fgetl(fid);
end
% close the file
fclose(fid);

%% determine for each first filename the other tif-files in the sequence + the txt-file
for i = 1 : length(firstFilenames)
    firstFilename = firstFilenames{i};
    listOfFiles = getAllFilesBelongingToFirstFile(firstFilename);
    if(isempty(listOfFiles))
        error('no files found for %s',firstFilename);
    end
    for j = 1 : length(listOfFiles)
        fn = listOfFiles{j}
        movefile_fast(fn, movieCollectionDir);
    end
    if(deleteMovieHomeDir)
        deleteDirectoryIfExists(fileparts(firstFilename));
    end
end


end

function listOfFiles = getAllFilesBelongingToFirstFile(firstFilename)
    regEx_imageSeriesNumbering = '_t[0-9]{4}'; %format of the numbering for multi-file image stacks

    d = fileparts(firstFilename);
    %strip off file extension and image series number of each filename
    [start_idx, end_idx, extents, matches, tokens, names, splits] = regexp(getFilenameWithoutExtension(firstFilename), ['(' regEx_imageSeriesNumbering ')$']);
    stub = splits{1};
    
    %pattern that includes all .tif files of the image sequence + the txt file
    pattern = ['^(' stub '(' regEx_imageSeriesNumbering ')?.(tif|txt))$'];
    
    listOfFiles = {};
    D = dir([d filesep '*.*']);
    for i = 1 : length(D)
        start_idx = regexp(D(i).name, pattern, 'once');
        if(~isempty(start_idx))
            listOfFiles{end+1} = [d filesep D(i).name];
        end
    end
end

