function [ T, header ] = ComputeSpindleProperties(T, header)
%ComputeSpindleProperties computes the 3D distance between pairs of centrosomes,
%the position of the spindle as the mean position of a pair of cs, the angle and the angle velocity of the spindle 
global param;

cellIDColIdx    = headerIndex(header, 'cellID');
trIDColIdx      = headerIndex(header, 'trID');
meanZ3DColIdx   = headerIndex(header, 'meanZ3D','none');
sideColIdx      = headerIndex(header, 'side','none');
[header, spindleLenMidZColIdx, wa, T]       = addHeaderEntry(header, 'spindleLenMidZ',0,T);
[header, spindleLen2DColIdx, wa, T]         = addHeaderEntry(header, 'spindleLen2D',0,T);
[header, spindleAngleColIdx, wa, T]         = addHeaderEntry(header, 'spindleAngle',0,T);
[header, spindleAngle2DColIdx, wa, T]       = addHeaderEntry(header, 'spindleAngle2D',0,T);
[header, spindlexColIdx, wa, T]             = addHeaderEntry(header, 'spindlex',0,T);
[header, spindleyColIdx, wa, T]             = addHeaderEntry(header, 'spindley',0,T);
[header, spindlezColIdx, wa, T]             = addHeaderEntry(header, 'spindlez',0,T);
[header, spindleVelo3DColIdx, wa, T]        = addHeaderEntry(header, 'spindleVelo3D',0,T);
[header, spindleLengthGrowthColIdx, wa, T]  = addHeaderEntry(header, 'spindleLengthGrowth',0,T);
[header, spindleAngle2DVeloColIdx, wa, T]   = addHeaderEntry(header, 'spindleAngle2DVelo',0,T);
[header, spindleAngle3DVeloColIdx, wa, T]   = addHeaderEntry(header, 'spindleAngle3DVelo',0,T);

if(meanZ3DColIdx > 0)
    [header, spindleLenGaussZColIdx,wa,T] = addHeaderEntry(header, 'spindleLenGaussZ',0,T);
end

%% compute spindle properties for each cell

unique_cellIDs = unique(T(:,cellIDColIdx));
for cellID = unique_cellIDs'
    if(cellID <= 0)
        continue;
    end
    R = T(T(:,cellIDColIdx)==cellID,:);
    unique_trIDs = unique(R(:,trIDColIdx));
    if(length(unique_trIDs)~=2)
        continue;
    end
    track1 = R(R(:,trIDColIdx) == unique_trIDs(1),:);
    track2 = R(R(:,trIDColIdx) == unique_trIDs(2),:);
    
    %make sure that track1 is always 'posterior' and track2 'anterior'
    if(sideColIdx > 0)
        if(track1(1,sideColIdx) == 2)
            h = track1;
            track1 = track2;
            track2 = h;
        end
    end
    
    
    time = [];
    lenGaussZ   = []; %spindle length 3D
    lenMidZ     = []; %spindle length 3D
    len2D       = []; %spindle length 2D
    pos         = []; %spindle position
    direction   = []; %a vector, cs1-cs2
    angle_z     = []; %angle of this vector to the x/y-plane
    angle2D     = []; %angle of this 2D-vector to the x-axis
    for i = 1 : size(track1,1)
        t = track1(i,4);
        cs2 = track2(track2(:,4) == t,:);
        if(isempty(cs2))
            continue;
        end

        cs1 = track1(i,:);               
       
        dist3D_midZ     = RealDistance(cs1(1:3),cs2(1:3));
        len2D(end+1)    = RealDistance(cs1(1:2),cs2(1:2));
        if(meanZ3DColIdx>0)
            dist3D_gaussZ   = RealDistance(cs1([1,2,meanZ3DColIdx]),cs2([1,2,meanZ3DColIdx]));
            lenGaussZ(end+1)    = dist3D_gaussZ;
        end
        pos(end+1,:)    = ((cs1(1:3)+cs2(1:3))/2).*param.resolutionVector;
        direction(end+1,:) = (cs1(1:3)-cs2(1:3)).*param.resolutionVector;
        time(end+1)     = t;
        lenMidZ(end+1)  = dist3D_midZ;
        
        %compute angle to x/y-plane
        a = direction(end,:);
        b = [0 0 1]; %normal vector to x/y-plane
        angle_z(end+1) = asind(abs((a*b'))/(norm(a)*norm(b))); %http://sites.inka.de/picasso/Schnurr/Schnittwinkel.html#Winkel(g,h)
        
         %compute angle to x-axis ignoring the z-coordinate
         %a spindle horizontal to the image x-axis and anterior left,
         %posterior right has angle = 0
        a = direction(end,1:2);
        angle2D(end+1) = atan2(a(2),a(1)) * 180 / pi;
    end
    posDiff = diff([pos(1,:);pos]);
    lenDiff = abs(diff([lenMidZ(1);lenMidZ(:)]));
    cos_alpha3D = ones(size(posDiff,1),1);
    cos_alpha2D = cos_alpha3D;
    for i = 2 : length(cos_alpha3D)
        %3D
        a = direction(i-1,:);
        b = direction(i  ,:);
        cos_alpha3D(i) = (a*b')/(norm(a)*norm(b));
        
        %2D
        a = direction(i-1,1:2);
        b = direction(i  ,1:2);
        cos_alpha2D(i) = (a*b')/(norm(a)*norm(b));
    end
    
    for i = 1 : length(time)
        rowIndex = T(:,4) == time(i) & T(:,cellIDColIdx) == cellID;

        %spindle length
        T(rowIndex,spindleLenMidZColIdx)        = lenMidZ(i)/1000;
        T(rowIndex,spindleLen2DColIdx)          = len2D(i)/1000;
        if(meanZ3DColIdx>0)
            T(rowIndex,spindleLenGaussZColIdx)  = lenGaussZ(i)/1000;
        end

        %spindle length change
        T(rowIndex,spindleLengthGrowthColIdx)    = lenDiff(i,1) / param.frameInterval;
        
        %spindle position
        T(rowIndex,spindlexColIdx)   = pos(i,1);
        T(rowIndex,spindleyColIdx)   = pos(i,2);
        T(rowIndex,spindlezColIdx)   = pos(i,3);
 
        %spindle velocity
        T(rowIndex,spindleVelo3DColIdx) = norm(posDiff(i,:)) / param.frameInterval;
        
        %spindle angle
        T(rowIndex,spindleAngleColIdx) = angle_z(i);
        
         %spindle angle in 2D
        T(rowIndex,spindleAngle2DColIdx) = angle2D(i);
                
        %spindle angle velocity
        angle2DVelo = acosd(cos_alpha2D(i)) / param.frameInterval;
        angle3DVelo = acosd(cos_alpha3D(i)) / param.frameInterval;
        T(rowIndex,spindleAngle2DVeloColIdx) = angle2DVelo;
        T(rowIndex,spindleAngle3DVeloColIdx) = angle3DVelo;
    end
    if(getDebugLevel>=2)
        figure, plot(time, lenMidZ, 'r', 'DisplayName','length via mid-z');
        hold on
        if(meanZ3DColIdx>0)
            plot(time, lenGaussZ,'k','DisplayName','length via Gaussian Fit meanZ3D');
        end
        legend('show');
        xlabel('frame #');
        ylabel('spindle length [nm]');
    end
end
