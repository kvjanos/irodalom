function [ index ] = FindCutpoint( X,Y, Dist2IntensityOrg )
global showCharts;

thisShowCharts = showCharts;
if(~exist('Dist2IntensityOrg','var'))
    thisShowCharts = false;
end

if(thisShowCharts)
    scatter(X,Y, 'ko');
    hold on;
    scatter(Dist2IntensityOrg(:,1),Dist2IntensityOrg(:,2),'gd','SizeData',3^2 )
    plot([X(1);X(end)],[Y(1);Y(end)])

    [r,p] = corrcoef(X, Y);
    title(sprintf( 'corrcoef = %.4f (p-value = %.4f)',r(2,1),p(2,1)));
end

 q1 = [X(1),Y(1)];
 q2 = [X(end),Y(end)];

 maxD = -inf;
 
 for i = 1 : length(X)
    p = [X(i) Y(i)];
    d = Point2LineDistance(q1,q2,p);

    if(d > maxD)
        maxD = d;
        maxDPos = p;
        index = i;
    end
 end
 
if(thisShowCharts)
    hold on;
    scatter(maxDPos(1),maxDPos(2),'rx','SizeData',15^2, 'LineWidth', 2);
    hold off;
end
