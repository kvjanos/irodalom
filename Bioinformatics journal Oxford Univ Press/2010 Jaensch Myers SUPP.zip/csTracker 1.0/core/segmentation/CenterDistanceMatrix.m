function [ M ] = CenterDistanceMatrix( siz, C, distanceFunction )
% input: siz - size of the desired matrix
%        C   - center point from which the distance to each point will be
%              computed, C = (y,x)
%        distanceFunction - 'Manhattan', 'Euclidean'
%

M = zeros(siz, 'double');

if(nargin < 2)
    C = ceil(siz / 2);
end

if(nargin <= 2 || strcmpi(distanceFunction,'Manhattan'))
    for i = 1:siz(1)
        for j = 1:siz(2)
             M(i,j) = abs(i-C(1)) + abs(j-C(2));
        end
    end
elseif(strcmpi(distanceFunction,'Euclidean'))
    for i = 1:siz(1)
        for j = 1:siz(2)
             M(i,j) = sqrt((i-C(1))^2 + (j-C(2))^2);
        end
    end
end
