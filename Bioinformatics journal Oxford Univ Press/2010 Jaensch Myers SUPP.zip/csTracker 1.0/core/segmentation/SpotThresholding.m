function [ thrLevel, cutpointRadius, maxIntensityPoint, thrLevelRange, binaryImage ] = SpotThresholding( img, maxIntensitySearchRange, maxCorrCoef, imageCroppingStepsize, minImageSize, maxWeightLeftRight )

global showCharts;
if(~exist('showCharts','var'))
    showCharts = 0;
end

if(nargin == 1)
    %range around center of image in which the maximum intensity pixel will be
    %searched for
    maxIntensitySearchRange = [5,5];
    
    %correlation coefficient of dist vs. intersity data must be less than maxCorrCoef
    maxCorrCoef = -0.7;
    
    %number of pixels by which the image will be cropped at the margins
    imageCroppingStepsize = 5;
    
    %image cropping will be stopped if the image is smaller than minImageSize
    minImageSize = [17 17];
    
    %let maxL be the maximum intensity in the left part of the cut point
    %let maxR be the maximum intensity in the right part of the cut point
    %if maxWeightLeftRight*maxL < maxR, then the cut point will be
    %searched again starting at the position of maxR
    maxWeightLeftRight = 6/7;
end

warningOn = 0;
imgOrg = img;
maxIntensityPoint = 0;
loopCnt = 1;
while 1
    imgCen = ceil(size(img)/2);
    [cenI, cenJ] = index2DOfMax(img,CenteredRoi( imgCen, maxIntensitySearchRange ));
    maxIntPoint = [cenI, cenJ];
    cenDist = CenterDistanceMatrix(size(img), maxIntPoint );
    
    if(maxIntensityPoint == 0)
        maxIntensityPoint = maxIntPoint;
    end
    
    Dist2Intensity = AggregateXGroups(cenDist(:),img(:),@max);
    
    if(showCharts)
        hold on
        subplot(2,3,4:6), scatter(Dist2Intensity(:,1), Dist2Intensity(:,2), scatterStyles(loopCnt));
    end
    
    
    r = corrcoef(Dist2Intensity);
    if(r(2,1) < maxCorrCoef)
        break;
    end
    
    img = imcropCentered(img,imgCen(1),imgCen(2), floor(size(img,1)/2)-imageCroppingStepsize, floor(size(img,2)/2)-imageCroppingStepsize);
    if(imageCroppingStepsize <= 0 || size(img, 1) <= minImageSize(1) || size(img, 2) <= minImageSize(2))
        if(warningOn)
            warning('distance vs. intensity diagram does not have the right shape for spot segmentation\n');
        end
        break;
    end
    loopCnt = loopCnt + 1;
end

cutpointIdx = FindCutpoint( Dist2Intensity(:,1), Dist2Intensity(:,2));

%check whether max of right part is greater than max of
%left part and find the cut point in the modified data
maxLeftPart =  max(Dist2Intensity(1:cutpointIdx-1,2));
[maxRightPart, maxRightPartIdx ]= max(Dist2Intensity(cutpointIdx:end,2));
if(maxLeftPart*maxWeightLeftRight < maxRightPart)
    if(warningOn)
        warning('the cut point will be searched for in modified distance vs. intensity diagram\n');
    end
    Dist2Intensity(1:maxRightPartIdx+cutpointIdx-1,2) = maxRightPart;
    cutpointIdx = FindCutpoint( Dist2Intensity(:,1), Dist2Intensity(:,2));
end

if(cutpointIdx == 1)
    if(warningOn)
        warning('the cut point has been found at distance = 0, the image is unlikely to represent a spot, the theshold will be set to the median of the pixel intensities\n');
    end
    cutpointRadius  = ceil (norm( size(imgOrg) ) / 2 ); %set radius to half the diagonal of the image
    thrLevel = median(imgOrg(:));
    thrLevelRange = thrLevel;
else
    shift = -1;
    for ii = -1:1
        if(Dist2Intensity(cutpointIdx+ii,2) < max(Dist2Intensity(cutpointIdx+ii+1:end,2)))
            break;
        end
        shift = ii;
    end
    cutpointRadius  = Dist2Intensity(cutpointIdx+shift,1);
    thrLevel       = Dist2Intensity(cutpointIdx+shift,2); %threshold at level of cut point
    thrLevelRange  = Dist2Intensity(cutpointIdx-1:cutpointIdx+1,2); %the range of threshold between -1 and +1 from the cutpoint
    
end

if(nargout > 4)
    binaryImage = double(imgOrg > thrLevel);
end

if(showCharts)
    scatter(Dist2Intensity(cutpointIdx,1),Dist2Intensity(cutpointIdx,2),'rx','SizeData',15^2, 'LineWidth', 2);
    plot(Dist2Intensity([1,end],1), [thrLevel;thrLevel], ':r');
end