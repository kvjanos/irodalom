function cellIDs_initialCellstage = CellIDsOfInitialCellstage(T, header)
%find the IDs of the cells in the initial cell stage of the movie
%
%example: if the movie starts at the 2-cell stage, the ids of the cells in
%         the 2-cell stage (i.e. AB and P1) will be returned


cellIDColIdx      = headerIndex(header, 'cellID');
parentTrIDColIdx  = headerIndex(header, 'parentTrID');

%all centrosomes with valid cell-ID and no parent centrosome
idx_cellIDs_initialCellstage = T(:,cellIDColIdx)>0 & T(:,parentTrIDColIdx)==0;

cellIDs_noParent = unique(T(idx_cellIDs_initialCellstage, cellIDColIdx));

if(~isempty(cellIDs_noParent))
    cellIDgroups_overlappingInTime = groupCellIDsByOverlap(T, header, cellIDs_noParent);
    
    %we assume that the initial centrosomes all overlap in time
    %==> only consider the first group of centrosomes having
    %    no parent as initial centrosomes
    cellIDs_initialCellstage = cellIDgroups_overlappingInTime{1};
else
    cellIDs_initialCellstage = [];
end
end

function cellIDgroups = groupCellIDsByOverlap(T, header, cellIDs)
% groups the given cellIDs such that centrosomes overlaps in time in each
% group of cells
%
% example: Consider paired tracks A...D on the following time plot:
%          Cells 1 and 2 (tracks A(a), A(p), B(a), B(p)) overlap in time,
%          then there is a break between the last timepoint of this group
%          (timepoint x) and the first timepoint of the following group
%          (timepoint y, cells 3 and 4).
%          Thus:
%          groupCellIDsByOverlap(T, header, [1,2,3,4]) yields
%          cellIDgroups = {[1,2],[3,4]}
%
% =================== time >>> =x=======y========================================
% -------A(a):cellID=1-------
%     -------A(p):cellID=1-------
%         ----B(a):cellID=2-----
%       -----B(p):cellID=2------
%                                       -------C(a):cellID=3--------
%                                       ----------C(p):cellID=3----------
%                                                        ---D(p):cellID=4--
%                                                        ---D(a):cellID=4--
%

cellIDColIdx = headerIndex(header, 'cellID');
firstFrameCellID    = AggregateXGroups(T(:,cellIDColIdx),T(:,4), @min); %1st col: cellID, 2nd col: frame# (t)
lastFrameCellID     = AggregateXGroups(T(:,cellIDColIdx),T(:,4), @max); %1st col: cellID, 2nd col: frame# (t)

firstFrameCellID = sortrows(firstFrameCellID,1); %sort by cellID
lastFrameCellID  = sortrows(lastFrameCellID,1);  %sort by cellID

cellID_t1_tN = [firstFrameCellID lastFrameCellID(:,2)];
cellID_t1_tN  = sortrows(cellID_t1_tN,2);  %sort by t1

cellID_t1_tN = cellID_t1_tN(ismember(cellID_t1_tN(:,1), cellIDs),:);

grpID = 1;
cellIDgroups{grpID} = cellID_t1_tN(1,1);
for i = 2 : size(cellID_t1_tN, 1)
    if(cellID_t1_tN(i,2) <= cellID_t1_tN(i-1,3))
        cellIDgroups{grpID} = [cellIDgroups{grpID} cellID_t1_tN(i,1)];
    else
        grpID = grpID + 1;
        cellIDgroups{grpID} = cellID_t1_tN(i,1);
    end
end


end