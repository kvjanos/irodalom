function [ filenameOut ] = AssignPosteriorAnterior(workingDir, filenameIn, skipIfFileoutExists)
%Each centrosome pair is assigned anterior and posterior by considering the
%distance to the posterior pole in the last frame where both centrosomes have been detected.
%The centrosome with the closer distance is assigned posterior, the other centrosome anterior.
%
% see also: AssignCellNames, FindPosteriorPole
fprintf('%s\n',mfilename);

if(nargin == 0)
    workingDir = [baseDir filesep 'RSA1-GFP2_WT_4to8cellstage\workingDir\1'];
    filenameIn = 'tracksComplete_GFit3D_Seg_bgLevel_pairs_trTree.txt';
    setDebugLevel(1)
end

global param;
[filenameIn, filenameOut, dirDebug ] = initProcessingStep( workingDir, filenameIn, 'side',mfilename);
if(exist('skipIfFileoutExists','var') && skipIfFileoutExists && exist(filenameOut, 'file'))
    return
end

[T, header] = loadList(filenameIn);
T = sortrows(T, 4); %sort by time

[trIDColIdx]   = headerIndex(header, 'trID');
[cellIDColIdx] = headerIndex(header, 'cellID');
[header, sideColIdx, columnHasBeenAdded, T ] = addHeaderEntry( header, 'side', -1, T );
[header, cellNameColIdx, columnHasBeenAdded, T ] = addHeaderEntry( header, 'cellName', -1, T );

trID2lastFrame   = AggregateXGroups(T(:,trIDColIdx),T(:,4), @max); %1st col: trID, 2nd col: frame# (t)

if(isfield(param, 'posterior'))
    p_posterior = param.posterior;
else
    p_posterior = FindPosteriorPole(fileparts(filenameIn), filenameIn);
end

if(isempty(p_posterior))
    error('error:posteriorPositionNotAvailable','position of the posterior pole is not available. cannot determine centrosome identities');
end
%% assign sidenames (posterior / anterior) to centrosomes
unique_cellID = unique(T(:,cellIDColIdx));
unique_cellID = unique_cellID(unique_cellID>0);
for cellID = unique_cellID'
    R = T(T(:,cellIDColIdx) == cellID,:);
    trIDs = unique(R(:,trIDColIdx));
    if(length(trIDs) == 2)
        t = min(trID2lastFrame(ismember(trID2lastFrame(:,1),trIDs),2));
        p1 = R(R(:,4) == t & R(:,trIDColIdx) == trIDs(1),1:2);
        p2 = R(R(:,4) == t & R(:,trIDColIdx) == trIDs(2),1:2);
        if(isempty(p1) || isempty(p2))
           error('no x-position found for trIDs %d and %d at t = %d',trIDs(1),trIDs(2),t);
        end

        if(norm(p1-p_posterior) < norm(p2-p_posterior))
            T(T(:,trIDColIdx) == trIDs(1),sideColIdx) = 1; %1 = posterior
            T(T(:,trIDColIdx) == trIDs(2),sideColIdx) = 2; %2 = anterior
            if(getDebugLevel >= 2)
                fprintf('track ID %d ==> posterior, track ID %d ==> anterior\n',trIDs(1),trIDs(2));
            end
        else
            T(T(:,trIDColIdx) == trIDs(2),sideColIdx) = 1; %1 = posterior
            T(T(:,trIDColIdx) == trIDs(1),sideColIdx) = 2; %2 = anterior
            if(getDebugLevel >= 2)
                fprintf('track ID %d ==> posterior, track ID %d ==> anterior\n',trIDs(2),trIDs(1));
            end
        end
    elseif(length(trIDs) == 1)
        T(T(:,trIDColIdx) == trIDs(1),sideColIdx) = 1; %1 = posterior
    else
        warning('more than two centrosomes in a pair (same cellID)');
    end
end

fprintMatrix(filenameOut, T, header);
if(nargin == 0)
    showTrackingMovie(filenameOut,0)
end

end

