function [ fnStacksOrg, fnStacksNew ] = SplitStackByColorChannels( fnMetafile, regEx_imageSeriesNumbering )

% reads the meta data file and splits all tif-files that belong to the meta
% data file so that each color channel is a single image stack
% assumes the order color1_img1 color2_img1 ... colorn_img1, color1_img2 color2_img2 ... colorn_img2
%
% output: fnStacksOrg - list of input files belonging to the given meta file
%         fnStacksNew - a cell array containing the following structure for
%                       each extracted color channel:
%                       + metafile
%                       + wavelength
%                       + listOfImageFiles

% see also: GetAllTiffFilesFromMetadatafile, makeSubstack, splitTimelapseStack

if(nargin < 2)
    regEx_imageSeriesNumbering = '_t[0-9]{4}';
end

if(nargin == 0)
    fnMetafile = 'V:\microscopy\_beads\CY5\tmp\GFP_CY5_test2.txt';
end

metadata      = readSpinningDiskMetaFile( fnMetafile );
wavelengthCnt = length(metadata.wavelength);

if(wavelengthCnt > 1)
    fnStacksOrg = GetAllTiffFilesFromMetadatafile( fnMetafile, regEx_imageSeriesNumbering );
    
    for i = 1 : length(fnStacksOrg)
        fn = fnStacksOrg{i};
        numberingExtension = GetSeriesNumberingExtension( fn, regEx_imageSeriesNumbering );
        iminfo   = imfinfo(fn);
        imageCnt = length(iminfo);
        
        imgIdxList = {};
        extension  = {};
        for c = 1 : wavelengthCnt
            imgIdxList{c} = c:wavelengthCnt:imageCnt;
            
            extension{c}  = sprintf('_lambda%d%s',metadata.wavelength(c),numberingExtension);
            if(i == 1)
                fnStacksNew{c}.listOfImageFiles = {};
            end
        end
        fnSubstacks = makeSubstack( fn, getPathAndFilenameWithoutExtension(fnMetafile), imgIdxList, extension);
        for c = 1 : wavelengthCnt
            fnStacksNew{c}.listOfImageFiles{end+1} = fnSubstacks{c};
        end
    end
    for c = 1 : wavelengthCnt
        fnMetafile_thisWavelength = [getPathAndFilenameWithoutExtension(fnMetafile) sprintf('_lambda%d.txt',metadata.wavelength(c))];
        copyfile(fnMetafile, fnMetafile_thisWavelength);
        fnStacksNew{c}.metafile   = fnMetafile_thisWavelength;
        fnStacksNew{c}.wavelength = metadata.wavelength(c);
    end
else
    fnStacksOrg = [];
    fnStacksNew = [];
    fprintf('there is only one color channel for %s',fnMetafile);
end

end

