function [ e ] = expectedMetadataFields(  )

e = {'name','date','time','effectiveBitDepth','resolution','zCount','frameInterval','zResolution'};