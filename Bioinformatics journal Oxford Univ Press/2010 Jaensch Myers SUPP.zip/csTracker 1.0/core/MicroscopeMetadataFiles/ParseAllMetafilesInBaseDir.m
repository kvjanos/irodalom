function [ M, fn_matlab ] = ParseAllMetafilesInBaseDir( saveResultsToDisk )
D = dir(baseDir);
M = {};
N = length(D);
for i = 1 : N
    if(D(i).isdir)
        movieDir = [baseDir filesep D(i).name];
        p = tryReadSpinningDiskMetaFile( movieDir, 'warnings', 'off' );
        if(~isempty(p))
            p.movieDir = movieDir;
            M{end+1} = p;
        end
    end
    if(mod(i,20) == 0)
        waitbar(i/N, mfilename);
    end
end
waitbar();

if(nargin > 0 && saveResultsToDisk)
    ensureDirExists(poolDir);
    fn_matlab = [poolDir filesep 'AllMetafilesParsed.mat'];
    save(fn_matlab, 'M');
end

end

