function [ metadata] = readSpinningDiskMetaFile( filename, varargin )
%reads from a meta file created by the spinning disk microscope the
%following information:
% name
% date/time
% effective bit depth - the number of bits actually used by the camera (<= bit depth of the image)
% resolution          - the resolution in x/y [nm/pixel]
% zResolution         - the resolution in z [nm/pixel] (i.e. the distance between two z-planes)
% zCount              - the number of z-planes in each stack (frame)
% frameInterval       - the time between the first z-plane in frame t and the first z-plane in frame t+1
% zRange              - distance from the first to the last plane
% wavelength          - all excitation wavelengths
%
% see also: tryReadSpinningDiskMetaFile,
%           readFieldsFromSpinningDiskMetaFile, expectedMetadataFields,
%           readDeltaVisionMetaFile
%
if(nargin == 0)
    filename = 'V:\microscopy\_beads\CY5\GFP_CY5_test1.txt';
    filename = 'V:\microscopy\yTUB-GFP1_GPR12_28hrsRNAi_2to4cellstage\yTUB-GFP1_GPR12_28hrsRNAi_2to4cellstage.txt';
end

warnings = getVarargin(varargin, 'warnings', 'on'); %on, off

fid = fopen(filename,'rt');     % 'rt' means "read text"

if (fid < 0)
    error('could not open file %s',filename);
end

metadata = [];
matches  = [];
fp = ['(' regexpFloatingPoint ')'];
while 1
    tline = lower(fgetl(fid));
    if ~ischar(tline), break, end
    %disp(tline)
    
    
    matches = matchRegularExpression( tline, 'name\s*:\s*(.*)',                          matches, 'name' );
    matches = matchRegularExpression( tline, 'type\s*:\s*(\d+)',                         matches, 'effectiveBitDepth' );
    matches = matchRegularExpression( tline, ['x\s*:\s*(?:\d+)\s*\*\s*' fp '\s*:\s*um'], matches, 'resolution' );
    matches = matchRegularExpression( tline, ['z control\s?-\s?step\D*' fp],             matches, 'zResolution' );
    matches = matchRegularExpression( tline, ['z\s*' fp '\s*um in \d+ planes'],          matches, 'zRange');
    matches = matchRegularExpression( tline, 'z\s*:\s*(-?\d+)',                          matches, 'zCount' );
    matches = matchRegularExpression( tline, '^interval\D*(\d+)',                        matches, 'frameInterval' );
    matches = matchRegularExpression( tline, ['scale\s*:\s*' fp],                        matches, 'scale' );
    matches = matchRegularExpression( tline, 'wavelength\s*:\s*(\d+)',                   matches, 'wavelength' );
end

if(isfield(matches, 'name'))
    str = matches.name{1}{1};
    
    [start_idx, end_idx, extents, matches_, tokens, names, splits] = regexp(str, '\t');
    for i = length(splits):-1:1
        if(isempty(splits{i}))
            splits(i) = [];
        end
    end
    metadata.name = splits{1};
    metadata.date = splits{2};
    metadata.time = splits{3};
end
if(isfield(matches, 'effectiveBitDepth'))
    metadata.effectiveBitDepth = str2double(matches.effectiveBitDepth{1});
end
if(isfield(matches, 'resolution'))
    metadata.resolution = round(str2double(matches.resolution{1})*1000);
end
if(isfield(matches, 'zResolution'))
    metadata.zResolution = abs(round(str2double(matches.zResolution{1})*1000));
end
if(isfield(matches, 'frameInterval'))
    %convert all frame interval entries to numbers
    for i = 1 : length(matches.frameInterval)
        metadata.frameInterval(i) = str2double(matches.frameInterval{i});
    end
    if(length(metadata.frameInterval) > 1)
        metadata.frameInterval = max(metadata.frameInterval);
        if(strcmpi(warnings,'on'))
            
            warning('more than one entry for "frame interval" found. using maximum value T = %d sec',metadata.frameInterval);
        end
    end
    %assume milli seconds if frame interval >= 1000 and convert to seconds
    if(metadata.frameInterval >= 1000)
        metadata.frameInterval = metadata.frameInterval / 1000;
        if(strcmpi(warnings,'on'))
            warning('"frame interval" is greater than 1000. assuming milli seconds. T = %d sec', metadata.frameInterval);
        end
    end
end
if(isfield(matches, 'zCount'))
    metadata.zCount = str2double(matches.zCount{1});
end
if(isfield(matches, 'zRange'))
    metadata.zRange = round(str2double(matches.zRange{1})*1000);
    if(isfield(metadata,'zCount'))
        metadata.zResolution = round(metadata.zRange / (metadata.zCount-1));
    end
end
if(isfield(matches, 'wavelength'))
    ix = 1;
    for i = 1 : length(matches.wavelength)
        w = str2double(matches.wavelength{i});
        if(w > 10)
            metadata.wavelength(ix) = w;
            ix=ix+1;
        end
    end
end
fclose(fid);