function [ numberingExtension ] = GetSeriesNumberingExtension( fn, regEx_imageSeriesNumbering )

regEx = ['.*(' regEx_imageSeriesNumbering ')\..*'];
[start_idx, end_idx, extents, matches, tokens] = regexpi(fn, regEx);

if(~isempty(tokens))
    numberingExtension = tokens{1}{1};
else
    numberingExtension = '';
end

end

