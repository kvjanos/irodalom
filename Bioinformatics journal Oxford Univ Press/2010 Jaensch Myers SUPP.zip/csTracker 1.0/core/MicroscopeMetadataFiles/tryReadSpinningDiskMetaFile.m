function [metadata] = tryReadSpinningDiskMetaFile( directory, varargin )
% searches for .txt-files in the specified directory and tries to read them
% as spinning disk microscope meta files
%
% see also: readSpinningDiskMetaFile, readFieldsFromSpinningDiskMetaFile
%

eFields = expectedMetadataFields();
warnings = getVarargin(varargin, 'warnings', 'on'); %on, off

D = dir([directory filesep '*.txt']);
N = length(D);
metadata = [];
for i = 1 : N
    filename = [directory filesep D(i).name];
    md = readSpinningDiskMetaFile(filename, 'warnings', warnings);
    success = 1;
    for j = 1 : length(eFields)
        if(~isfield(md, eFields{j}))
            success = 0;
            break
        end
    end
    if(success)
        metadata = md;
        metadata.pathMetadataFile = filename;
        break;
    end
end

