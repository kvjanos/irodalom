function [ fnTiffs, stub ] = GetAllTiffFilesFromMetadatafile( fnMetafile, regEx_imageSeriesNumbering )

% returns a list of tiff-files that 
% - are in the same folder as fnMetafile
% - have the same name apart from image series numbering and the file extension

if(nargin < 2)
    regEx_imageSeriesNumbering = '_t[0-9]{4}';
end

if(nargin == 0)
    fnMetafile = 'V:\microscopy\yTUB-GFP1_GPR12_28hrsRNAi_2to4cellstage\yTUB-GFP1_GPR12_28hrsRNAi_2to4cellstage.txt';
end

stub      = getFilenameWithoutExtension(fnMetafile);
directory = fileparts(fnMetafile);

regExprFileFilter = ['^' regexptranslate('escape', stub) '(' regEx_imageSeriesNumbering ')?' '\.tif'];
[files, bytes, fnTiffs] = dirr(directory,regExprFileFilter,'name');

end

