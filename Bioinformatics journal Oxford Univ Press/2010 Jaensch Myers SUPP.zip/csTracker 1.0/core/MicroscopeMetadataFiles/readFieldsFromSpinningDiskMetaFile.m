function [ md ] = readFieldsFromSpinningDiskMetaFile( directory, properties )
% searches for .txt-files in the specified directory and tries to read them
% as spinning disk microscope meta file. returns the file which has a maximum number of detected fields.
% Fields that are not found in the respective file are taken from the specified property structure.
%
% see also: readSpinningDiskMetaFile, tryReadSpinningDiskMetaFile
%

D = dir([directory filesep '*.txt']);
N = length(D);
md = [];
pathMetadataFile = [];
for i = 1 : N
    filename = [directory filesep D(i).name];
    hlp = readSpinningDiskMetaFile(filename);
    if(length(getFieldnames(hlp)) > length(getFieldnames(md)) )
        md = hlp;
        pathMetadataFile = filename;
    end
end
md.pathMetadataFile = pathMetadataFile;

expectedFieldnames = expectedMetadataFields();

for i = 1 : length(expectedFieldnames)
    f = expectedFieldnames{i};
    if(~isfield(md, f))
        warning('field "%s" could not be found in "%s" ',f, md.pathMetadataFile);
        if(isfield(properties, f))
            fprintf('\tfield "%s" is present in the properties',f);
            md.(f) = properties.(f);
        else
            error('\tfield "%s" could not be found in the properties either',f);
        end
    end
end