function pattern = MakeRingPattern( siz, radius, innerGrayValue, outerGrayValue, center )
%makes a circular pattern like this:
%0000000
%0001000
%0011100
%0111110
%0011100
%0001000
%0000000
%where '1' is the inner gray value and '0' the outer gray value

%input:     center = [y x]

  pattern = ones(siz,'double')*outerGrayValue;
  
  if(nargin < 5)
    center = ceil(siz/2);
  end
  
  circle = plot_circle(center(1),center(2),radius,'bresenhamSolid');

  for i = 1 : size(circle,1)
    if(circle(i,1) > 0 && circle(i,1) <= siz(1) && circle(i,2) > 0 && circle(i,2) <= siz(2))
        pattern(circle(i,1),circle(i,2)) = innerGrayValue;
    end
  end
  