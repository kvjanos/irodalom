function [ pattern ] = MakeEllipsePattern( siz, a, b, theta, innerGrayValue, outerGrayValue, center )

  pattern = ones(siz,'double')*outerGrayValue;
  
  if(nargin < 7)
    center = ceil(siz/2);
  end
  pattern = ellipseMatrix(center(1), center(2), a, b, deg2rad(theta), pattern, innerGrayValue);
end