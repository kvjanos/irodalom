function [ varargout ] = FindBrightestPlane( varargin )
% finds for each centrosome the plane where the average intensity within
% the Gaussian measured radius is brightest ==> update the z-coordinate


if(nargin == 0)
    workingDir = [baseDir filesep 'SPD2-GFP3_WT_4to8cellstage\workingDir\9'];
    filenameIn = 'candidates3D_noTooClPlane_mexHat_GFit2D_noTooCl3D.txt';
    
    workingDir = [baseDir filesep 'SPD5-YFP3_WT_2to4cellstage\workingDir\1'];
    filenameIn = finalTrackingFile();
        
    varargin{1} = workingDir;
    varargin{2} = filenameIn;
    setDebugLevel(2)
end
fprintf('%s\n',mfilename);


global param;
[T, header, filenameIn, filenameOut, dirDebug] = processInput(varargin, '*brPl', mfilename);
if(isempty(T))
    varargout{1} = filenameOut;
    return;
end
fn_debug = makeFilenameUnique([dirDebug filesep 'entries changed.txt']);
[T, header] = ComputeDerivedParameters(T, header);

xWidthColumn        = 'sigmaX2D';
yWidthColumn        = 'sigmaY2D';
minMeanSigmaXY2D    = 300; %nm
relZRange           = -2:1:2;

setImageSource('type','smoothed');

xWidthColumnColIdx      = headerIndex(header, xWidthColumn);
yWidthColumnColIdx      = headerIndex(header, yWidthColumn);
meanSigmaXY2DColIdx     = headerIndex(header, 'meanSigmaXY2D');
objIDColIdx             = headerIndex(header, 'objID');

if(getDebugLevel() >= 2)
%     T = T(ismember(T(:,objIDColIdx),[1196]),:);
    minMeanSigmaXY2D = 0;
    relZRange           = -4:1:4;
end

[header, zorgColIdx, isColumnNew] = addHeaderEntry( header, 'zorg');
if(isColumnNew)
    T(:,zorgColIdx) = T(:,3);
end

N = size(T,1);
T = sortrows(T,4); %sort by time
lastT = -1;
N_zChanged  = 0;
ix_zChanged = [];
for i = 1 : N
    %do not update very small objects
    meanSigmaXY2 = T(i,meanSigmaXY2DColIdx);
    if(meanSigmaXY2 < minMeanSigmaXY2D)
        continue
    end
    x = round(T(i,1));
    y = round(T(i,2));
    z = round(T(i,3));
    t = T(i,4);
    objID = T(i, objIDColIdx);
    if(getDebugLevel() >= 2)
        if(objID ~= 1196)
            continue
        end
    end
    if(lastT ~= t)
        fprintf('%t = d / %d\n', t , T(N,4));
        allZinThisT_1 = unique(round(T(T(:,4)==t,3)));
        allZinThisT = [];
        for zi = 1 : length(relZRange)
                allZinThisT = [allZinThisT;allZinThisT_1+relZRange(zi)];
        end
        allZinThisT = min(allZinThisT, param.zCount);
        allZinThisT = max(allZinThisT, 1);
        allZinThisT = unique(allZinThisT);
                
        stack_all = loadPartialFrame([allZinThisT allZinThisT], t, 'full' );
        waitbar(i/N,mfilename);
    end
    lastT = t;
    zRange = unique(max(min(z + relZRange, param.zCount),1));
    stack = stack_all(:,:,zRange);
    
    wx      = T(i, xWidthColumnColIdx);
    wy      = T(i, yWidthColumnColIdx);
    stack_patch = imcropCentered3( stack, [y,x], round([wy, wx]) );
    
    meanIntOverZ = squeeze(mean(mean(stack_patch, 1),2));
    [maxInt, idx_z_at_maxIntensity] = max(meanIntOverZ);  
    z_at_maxIntensity = zRange(idx_z_at_maxIntensity);
    
    if(getDebugLevel() >= 2)
        figure, plot(zRange, meanIntOverZ); hold on
        plot(z, meanIntOverZ(zRange == z), 'x', 'DisplayName', 'old z-plane')
        plot(z_at_maxIntensity, meanIntOverZ(zRange == z_at_maxIntensity), 'o', 'DisplayName', 'new z-plane')
        title(sprintf('objID = %d, t = %d, z = %d',objID,t,z));
        xlabel('z')
        ylabel('mean intensity')
        legend('show')
    end
    
    if(z ~= z_at_maxIntensity)
        %update z
        T(i, 3) = z_at_maxIntensity;
        
        %set Gaussian fit invalid
        T(i, xWidthColumnColIdx) = -999; 
        
        N_zChanged = N_zChanged + 1;
        ix_zChanged = [ix_zChanged i];
    end
end
waitbar();

T_changed = T(ix_zChanged, :);
fprintMatrix(fn_debug, T_changed, header);

if(isempty(filenameOut))
    varargout{1} = T;
    varargout{2} = header;
    varargout{3} = N_zChanged;
else
    fprintMatrix(filenameOut, T, header);
    varargout{1} = filenameOut;
    varargout{2} = N_zChanged;
end