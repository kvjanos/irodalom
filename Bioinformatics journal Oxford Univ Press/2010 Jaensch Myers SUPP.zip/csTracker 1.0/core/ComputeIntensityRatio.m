function [ varargout ] = ComputeIntensityRatio( varargin )
% computes the ratio between background and peak intensity for each centrosome


if(nargin == 0)
    workingDir = [baseDir filesep 'SPD2-GFP3_WT_4to8cellstage\workingDir\9'];
    filenameIn = 'candidates3D_noTooClPlane_mexHat_GFit2D_noTooCl3D.txt';
    
    workingDir = [baseDir filesep 'SPD2-GFP2_WT_4to8cellstage\workingDir\9'];
    filenameIn = 'candidates3D_noTooClPlane_mexHat_GFit2D.txt';

    workingDir = [baseDir filesep 'RSA1-GFP2_WT_8to16cellstage\workingDir\1'];
    filenameIn = finalTrackingFile();

    workingDir = [baseDir filesep 'SPD2-GFP1_RNAiresistant_noRNAi\workingDir\1'];
    filenameIn = finalTrackingFile();
        
    workingDir = [baseDir filesep 'SPD5-YFP1_htrFRAP\workingDir\1'];
    filenameIn = 'candidates3D_noSameLoc_mexHat_noTooCl2D_GFit2D_brPl_GFit2D_noSameLoc_noTooCl3D_mexHat.txt'; 

    workingDir = [baseDir filesep 'SPD2-GFP3_RNAiresistant_SPD2_22-24hrsRNAi\workingDir\1'];
    filenameIn = finalTrackingFile(); 
    
    workingDir = [baseDir filesep 'aa_test_SPD2-GFP_XFPRNAi_twocell01_R3D\workingDir\1'];
    filenameIn = 'candidates3D_bigObj_noSameLoc_mexHat_noTooCl2D_GFit2D_brPl_GFit2D_noSameLoc_noTooCl3D_mexHat.txt';
    
    
    workingDir = [baseDir filesep 'Air1-GFP1_WT\workingDir\1'];
    filenameIn = finalTrackingFile();
    
    

    varargin{1} = workingDir;
    varargin{2} = filenameIn;
    setDebugLevel(1)
end
fprintf('%s\n',mfilename);

global param;
[T, header, filenameIn, filenameOut, dirDebug] = processInput(varargin, 'intRatio', mfilename);
if(isempty(T))
    varargout{1} = filenameOut;
    return;
end

if(strcmpi(param.fluorescentMarker, 'histone'))
    xWidthColumn        = 'fittedxcorrSigma';
    yWidthColumn        = 'fittedxcorrSigma';
    backgroundColumn    = 'fmc_gaussAdd2D';
else
    xWidthColumn        = 'sigmaX2D';
    yWidthColumn        = 'sigmaY2D';
    backgroundColumn    = 'gaussAdd2D';
    angleColumn         = 'rho';
end



setImageSource('type','smoothed');

xWidthColumnColIdx      = headerIndex(header, xWidthColumn);
yWidthColumnColIdx      = headerIndex(header, yWidthColumn);
backgroundColumnColIdx  = headerIndex(header, backgroundColumn);
angleColumnColIdx       = headerIndex(header, angleColumn, 'none');
objIDColIdx             = headerIndex(header, 'objID');

[header, maxIntensityColIdx]                = addHeaderEntry(header, 'maxIntensity');
[header, centerIntensityColIdx]             = addHeaderEntry(header, 'centerIntensity');
[header, centerIntensityAboveColIdx]        = addHeaderEntry(header, 'centerIntensityAbove');
[header, centerIntensityBelowColIdx]        = addHeaderEntry(header, 'centerIntensityBelow');
[header, intensityRatioToAboveBelowColIdx]  = addHeaderEntry(header, 'intensityRatioToAboveBelow');
[header, intensityRatioColIdx]              = addHeaderEntry(header, 'intensityRatio');
[header, centerRadiusColIdx]                = addHeaderEntry(header, 'centerRadius');
[header, maxIntensityRatioColIdx]           = addHeaderEntry(header, 'maxIntensityRatio');
if(angleColumnColIdx>0)
    [header, ellipseMeanIntensityColIdx]    = addHeaderEntry(header, 'ellipseMeanIntensity');
    [header, ellipseMeanIntensityRatioColIdx]    = addHeaderEntry(header, 'ellipseMeanIntensityRatio');
end

if(getDebugLevel() >= 2)
    setDebugDir(dirDebug);
    ensureEmptyDirExists(dirDebug);
    objIDColIdx = headerIndex(header, 'objID');
    T = T(ismember(T(:,objIDColIdx), [1356]),:);
end

N = size(T,1);
T = sortrows(T,4); %sort by time
lastT = -1;

for i = 1 : N
    x = T(i,1);
    y = T(i,2);
    z = T(i,3);
    t = T(i,4);
    objID = T(i, objIDColIdx);
    fprintf('%d: objID = %d\n',i,objID);
    if(lastT ~= t)
        fprintf('%t = d / %d\n', t , T(N,4));
        allZinThisT = T(T(:,4)==t,3);
        
        %add the plane above and below for each plane
        allZinThisT = unique([allZinThisT;max(1,allZinThisT-1);min(param.zCount,allZinThisT+1)]);
        
        stack = loadPartialFrame([allZinThisT allZinThisT], t, 'full' );
        waitbar(i/N,mfilename);
    end
    lastT = t;
    I = stack(:,:,z);
    
    wx      = T(i, xWidthColumnColIdx);
    wy      = T(i, yWidthColumnColIdx);
    bg      = T(i, backgroundColumnColIdx);
    radius  = max(3,ceil(mean([wx,wy])));
    dim 	= 2*radius+1;
    innerRingPattern    = MakeRingPattern([dim,dim],radius,1,0);
    sumInnerRingPattern = sum(innerRingPattern(:));
    centerIntensity     = ComputeCorrelationScore(I, innerRingPattern, round(y), round(x)) / sumInnerRingPattern;
    
    if(angleColumnColIdx > 0)
        a = 2*wx;
        b = 2*wy;
        dim = (2*ceil(1.5*a))+1;
        theta = T(i, angleColumnColIdx);
        ellipsePattern = MakeEllipsePattern( ceil([dim,dim]), a,b, -theta, 1, 0 );
        sumEllipsePattern = sum(ellipsePattern(:));
%         setDebugLevel(2);
        ellipseIntensity  = ComputeCorrelationScore(I, ellipsePattern, round(y), round(x)) / sumEllipsePattern;
%         setDebugLevel(1);
        T(i, ellipseMeanIntensityColIdx)        = ellipseIntensity;
        T(i, ellipseMeanIntensityRatioColIdx)   = ellipseIntensity / bg;
    end

    if(z > 1)
        Ibelow = stack(:,:,z-1);
        centerIntensity_below = ComputeCorrelationScore(Ibelow, innerRingPattern, round(y), round(x)) / sumInnerRingPattern;
        centerIntensityAboveAndBelow  = centerIntensity_below;
    else
        centerIntensity_below = -1;
        centerIntensityAboveAndBelow = [];
    end
    
    if(z < param.zCount)
        Iabove = stack(:,:,z+1);
        centerIntensity_above = ComputeCorrelationScore(Iabove, innerRingPattern, round(y), round(x)) / sumInnerRingPattern;
        centerIntensityAboveAndBelow = [centerIntensityAboveAndBelow centerIntensity_above];
    else
        centerIntensity_above = -1;
    end
    
    patch = imcropCentered3(I, round([y,x]), radius);
    maxIntensity = max(patch(:));

    T(i, maxIntensityColIdx)                = maxIntensity;
    T(i, centerIntensityColIdx)             = centerIntensity;
    T(i, centerIntensityAboveColIdx)        = centerIntensity_below;
    T(i, centerIntensityBelowColIdx)        = centerIntensity_above;
    T(i, intensityRatioToAboveBelowColIdx)  = max(centerIntensityAboveAndBelow) /centerIntensity;
    T(i, intensityRatioColIdx)              = centerIntensity / bg;
    T(i, maxIntensityRatioColIdx)           = maxIntensity / bg;
    T(i, centerRadiusColIdx)                = radius;
    
end
waitbar();

if(isempty(filenameOut))
    varargout{1} = T;
    varargout{2} = header;
else
    fprintMatrix(filenameOut, T, header);
    varargout{1} = filenameOut;
end