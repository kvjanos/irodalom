function [ varargout ] = FilterIntersectingObjects_anisotropicSpace3D( varargin )
%see also: FilterIntersectingObjects, FilterIntersectingObjects_atSamePixelLocation,
%          FilterIntersectingObjects_onSamePlane

fprintf('%s\n',mfilename);

if(nargin == 0)
    workingDir = [baseDir filesep 'yTUB-GFP8_GPR12_28hrsRNAi_1to8cellstage\workingDir\1'];
    filenameIn = 'candidates3D_noSameLoc_mexHat_GFit2D_brPl_GFit2D.txt';
    
    varargin{1} = workingDir;
    varargin{2} = filenameIn;
    setDebugLevel(1)
end

radiusColName  = getVarargin( varargin, 'radiusColName', 'csRadiusGaussianFitting', 1 );
qualityColName = getVarargin( varargin, 'qualityColName', 'peakBGRatio', 1 ); %peakBGRatio, innerRingScore

global param
[T, header, filenameIn, filenameOut, dirDebug] = processInput(varargin, '*noTooCl3D', mfilename);
if(isempty(T))
    varargout{1} = filenameOut;
    return;
end

%% --------------- parameter settings ---------------------------
zStretchingFactor = 2; %objects appear elongated in the z-direction by this factor

[T, header] = ComputeDerivedParameters(T,header);
if(getDebugLevel() >= 2)
    T = T(ismember(T(:,headerIndex(header, 'objID')), [19,20,32]),:);
end

%assume only half the radius for objects that might actually be smaller than the PSF
maxRadius_PSF                           = 550; %nm
minRadiusAboveResolution                = maxRadius_PSF / param.resolution; 

radiusColIdx                            = headerIndex(header, radiusColName);
clusterFields                           = {'t'};
computeDistanceAndRadiusMatrixFunction  = @(R) (computeDistanceAndRadiusMatrix_anisotropicSpace3D(R, radiusColIdx, zStretchingFactor, minRadiusAboveResolution));
radiusTransferFunction                  = @(r)(.95*r);

[T, R] = FilterIntersectingObjects( T, header, qualityColName, clusterFields, computeDistanceAndRadiusMatrixFunction, radiusTransferFunction);

fn_debug = deleteFileIfExists([dirDebug filesep 'removedEntries.txt']);
if(~isempty(R))
    fprintMatrix(fn_debug,R,header);
end

if(isempty(filenameOut))
    varargout{1} = T;
    varargout{2} = header;
else
    fprintMatrix(filenameOut, T, header);
    varargout{1} = filenameOut;
end

if(nargin == 0)
    showTrackingMovie(filenameOut);
end

end

function r = transformRadius(r, minRadiusAboveResolution)
    if(r < minRadiusAboveResolution)
        r = .5*r;
    end
end

function [D, r] = computeDistanceAndRadiusMatrix_anisotropicSpace3D(R, radiusColIdx, zStretchingFactor, minRadiusAboveResolution)
%all entries in R same t!!!
global param;
n = size(R,1);
D = ones(n,n)*inf;
r = zeros(n,n);
resolutionRatio = param.zResolution / param.resolution;
f = param.resolution / param.zResolution * zStretchingFactor;
for i = 1 : n-1
    for j = i+1 : n
        
        dist2D = sqrt((R(i,1)-R(j,1))^2 + (R(i,2)-R(j,2))^2 + resolutionRatio*(R(i,3)-R(j,3))^2);

        
        radiusXY_i = transformRadius(R(i,radiusColIdx), minRadiusAboveResolution);
        radiusXY_j = transformRadius(R(j,radiusColIdx), minRadiusAboveResolution);
        
        radiusZ_i = max(1,radiusXY_i * f);
        radiusZ_j = max(1,radiusXY_j * f);
        
        
        if(dist2D < radiusXY_i+radiusXY_j)
            D(i,j) = norm(R(i,1:3) - R(j,1:3));
            r(i,j) = ellipsoidRadius(R(i,1:3), radiusXY_i, radiusXY_i, radiusZ_i, R(j,1:3)+eps*10); %+epsilon to handle objects at exactly the same position
            r(j,i) = ellipsoidRadius(R(j,1:3), radiusXY_j, radiusXY_j, radiusZ_j, R(i,1:3)+eps*10); %+epsilon to handle objects at exactly the same position
        else %i and j are certainly not in conflicting positions relative to each other
            D(i,j) = 999999;
        end
        
    end
end
end

function [r,x,y,z] = ellipsoidRadius(p1, a, b, c, p2)
%"radius" of the ellipsoid with semi-axes lengths a, b and c and center p1 in
%the direction p1 --> p2
%
% http://en.wikipedia.org/wiki/Ellipsoid
% http://mathworld.wolfram.com/Ellipsoid.html

x1 = p2(1)-p1(1);
y1 = p2(2)-p1(2);
z1 = p2(3)-p1(3);

lambda = sqrt(1/(x1*x1/(a*a)+y1*y1/(b*b)+z1*z1/(c*c)));

x = lambda * x1;
y = lambda * y1;
z = lambda * z1;
r = norm([x,y,z]);

if(nargout > 1)
    x = x + p1(1);
    y = y + p1(2);
    z = z + p1(3);
end
end