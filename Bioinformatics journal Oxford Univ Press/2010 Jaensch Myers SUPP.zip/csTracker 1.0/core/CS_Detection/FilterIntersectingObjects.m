function [ T, R ] = FilterIntersectingObjects( T, header, qualityColName, clusterFields, computeDistanceAndRadiusMatrixFunction, radiusTransferFunction)
%iteratively determines for each candidate a if there is another candidate b
%with distance(a,b) < radius(a)+radius(b)
%if so, the candidate with the lower quality will be removed.
%
%the radius of each candidate may depend on the direction to the candidate it is compared with
%
%see also: FilterIntersectingObjects_anisotropicSpace3D, FilterIntersectingObjects_atSamePixelLocation,
%          FilterIntersectingObjects_onSamePlane
%
qualityColIdx       = headerIndex(header, qualityColName);
clusterFieldsColIdx = headerIndex(header, clusterFields);
[rangeIndices, T]   = clusterTable_indices(T, clusterFieldsColIdx);

deleteIdx = [];
for i = 1:length(rangeIndices)-1
    ix = rangeIndices(i) : rangeIndices(i+1)-1;
    
    R = T(ix,:); % all entries with same cluster values
    plotCandidates([]) %plot all candidates

    [D, radius] = computeDistanceAndRadiusMatrixFunction(R);
    
    if(~isempty(radiusTransferFunction))
        radius = radiusTransferFunction(radius);
    end
    
    q = R(:,qualityColIdx);
    
    examplars = FindExamplars(D, radius, q, R, header);
    plotCandidates(examplars)  %mark examplars
    thisDeleteIdx = find(examplars == 0) + ix(1) - 1;
    deleteIdx = [deleteIdx;thisDeleteIdx];
end

R = T(deleteIdx,:);
T(deleteIdx,:) = [];
fprintf('%d entries removed\n\n',length(deleteIdx));

    function plotCandidates(idx_examplars) %nested function
        if(getDebugLevel() >= 2)
            if(isempty(idx_examplars))
                fig1 = sfigure();
                plot3(R(:,1),R(:,2),R(:,3), 'xr');
                hold on
            else
                plot3(R(idx_examplars,1),R(idx_examplars,2),R(idx_examplars,3), 'ok');
            end
        end
    end
end %of main

function examplars = FindExamplars(D, radius, q, T, header)
%iteratively searches for pairs (i,j) with distance <= radius(i)+radius(j) and
%removes the element with the lower quality
%
%assuming ellipsoid-shaped objects due to the point spread function the
%radius of an object i depends on the direction to the object with with i
%is compared

%input:
%D      - distance matrix, NxN
%radius - radius, NxN matrix, radius(i,j) --> radius of object(i) in the direction toward object(j)
%  or
%radius - radius, Nx1 vector, radius(i) --> radius of object(i)
   
%q      - quality, Nx1-vector
%T      - the complete table of elements

%output:
%examplars - Nx1 vector, examplars(i) == 1 ==> i is examplar

examplars = true(length(q), 1); %all elements are examplars to begin with
[d, ix] = sort(D(:));
[ixSorted, ix_rev] = sort(ix);
siz = size(D);

max_radius = 2*max(radius(:));
isRadiusMatrix = size(radius,2) > 1;

objIDColIdx = headerIndex(header, 'objID');
k = 1;
while(1)
    if(k > length(d))
        break
    end
    if(d(k) == inf)
        k = k + 1;
    else
        [i,j] = ind2sub(siz,ix(k));
        
        if(isRadiusMatrix)
            minDist = radius(i,j)+radius(j,i);
        else
            minDist = radius(i)+radius(j);
        end
        
        if(d(k) <= minDist || d(k)==0)
            if(q(i) < q(j))
                r = i; %index to be removed
            else
                r = j; %index to be removed
            end
            examplars(r) = 0;
            
            %             pi = T(i,1:3)
            %             pj = T(j,1:3)
            %             objIDi = T(i,objIDColIdx)
            %             objIDj = T(j,objIDColIdx)
            %             ri = radius(i)
            %             rj = radius(j)
%             fprintf('-------------------------\n')
            for p = 1 : siz(1)
                h = sub2ind(siz, p, r);
                d(ix_rev(h)) = inf;
                h = sub2ind(siz, r, p);
                d(ix_rev(h)) = inf;
            end
        elseif(d(k) > max_radius) %only distances > max_radius will follow
            break
        else
            k = k + 1;            
        end
    end
end

%test:
% A = ones(4,4) * inf;
% A(1,2) = 1;
% A(1,3) = 4;
% A(1,4) = 7;
% A(2,3) = 2;
% A(2,4) = 8;
% A(3,4) = 9;
%
% q = [.9 .8 .85 .76];
% max_d = 2;
%
% examplars = FindExamplars(A, max_d, q)
% return
end





