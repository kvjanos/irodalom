function [ varargout ] = FilterSplodges( varargin )
%occasionally there are bright spots on singles planes in the images
%at the same position in the plane above and below there is no evidence of
%a spot 
%
%filter these by the intensity ratio between the plane above/below and the plane
%there the spot has been detected
%
%also see: ComputeIntensityRatio

fprintf('%s\n',mfilename);

if(nargin == 0)
    workingDir = [baseDir filesep 'SPD5-YFP8_WT_multicell\workingDir\8'];
    filenameIn = 'candidates.txt';

    workingDir = [baseDir filesep 'SPD5-YFP1_multicell\workingDir\8'];
    filenameIn = 'candidates_noTooClPlane_zStbl_zGrps_zSplit_hotSpots_GFit2D_mexHat_noBelowRes_intRatio_noTooClose_OutsideEmbryoFlag.txt';
    filenameIn = 'candidates.txt';
    
    workingDir = [baseDir filesep 'SPD2-GFP1_WT_4to8cellstage\workingDir\8'];
    filenameIn = 'candidates3D_noTooClPlane_mexHat_GFit2D.txt';

    varargin{1} = workingDir;
    varargin{2} = filenameIn;
end

minAllowedIntensityRatioToAboveBelow = .57;

global param
[T, header, filenameIn, filenameOut] = processInput(varargin, '*noSplodges', mfilename);
if(isempty(T))
    varargout{1} = filenameOut;
    return;
end

if(getDebugLevel() >= 2)
    T = T(T(:,4) == 39,:);
end

intensityRatioToAboveBelowColIdx  = headerIndex(header, 'intensityRatioToAboveBelow');

deleteIdx = find(T(:,intensityRatioToAboveBelowColIdx)<minAllowedIntensityRatioToAboveBelow);
T(deleteIdx,:) = [];
fprintf('%d entries deleted\n',length(deleteIdx));

if(isempty(filenameOut))
    varargout{1} = T;
    varargout{2} = header;
else
    fprintMatrix(filenameOut, T, header);
    varargout{1} = filenameOut;
end

if(nargin == 0)
    showTrackingMovie(filenameOut);
end
end %of main
