function [ varargout ] = FilterIntersectingObjects_atSamePixelLocation( varargin )

%see also: FilterIntersectingObjects, FilterIntersectingObjects_onSamePlane,
%          FilterIntersectingObjects_anisotropicSpace3D

fprintf('%s\n',mfilename);

if(nargin == 0)
    workingDir = [baseDir filesep 'yTUB-GFP8_GPR12_28hrsRNAi_1to8cellstage\workingDir\1'];
    filenameIn = 'candidates3D.txt';
    
    workingDir = [baseDir filesep 'yTUB-GFP1_Histone-GFP_1to8cellstage\workingDir\1'];
    filenameIn = 'candidates3D_noSameLoc_mexHat_noTooCl2D_GFit2D_brPl_GFit2D_mexHat.txt';
    
    varargin{1} = workingDir;
    varargin{2} = filenameIn;
    setDebugLevel(1)
end

qualityColName = getVarargin( varargin, 'qualityColName', 'xcorr', 1 );

global param
[T, header, filenameIn, filenameOut, dirDebug] = processInput(varargin, '*noSameLoc', mfilename);
if(isempty(T))
    varargout{1} = filenameOut;
    return;
end

if(getDebugLevel() >= 2)
%     T = T(ismember(T(:,headerIndex(header, 'objID')), [2517, 2525]),:);
    T = T(ismember(T(:,headerIndex(header, 't')), [76]),:);
    %     setDebugLevel(1)
    fprintMatrix([getPathAndFilenameWithoutExtension(filenameIn) '_debugLevel2_filtered.txt'], T, header);
end

clusterFields = {'z', 't'};
computeDistanceAndRadiusMatrixFunction = @computeDistanceAndRadiusMatrix_atSamePixelLocation;
radiusTransferFunction                 = [];
[T, R] = FilterIntersectingObjects( T, header, qualityColName, clusterFields, computeDistanceAndRadiusMatrixFunction, radiusTransferFunction);

fn_debug = deleteFileIfExists([dirDebug filesep 'removedEntries.txt']);
if(~isempty(R))
    fprintMatrix(fn_debug,R,header);
end

if(isempty(filenameOut))
    varargout{1} = T;
    varargout{2} = header;
else
    fprintMatrix(filenameOut, T, header);
    varargout{1} = filenameOut;
end

if(nargin == 0)
   makeTrackingMovie(workingDir, filenameOut,[],0, 'skipFramesWhereNoCentrosomePresent',1,'openMovie',1);
end

end

function [D, r] = computeDistanceAndRadiusMatrix_atSamePixelLocation(R)
%all entries in R same z,t!!!
global param;
n = size(R,1);
D = ones(n,n)*inf;
r = ones(n,1);
for i = 1 : n-1
    for j = i+1 : n
        dist2D = sqrt((R(i,1)-R(j,1))^2 + (R(i,2)-R(j,2))^2);
        if(dist2D < 1)
            D(i,j) = 0;
        else
            D(i,j) = 999999;
        end
    end
end

end