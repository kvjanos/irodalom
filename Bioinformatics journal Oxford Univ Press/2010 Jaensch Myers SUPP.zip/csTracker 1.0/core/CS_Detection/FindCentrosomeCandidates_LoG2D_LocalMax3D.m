function [ filenameOut ] = FindCentrosomeCandidates_LoG2D_LocalMax3D(workingDir, filenameOut, skipIfFileoutExists)


global param;
fprintf('%s\n',mfilename);

if(nargin == 0)
    workingDir = [baseDir filesep 'SPD2-GFP_WT_long2\workingDir\4'];
    workingDir = [baseDir filesep 'SPD5-YFP1_multicell\workingDir\5'];
    workingDir = [baseDir filesep 'yTUB-GFP2_WT_4to8cellstage\workingDir\9'];
    workingDir = [baseDir filesep 'SPD2-GFP1_WT_4to8cellstage\workingDir\8'];
    workingDir = [baseDir filesep 'yTUB-GFP10_WT_1to8cellstage\workingDir\8'];
    
    
    filenameOut = [workingDir filesep 'candidates_debugMode.txt'];
    loadGlobalParams(workingDir);
    setDebugLevel(2)
else
    loadGlobalParams(workingDir);

    if(nargin < 2 || isempty(filenameOut))
        filenameOut = getFullPath(param.relPathCandidatesFile);
    else
        filenameOut = addDirectoryToFilename(workingDir,filenameOut);
    end
    if(nargin < 3)
        skipIfFileoutExists = 0;
    end
end


filenameOut = [getPathAndFilenameWithoutExtension(filenameOut) '3D.txt'];
if(exist('skipIfFileoutExists','var') && skipIfFileoutExists == 1 && exist(filenameOut,'file'))
    return
end

filenameOut_tmp = [getPathAndFilenameWithoutExtension(filenameOut) '__.tmp'];
fid = fopen(filenameOut_tmp, 'w+t');
fprintf(fid,'x\ty\tz\tt\tobjID\txcorr\txcorrSigma\tPixelCntXCorr\tdetectionscale\tinnerRingScore\touterRingScore\tratioRingScore\txorg\tyorg\tzorg\n');

dirDebug = [getFullPath(param.relPathDebug) filesep mfilename];
ensureDirExists(dirDebug);

normxcrossThreshold = param.ap.ObjectDetection.normxcrossThreshold;
mexhat_sigma        = param.ap.ObjectDetection.sigma / param.resolution;
mexhat_scale        = param.ap.ObjectDetection.scale;


param.objectDetection.MexicanHatSigma      = mexhat_sigma;
param.objectDetection.MexicanHatScale      = mexhat_scale;
param.objectDetection.normxcrossThreshold  = normxcrossThreshold;

if(getDebugLevel()>=2)
%     mexhat_sigma = [2];
%     mexhat_sigma = [2 3];
%      mexhat_sigma = mexhat_sigma(1:2)
end

%2D norm. x-correlation
kernels = MakeKernelPyramide2D('log2', mexhat_sigma);

imgSourceRaw        = setImageSource( 'type', 'raw' );
imgSourceSmoothed   = setImageSource( 'type', 'smoothed' );


% if(getDebugLevel()>=2)
%     for j = 1 : length(kernels)
%         H = kernels{j};
%         WriteStackAsMultiTIFF(im2uint8(H),[myTempDir filesep 'MexHat2D.tif']);
%         for i = 1 : size(H,1)
%             h = squeeze(H(i,:,:));
%             m1(i) = mean(h(:));
%         end
%         for i = 1 : size(H,2)
%             h = squeeze(H(:,i,:));
%             m2(i) = mean(h(:));
%         end
%         figure, plot(m2,'o-');
%         title(sprintf('x and y, mexhat_sigma = %.1f',mexhat_sigma(j)));
%     end
% end

%% 
r0  = 3; %radius of inner ring score
r1  = ceil(param.r1 / param.resolution);
r2  = ceil(param.r2 / param.resolution);
dim = 2*r2+1;

innerRingPattern = MakeRingPattern([dim,dim],r0,1,0);
outerRingPattern = MakeRingPattern([dim,dim],r1,0,1);
sumInnerPattern = sum(sum( innerRingPattern ));
sumOuterPattern = sum(sum( outerRingPattern ));

%% loop over all images
i = 0;
objIDCounter = 1;

timepoints = param.firstTimepoint : param.lastTimepoint;

if(getDebugLevel() >= 2)
    timepoints = 40:43;
end

for t = timepoints
    t
    i = i + 1;
    fprintf('processing timepoint %d / %d\n', i, length(timepoints));
    
    setImageSource(imgSourceRaw);
    stack = loadTimepoints(t);
    
    setImageSource(imgSourceSmoothed);
    stack_3DSmoothed = loadTimepoints(t);
    
    [y0,x0,z0,maxXcorrValue,kernelIndex,pixelCnt, detectionscale] = FindSpots_LoG2D_LocalMax3D_scaleSpace( stack, stack_3DSmoothed, kernels, mexhat_scale, normxcrossThreshold);

    xcorrsigma = zeros(length(kernelIndex),1);
    for k = 1: length(kernelIndex)
        xcorrsigma(k) = mexhat_sigma(kernelIndex(k));
    end
    
    objID = zeros(length(y0),1);
    n = length(y0)
    N(t) = n;
    for j = 1 : length(y0)
        [inner, outer, ratio] = ComputeRingscore(stack(:,:,z0(j)),round(y0(j)),round(x0(j)));
        objID(j) = objIDCounter;
        fprintVector(fid,[x0(j),y0(j),z0(j),t,objIDCounter,maxXcorrValue(j),xcorrsigma(j),pixelCnt(j),detectionscale(j),inner,outer,ratio,x0(j),y0(j),z0(j)]);
        objIDCounter = objIDCounter + 1;
    end    
    waitbar(i / length(timepoints), mfilename);
end

waitbar();

fclose(fid);
deleteFileIfExists(filenameOut);
copyfile(filenameOut_tmp, filenameOut,'f');
deleteFileIfExists(filenameOut_tmp);

% movefile_fast(filenameOut_tmp, filenameOut, 'f');
if(~exist(filenameOut, 'file'))
    error('could not rename %s to %s',filenameOut_tmp,filenameOut);
end

param.nextFreeObjID = objIDCounter;
saveGlobalParams();
figure, plot(N,'o-'), title('number of calls per frame'), xlabel('frame #'), ylabel('count');
if(nargin == 0)
    makeTrackingMovie(workingDir, filenameOut,[],0, 'skipFramesWhereNoCentrosomePresent',1,'openMovie',1);
end

function [inner, outer, ratio] = ComputeRingscore(I,y,x)
    %find max intensity pixel around (y,x) ==> use as position for inner
    %and outer ring score
    [y_maxI, x_maxI] = index2DOfMax(I, [x-3,y-3,7,7]);
    
    inner = ComputeCorrelationScore(I, innerRingPattern, y_maxI, x_maxI) / sumInnerPattern;
    outer = ComputeCorrelationScore(I, outerRingPattern, y_maxI, x_maxI) / sumOuterPattern;
    ratio = inner / outer;
end

end

function [ kernels ] = MakeKernelPyramide2D( type, sigmas )

%input: type    - 'log', 'log2', 'gaussian'
%       sigmas  - vector of mexhat_sigma values 

kernels = cell(1,length(sigmas));
for i = 1 : length( sigmas )
    siz = ceil(3.5*sigmas(i))*2+1;
    kernels{i} = MakeKernels( type, sigmas(i), siz );
end


end



