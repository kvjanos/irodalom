function [maxCorrelationValue, maxI, maxJ] = CorrelationSeries( I, kernels, pos, radius)
%
% applies norm. cross-correlation with the given kernels to image I in a
% ROI specified by (pos, radius)
% for each kernel the position and value of the maximum correlation value
% is returned
%
%input:
%- kernels is either a cell array of kernel matrices or a (3-dimensional) stack of
%  kernel matrices
%- pos(y,x), radius(y,x) - define a roi in which the maximum x-corr value will be searched for

if(iscell(kernels))
    N = length(kernels);
else
    N = size(kernels,3);
end


maxCorrelationValue = zeros(1,N);
maxI = zeros(1,N);
maxJ = zeros(1,N);

for i = 1 : N
    if(iscell(kernels))
        kernel = kernels{i};
    else
        kernel = kernels(:,:,i);
    end
    h_kernel = (size(kernel,1)-1)/2;
    w_kernel = (size(kernel,2)-1)/2;
    patch_radius      = [radius(1)+h_kernel, radius(2)+w_kernel];
    [patch, idxROI] = imcropCentered3(I, pos, patch_radius);
    
    if(any( size(patch) < size(kernel) ))
        thisMaxI = pos(1);
        thisMaxJ = pos(2);
        maxCorr  = 0;
    else
        Icorr = NormCorrelation(patch,kernel);
        [maxCorr, idx] = max(Icorr(:)); 
        [thisMaxI, thisMaxJ] = ind2sub(size(patch),idx);
        thisMaxI = thisMaxI + idxROI(1) - 1;
        thisMaxJ = thisMaxJ + idxROI(3) - 1;
    end


    maxI(i) = thisMaxI;
    maxJ(i) = thisMaxJ; 
    maxCorrelationValue(i) =  maxCorr;

%     figure, imshow(patch,[]);
%     figure, imshow(Icorr,[]);
%     figure, imshow(I,[]);
%     hold on
%     plot(maxJ(i), maxI(i), 'rx');

end



