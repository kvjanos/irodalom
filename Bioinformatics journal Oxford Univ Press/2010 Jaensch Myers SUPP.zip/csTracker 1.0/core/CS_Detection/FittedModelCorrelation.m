function varargout = FittedModelCorrelation(varargin)
% performs norm. x-correlation on the detected spots with 
% smaller increments of the size of the Mexican hat than in the spot
% detection step


fprintf('%s\n',mfilename);
if(nargin == 0)

    workingDir = [baseDir filesep 'yTUB-GFP1\workingDir\1'];
    workingDir = [baseDir filesep 'SPD2-GFP_WT_long4\workingDir\1'];
    workingDir = [baseDir filesep 'SPD5-YFP4_multicell\workingDir\8'];
    workingDir  = [baseDir filesep 'yTUB-GFP1_AMA1_24hrsRNAi\workingDir\1'];
    filenameIn = 'candidates_noTooClPlane_zStbl_zGrps_zSplit_hotSpots_GFit2D.txt';
    
    workingDir = [baseDir filesep 'SPD5-YFP12_WT_multicell\workingDir\8'];
    filenameIn = 'tr_trSpltInc_noOvertr_noNoiseTr_extTr_noOvertr_joinTr_pairs_trTree_cName.txt';

    workingDir = [baseDir filesep 'yTUB-GFP1_AMA1_24hrsRNAi_4P0-Centrosomes\workingDir\1'];
    filenameIn = 'candidates.txt';

    workingDir = [baseDir filesep 'SPD2-GFP1_WT_4to8cellstage\workingDir\8'];
    filenameIn = 'candidates3D_noTooClPlane.txt';
    
    workingDir = [baseDir filesep 'Histone-GFP1_WT_multicell\workingDir\2'];
    filenameIn = 'candidates_debugMode3D_noTooClPlane.txt';
    
    workingDir = [baseDir filesep 'SPD2-GFP1_T233A_T232S\workingDir\1'];
    filenameIn = 'candidates3D_noSameLoc.txt';
    
   setDebugLevel(2)
end



updatePosition2D            = getVarargin( varargin, 'updatePosition2D', 1, 1 );
maxXCorrScoreSearchRadius   = getVarargin( varargin, 'maxXCorrScoreSearchRadius', 'byDetectionScale', 1 );

global param
[T, header, filenameIn, filenameOut] = processInput(varargin, '*mexHat', mfilename);
if(isempty(T))
    varargout{1} = filenameOut;
    return;
end

%% parameters
maxCSRadius      = param.bio.rmax; %nm (3600 nm) 
stepSizeInPixels = .5;
%% //parameters

setImageSource('type','raw');

if(getDebugLevel>=2)
%     T = T(ismember(T(:,headerIndex(header, 'objID')), [208]),:);
%     T = T(ismember(T(:,4),[8,29]),:);
%     T = T(ismember(T(:,headerIndex(header, 't')), [15]),:);
end
objIDColIdx         = headerIndex(header, 'objID');
trIDColIdx          = headerIndex(header, 'trID','none');
detectionScaleColIdx = headerIndex(header, 'detectionScale','none');

colName_fittedxcorrValue = 'fittedxcorrValue';
[header, fittedCorrSigmaColIdx ] = addHeaderEntry(header,'fittedxcorrSigma');
[header, fittedCorrValueColIdx ] = addHeaderEntry(header,colName_fittedxcorrValue);

N = size(T,1);
T = sortrows(T,4); %sort by time

kernelType = 'log2';
sigma_all = 1.5:stepSizeInPixels:ceil(maxCSRadius / param.resolution);
kernels = MakeKernelPyramide( kernelType, sigma_all );


if(strcmpi(maxXCorrScoreSearchRadius, 'byDetectionScale'))
    if(detectionScaleColIdx > 0)
        radiusMax_ifNoDetectionScale = -1; %in which to search for the maximum xcorr-value in the xcorr-image
    else
        radiusMax_ifNoDetectionScale = 1; %in which to search for the maximum xcorr-value in the xcorr-image
    end
else
    radiusMax_ifNoDetectionScale = maxXCorrScoreSearchRadius; %in which to search for the maximum xcorr-value in the xcorr-image
end

% %PhD Thesis: Algorithms for detection and tracking of objects with
% %super-resolution in 3D Fluorescence Microscopy, page 12 and 58
% smoothingSigma = 0.21 * param.emissionWavelength / param.NA / param.resolution;

smoothingSigma = 0;

try
    sigma_initial  = param.objectDetection.MexicanHatSigma;
catch
    sigma_initial = [330 660 1300 2000] / param.resolution;
end

idx_initial   = unique(findClosestIndex(sigma_all, sigma_initial));
if(idx_initial(1) ~= 1)
    idx_initial = [1 idx_initial];
end

lastT = -1;
for i = 1 : N
    x = round(T(i,1));
    y = round(T(i,2));
    t = T(i,4);
    z = T(i,3);
    objID = T(i,objIDColIdx);
    
    if(radiusMax_ifNoDetectionScale < 0)
        detectionScale = T(i,detectionScaleColIdx);
        radiusMax = (1/detectionScale)-1;
    else
        radiusMax = radiusMax_ifNoDetectionScale;
    end
%    radiusMax = max(1, floor(T(i, xcorrSigmaColIdx) / 2));
    
    if(lastT ~= t)
        fprintf('%t = d / %d\n', t , T(N,4));
        allZinThisT = unique(T(T(:,4)==t,3));
        stack = loadPartialFrame([allZinThisT allZinThisT], t, 'full' );
        if(smoothingSigma > 0)
            for k = allZinThisT'
                stack(:,:,k) = imsmooth(stack(:,:,k),smoothingSigma);
            end
        end
        waitbar(i/N,mfilename);
    end
    lastT = t;
    I = stack(:,:,z);
    
    %old code: compute xcorr value for every single sigma
    if(getDebugLevel() >= 2)
        [maxCorrelationValue, maxI, maxJ] = CorrelationSeries( I, kernels, [y x], [radiusMax radiusMax]);
        maxCorrelationValue_gt = maxCorrelationValue;
    end
    
    %new optimized code for faster execution: compute xcorr value for selected sigmas and
    %iteratively refine the curve (it's a heuristic!!!, no garantee that the
    %correct global maximum will be found)
    try
        validValues         = zeros(1,length(sigma_all));
        maxCorrelationValue = zeros(1,length(sigma_all));

        validValues(idx_initial) = 1;
        [mcv, maxI_, maxJ_] = CorrelationSeries( I, kernels(idx_initial), [y x], [radiusMax radiusMax]);
        maxCorrelationValue(idx_initial) = mcv;
        maxI(idx_initial) = maxI_;
        maxJ(idx_initial) = maxJ_;
        while(1)
            newIdx = NextIndicesForBinaryMaximumSearch(maxCorrelationValue,validValues);
            newValuesCnt = 0;
            for j = 1 : length(newIdx)
                if(validValues(newIdx(j)) == 0)
                    [mcv, maxI_, maxJ_] = CorrelationSeries( I, kernels(newIdx(j)), [y x], [radiusMax radiusMax]);
                    maxCorrelationValue(newIdx(j)) = mcv;
                    maxI(newIdx(j)) = maxI_;
                    maxJ(newIdx(j)) = maxJ_;
                    validValues(newIdx(j)) = 1;
                    newValuesCnt = newValuesCnt + 1;
                end
            end
            if(newValuesCnt == 0)
                break
            end
        end
        ix_validValues = find(validValues == 1);
        sigma = sigma_all(ix_validValues);
        maxCorrelationValue = maxCorrelationValue(ix_validValues);
        maxI = maxI(ix_validValues);
        maxJ = maxJ(ix_validValues);        
    catch
        %old code: compute xcorr value for all sigmas
        [maxCorrelationValue, maxI, maxJ] = CorrelationSeries( I, kernels, [y x], [radiusMax radiusMax]);
        sigma = sigma_all;
    end
    
    [maxMaxCorrV, maxMaxCorrIdx] = max(maxCorrelationValue(:));
    x0 = maxJ(maxMaxCorrIdx);
    y0 = maxI(maxMaxCorrIdx);
    
    if(getDebugLevel() >= 2)
%     if(T(i,fittedCorrSigmaColIdx) ~= sigma(maxMaxCorrIdx))
        fn_ps = [poolDir() filesep 'FittedModelCorrelation.ps'];
        if(~exist('fig1','var'))
            fig1 = sfigure;
            maximize(fig1)            
        end

        clf(fig1)
        subplot(1,3,1:2)
        plot(sigma_all,maxCorrelationValue_gt,'-ob','LineWidth',3, 'MarkerSize',7); hold on
        ylim([0 1]);
        plot(sigma,maxCorrelationValue,'-ok','LineWidth',2, 'MarkerSize',11); hold on
        plot(sigma(maxMaxCorrIdx),maxCorrelationValue(maxMaxCorrIdx), 'd', 'MarkerSize', 11);
        plot([sigma(maxMaxCorrIdx) sigma(maxMaxCorrIdx)],ylim, '-r');
        ylim([0 1]);
        xlabel('sigma');
        ylabel('norm. x-corr value');
        
        if(trIDColIdx > 0)
            trID = T(i,trIDColIdx);
        else
            trID = -1;
        end
        title(sprintf('%s, t = %d, x = %03d, y = %03d,  z = %02d, objID = %d, trID = %d, radiusMax = %d',strrep(param.tag,'_','\_'),t,x,y,z,objID,trID, radiusMax));
        subplot(1,3,3)
        patch = imcropCentered3(I, [y0 x0], [41 41]);
        imshow(patch,[]);
        hold on
        cen = ceil(size(patch)/2);
        circ0   = plot_circle(cen(2),cen(1),sigma(maxMaxCorrIdx),'bresenham');
        plot(circ0(:,1),circ0(:,2), '-r');
        printFigureToPostScript(fig1, fn_ps, 1);
%     end
    end
    
    T(i,fittedCorrSigmaColIdx) = sigma(maxMaxCorrIdx);
    T(i,fittedCorrValueColIdx) = maxMaxCorrV;
    if(updatePosition2D)
        T(i,1) = x0;
        T(i,2) = y0;
    end
end
try
     close(fig1)
catch
end
waitbar();
[T, header] = ComputeRank(T, header, colName_fittedxcorrValue, 'desc');

if(isempty(filenameOut))
    varargout{1} = T;
    varargout{2} = header;
else
    fprintMatrix(filenameOut, T, header);
    varargout{1} = filenameOut;
end

end

function ix = findClosestIndex(x, a)
    %searches for each element ai in a the value in x which has minimum
    %difference to ai
    ix = zeros(size(a));
    for i = 1 : length(a)
        d = abs(x - a(i));
        [mind, minIx] = min(d);
        ix(i) = minIx;
    end
end