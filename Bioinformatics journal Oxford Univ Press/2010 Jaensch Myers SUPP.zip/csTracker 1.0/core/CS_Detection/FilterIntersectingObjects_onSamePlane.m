function [ varargout ] = FilterIntersectingObjects_onSamePlane( varargin )
%
%see also: FilterIntersectingObjects, FilterIntersectingObjects_atSamePixelLocation,
%          FilterIntersectingObjects_anisotropicSpace3D

fprintf('%s\n',mfilename);

if(nargin == 0)
    workingDir = [baseDir filesep 'yTUB-GFP8_GPR12_28hrsRNAi_1to8cellstage\workingDir\1'];
    filenameIn = 'candidates3D_noSameLoc_mexHat.txt';
    
    varargin{1} = workingDir;
    varargin{2} = filenameIn;
    setDebugLevel(1)
end



global param
[T, header, filenameIn, filenameOut, dirDebug] = processInput(varargin, '*noTooCl2D', mfilename);
if(isempty(T))
    varargout{1} = filenameOut;
    return;
end

[T, header] = ComputeDerivedParameters(T,header);
if(getDebugLevel() >= 2)
    T = T(ismember(T(:,headerIndex(header, 'objID')), [1568 1543 1536 1558]),:);
    %     T = T(ismember(T(:,headerIndex(header, 't')), [42]),:);
    %     setDebugLevel(1)
    fprintMatrix([getPathAndFilenameWithoutExtension(filenameIn) '_debugLevel2_filtered.txt'], T, header);
end

radiusColName  = 'fittedxcorrSigma';
qualityColName = 'fittedxcorrValue';
radiusColIdx  = headerIndex(header, radiusColName);
clusterFields = {'z', 't'};
computeDistanceAndRadiusMatrixFunction = @(R) (computeDistanceAndRadiusMatrix_withinSamePlane(R, radiusColIdx));

thresholdSmallObjects = 6;
radiusMultiplier      = .5;
radiusTransferFunction                 = @(r)(cutOffRadius(r, thresholdSmallObjects, radiusMultiplier));
[T, R] = FilterIntersectingObjects( T, header, qualityColName, clusterFields, computeDistanceAndRadiusMatrixFunction, radiusTransferFunction);

fn_debug = deleteFileIfExists([dirDebug filesep 'removedEntries.txt']);
if(~isempty(R))
    fprintMatrix(fn_debug,R,header);
end

if(isempty(filenameOut))
    varargout{1} = T;
    varargout{2} = header;
else
    fprintMatrix(filenameOut, T, header);
    varargout{1} = filenameOut;
end

if(nargin == 0)
    showTrackingMovie(filenameOut);
end

end

function r = cutOffRadius(r, threshold, radiusMultiplier)
r(r<=threshold) = 1;
r = radiusMultiplier*r; 
end

function [D,r ] = computeDistanceAndRadiusMatrix_withinSamePlane(R, radiusColIdx)
%all entries in R same z,t!!!
n = size(R,1);
D = ones(n,n)*inf;
for i = 1 : n-1
    for j = i+1 : n
        D(i,j) = norm(R(i,1:2) - R(j,1:2));
    end
end
r = R(:, radiusColIdx);
end