function [score, idxROI] = ComputeCorrelationScore( I, pattern, y, x, aFunction )

if(nargin < 5)
    aFunction = @sum;
end

[R C] = size(pattern);

Hy = (R-1)/2;
Hx = (C-1)/2;
idxROI = [max(1,y-Hy),min(size(I,1),y+Hy),max(1,x-Hx),min(size(I,2),x+Hx)];
clip = I(idxROI(1):idxROI(2),idxROI(3):idxROI(4));

if(size(clip,1) ~= R || size(clip, 2) ~= C)
    clip = embedMatrix(clip,[R,C]);
end

if(getDebugLevel()>=2)
  
    Ic = OverlayMask(clip, pattern, 0, 'white', 1, 1 );
    Ic = embedMatrix(Ic,[61,61]);
    dirDebug = getDebugDir();
    writeTIFF(im2uint16(Ic), makeFilenameUnique([dirDebug filesep 'ellipse.tif']));
    if(getDebugLevel()>=3)
    figure, imshow(Ic,[]);
    end
end

clip = clip .* pattern;
score = aFunction(clip(:));

