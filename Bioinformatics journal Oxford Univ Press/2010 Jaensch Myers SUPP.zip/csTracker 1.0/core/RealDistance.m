function [ dist ] = RealDistance( p1, p2, zStretchingCorrection )
%REALDISTANCE computes the distance between points p1 = (x1, y1[, z1]) and p2
%= (x2, y2[, z2]) in real coordinates
%
%input:     p1, p2                  - Nx2 or Nx3 matrices
%           zStretchingCorrection   - default: 1.0
%           
%output:    dist    - Nx1 matrix

global param;
if(nargin < 3)
    zStretchingCorrection = 1.0;
end

if(length(p1(1,:))==3 && length(p2(1,:))==3)
    dist = sqrt(((p1(:,1) - p2(:,1)) * param.resolution).^2  + ((p1(:,2) - p2(:,2))* param.resolution).^2  + ((p1(:,3) - p2(:,3))* param.zResolution*zStretchingCorrection).^2 );
elseif(length(p1(1,:))==2 && length(p2(1,:))==2)
    dist = sqrt(((p1(:,1) - p2(:,1)) * param.resolution).^2  + ((p1(:,2) - p2(:,2))* param.resolution).^2);
else
    error('input vectors must have either 2 or 3 elements');
end
