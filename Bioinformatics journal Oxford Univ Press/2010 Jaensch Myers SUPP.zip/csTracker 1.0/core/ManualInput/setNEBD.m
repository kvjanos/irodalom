function fn = setNEBD(workingDir,fn, cellName_NEBD_list, propertiesUpdateMode)
% sets NEBD-values for the given cells and writes the NEBD info 
% to the properties-file if desired
%
% input: cellName_NEBD_list   - cell array of alternating cellname and NEBD-frame
%                               example: {'AB',56, 'ABa', 99}
%        propertiesUpdateMode - 'none'   ==> properties.xml will not be changed
%                               'update' ==> given NEBD will be updated in properties.xml
%                                            however, NEBD of cells not specified in cellName_NEBD_list 
%                                            will be left unchanged in properties.xml
%                               'overwrite' ==> existing NEBD-info in properties.xml is completely 
%                                               overwritten by cellName_NEBD_list
%                               
%
% example: updateNEBD_general(workingDir,fn, {'AB',56, 'ABa', 99}, 'update')

loadGlobalParams(workingDir);

if(any(strcmpi(propertiesUpdateMode, {'update', 'overwrite'})))
    props = loadProperties();
    updateProperties = 1;
    if(strcmpi(propertiesUpdateMode, 'overwrite'))
        props = rmfieldIfExists(props, 'NEBD');
    end
else
    updateProperties = 0;
end

idx = 1;
for i = 1 : 2 : length(cellName_NEBD_list)
    cellName    = cellName_NEBD_list{i};
    NEBD        = cellName_NEBD_list{i+1};
    numCellName = cellnameToNumericCellname(cellName);
    strUpdate{idx} = ['UPDATE ' fn ' SET NEBD = ' num2str(NEBD) ' WHERE cellname == ' num2str(numCellName)];
    idx = idx + 1;
    if(updateProperties)
        props.NEBD.(cellName) = NEBD;
    end
end
fn = csql_processUpdate( workingDir, strUpdate );

if(updateProperties)
    saveProperties(props);
end
end