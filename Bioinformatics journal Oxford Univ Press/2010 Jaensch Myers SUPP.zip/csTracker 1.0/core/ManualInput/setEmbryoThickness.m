function setEmbryoThickness( workingDir )

global param;
loadGlobalParams(workingDir);

[ maxYPrj, fn_maxyprj ] = loadMaxYProjection('getFilenameOnly');
winopen(fn_maxyprj);

thickness = input('embryo thickness in pixel: ', 's');
p = loadProperties();
p.embryoThicknessInPixels = thickness;
saveProperties(p);


end

