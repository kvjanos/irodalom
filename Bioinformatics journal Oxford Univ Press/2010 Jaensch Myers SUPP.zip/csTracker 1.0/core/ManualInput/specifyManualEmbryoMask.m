function [ fn_mask ] = specifyManualEmbryoMask( movieDir )
% see also: prepareImageStack, saveManualEmbryoMask, loadManualEmbryoMask

% lets the user draw a ROI on the max-max-projection to specify the embryo ROI
% prepareImageStack.m ==> checks whether a manual mask exists and if so
%                         uses this mask instead of segmenting the images automatically
%
if(nargin == 0)
    movieDir = [baseDir filesep 'yTUB-GFP6_ANI2_24hrsRNAi_1to2cellstage'];
    movieDir = [baseDir filesep 'Beads1000-RFP5_Alexa488_noEmbryo'];
    movieDir = [baseDir filesep 'yTUB-GFP6_WT_Alexa488'];
    movieDir = [baseDir filesep 'Beads1000-RFP29_Alexa488'];
    movieDir = [baseDir filesep 'yTUB-GFP4_GFP_13-14hrsRNAi'];
    
end
global pathHomeDir;
pathHomeDir = movieDir;

pattern = '*meanProjection*.tif';
D = dir([pathHomeDir filesep pattern]);
if(isempty(D))
    error('maximum projection of original stack in %s not found',pathHomeDir);
else
    if(length(D)>1)
        warning('multiple images matching "%s" found in %s',pattern,pathHomeDir);
    end
    fn = [pathHomeDir filesep D(1).name];
    stack = imreadStackDouble(fn);
    maxprj = max(stack,[],3);
    
    manualEmbryoMask = loadManualEmbryoMask();
    if(~isempty(manualEmbryoMask))
        maxprj = OverlayMask(maxprj, manualEmbryoMask);
    end
    [embryoMask,fig1] = userInputMarker(maxprj, sprintf('%s',strrep(strrep(fn,'\','\\'),'_','\_')));
    fn_mask = saveManualEmbryoMask(embryoMask);
    close(fig1); 
end


end

function [marker, fig1] = userInputMarker(img, txt_title)
   
    marker = zeros(size(img));
    cnt = 0;
    img = overlayMask(img, marker);
    fig1 = figure, imshow(img, [])
    title(txt_title);
    myWait(.1)
    while(1)
        [bw,xi,yi] = roipoly(imadjust(img));
        title(txt_title);
        if(length(xi) < 3)
            break
        end
        cnt = cnt+1;
        marker = max(marker,bw);
        img = overlayMask(img, marker);
        break
    end
    if(cnt == 0)
        marker = [];
    end
end