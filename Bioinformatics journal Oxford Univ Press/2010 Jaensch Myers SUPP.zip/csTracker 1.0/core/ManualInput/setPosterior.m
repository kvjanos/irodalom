function posterior_position = setPosterior( workingDir, varargin )

if(nargin == 0)
    workingDir = [baseDir filesep 'RSA1-GFP4_WT_8to16cellstage\workingDir\1'];
    varargin = {'timeout',10};
end
timeout = getVarargin(varargin, 'timeout', 30);

global param;
loadGlobalParams(workingDir);
setImageSource('type','smoothed');

maxPrj = loadMaxProjection(1,min(12,param.lastTimepoint));
I = max(maxPrj,[],3);

p = loadProperties();

fig2=figure;
maximize(fig2);
myMontage(maxPrj,0, {strrep(param.tag,'_','\_')});

fig1=figure;
I = imadjust(I);
imshow(I,[]);
hold on
if(isfield(p,'posterior'))
    plot(p.posterior(1), p.posterior(2),'dr','MarkerSize',11);
    text(p.posterior(1), p.posterior(2),'posterior');
end
if(isfield(p,'anterior'))
    plot(p.anterior(1), p.anterior(2),'or','MarkerSize',11);
    text(p.anterior(1), p.anterior(2),'anterior');
end
title(sprintf('%s\nPlease klick on the posterior pole of the embryo',strrep(param.tag,'_','\_')));

myWait(.5);
maximize(fig1);

try
    %[x,y] = ginput(1);
    %posterior_position = round([x y]);
    posterior_position = round(mouseinput_timeout(timeout, gca));  
    if(isempty(posterior_position))
        error('manual specification of the posterior pole has been terminated by timeout');
    end
    
    clf
    imshow(I,[]);
    hold on
    title(sprintf('%s',strrep(param.tag,'_','\_')));
    plot(posterior_position(1),posterior_position(2),'or','MarkerSize',11);
    myWait(.5);
    
    p.posterior = posterior_position;
    saveProperties(p);
    loadGlobalParams(workingDir, 1)
    fprintf('working directory: %s\n', workingDir);
    fprintf('posterior information successfully saved to the properties file\n');
    close(fig1);
    close(fig2);
catch
    posterior_position = [];
    printDebugStack(lasterror);
end


