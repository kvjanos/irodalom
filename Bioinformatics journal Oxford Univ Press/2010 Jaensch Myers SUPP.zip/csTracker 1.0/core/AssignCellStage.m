function [ varargout ] = AssignCellStage( varargin )
% assigns the cell stage to each centrosome
% requires cell names


if(nargin == 0)
    workingDir = [baseDir filesep 'SPD2-GFP3_WT_4to8cellstage\workingDir\9'];
    filenameIn = 'candidates3D_noTooClPlane_mexHat_GFit2D_noTooCl3D.txt';
    
    workingDir = [baseDir filesep 'SPD2-GFP2_WT_4to8cellstage\workingDir\9'];
    filenameIn = 'candidates3D_noTooClPlane_mexHat_GFit2D.txt';

        
    varargin{1} = workingDir;
    varargin{2} = filenameIn;
end
fprintf('%s\n',mfilename);

global param;
[T, header, filenameIn, filenameOut] = processInput(varargin, 'cellst');
if(isempty(T))
    varargout{1} = filenameOut;
    return;
end

cellNameColIdx                  = headerIndex(header, 'cellName');
[header, cellstageColIdx]    = addHeaderEntry(header, 'cellstage');
uniqueCellnames = unique(T(:,cellNameColIdx));
for i = 1 : length(uniqueCellnames)
    num_cellname = uniqueCellnames(i);
    try
        treeDepth = numericCellnameToTreeDepth( num_cellname );
        T(T(:,cellNameColIdx) == num_cellname, cellstageColIdx) = 2^(treeDepth-1);
    catch
        T(T(:,cellNameColIdx) == num_cellname, cellstageColIdx) = -1;
    end
end

if(isempty(filenameOut))
    varargout{1} = T;
    varargout{2} = header;
else
    fprintMatrix(filenameOut, T, header);
    varargout{1} = filenameOut;
end