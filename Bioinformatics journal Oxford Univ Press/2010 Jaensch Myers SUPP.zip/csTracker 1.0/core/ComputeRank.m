function [ varargout ] = ComputeRank( varargin )
% sorts the data by the given column and assigns the rank in the respective
% order to each row indivually for each time point

%syntax:
%filenameOut = ComputeRank( workingDir, filenameIn, columnName, asc_or_desc, skipIfFileoutExists)
%filenameOut = ComputeRank( workingDir, filenameIn, columnName, asc_or_desc)
%[T, header] = ComputeRank( T, header, columnName, asc_or_desc, skipIfFileoutExists)
%[T, header] = ComputeRank( T, header, columnName, asc_or_desc)

if(nargin == 0)
    workingDir  = [baseDir filesep 'yTUB-GFP1_AMA1_24hrsRNAi\workingDir\1'];
    workingDir = [baseDir filesep 'SPD5-YFP8_WT_multicell\workingDir\8'];
    filenameIn  = 'candidates_noTooClPlane_zStbl_zGrps_zSplit_hotSpots_GFit2D_mexHat.txt'; 
    columnName  = 'fittedxcorrValue';
    asc_or_desc = 'desc';
    
    varargin{1} = workingDir;
    varargin{2} = filenameIn;
    varargin{3} = columnName;
    varargin{4} = asc_or_desc;
end
fprintf('%s\n',mfilename);


columnName  = varargin{3};
asc_or_desc = varargin{4};
varargin(3:4) = [];

% psFilename = [poolDir() filesep 'rank_of_' columnName '.ps'];
psFilename = [];
global param
[T, header, filenameIn, filenameOut] = processInput(varargin, 'rank');
if(isempty(T))
    varargout{1} = filenameOut;
    return;
end

colIdx                  = headerIndex(header, columnName);
[header, rankColIdx]    = addHeaderEntry(header, ['rank_of_' columnName]);


listOfTables = clusterTable( T, 4 );
T = [];
fig1 = sfigure;
for i = 1 : length(listOfTables)
    E = listOfTables{i}; %data at timepoint ti
    E = sortrows(E,colIdx);
    if(strcmpi(asc_or_desc, 'asc'))
        rank = 1:size(E,1);
    elseif(strcmpi(asc_or_desc, 'desc'))
        rank = size(E,1):-1:1;
    else
        error('Unknown sorting order %s. Allowed values are ''asc'' and ''desc''',asc_or_desc);
    end
    E(:,rankColIdx) = rank';
    T = [T;E];
    if(~isempty(psFilename))
        clf(fig1)
        plot(E(:,rankColIdx),E(:,colIdx));
        xlabel('rank');
        ylabel(columnName);
        try
            fn = strrep(getFilenameWithExtension(filenameIn),'_','\_');
        catch
            fn = ' ';
        end
        title(sprintf('%s\n%s\nt=%d',strrep(param.tag,'_','\_' ),fn,E(1,4)));
        try
            printFigureToPostScript(fig1, psFilename, 1);
        catch
        end
    end
    
end
close(fig1)

if(isempty(filenameOut))
    varargout{1} = T;
    varargout{2} = header;
else
    fprintMatrix(filenameOut, T, header);
    varargout{1} = filenameOut;
end