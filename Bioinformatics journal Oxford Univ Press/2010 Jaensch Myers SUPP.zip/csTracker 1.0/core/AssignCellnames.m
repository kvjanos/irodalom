function [ varargout ] = AssignCellnames( varargin )
% assigns a name to each cell
% required are: position of the posterior pole
%               parentTrID (i.e. the tracking tree)
%               side (anterior / posterior for each centrosome)
%
% see also: AssignPosteriorAnterior, FindPosteriorPole




if(nargin == 0)
    workingDir = [baseDir filesep 'yTUB-GFP6_SAS4_30-33hrsRNAi_2to4cellstage\workingDir\8'];
    filenameIn = 'tracksComplete_pairs_trTree_side.txt';
    setDebugLevel(1)
    
    varargin{1} = workingDir;
    varargin{2} = filenameIn;
end
fprintf('%s\n',mfilename);

global param;
[T, header, filenameIn, filenameOut] = processInput(varargin, 'cName');
if(isempty(T))
    varargout{1} = filenameOut;
    return;
end
[T, header] = ComputeDerivedParameters(T, header);

trIDColIdx        = headerIndex(header, 'trID');
cellIDColIdx      = headerIndex(header, 'cellID');
parentTrIDColIdx  = headerIndex(header, 'parentTrID');
treeDepthColIdx   = headerIndex(header, 'treeDepth');
sideColIdx        = headerIndex(header, 'side');

[header, cellNameColIdx, columnHasBeenAdded, T ] = addHeaderEntry( header, 'cellName', -1, T );

if(isfield(param, 'posterior'))
    p_posterior = param.posterior;
else
    p_posterior = FindPosteriorPole(fileparts(filenameIn), filenameIn);
end
if(isempty(p_posterior))
    error('error:posteriorPositionNotAvailable','position of the posterior pole is not available. cannot determine centrosome identities');
end

cellIDs_initialCellstage = CellIDsOfInitialCellstage(T, header);
initialCellStage         = length(cellIDs_initialCellstage);

%% assign names to the initial cells (depends on which cell stage the movie starts at)

if(initialCellStage == 1)
    %movie starts at 1-cell stage ==> P0
    T(ismember(T(:,cellIDColIdx),cellIDs_initialCellstage), cellNameColIdx) = cellnameToNumericCellname('P0');
elseif(initialCellStage == 2)
    %movie starts at 2-cell stage
    % - the cell with the later cs-pair is P1
    cellID2displacement = SortCellsByTimeUsingSpindleLength( T, header, cellIDs_initialCellstage );
    %the first cell is AB
    %the last cell is P1
    T(T(:,cellIDColIdx) == cellID2displacement(1,1), cellNameColIdx) = cellnameToNumericCellname('AB');
    T(T(:,cellIDColIdx) == cellID2displacement(2,1), cellNameColIdx) = cellnameToNumericCellname('P1');
elseif(initialCellStage == 4)
    cellID2displacement = SortCellsByTimeUsingSpindleLength( T, header, cellIDs_initialCellstage );
    %the first two cells are ABa and ABp
    %the last two cells are EMS and P2
    
    %compute mean position over the entire trajectory
    p_cell1 = mean(T(ismember(T(:,cellIDColIdx),cellID2displacement(1,1)), 1:2)); %ABa or ABp
    p_cell2 = mean(T(ismember(T(:,cellIDColIdx),cellID2displacement(2,1)), 1:2)); %ABa or ABp
    p_cell3 = mean(T(ismember(T(:,cellIDColIdx),cellID2displacement(3,1)), 1:2)); %EMS or P2
    p_cell4 = mean(T(ismember(T(:,cellIDColIdx),cellID2displacement(4,1)), 1:2)); %EMS or P2
    
    if(norm(p_cell1 - p_posterior) < norm(p_cell2 - p_posterior)) %cell1 closer to posterior pole than cell2
        cellID_ABp = cellID2displacement(1,1);
        cellID_ABa = cellID2displacement(2,1);
    else
        cellID_ABp = cellID2displacement(2,1);
        cellID_ABa = cellID2displacement(1,1);
    end
    
    if(norm(p_cell3 - p_posterior) < norm(p_cell4 - p_posterior)) %cell3 closer to posterior pole than cell4
        cellID_P2  = cellID2displacement(3,1);
        cellID_EMS = cellID2displacement(4,1);
    else
        cellID_P2  = cellID2displacement(4,1);
        cellID_EMS = cellID2displacement(3,1);
    end
    T(T(:,cellIDColIdx) == cellID_ABa, cellNameColIdx) = cellnameToNumericCellname('ABa');
    T(T(:,cellIDColIdx) == cellID_ABp, cellNameColIdx) = cellnameToNumericCellname('ABp');
    T(T(:,cellIDColIdx) == cellID_EMS, cellNameColIdx) = cellnameToNumericCellname('EMS');
    T(T(:,cellIDColIdx) == cellID_P2 , cellNameColIdx) = cellnameToNumericCellname('P2');
elseif(initialCellStage == 8)
    %movie starts at 8-cell stage ==> cellst8
    T(ismember(T(:,cellIDColIdx),cellIDs_initialCellstage), cellNameColIdx) = cellnameToNumericCellname('cellst8');
elseif(initialCellStage > 8)
    %movie starts at 8-cell stage, but for more centrosome-pairs there is
    %no parent centrosome (for some reason not visible in the movie)
    cellID2displacement = SortCellsByTimeUsingSpindleLength( T, header, cellIDs_initialCellstage );
    %assign cellst8 to the first 8 centrosome pairs
    T(ismember(T(:,cellIDColIdx),cellID2displacement(1:8,1)), cellNameColIdx) = cellnameToNumericCellname('cellst8');
    %assign cellst16 to the following 16 centrosome pairs
    if(size(cellID2displacement,1) > 8)
        T(ismember(T(:,cellIDColIdx),cellID2displacement(9:min(end,24),1)), cellNameColIdx) = cellnameToNumericCellname('cellst16');
    end
elseif(initialCellStage < 8 && initialCellStage > 4)
    %movie starts at 8-cell stage, but not all centrosome have been
    %tracked correctly
    T(ismember(T(:,cellIDColIdx),cellIDs_initialCellstage), cellNameColIdx) = cellnameToNumericCellname('cellst8');
end

%% propagate cellnames through the tracking tree
allTreeDepths = unique(T(:,treeDepthColIdx));
for treeDepth = allTreeDepths'
    if(treeDepth < 1)
        continue; %track is not in the tracking tree ==> ignore
    elseif(treeDepth == 1)
        continue; %cell names of the cells on the upper most tree level have been assigned above
    else
        R = T(T(:,treeDepthColIdx) == treeDepth, :);
        uniqueParentTrID = unique(R(:,parentTrIDColIdx));
        for parentID = uniqueParentTrID'
            ix_children = T(:,parentTrIDColIdx) == parentID;
            ix_parent   = T(:,trIDColIdx) == parentID;
            num_cellnameOfParent = unique(T(ix_parent, cellNameColIdx));
            num_sideOfParent     = unique(T(ix_parent, sideColIdx));
            if(num_cellnameOfParent <= 0)
                break;
            end
            num_cellnameOfParent
            [cellName_posterior, cellname_anterior] = getChildCellnames(numericCellnameToCellname(num_cellnameOfParent));
            if(isempty(cellName_posterior))
                break;
            end
            if(num_sideOfParent == 1) %posterior
                num_cellNameOfChildren = cellnameToNumericCellname(cellName_posterior);
            else %anterior
                num_cellNameOfChildren  = cellnameToNumericCellname(cellname_anterior);
            end
            T(ix_children,cellNameColIdx) = num_cellNameOfChildren;
        end
    end
end
if(isempty(filenameOut))
    varargout{1} = T;
    varargout{2} = header;
else
    fprintMatrix(filenameOut, T, header);
    varargout{1} = filenameOut;
    if(nargin == 0)
        showTrackingMovie(filenameOut,0)
    end
end
end

function [cellName_posterior, cellname_anterior] = getChildCellnames(parentCellName)
cellName_posterior = '';
cellname_anterior = '';
if(strcmpi(parentCellName, 'P0'))
    cellName_posterior = 'P1';
    cellname_anterior  = 'AB';
elseif(strcmpi(parentCellName, 'P1'))
    cellName_posterior = 'P2';
    cellname_anterior  = 'EMS';
elseif(strcmpi(parentCellName, 'AB'))
    cellName_posterior = 'ABp';
    cellname_anterior  = 'ABa';
    % elseif(any(strcmpi(parentCellName, {'ABa','ABp','EMS','P1'})))
    %     cellName_posterior = 'cellst8';
    %     cellname_anterior  = 'cellst8';
    % elseif(strcmpi(parentCellName, 'cellst8'))
    %     cellName_posterior = 'cellst16';
    %     cellname_anterior  = 'cellst16';
elseif(strcmpi(parentCellName, 'P2'))
    cellName_posterior = 'P3';
    cellname_anterior  = 'C';
elseif(strcmpi(parentCellName, 'EMS'))
    cellName_posterior = 'E';
    cellname_anterior  = 'MS';
elseif(strcmpi(parentCellName, 'ABp'))
    cellName_posterior = 'ABpr';
    cellname_anterior  = 'ABpl';
elseif(strcmpi(parentCellName, 'ABa'))
    cellName_posterior = 'ABar';
    cellname_anterior  = 'ABal';
elseif(strcmpi(parentCellName, 'P3'))
    cellName_posterior = 'P4';
    cellname_anterior  = 'D';
elseif(strcmpi(parentCellName, 'C'))
    cellName_posterior = 'Cp';
    cellname_anterior  = 'Ca';
elseif(strcmpi(parentCellName, 'E'))
    cellName_posterior = 'intestine';
    cellname_anterior  = 'intestine';
elseif(strcmpi(parentCellName, 'MS'))
    cellName_posterior = 'MSp';
    cellname_anterior  = 'MSa';
elseif(strcmpi(parentCellName, 'ABpr'))
    cellName_posterior = 'ABprp';
    cellname_anterior  = 'ABpra';
elseif(strcmpi(parentCellName, 'ABpl'))
    cellName_posterior = 'ABplp';
    cellname_anterior  = 'ABpla';
elseif(strcmpi(parentCellName, 'ABar'))
    cellName_posterior = 'ABarp';
    cellname_anterior  = 'ABara';
elseif(strcmpi(parentCellName, 'ABal'))
    cellName_posterior = 'ABalp';
    cellname_anterior  = 'ABala';
elseif(any(strcmpi(parentCellName, {'P3','C','E','MS','ABpl','ABpr','ABal','ABar','cellst8'})))
    cellName_posterior = 'cellst16';
    cellname_anterior  = 'cellst16';
elseif(strcmpi(parentCellName, 'cellst16'))
    cellName_posterior = 'cellst32';
    cellname_anterior  = 'cellst32';
elseif(strcmpi(parentCellName, 'cellst32'))
    cellName_posterior = 'cellst64';
    cellname_anterior  = 'cellst64';
end
end