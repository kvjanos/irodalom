function fn_intprj = ComputeIntensityProjection( workingDir, prjFunc, dimension, imgSrcType, recompute )
% computes a max- or mean- intensity projection along the given dimension
% for the entire raw stack
%
% input: workingDir
%        prjFunc    - 'max', 'mean', 'median'
%        dimension  - either 'x', 'y' or 'z'
%        imgSrcType - 'raw', 'smoothed' (other values are possible
%                     depending on what image types are available for the
%                     working directory)
%        recompute  - 1 ==> projection will be deleted and recomputed if
%                           already exists
%see also: loadMaxYProjection, Projection

if(nargin == 0)
    workingDir = [baseDir filesep 'SPD5-YFP1_multicell\workingDir\1'];
    prjFunc       = 'max';
    dimension     = 'x';
end

if(strcmpi(dimension, 'x'))
    d = 2;
elseif(strcmpi(dimension, 'y'))
    d = 1;
elseif(strcmpi(dimension, 'z'))
    d = 3;
else
    error('dimension must either be ''x'', ''y'' or ''z''');
end

if(nargin < 5)
    recompute = 1;
end

global param;
loadGlobalParams(workingDir);
setImageSource('type', imgSrcType);
fn_intprj = [workingDir filesep prjFunc upper(dimension) 'Prj.tif'];
if(~recompute && exist(fn_intprj,'file'))
    return
end
deleteFileIfExists(fn_intprj);

fprintf('computing %s %s-projection on %s images\n',prjFunc,dimension, imgSrcType);
fprintfNTimes( '.', param.lastTimepoint, 1 )
for t = 1 : param.lastTimepoint
    fprintf('.');
    stack = loadPartialFrame([1, param.zCount], t);
    if(strcmpi(prjFunc, 'max'))
        intPrj = squeeze(max(stack,[],d));
    elseif(strcmpi(prjFunc, 'mean'))
        intPrj = squeeze(mean(stack,d));
    elseif(strcmpi(prjFunc, 'median'))
        intPrj = squeeze(median(stack,d));
    else
        error('unknown projection prjFunction %s', prjFunc);
    end
    imwrite(im2uint16(intPrj), fn_intprj, 'Compression', 'none', 'WriteMode', 'append');
end
fprintf('\n');
end

