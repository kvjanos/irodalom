function [ fnOut ] = DisplayBrightestPlaneOnMaxYProjection( workingDir, filenameIn )

if(nargin == 0)
    workingDir = [baseDir filesep 'yTUB-GFP1_Background\workingDir\1'];
    workingDir = [baseDir filesep 'SAS4-GFP_WT_longBG2\workingDir\1'];
    workingDir = [baseDir filesep 'yTUB-GFP29_WT_2to4cellstage\workingDir\1'];
    
    filenameIn = 'finalTrackingResults_brPl.txt';
    
    workingDir = [baseDir filesep 'Beads1000-RFP4_Alexa488\workingDir\1'];
    workingDir = [baseDir filesep 'Beads1000-RFP2_Alexa488_noEmbryo\workingDir\1'];
    filenameIn = finalTrackingFile();
    
    workingDir = [baseDir filesep 'RSA1-GFP1_WT_1to2cellstage\workingDir\9'];
    filenameIn = completeTracksFile();
    
    workingDir = [baseDir filesep 'beads4_100nm_onSlide\workingDir\1'];
    filenameIn = finalTrackingFile();

    workingDir = [baseDir filesep 'yTUB-HIST-GFP4_WT_long\workingDir\1'];
    workingDir = [baseDir filesep 'yTUB-GFP3_htrFRAP\workingDir\1'];
    
    filenameIn = 'tr.txt';
    
    workingDir = [baseDir filesep 'yTUB-GFP1_WT_8to16cellstage\workingDir\1'];
    filenameIn = finalTrackingFile();
end

fnOut        = [workingDir filesep 'maxYPrjBrightestPlane.tif'];
fnOut_GFit3D = [workingDir filesep 'maxYPrjBrightestPlane_GFit3D.tif'];
filenameIn = addDirectoryToFilename(workingDir, filenameIn);

global param;
loadGlobalParams(workingDir);

[T, header] = loadList(filenameIn);


maxyprj = loadMaxYProjection();

trIDColIdx = headerIndex(header, 'trID', 'none');
zEmbryoStartColIdx = headerIndex(header, 'zEmbryoStart', 'none');
validColIdx = headerIndex(header, 'valid', 'none');
if(validColIdx > 0)
    T = T(T(:,validColIdx) == 1,:);
end

maxyprj_withCentrosomePositions = MarkCentrosomesInYPrj(maxyprj, T, 1, 3, 4, trIDColIdx);
if(zEmbryoStartColIdx > 0)
    maxyprj_withCentrosomePositions = MarkEmbryoStartInYPrj(maxyprj_withCentrosomePositions, T, zEmbryoStartColIdx);
end
WriteStackAsMultiTIFF(im2uint16(maxyprj_withCentrosomePositions), fnOut);

% meanX3DcolIdx = headerIndex(header, 'meanX3D', 'none');
% meanZ3DcolIdx = headerIndex(header, 'meanZ3D', 'none');
% if(meanX3DcolIdx > 0)
%     maxyprj_withCentrosomePositions = MarkCentrosomesInYPrj(maxyprj, T, meanX3DcolIdx, meanZ3DcolIdx, 4);
%     WriteStackAsMultiTIFF(im2uint16(maxyprj_withCentrosomePositions), fnOut_GFit3D);
% end
end

function maxyprj_withEmbryoStart = MarkEmbryoStartInYPrj(maxyprj, T, zEmbryoStartColIdx)
maxyprj_withEmbryoStart = maxyprj;
uniqueT = unique(T(:,4));
for t = uniqueT'
    R = T(T(:,4) == t,:);
    z_embryoStart = R(1,zEmbryoStartColIdx);
    I = maxyprj_withEmbryoStart(:,:,t);
    
    len = 20;
    I(1:min(len, size(I,1)),    z_embryoStart) = 0;
    I(max(1,size(I,1)-len):end, z_embryoStart) = 0;
    maxyprj_withEmbryoStart(:,:,t) = I;
end
end

function maxyprj_withCentrosomePositions = MarkCentrosomesInYPrj(maxyprj, T, xColIdx, zColIdx, tColIdx, trIDColIdx)
maxyprj_withCentrosomePositions = maxyprj;
for i = 1 : size(T,1)
    x = round(T(i,xColIdx));
    z = round(T(i,zColIdx));
    t = T(i,tColIdx);
    if(trIDColIdx > 0)
        trID = T(i,trIDColIdx);
    else
        trID = -1;
    end
    I = maxyprj_withCentrosomePositions(:,:,t);
    
    I(max(1,x-20):min(size(I,1),x+20), z) = 0;
    if(trID > 0)
        printOnImage_init(I);
        text(z-3,x-12,sprintf('%d',trID), 'Color', 'w');
        I = printOnImage_finish(I,1);
    end
    maxyprj_withCentrosomePositions(:,:,t) = I;
end
end