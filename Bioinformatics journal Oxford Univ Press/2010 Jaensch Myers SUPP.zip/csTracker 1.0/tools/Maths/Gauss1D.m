function [ y ] = Gauss1D( x, mean, sigma )
    y = (1 / (sigma * sqrt(2*pi))) *  exp(-.5*((x-mean)/sigma).^2);
end
