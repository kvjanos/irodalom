function [ alpha ] = intersectionAngleOfTwoLines2D( p1,p2,q1,q2 )
% alpha = the intersection angle of the two lines defined by (p1,p2) and (q1,q2)
% 0 <= alpha < 180
p = p1(:)-p2(:);
q = q1(:)-q2(:);

alpha = acosd(p'*q / (norm(p)*norm(q)));




end

