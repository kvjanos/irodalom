function [ flag ] = ccw( p1, p2, q )
% 1  if p1-p2-q is a ccw turn
%-1  if p1-p2-q is a cw turn
% 0  if p1, p2, q are colinear

% 1: ccw
%  p1---------p2
%            /
%           /
%          q
%
%
% -1: cw          
%          q
%           \
%            \
%  p1---------p2
% 
%
% 0: colinear
% 
%   p1---------p2---q
%
%debug:
% figure, plot([p1(1),p2(1)],[p1(2),p2(2)],'o-'); hold on; plot([p2(1),q(1)],[p2(2),q(2)],'o--');
% text(p1(1),p1(2), 'p1','background','b');
% text(p2(1),p2(2), 'p2','background','b');
% text(q(1),q(2), 'q','background','b');

dx1 = p2(1) - p1(1); 
dy1 = p2(2) - p1(2);
dx2 = q(1)  - p1(1); 
dy2 = q(2)  - p1(2);
if (dx1*dy2 > dy1*dx2) 
    flag = 1; 
elseif (dx1*dy2 < dy1*dx2) 
    flag = -1; 
else
    flag = 0;
end


end

