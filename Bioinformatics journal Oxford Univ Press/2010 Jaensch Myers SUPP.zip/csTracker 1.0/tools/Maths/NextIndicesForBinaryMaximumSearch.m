function [newIdx] = NextIndicesForBinaryMaximumSearch(y,b)
% determines all local maxima in y(b==1) and returns the indices halfway between a
% local maximum and its next left and right neighbour
% 
% this function can be used to heuristically find a maximum in a vector
% without having to compute all values in the vector
%
% input:
% y - vector of real values
% b - binary vector with length(y) elements indicating which values in y
%     have already been computed
%
% output:
% newIdx - indices where values need to be computed
%

    newIdx = [];
    idx = find(b == 1); %where do we have valid values?
    y0 = y(idx);
    localMaxIdx = find(localmaxmin(y0));
    for k = 1 : length(localMaxIdx)
        p = localMaxIdx(k);
        if(p > 1)
            newIdx(end+1) = ceil((idx(p-1)+idx(p))/2);
        else
             if(b(1) == 0)
                newIdx(end+1) = 1;
            end
        end
        if(p < length(idx))
            newIdx(end+1) = ceil((idx(p+1)+idx(p))/2);
        else
            if(b(length(y)) == 0)
                newIdx(end+1) = length(y);
            end
        end
    end
end