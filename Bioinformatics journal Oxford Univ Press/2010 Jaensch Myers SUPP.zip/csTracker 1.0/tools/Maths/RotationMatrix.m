function [ R ] = RotationMatrix( alpha )

c = cosd(alpha);
s = sind(alpha);

R = [c -s;s c];
