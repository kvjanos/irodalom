function y = derivativeOfVector(x)
    y = zeros(length(x)-2,1);
    for i = 2 : length(x)-1
        y(i-1) = x(i+1) - x(i-1);
    end
end