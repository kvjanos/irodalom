function [value] = ComputeGauss_nD( x, mean, covar )
n = length(x);
diff = x-mean;

%http://de.wikipedia.org/wiki/Normalverteilung
value = (1/((2*pi)^(n/2)*det(covar)^(1/2))) * exp((-1/2) * diff' * inv(covar) * diff);
