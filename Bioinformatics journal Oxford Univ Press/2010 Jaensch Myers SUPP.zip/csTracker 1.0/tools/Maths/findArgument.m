function [ x ] = findArgument( f, y, mode )
%finds for the given y-value the x-value where y = f(x)
%
% f    - a value table, first column x-values, second column y-values
%        f is assumed to be piecewise linear
% y    - an arbitrary y-value
% mode - 'all' (default), 'first', 'last'

equal   = f(:,2) == y;
greater = f(:,2) > y;
less    = f(:,2) < y;

h_down = (greater(1:end-1) | equal(1:end-1)) & less(2:end);
h_up   = (less(1:end-1)    | equal(1:end-1)) & greater(2:end);

h = find(h_down | h_up);

if(nargin < 3)
    mode = 'all';
end

if(strcmpi(mode, 'last'))
    h = h(end);
elseif(strcmpi(mode, 'first'))
    h = h(1);
end
   
x = zeros(length(h),1);
for i = 1 : length(h)
    p1   = f(h(i),  :);
    p2   = f(h(i)+1,:);    
    x(i) = inverseOfLinearFunction(p1,p2,y);
end

end

