function [ x ] = inverseOfLinearFunction( p1, p2, y )

% finds x where y = f(x) with f being a linear function defined by points
% p1 and p2
% 
% input:
% p1 = [x1,y1] or p1 = m
% p2 = [x2,y2] or p2 = n
% y  - an arbitrary y-value
%
% example: x = inverseOfLinearFunction( [1 2], [3 9], .8 )
%          x = inverseOfLinearFunction( 2, 10, .8 )
%

if(length(p1) == 2)
    m = (p2(2)-p1(2)) / (p2(1)-p1(1));
    n = p1(2) - m * p1(1);
else
    m = p1;
    n = p2;
end

x = (y - n) / m;

end

