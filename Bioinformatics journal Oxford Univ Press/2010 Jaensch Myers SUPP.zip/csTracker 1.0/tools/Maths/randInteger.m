function [ X ] = randInteger( minx, maxx, siz )

    if(nargin < 3)
        siz = [1 1];
    end

    r = maxx - minx + 1;
    X = floor(rand(siz) * r) + minx;

end