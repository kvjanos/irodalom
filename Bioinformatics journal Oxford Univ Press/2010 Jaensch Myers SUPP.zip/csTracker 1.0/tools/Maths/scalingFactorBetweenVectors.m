function [ alpha ] = scalingFactorBetweenVectors( x,y )
%SCALINGFACTORBETWEENVECTORS computes a scalar alpha that 
%minimizes the expression: norm(x - alpha*y)^2

x = x(:);
y = y(:);
alpha = (x'*y) / (y'*y);