function Y = runningAverage(X, windowSize)
   %computes the running average for each column vector in X
   %the first windowSize-1 entries are computed assuming 0 for values
   %outside the vectors
   %Y = filter(ones(1,windowSize)/windowSize,1,X);
   Y = imfilter(X,ones(windowSize,1)/windowSize,'symmetric');
end