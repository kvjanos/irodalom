function [ sErrMean ] = sem( x, dim )
%SEM computes the standard error of the mean
%sem = std / sqrt(n)

if(size(x,1) == 1 || size(x,2) == 1)
    sErrMean = std(x) / sqrt(length(x));
else
    sErrMean = std(x,0,dim) / size(x,dim);
end