%function [ output_args ] = test_2Dpolyfit( input_args )
%TEST_2DPOLYFIT Summary of this function goes here
%   Detailed explanation goes here
close all
x  = [1 2 3 4 5 6 1 2 3 4 5 6 1 1 1 1 1];
y  = [1 1 1 1 1 1 8 8 8 8 8 8 2 3 4 5 6];
z = [.5 .4 .9 .5 .2 .7 .5 .4 .9 .8 .3 .4 .5 .3 .2 .7 .6];
%z = [1 2 2.1 3 4]
n = 2;
w = ones(length(x),1);

p = polyfitweighted2(x,y,z,n,w)

[X,Y] = meshgrid(1:10,1:10);
Z = polyval2(p,1:10,1:10);
mesh(X,Y,Z);
hold on
plot3(x,y,z,'x')
