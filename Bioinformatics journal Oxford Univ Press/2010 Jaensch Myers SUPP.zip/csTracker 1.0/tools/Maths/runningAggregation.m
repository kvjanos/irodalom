function [ y ] = runningAggregation( x, aggFunctionHandle )

y = zeros(size(x));
for i = 1 : length(x)
    y(i) = aggFunctionHandle(x(1:i));
end


end

