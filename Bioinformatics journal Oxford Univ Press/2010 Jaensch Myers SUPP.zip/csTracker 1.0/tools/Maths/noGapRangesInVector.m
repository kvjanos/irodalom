function [ ranges ] = noGapRangesInVector( x )
% x      = [ 2 3 4 6 7 8 9 10 12]
% ranges = [1     3     4     8     9     9] 
% meaning: index 1-3, 4-8 and 9-9 are ranges in which x(i)+1 = x(i+1)

if(isempty(x))
    ranges = [];
    return
end

ranges(1) = 1;
for i = 1 : length(x)-1
    if(x(i)+1 ~= x(i+1))
        ranges(end+1)=i;
        ranges(end+1)=i+1;
    end
end
ranges(end+1)=length(x);