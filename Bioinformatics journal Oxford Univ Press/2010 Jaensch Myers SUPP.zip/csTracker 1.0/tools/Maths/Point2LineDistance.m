function [ d ] = Point2LineDistance( q1, q2, p )
%POINT2LINEDISTANCE computes the distance of point p to the line defined by
%points q1 and q2


d = ((q2(1)-q1(1))*(q1(2)-p(2))-(q1(1)-p(1))*(q2(2)-q1(2))) / norm(q1-q2);