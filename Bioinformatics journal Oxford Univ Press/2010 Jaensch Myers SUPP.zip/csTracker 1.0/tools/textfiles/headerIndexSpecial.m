function [ colIdx ] = headerIndexSpecial(header, colNames, varargin )
% 
% works as headerIndex but allows to specify special columns with a predefined
% column index, the special columns are not checked for occurrance in the header
%
% call: headerIndexSpecial(header, colNames, 'specialColNameA', predefinedColIdxA, 'specialColNameB', predefinedColIdxB, ... )
%       headerIndexSpecial(header, colNames, 'specialColNameA', predefinedColIdxA, 'specialColNameB', predefinedColIdxB, ... , 'warning' )
%       headerIndexSpecial(header, colNames, 'specialColNameA', predefinedColIdxA, 'specialColNameB', predefinedColIdxB, ... , 'error' )
%       headerIndexSpecial(header, colNames, 'specialColNameA', predefinedColIdxA, 'specialColNameB', predefinedColIdxB, ... , 'none' )
%       headerIndexSpecial(header, colNames, 'error' )
%       headerIndexSpecial(header, colNames, 'warning' )
%       headerIndexSpecial(header, colNames, 'none' )
%
%see also: headerIndex

if(mod(length(varargin),2) == 1)
    errorOrWarningOrNone = varargin{end};
    varargin(end) = [];
else
    errorOrWarningOrNone = 'error';
end

if(~isempty(varargin))
    if(ischar(colNames))
        a = colNames;
        colNames = {a};
    end
    
    
    specialColNames = varargin(1:2:end);
    specialColIdx   = varargin(2:2:end);
    
    ix = strListMatch(colNames, specialColNames);
    
    %get the header column indices of the normal columns
    normalIdx = find(ix <= 0);
    colIdx(normalIdx) = headerIndex(header, colNames(normalIdx), errorOrWarningOrNone);  

    %complete the index-vector with the predefined special column indices
    specialIdx = find(ix > 0);
    for i = 1 : length(specialIdx)
        colIdx(specialIdx(i)) = specialColIdx{ix(specialIdx(i))};
    end
else
    colIdx =  headerIndex(header, colNames, errorOrWarningOrNone);
end
