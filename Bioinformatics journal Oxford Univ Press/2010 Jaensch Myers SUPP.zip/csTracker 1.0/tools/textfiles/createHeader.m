function [ header ] = createHeader( varargin )

header = varargin{1};
t = tab();
for i = 2 : length(varargin)
    header = [header t varargin{i}]; 
end