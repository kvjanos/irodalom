function [ columnIndex, columnCount, C, colName2colIdx ] = headerIndex( header, columnName, errorOrWarningOrNone )
%HEADERINDEX splits the header string (delimiter=tab) and finds the index
%of the column specified by its name
%
%%see also: headerIndexSpecial 
%
%

if(isempty(header))
    columnIndex = -1;
    columnCount = 0;
    C = [];
    colName2colIdx = [];
    return
end

C = splitHeader(header);
columnCount = length(C);

if(nargin < 2)
    %get index for all colums as struct
    columnIndex = struct;
    for i = 1 : columnCount
        colName = C(i);
        colName = colName{1};
        columnIndex.(colName) = i;
    end
    return
end

if(ischar(columnName))
    colName{1} = columnName;
else
    colName = columnName;
end

N = length(colName);

columnIndex = ones(1,N) * -1;
for j = 1 : N
    for i = 1 : columnCount
        if(strcmpi(C(i),colName{j}))
            columnIndex(j) = i;
            break;
        end
    end

    if(columnIndex(j) <= 0)
        if(nargin < 3 || strcmpi(errorOrWarningOrNone, 'error'))
            error('Error: column "%s" not found\n',colName{j});
        else
            if(~strcmpi(errorOrWarningOrNone, 'none'))
                fprintf('Warning: column "%s" not found\n', colName{j});
            end
        end
    end
end
if(nargout>=4)
    colName2colIdx = MakeHashtable(columnName, columnIndex);
end
end
function h = MakeHashtable(columnNames, columnIndex)
    import java.util.*;
    h = java.util.Hashtable;
    for i = 1 : length(columnNames)
        h.put(columnNames{i},columnIndex(i));
    end
end

