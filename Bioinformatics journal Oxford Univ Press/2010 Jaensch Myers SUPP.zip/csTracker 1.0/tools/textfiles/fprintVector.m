function fprintVector(fid, vector, formatter )
if(nargin < 3)
    formatter = '%f';
end
for i=1:(length(vector)-1)
    fprintf(fid,[formatter '\t'],vector(i));
end
fprintf(fid,[formatter '\n'],vector(end));