function [T, header] = removeTableColumn(T, header, columnName)

[colIdx] = headerIndex( header, columnName, 'none' );

colIdx = colIdx(colIdx>0);
if(~isempty(colIdx))
    colNames = splitHeader( header );
    T(:, colIdx) = [];
    colNames(colIdx) = [];
    
    header = colNames{1};
    t = tab();
    for i = 2 : length(colNames)
        header = [header t colNames{i}];
    end
end
end

