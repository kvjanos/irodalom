function [ T, header ] = swapTableColumns( T, header, idx1, idx2 )

if(nargin > 3)
    ix = 1 : size(T,2);
    ix(idx1) = idx2;
    ix(idx2) = idx1;
else
    ix = idx1;
end

T = T(:,ix);
header = swapHeaderEntries(header, ix);

end

