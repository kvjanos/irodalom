function [table, header, colIdx] = loadList( filename, columnsCount )
%loads a text file containing a table with a one-line header
%see also: loadListBuffered

% open file
fid = fopen(filename,'rt');     % 'rt' means "read text"

if (fid < 0)
    error('could not open file %s',filename);
end;

%read header line
header = fgetl(fid);

if(nargin==1)
    tab=sprintf('\t');
    columnsCount = length(strfind(header,tab))+1;
end

%build format string
parseString = '';
for i = 1 : columnsCount
    parseString = [parseString '%f\t'];
end
parseString(end-1:end) = '\n';

% read from file into table
table = fscanf(fid,parseString,[columnsCount,inf])';
% close the file
fclose(fid);


if(nargout > 2)
    colIdx = headerIndex(header);
end

