function [ newHeader, colIdx, columnHasBeenAdded, T ] = addHeaderEntry( header, colName, defaultValue, T )
%required input: header, colName
%optinal input: defaultValue, T
%
%output: 'T' may only be requested if 'defaultValue' and 'T' are provided as
%        input arguments

[idx, columnCount] = headerIndex(header, colName, 'none');
if(idx <= 0)
    if(isempty(header))
        newHeader = colName;
    else
        newHeader = [header sprintf('\t') colName];
    end
    colIdx    = columnCount + 1;
    columnHasBeenAdded = 1;
else
    newHeader = header;
    colIdx    = idx;
    columnHasBeenAdded = 0;
end

if(columnHasBeenAdded && nargin >= 4)
    T(:,colIdx) = defaultValue;
end