function PrintToFile(text, path, permission, printToScreen)

    if(nargin < 3 || isempty(permission))
        permission = 'a';
    end
    if(nargin < 4)
        printToScreen = 0;
    end
    
    dir = fileparts(path);
    ensureDirExists(dir);
    fid = fopen(path, permission);
    fprintf(fid,'%s\n',text);
    fclose(fid);
    
    if(printToScreen)
        fprintf('%s\n', text);
    end
end