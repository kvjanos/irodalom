function [table, header] = loadListBuffered( filename )
% loads the file as in loadList.m and keeps the data in memory for faster
% loading when accessed a second time
%
% use loadListBuffered( '#clear' ) to clear the buffer and force reload from hard disk
%
% see also: loadList

global hashTable_loadedFiles_loadListBuffered;

if(strcmpi(filename, '#clear'))
    hashTable_loadedFiles_loadListBuffered = hashtable;
    return
end

if(~exist('hashTable_loadedFiles_loadListBuffered', 'var') || isempty(hashTable_loadedFiles_loadListBuffered))
    hashTable_loadedFiles_loadListBuffered = hashtable;
else
    if(iskey(hashTable_loadedFiles_loadListBuffered, filename))
        data   = get(hashTable_loadedFiles_loadListBuffered, filename);
        table  = data.T;
        header = data.header;
        return
    end
end

[table, header] = loadList( filename );
data.T = table;
data.header = header;
hashTable_loadedFiles_loadListBuffered = put(hashTable_loadedFiles_loadListBuffered, filename, data);
end

