function [ header ] = swapHeaderEntries( header, idx1, idx2 )

%syntax: header = swapHeaderEntries( header, idx1, idx2 )  ==> swap positions idx1 and idx1
%        header = swapHeaderEntries( header, ix )          ==> read-out header in the given index sequence

headerSplit = splitHeader(header);
if(nargin > 2)
    ix = 1 : length(headerSplit);
    ix(idx1) = idx2;
    ix(idx2) = idx1;
else
    ix = idx1;
end
headerSplit = headerSplit(ix);
header = strList2SeparatedString( headerSplit, tab());
end

