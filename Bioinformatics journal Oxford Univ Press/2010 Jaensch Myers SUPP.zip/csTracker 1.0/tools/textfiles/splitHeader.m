function [ colNames ] = splitHeader( header )

C = textscan(header,'%s','Delimiter',tab());
colNames = C{1};