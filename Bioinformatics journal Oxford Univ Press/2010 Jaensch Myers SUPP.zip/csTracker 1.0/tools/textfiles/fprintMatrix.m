function fprintMatrix( fidOrFilename, matrix, header, additionalText )
% header - a single string or a cell array of strings

rows = size(matrix, 1);
cols = size(matrix, 2);

if(ischar(fidOrFilename))
    fn      = fidOrFilename;
    fn_tmp  = [getPathAndFilenameWithoutExtension(fn) '_temp.tmp']; %write to temp file first and then rename temp file to given filename 
    
    [fid, message] = fopen(fn_tmp, 'w+t');
    if fid < 0
        disp(message);
        error('could not open %s for writing',fn_tmp);
    end

else
    fn  = [];
    fid = fidOrFilename;
end

if(nargin >= 3 && ~isempty(header))
    if(ischar(header))
        fprintf(fid,'%s\n',header);
    else
        for i = 1: length(header)
            fprintf(fid,'%s\n',header{i});
        end
    end
end

for j=1:rows
    for i=1:(cols-1)
        fprintf(fid,'%f\t',matrix(j,i));
    end
    fprintf(fid,'%f\n',matrix(j,end));
end

if(nargin >= 4 && ~isempty(additionalText))
    fprintf(fid,'%s\n',additionalText);
end

if(~isempty(fn))
    fclose(fid);
    movefile_fast(fn_tmp, fn, 'f');
end
