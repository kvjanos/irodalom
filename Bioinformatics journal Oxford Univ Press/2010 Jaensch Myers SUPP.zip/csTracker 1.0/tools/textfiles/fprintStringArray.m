function fprintStringArray( fn, lines )

%convert numbers to strings and convert single strings to cell array of
%strings with one element
for k = 1 : length(lines)
    line    = lines{k};
    newline = {};
    if(isnumeric(line))
        v = line;
        for i = 1 : length(v)
            newline{i} = num2str(v(i));
        end
    elseif(ischar(line))
        newline{1} = line;
    else
        for i = 1 : length(line)
            v = line{i};
            if(isnumeric(v))
                for j = 1 : length(v)
                newline{end+1} = num2str(v(j));
                end
            else
                newline{end+1} = v;
            end
        end
    end
    lines{k} = newline;
end

fid = fopen(fn, 'w+t');
tab_ = sprintf('\t');
for k = 1 : length(lines)
    line = lines{k};
    str = strList2SeparatedString(line, tab_, 0);
    str = strrep(str, sprintf('\n'), ' / ');
    fprintf(fid, '%s\n', str);
end
fclose(fid);

end

