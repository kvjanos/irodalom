function [unique, count] =  countOccurrences( x )
if(isempty(x))
    unique = [];
    count  = [];
end
x = sort(x(:)); 
difference = diff([x;x(end)+1]); 
count = diff(find([1;difference]));
unique = x(find(difference)); 

