function [ E ] = AggregateXGroups( X,Y, aggregationFunction )
%AggregateXGroups aggregates the y-values for each unique x using the
%given aggregation function
%E has two columns: 1. column: unique x-values, 2. column: the aggregated
%y-values
%see also: AggregateXGroupsOutlier


X = X(:);
Y = Y(:);

if(length(X) ~= length(Y))
    error('X and Y must have the same length');
end

if(length(X) == 1)
    E = [X Y];
    return;
end


D = sortrows([X Y],1);
di = [1 1; diff(D)];
idx = [find(di(:,1));length(X)+1];

E = zeros(length(idx)-1,2);

for i = 1 : length(idx)-1;
    E(i,1) = D(idx(i),1);
    E(i,2) = aggregationFunction(D(idx(i):idx(i+1)-1,2));
end