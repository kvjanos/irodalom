function [ ix ] = getIndicesInSuperset( subset, superset )
% finds for each element in subset the index of the same element in superset
% example: getIndicesInSuperset( ['a' 'e' 'a' 'b' 'a'], ['a','b','c','d','e'] )
%          ==> [1 5 1 2 1]
%
% the following combinations of data types are allowed:
% *subset*      *superset* 
% string      - string list
% string list - string list
% num vector  - num vector
% char vector - char vector

if(ischar(subset) && iscellstr(superset))
    k = find(strcmpi(superset, subset),1,'first');
    if(~isempty(k))
        ix = k;
    else
        ix = 0;
    end
elseif(iscellstr(subset) && iscellstr(superset))
    ix = zeros(size(subset));
    for i = 1 : length(subset)
        k = find(strcmpi(superset, subset{i}),1,'first');
        if(~isempty(k))
            ix(i) = k;
        end
    end
else
    ix = zeros(size(subset));
    for i = 1 : length(subset)
        k = find(superset == subset(i),1,'first');
        if(~isempty(k))
            ix(i) = k;
        end
    end
end
end

