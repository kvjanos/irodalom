function [ clusters ] = clusterCellArray( cellArray, fieldnames )
%clusters a cell array (i.e. a list!!!) of structures by the given
%fieldname(s)
%
%input: cellArray   - a cell array
%       fieldnames  - a single string or a cell array of strings
%
%output is a cell array of the following structure:
%   s.fieldname_1
%   ...
%   s.fieldname_n
%   s.members
%   s.indices
%
%where fieldname1,...fieldname_n are the entries in fieldnames and members
%is the sub (structure) array identical to the input that belongs to the
%respective cluster
%
%
% example: see test_clusterCellArray
%


if(ischar(fieldnames))
    fnames{1} = fieldnames;
else
    fnames = fieldnames;
end

keyToCluster = hashtable;
for i = 1 : length(cellArray)
    entry = cellArray{i};
    key = '';
    for j = 1 : length(fnames)
        v = entry.(fnames{j});
        
        if(iscellstr(v))
            key = [key '_' strList2SeparatedString(v, '_')];
        elseif(ischar(v))
            key = [key '_' v];
        elseif(islogical(v))
                 key = [key sprintf('_%d',v)];            
        elseif(isempty(v))
                 key = [key '#*#special_key_for_empty_entry#*#'];            
        elseif(length(v) == 1 && isnumeric(v))
            if(isinteger(v))
                key = [key sprintf('_%d',v)];
            elseif(isfloat(v))
                key = [key sprintf('_%f',v)];
            else
                error('unknown numeric type');
            end
        else
            error('only string, logical and numerical scalar types and cell arrays of strings can be clustered');
        end
    end
    if(iskey(keyToCluster,key))
        cluster = get(keyToCluster,key);
        cluster.members{end+1} = entry;
        cluster.indices(end+1) = i;
    else
         clear 'cluster';
         for j = 1 : length(fnames)
            cluster.(fnames{j}) = entry.(fnames{j});
         end
         cluster.members{1} = entry;
         cluster.indices(1) = i;
    end
    keyToCluster = put(keyToCluster, key, cluster);
    
end
clusters = values(keyToCluster);


