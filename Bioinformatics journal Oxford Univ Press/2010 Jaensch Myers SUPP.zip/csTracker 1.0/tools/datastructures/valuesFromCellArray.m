function [ values ] = valuesFromCellArray( cellArrayOfStructs, fieldname, convertToNumercialArray, convertToNumercialMatrix )
%VALUESFROMCELLARRAY returns the set of values for a given fieldname in a
%cell array of structs,
%convertToNumercialArray  ==> converts the set into a row vector if all values are numeric
%convertToNumercialMatrix ==> converts the set into a matrix if all values are numeric vectors
%                             of the same length

if(nargin < 3)
    convertToNumercialArray = 1;
end
if(nargin < 4)
    convertToNumercialMatrix = 0;
end

if(convertToNumercialMatrix)
    convertToNumercialArray = 1;
end

values = cell(numel(cellArrayOfStructs),1);
areAllValuesNumericOrLogical = 1;
for i = 1 : numel(cellArrayOfStructs)
    if(isfield(cellArrayOfStructs{i}, fieldname))
        v = [cellArrayOfStructs{i}.(fieldname)];
        values{i} = v;
        if(~isnumeric(v) && ~islogical(v))
            areAllValuesNumericOrLogical = 0;
        end
    end
end

if(convertToNumercialArray && areAllValuesNumericOrLogical)
    v = [];
    if(convertToNumercialMatrix)
         v = [];
         convertingToRowVector = 0;
        for i = 1 : length(values)
            num = values{i};
            if(i>1 && size(v,2) ~= size(num,2))
                v = v(:);
                v = [v;num(:)];
                if(~convertingToRowVector)
                warning('not all vectors have the same length. cannot convert to matrix. converting values to row vector instead.');
                end
                convertingToRowVector = 1;
            else
                v = [v;num(:)'];
            end
        end
    else
        for i = 1 : length(values)
            num = values{i};
            v = [v;num(:)];
        end
    end
    values = v;
end






