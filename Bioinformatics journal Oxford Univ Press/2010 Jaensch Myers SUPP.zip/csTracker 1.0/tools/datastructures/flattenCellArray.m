function [ c ] = flattenCellArray( aCellArray )
%FLATTENCELLARRAY Summary of this function goes here
%   Detailed explanation goes here

c = {};
for i = 1 : length(aCellArray)
    if(iscell(aCellArray{i}))
        c = [c flattenCellArray(aCellArray{i})];
    else
        c = [c aCellArray{i}];
    end
end

