function [ v ] = convertMatrixListToVector( list )
%CONVERTMATRIXLISTTOVECTOR converts a cell array containing numeric objects
%into one vector

v = [];
for i = 1 : length(list)
    x = list{i};
    v = [v;x(:)];
end