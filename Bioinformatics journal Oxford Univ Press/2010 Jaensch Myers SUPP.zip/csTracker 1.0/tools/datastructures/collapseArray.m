function [ s ] = collapseArray( a, uniqueValueFields )
%see also: mergeStructs, collapseClusters

if(nargin < 2)
    uniqueValueFields = {};
end
if(isstruct(a))
    s = a(1);
    for i = 2 : length(a)
        s = mergeStructs(s, a(i));
    end
elseif(iscell(a))
    s = a{1};
    for i = 2 : length(a)
        s = mergeStructs(s, a{i});
    end
    
end

for j = 1 : length(uniqueValueFields)
    fname = uniqueValueFields{j};
    if(isfield(s, fname))
        v = s.(fname);
        if(~ischar(v))
            v_unique = unique(v);
            if(iscellstr(v_unique) && length(v_unique) == 1)
                v_unique = v_unique{1};
            end
            s.(fname) = v_unique;
        end
    end
end


end

