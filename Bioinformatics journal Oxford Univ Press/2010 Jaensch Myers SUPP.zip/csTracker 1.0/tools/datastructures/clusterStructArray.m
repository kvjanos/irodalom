function [ clusters ] = clusterStructArray( structArray, fieldnames )
%clusters a structure array (the elements of which are accessed by
%parentheses) by the given filenames
%
%input: structArray - a structure array
%       fieldnames  - a single string or a cell array of strings
%
%output is a cell array of the following structure:
%   s.fieldname_1
%   ...
%   s.fieldname_n
%   s.members
%   s.indices
%where fieldname1,...fieldname_n are the entries in fieldnames and members
%is the sub (structure) array identical to the input that belongs to the
%respective cluster
%
%
% example:  structArray(1).a = 1
%           structArray(1).b = 'sdadasd'
%           structArray(1).c = 'left'
%
%           structArray(2).a = 2
%           structArray(2).b = 'etwrws'
%           structArray(2).c = 'right'
%
%           structArray(3).a = 1
%           structArray(3).b = 'etwrws'
%           structArray(3).c = 'left'
%
%           structArray(4).a = 3
%           structArray(4).b = 'etwrws'
%           structArray(4).c = 'right'
%
%           clusters = clusterStructArray( structArray, {'a','c'} )
%           returns:
%
%           clusters{1}.a = 1
%           clusters{1}.c = 'left'
%           clusters{1}.members(1) = "structArray(1)"
%           clusters{1}.members(2) = "structArray(3)"
%
%           clusters{2}.a = 2
%           clusters{2}.c = 'right'
%           clusters{2}.members(1) = "structArray(2)"
%
%           clusters{3}.a = 3
%           clusters{3}.c = 'right'
%           clusters{3}.members(1) = "structArray(4)"
%


if(ischar(fieldnames))
    fnames{1} = fieldnames;
else
    fnames = fieldnames;
end

keyToCluster = hashtable;
for i = 1 : length(structArray)
    entry = structArray(i);
    key = '';
    for j = 1 : length(fnames)
        v = entry.(fnames{j});
        if(ischar(v))
            key = [key '_' v];
        elseif(islogical(v))
                 key = [key sprintf('_%d',v)];            
        elseif(length(v) == 1 && isnumeric(v))
            if(isinteger(v))
                key = [key sprintf('_%d',v)];
            elseif(isfloat(v))
                key = [key sprintf('_%f',v)];
            else
                error('unknown numeric type');
            end
        else
            error('only string, logical and numerical scalar types can be clustered');
        end
    end
    if(iskey(keyToCluster,key))
        cluster = get(keyToCluster,key);
        cluster.members(end+1) = entry;
        cluster.indices(end+1) = i;
    else
         clear 'cluster';
         for j = 1 : length(fnames)
            cluster.(fnames{j}) = entry.(fnames{j});
         end
         cluster.members(1) = entry;
         cluster.indices(1) = i;
    end
    keyToCluster = put(keyToCluster, key, cluster);
    
end
clusters = values(keyToCluster);

