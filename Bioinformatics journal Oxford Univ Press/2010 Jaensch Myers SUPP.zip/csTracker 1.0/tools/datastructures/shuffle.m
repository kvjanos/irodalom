function [ x ] = shuffle( x )
%SHUFFLE array / structure array / cell array

x = x(randperm(length(x)));

end

