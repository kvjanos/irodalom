function [ unique_x, idx ] = uniquePreserveOrder( x, occurrence )
%finds the unique values in vector x, the order of the values in unique_x
%is the same as in x

if(nargin < 2)
    occurrence = 'first';
end

[unique_x, idx] = unique(x,occurrence);
idx = sort(idx);
unique_x = x(idx);


% unique_x = [];
% idx      = [];
% for i = 1 : length(x)
%     if(isempty(find(ismember(unique_x, x(i)), 1)))
%         unique_x(end+1) = x(i);
%         if(nargout > 1)
%             idx(end+1) = i;
%         end
%     end
% end