function [ s ] = rmfieldIfExists( s, fieldname )

if(ischar(fieldname))
    if(isfield(s,fieldname))
        s = rmfield(s,fieldname);
    end
else
   for i = 1 : length(fieldname)
        if(isfield(s,fieldname{i}))
            s = rmfield(s,fieldname{i});
        end
   end
end
