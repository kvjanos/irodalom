function a = setStructureArrayField(a, fieldname, value)
    for i = 1 : length(a)
        a(i).(fieldname) = value;
    end
end

