%function [ output_args ] = test_clusterCellArray( input_args )
%TEST_CLUSTERCELLARRAY Summary of this function goes here
%   Detailed explanation goes here


a.x = 1;
a.y = 99;
a.z = 'hallo';

b.x = 1;
b.y = 329;
b.z = 'welt';


c.x = 3;
c.y = 329;
c.z = 's';
c.w = 3049;

d.x =  1;
d.y = 33;
d.z = 't';

L = {a,b,c,d};

clusters = clusterCellArray(L, 'x')
i=1