function [ listOfTables ] = clusterTable( T, colIdx )

T = sortrows(T, colIdx);
T(end+1,:) = inf; %dummy row to have different row for the last chunk of rows ==> will not be included in the clustered table

% lastx    = -inf;
% firstIdx = -1;
% listOfTables = {};
% for i = 1 : size(T,1)
%     x = T(i,colIdx);
%     if(x ~= lastx)
%         if(firstIdx > 0)
%             listOfTables{end+1} = T(firstIdx:(i-1), :);
%         end
%         firstIdx = i;
%     end
%     lastx = x;
% end


lastx    = ones(1,length(colIdx)) * -inf;
firstIdx = -1;
listOfTables = {};
for i = 1 : size(T,1)
    x = T(i,colIdx);
    if(any(x ~= lastx))
        if(firstIdx > 0)
            listOfTables{end+1} = T(firstIdx:(i-1), :);
        end
        firstIdx = i;
    end
    lastx = x;
end
