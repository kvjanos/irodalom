function [ list ] = getFieldnames( a )

if(isstruct(a))
    list = fieldnames(a);
else
    list = {};
end