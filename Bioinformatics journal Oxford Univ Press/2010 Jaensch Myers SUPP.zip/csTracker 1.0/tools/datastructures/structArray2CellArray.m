function [ cellArray ] = structArray2CellArray( structArray )
%structArray2CellArray converts a struct array to a cell array of structs

clear 'cellArray'

if(isempty(structArray))
    cellArray = {};
elseif(isstruct(structArray))
    cellArray = cell(size(structArray));
    for i = 1 : length(structArray)
        cellArray{i} = structArray(i);
    end
else
    cellArray = structArray;
end