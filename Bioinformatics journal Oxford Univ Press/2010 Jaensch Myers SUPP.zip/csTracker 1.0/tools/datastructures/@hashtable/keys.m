function keys = keys(hash)
%KEYS Get all the keys currently being used in the hash
%   keys = keys(hash)

% Copyright (c) 2004 Matthew Krauski (mkrauski@uci.edu), CNLM, UC Irvine

keys = hash.keys;

