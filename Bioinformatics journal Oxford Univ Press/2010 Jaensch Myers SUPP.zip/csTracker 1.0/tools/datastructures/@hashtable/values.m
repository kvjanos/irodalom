function data = values(hash)
%VALUES Get all data contained in the hash table
%   data = values(hash)

% Copyright (c) 2004 Matthew Krauski (mkrauski@uci.edu), CNLM, UC Irvine

data = hash.data;

