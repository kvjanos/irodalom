function [ s ] = collapseClusters( a, clusterFields, uniqueValueFields )
%see also: collapseArray, mergeStructs

if(nargin < 3)
    uniqueValueFields = {};
end

uniqueValueFields = unique([clusterFields uniqueValueFields]);
if(iscell(a))
    clusters = clusterCellArray(a, clusterFields);
    s = cell(1, length(clusters));
    for i = 1 : length(clusters)
        cluster_i = clusters{i};
        s{i} = collapseArray(cluster_i.members, uniqueValueFields);
    end
else
    clusters = clusterStructArray(a, clusterFields);
    for i = 1 : length(clusters)
        cluster_i = clusters{i};
        s(i) = collapseArray(cluster_i.members, uniqueValueFields);
    end
end

