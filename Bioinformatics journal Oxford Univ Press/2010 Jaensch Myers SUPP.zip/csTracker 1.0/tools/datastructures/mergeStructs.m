function [ s1 ] = mergeStructs( s1, s2 )
%see also: collapseArray, collapseClusters

fnames2 = fieldnames(s2);

for i = 1 : length(fnames2)
    fname = fnames2{i};
    v2 = s2.(fname);
    if(isfield(s1, fname))
        v1 = s1.(fname);
        if(isnumeric(v1) && isnumeric(v2) || islogical(v1) && islogical(v2) || iscell(v1) && iscell(v2))
            if(size(v1,1) == size(v2,1))
                s1.(fname) = [v1 v2];
            elseif(size(v1,2) == size(v2,2))
                s1.(fname) = [v1;v2];
            else
                s1.(fname) = [v1(:);v2(:)];
            end
        elseif(ischar(v1) && ischar(v2))
            s1.(fname) = {v1, v2};
        elseif(ischar(v1) && iscellstr(v2))
            if(size(v2,1) == 1)
                s1.(fname) = [{v1}, v2];
            elseif(size(v2,2) == 1)
                s1.(fname) = [{v1}; v2];
            else
                s1.(fname) = [{v1}; v2(:)];
            end
        elseif(iscellstr(v1) && ischar(v2))
            if(size(v1,1) == 1)
                s1.(fname) = [v1, {v2}];
            elseif(size(v1,2) == 1)
                s1.(fname) = [v1; {v2}];
            else
                s1.(fname) = [v1(:), {v2}];
            end
        elseif(iscellstr(v1) && iscellstr(v2))
            s1.(fname) = [v1, v2];
        elseif(isstruct(v1) && isstruct(v2))
            try
                if(size(v1,1) == size(v2,1))
                    s1.(fname) = [v1 v2];
                elseif(size(v1,2) == size(v2,2))
                    s1.(fname) = [v1;v2];
                else
                    s1.(fname) = [v1(:);v2(:)];
                end
            catch
                s1.(fname) = {v1, v2};
            end
        else
            s1.(fname) = {v1, v2};
        end
    else
        s1.(fname) = v2;
    end
end
end

