function [ c ] = sortCellArrayByField( c, fieldname )
%sorts a cell array of structs by the specified field(s)
%entries that do not have the resp. field will be put at the end of the cell array

n = length(c);
if(iscell(fieldname))
    for i = length(fieldname) : -1 : 1
        [v, ix] = sort(valuesFromCellArray(c, fieldname{i}));
        ixn = setdiff(1:length(c), ix); %all indices that have to entry for fieldname_i
        c = c([ix ixn]);
    end
else
    [v, ix] = sort(valuesFromCellArray(c, fieldname ));
    ixn = setdiff(1:length(c), ix); %all indices that have to entry for fieldname
    c = c([ix ixn]);
end
if(length(c) ~= n)
    error('length(c) has changed');
end


