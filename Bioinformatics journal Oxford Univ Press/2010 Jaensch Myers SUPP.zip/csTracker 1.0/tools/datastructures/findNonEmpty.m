function [ idx ] = findNonEmpty( cellArray )

idx = [];
for i = 1 : length(cellArray)
    if(~isempty(cellArray{i}))
        idx(end+1) = i;
    end
end

