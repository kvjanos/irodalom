function [ values ] = valuesFromStructureArray( structureArray, fieldname, convertToMatrix )
%VALUESFROMCELLARRAY returns the set of values for a given fieldname in a
%structure array, converts the set into a matrix if all values are
%numeric and scalar
%
%remark: a structure array is an array the elements of which are access by
%parentheses as opposed to a cell array the elements of which are access by
%braces

if(nargin < 3)
    convertToMatrix = 1;
end

values = cell(length(structureArray),1);
areAllValuesNumericOrLogical = 1;
for i = 1 : length(structureArray)
    v = structureArray(i).(fieldname); 
    values{i} = v;
    if(~isnumeric(v) && ~islogical(v) || length(v) > 1)
        areAllValuesNumericOrLogical = 0;
    end
end

if(convertToMatrix && areAllValuesNumericOrLogical)
    v = [];
    for i = 1 : length(values)
        num = values{i};
        v = [v;num(:)];
    end
    values = v;
end