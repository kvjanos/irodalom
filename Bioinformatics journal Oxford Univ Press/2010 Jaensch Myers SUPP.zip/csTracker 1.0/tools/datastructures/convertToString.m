function [ strList ] = convertToString( x )

strList = cell(size(x));

if(iscell(x))
    for i = 1 : length(x)
        try
            strList{i} = num2str(x{i});
        catch
            strList{i} = '';
        end
    end
else
    for i = 1 : length(x)
        try
            strList{i} = num2str(x(i));
        catch
            strList{i} = '';
        end
    end
    
end