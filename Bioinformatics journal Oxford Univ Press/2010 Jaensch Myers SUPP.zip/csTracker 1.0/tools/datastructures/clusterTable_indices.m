function [rangeIndices, T, sort_ix ] = clusterTable_indices( T, colIdx,isSorted )
%T will be sorted!
%
%output: rangeIndices - [i(1) i(2) ... i(n)] ==> [i(1):i(2)-1], [i(2):i(3)-1], ..., [i(n-1):i(n)-1]

if(nargin < 3)
    isSorted = 0;
end

if(~isSorted)
    [T, sort_ix] = sortrows(T, colIdx);
end

T(end+1,:) = inf; %dummy row to have different row for the last chunk of rows ==> will not be included in the clustered table

lastx    = ones(1,length(colIdx)) * -inf;
firstIdx = -1;
rangeIndices = [];
for i = 1 : size(T,1)
    x = T(i,colIdx);
    if(any(x ~= lastx))
        if(firstIdx > 0)
            rangeIndices(end+1) = i;
        else
            rangeIndices(end+1) = 1;
        end
        firstIdx = i;
    end
    lastx = x;
end
T(end,:) = [];%remove dummy row