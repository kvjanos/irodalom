function [ structArray ] = cellArray2structArray( cellArray )
%CELLARRAY2STRUCTARRAY converts a cell array containing structs to a struct
%array
clear 'structArray'
if(isempty(cellArray))
    structArray = [];
elseif(isstruct(cellArray))
    structArray = cellArray;
else
    structArray(length(cellArray)) = cellArray{end};
    for i = 1 : length(cellArray)-1
        structArray(i) = cellArray{i};
    end
end