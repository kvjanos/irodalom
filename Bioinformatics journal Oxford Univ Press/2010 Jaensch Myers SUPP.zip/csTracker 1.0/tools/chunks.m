function [ idx, chnks ] = chunks( x, chunkSize )
%breaks a vector down into chunks of the same size
%input:     x           - a vector
%           chunkSize   - size of each chunk
%output:    idx = the indices of the first entry of each chunk
%
%example:   x = 1:714, chunkSize = 300   
%           idx =   1
%                 301
%                 601
%                 715
%           (1. chunk   1 - 300
%            2. chunk 301 - 600
%            3. chunk 601 - 714)

N = floor(length(x) / chunkSize);

idx = zeros(N+1,1);
for i = 1 : N+1
    idx(i) = (i-1) * chunkSize + 1;
end
if(idx(end) <= length(x))
    idx(end+1) = length(x);
    idx(end) = idx(end)+1;
end


if(nargout > 1)
    chnks = cell(1,length(idx)-1);
    for i = 1 : length(idx)-1
        chnks{i} = x(idx(i):idx(i+1)-1);
    end
end