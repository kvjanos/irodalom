
%TEST_AGGREGATEXGROUPSOUTLIER Summary of this function goes here
%   Detailed explanation goes here

M = [1 0.5 493;1 0.4 360;1 4.3 456;1 1.1 390;1 0.0002 300;3 0.9 888;3 .7 700;3 .002 12;3 .8 400;1 0.6 520;3 14.3 304;3 .8 540; 6 7 7; 6 8 8];
M
trueResult = [mean(M([1,2,3,4,5,10],:));mean(M([6,7,8,9,11,12],:))]
[E,idx,cnt] = AggregateXGroupsOutlier(M,@mean,[0,0],3)

M(idx,:)