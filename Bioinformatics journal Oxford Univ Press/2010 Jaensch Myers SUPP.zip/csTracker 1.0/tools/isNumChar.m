function [ logical ] = isNumChar( c )
logical = c >= '0' && c <= '9';
