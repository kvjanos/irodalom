function prepareFigureForPrint( fig_handle )
    set(fig_handle, 'PaperUnits', 'normalized ');
    set(fig_handle, 'PaperType', 'A4');
    set(fig_handle, 'PaperPositionMode', 'manual');
    set(fig_handle, 'PaperOrientation', 'landscape');
    set(fig_handle, 'PaperPosition', [-0.05 -0.05 1 1]);