function [ b ] = isDateAfter( c1, c2 )
%
%is c1 > c2? 
%example: isDateAfter( clock(), [2009 10 12] ) ==> given date is after now?

y1 = c1(1);
m1 = c1(2);
d1 = c1(3);

y2 = c2(1);
m2 = c2(2);
d2 = c2(3);

b = y1 > y2 || (y1 == y2 && (m1 > m2 || m1 == m2 && d1 > d2));

end

