function psFilename = figures2Postscript(directory, filenamePattern, searchRecursively, psFilename, deleteIfPSFileExists)
%see also: printFigureToPostScript

if(nargin < 5)
    deleteIfPSFileExists = 1;
end

if(nargin == 0)
    searchRecursively = 0;
    directory         = [poolDir filesep 'NEBDcurves_SPD5-YFP WT'];
    psFilename        = [directory filesep 'NEBDcurves_SPD5-YFP WT.ps'];

    directory         = [poolDir filesep 'timeplots_SPD2-GFP WT long'];
    psFilename        = [directory filesep 'timeplots_SPD2-GFP WT long.ps'];
    

    directory         = [baseDir filesep 'SPD5-YFP10_WT\workingDir\1\GaussianSumFitting2DViz'];
    

    directory         = [baseDir filesep 'yTUB-GFP1\workingDir\1\GaussianSumFitting2DViz'];
    psFilename        = [directory filesep 'GaussianFit_Slice1D.ps'];
    filenamePattern   = '.*1DSlice.*\.fig';

    
    directory         = [poolDir filesep 'EstimateBGLevel3D'];
    psFilename        = [directory filesep 'EstimateBGLevel3D_cytoplasm.ps'];
    filenamePattern   = '.*\.fig';

    directory         = [poolDir filesep 'NEBDcurves_SPD5-YFP WT multi-cell'];
    psFilename        = [directory filesep 'NEBDcurves_SPD5-YFP WT multi-cell.ps'];
    filenamePattern   = '.*\.fig';


    
    directory         = [poolDir filesep 'NEBDcurves_yTUB-GFP WT 8-16cellstage'];
    psFilename        = [directory filesep 'NEBDcurves_yTUB-GFP WT 8-16cellstage.ps'];
    filenamePattern   = '.*\.fig';
    
    directory         = [graphDir()];
    psFilename        = [directory filesep 'Centrosome Volume Conservation.ps'];
    filenamePattern   = '.*\.fig';
    printFilenameInTitle = 0;


    directory         = [baseDir filesep '_temp\new track merge, no core tr joins\tracking (remove edges = forbidden edges only, no core joining)'];
    psFilename        = [directory filesep 'maxVelocity3D.ps'];
    filenamePattern   = '.*theoreticalMaxVelo.*3D\.fig';
    printFilenameInTitle = 1;

    directory         = [poolDir filesep 'tracking (opt matching with forb edges)'];
    psFilename        = [directory filesep 'maxVelocity3D.ps'];
    filenamePattern   = '.*theoreticalMaxVelo_tracksComplete3D\.fig';
    printFilenameInTitle = 1;


    directory         = [graphDir()];
    psFilename        = [directory filesep 'centrosome size (FRAP).ps'];
    filenamePattern   = '.*\.fig';
    printFilenameInTitle = 0;
end

psFilename = addDirectoryToFilename(directory, psFilename);

if(deleteIfPSFileExists)
    deleteFileIfExists(psFilename);
end

if(searchRecursively)
    [Files,Bytes,fNameList] = dirr(directory,filenamePattern,'name');
else
    [Files,Bytes,fNameList] = dirr(directory,filenamePattern,'name','isdir','0');
end

fNameList = sortStrListNumerically(fNameList);

for i = 1 : length(fNameList)
    fullFilename = fNameList{i};
    open(fullFilename);
    fig1 = gcf;
    if(printFilenameInTitle)
    title(sprintf('%s', strrep(getFilenameWithExtension(fullFilename),'_','\_')));
    end
    printFigureToPostScript(fig1,psFilename);
    close(fig1);
end
if(nargin == 0)
    winopen(psFilename);
end
end