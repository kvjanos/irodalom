function printDebugStack( errorStruct, minDebugLevel, filename )
%errorStruct - a structure as returned by function 'lasterror'

try
    if(nargin < 2)
        minDebugLevel = 0;
    end
    if(nargin<3)
        filename = [];
    end
    if(getDebugLevel() < minDebugLevel)
        return
    end
    
    stack = errorStruct.stack;
    fprintf('\nan error occurred:\n%s\n',errorStruct.message);
    if(~isempty(filename))
        PrintToFile(sprintf('\nan error occurred:\n%s',errorStruct.message), filename);
    end
    for i = 1 : length(stack)
        fprintf('%d: %s\n',stack(i).line,stack(i).file);
        if(~isempty(filename))
            PrintToFile(sprintf('%d: %s',stack(i).line,stack(i).file), filename);
        end
    end
    fprintf('\n');
    if(~isempty(filename))
        PrintToFile('', filename);
    end
catch
    fprintf('error in printDebugStack');
end

