function fprintfNTimes( str, N, nl )

for i = 1 : N
    fprintf('%s',str)
end
if(nargin >= 3)
    fprintf('\n');
end

end

