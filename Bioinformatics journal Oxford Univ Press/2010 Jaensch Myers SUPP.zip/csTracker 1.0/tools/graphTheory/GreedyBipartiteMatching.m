function [Matching,Cost] = GreedyBipartiteMatching(weights)
%GREEDYBIPARTITEMATCHING Summary of this function goes here
%   Detailed explanation goes here

% A function for finding a greedy minimum matching between two classes of objects given a MxN Edge
% weight matrix WEIGHTS
%
% An edge weight of Inf indicates that the pair of vertices given by its
% position have no adjacent edge.


Matching = zeros(size(weights));
Cost = 0;
if(isempty(weights))
    return
end


while (1)

    [minW, minIdx] = min(weights(:));
    if(minW == inf)
        break;
    end
    [i,j] = ind2sub(size(weights), minIdx);
    Cost = minW;
    Matching(i,j) = 1;
    weights(i,:) = inf;
    weights(:,j) = inf;    

end




