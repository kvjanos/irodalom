function drawBipartiteGraph( AdjMatrix, noEdgeSymbol, labelsA, labelsB)
%DRAWBIPARTITEGRAPH Summary of this function goes here
%   Detailed explanation goes here
%   AdjMatrix is a MxN matrix 
%   noEdgeSymbol is the value used in AdjMatrix to indicate the absence of
%   an edge

if(nargin == 1)
   noEdgeSymbol = 0;
end

if(nargin < 3)
   labelsA = 1 : size(AdjMatrix,1);
   labelsB = 1 : size(AdjMatrix,2);
end

M = size(AdjMatrix,1);
N = size(AdjMatrix,2);
StdAdjMatrix = zeros(M+N);
StdWeightsMatrix = zeros(M+N);


for i = 1 : M
    for j = 1 : N
        if(AdjMatrix(i,j) ~= noEdgeSymbol )
            StdAdjMatrix(i,M+j) = 1;
            StdWeightsMatrix(i,M+j) = AdjMatrix(i,j);
        end
    end    
end    
PartitionIdx = [1,M;M+1,M+N];

drawMultiPartiteGraph(StdAdjMatrix,PartitionIdx,[labelsA(:); labelsB(:)],StdWeightsMatrix);

    