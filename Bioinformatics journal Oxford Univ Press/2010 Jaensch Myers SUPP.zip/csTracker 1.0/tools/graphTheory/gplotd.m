function gplotd(A,xy,labels, weights, varargin)
%GPLOTD Plot a Directed Graph
% GPLOTD(A,XY) Plots the Directed Graph represented by adjacency
%   matrix A and points xy using the default style described below
% GPLOTD(A,XY,PARAM1,VAL1,PARAM2,VAL2,...) Plots the Directed Graph
%   using valid parameter name/value pairs
%
%   Inputs:
%       A      - NxN adjacency matrix, where A(I,J) is nonzero
%               if and only if there is an edge between points I and J
%       xy     - Nx2 matrix of x/y coordinates
%       labels - 1XN matrix or cell array of labels, may be numeric or
%                alpha numeric
%       ...    - Parameter name/value pairs that are consistent with
%               valid PLOT parameters can also be specified
%       
%
%   Default Plot Style Details:
%       1. Undirected (2-way) edges are plotted in solid black lines
%       2. Directed (1-way) edges are plotted in two styles
%           a. If the edge connects a larger vertex ID with a smaller ID,
%               the edge is plotted as a blue dashed line
%           b. If the edge connects a smaller vertex ID with a larger ID,
%               the edge is plotted as a red dotted line
%       3. Any vertex that is connected to itself is plotted with a
%           black circle around it
%
%   Example:
%       % plot a directed graph using default line styles
%       A = round(rand(9));
%       xy = [cos(2*pi/9*(0:8)); sin(2*pi/9*(0:8))]';
%       gplotd(A,xy);
% 
%   Example:
%       % plot a directed graph using plot name/value parameter pairs
%       A = round(rand(9));
%       xy = [cos(2*pi/9*(0:8)); sin(2*pi/9*(0:8))]';
%       gplotd(A,xy,'LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','g');
%
%   See also: gplot, plot, graph_gui (FEX #15973)
%
% Author: Joseph Kirk
% Email: jdkirk630@gmail.com
% Release: 1.0
% Release Date: 8/27/07

% process inputs
if nargin < 2
    error('Not enough input arguments.');
end


[nr,nc] = size(A);
[n,dim] = size(xy);
if (~n) || (nr ~= n) || (nc ~= n) || (dim ~= 2)
    eval(['help ' mfilename]);
    error('Invalid input. See help notes above.');
end
params = struct();
for var = 1:2:length(varargin)-1
    params.(varargin{var}) = varargin{var+1};
end

if (nargin < 3  || isempty(labels))
    labels = cell(1,n);
    for i = 1 : n
        labels{i} = num2str(i);
    end
end

if(~iscell(labels))
    labelsCopy = labels;
    labels = cell(1,n);
    for i = 1 : length(labels)
        labels{i} = num2str(labelsCopy(i));
    end
end

if(~ischar(labels{1}))
    for i = 1 : length(labels)
        labels{i} = num2str(labels{i});
    end
end

% parse the adjacency matrix
A = max(0,min(1,ceil(abs(A))));
uA = A.*A'.*(1-eye(n));  % undirected edges (2-way)
dA = A - uA;             % all directed edges (1-way)
dAu = triu(dA,1);        % directed edges (1-way, sm2lg)
dAl = tril(dA,-1);       % directed edges (1-way, lg2sm)
iA = A.*eye(n);          % self-connecting edges

% make NaN-separated XY vectors
[ux,uy] = makeXY(uA,xy);
[dxu,dyu] = makeXY(dAu,xy);
[dxl,dyl] = makeXY(dAl,xy);
[ix,iy] = makeXY(iA,xy);

% plot the graph
hold on
plot(ux,uy,'k-',params)
plot(dxu,dyu,'r:',params)
plot(dxl,dyl,'b--',params)
plot(ix,iy,'ko',params)
plot(xy(:,1),xy(:,2),'k.')

for k = 1:n
    text(xy(k,1),xy(k,2),['  ' labels{k}],'Color','k','FontSize',12,'FontWeight','b')
end

if(nargin>=4)
    for k = 1:n
        for j = 1:n
            if(A(k,j) ~= 0)
                p1 = [xy(k,1),xy(k,2)];
                p2 = [xy(j,1),xy(j,2)];
                
                %place the weight label appr. at 1/4 of the straight line from
                %vertex k to j
                %by randomly varying the position, the weight labels are less likely to be drawn directly on top of each other 
                p  = (1/4+((rand(1) - .5)/5))*(p2-p1) + p1; 
      
                text(p(1),p(2),['  ' num2str(weights(k,j))],'Color','b','FontSize',12,'FontWeight','b')
            end
        end
    end
end
hold off

    function [x,y] = makeXY(A,xy)
        x = NaN;
        y = NaN;
        if any(A(:))
            [ii,jj] = find(A);
            m = length(ii);
            xmat = [xy(ii,1) xy(jj,1)]';
            ymat = [xy(ii,2) xy(jj,2)]';
            x = [xmat; NaN(1,m)]; x = x(:);
            y = [ymat; NaN(1,m)]; y = y(:);
        end
    end
end
