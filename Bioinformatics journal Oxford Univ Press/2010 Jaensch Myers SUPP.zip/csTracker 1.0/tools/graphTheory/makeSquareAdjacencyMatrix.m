function [ G_square ] = makeSquareAdjacencyMatrix(G, noEdgeSymbol)
%MAKESQUAREADJACENCYMATRIX Summary of this function goes here
%   Detailed explanation goes here

if(nargin < 2)
    noEdgeSymbol = 0;
end


M = size(G,1);
N = size(G,2);
if(noEdgeSymbol == 0)
    G_square = zeros(M+N);
else
    G_square = ones(M+N) * noEdgeSymbol;
end
for i = 1 : M
    for j = 1 : N
        if(G(i,j) ~= noEdgeSymbol )
            G_square(i,M+j) = G(i,j);
        end
    end    
end    