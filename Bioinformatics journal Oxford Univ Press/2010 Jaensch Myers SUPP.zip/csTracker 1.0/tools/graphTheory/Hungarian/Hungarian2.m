function [ Matching, Cost ] = Hungarian2( G )

[assignment, Cost]  = assignmentoptimal(G);
Matching            = zeros(size(G));

for i = 1 : length(assignment)
    j = assignment(i);
    if(j > 0)
        Matching(i,j) = 1;
    end
end

end

