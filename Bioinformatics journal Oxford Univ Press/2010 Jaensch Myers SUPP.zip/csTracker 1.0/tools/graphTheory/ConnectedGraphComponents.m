function [p,r] = ConnectedGraphComponents(A,directedConnectionType,isGraphBipartite)
% COMPONENTS : Connected or strongly connected components of a graph.
%
% blocks = components(A);
% [blocks,dag] = components(A);
%
% Input:  A                       is the n by n adjacency matrix for an n-vertex graph.
%         directedConnectionType  for directed graphs, type or connection,
%                                 i.e. either 'weakly' or 'strongly'
%
% Output: blocks    is an n-vector of integers 1:k, where A has k components, 
%                   that labels the vertices of A according to component.
%
% If the input A is undirected (i.e. symmetric), the blocks are its connected
% components and the dag has no edges (i.e. is a diagonal matrix).
%
% If the input A is directed (i.e. unsymmetric), the blocks are its strongly 
% connected components, numbered in topological order according to the dag.
%
% If the input A is a bipartite graph or a non-square adjacency matrix the
% output p is a cell array of the left indices of each connected component
% and r is a cell array of the right indices of each connected component
%
%
% See also DMPERM.
%
% John Gilbert, Xerox PARC, 8 June 1992.
% Copyright (c) 1990-1996 by Xerox Corporation.  All rights reserved.
% HELP COPYRIGHT for complete copyright and licensing notice.
if(nargin < 3)
    isGraphBipartite = 0;
end

[n,m] = size(A);
if (isGraphBipartite || n ~= m)
   A = makeSquareAdjacencyMatrix(A,0); 
   isGraphBipartite = 1;
else
    isGraphBipartite = 0;
end

if(nargin >= 2 && strcmpi(directedConnectionType,'weakly'))
    A = max(A,A'); %make symmetric
end


if ~all(diag(A)) 
    [p,p,r,r] = dmperm(A|speye(size(A)));
else
    [p,p,r,r] = dmperm(A);  
end

if(isGraphBipartite)
    leftVertexGroup  = cell(length(r)-1,1);
    rightVertexGroup = cell(length(r)-1,1);
    for i = 1 : length(r)-1
        v = p(r(i):r(i+1)-1);
        leftVertexGroup{i}  = v(v<=n);
        rightVertexGroup{i} = v(v>n)-n;
    end
    p = leftVertexGroup;
    r = rightVertexGroup;
end

 
