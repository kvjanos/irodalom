function drawMultiPartiteGraph(AdjMatrix, PartitionIdx, labels, weights)

minColIdx = max(1,size(PartitionIdx,1) - 15);
xy = zeros(size(AdjMatrix,1),2);
for i = 1 : size(PartitionIdx,1)
    y_coord = 1;
    for j = PartitionIdx(i,1) : PartitionIdx(i,2)
        if(i < minColIdx)
            xy(j,1) = 16;
        else
            xy(j,1) = (i-minColIdx) * 16;
        end
        xy(j,2) = -y_coord * 18;
        y_coord = y_coord + 1;
        
    end
end

%xy = xy + (rand(size(xy))*3);

if(nargin == 2)
gplotd(AdjMatrix,xy);
elseif(nargin == 3)
gplotd(AdjMatrix,xy,labels);
elseif(nargin == 4)
gplotd(AdjMatrix,xy,labels,weights);
end
axis off