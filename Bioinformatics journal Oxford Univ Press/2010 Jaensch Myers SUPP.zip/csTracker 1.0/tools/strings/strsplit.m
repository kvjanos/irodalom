function [ split ] = strsplit( str, delimiter )

if(nargin < 2)
    delimiter = tab();
end
C = textscan(str,'%s','Delimiter',delimiter);
split = C{1};
