function startsWith = strStartsWith( str, pattern )
    if(iscell(pattern))
        if(iscell(str))
            error('either ''str'' or ''pattern'' must be a single string');
        end
        startsWith = zeros(size(pattern));
        for i = 1 : length(pattern)
            startsWith (i) = strStartsWith_singlePattern(str, pattern{i});
        end
    else
        startsWith = strStartsWith_singlePattern(str, pattern );
    end
end


function startsWith = strStartsWith_singlePattern(str, pattern )
    idx = strfind(str, pattern);
    if(iscell(str))
        startsWith = zeros(1, length(str));
        for i = 1 : length(idx)
            startsWith(i) = ~isempty(idx{i}) && idx{i}(1) == 1;
        end
    else
        startsWith = ~isempty(idx) && idx(1) == 1;
    end
end