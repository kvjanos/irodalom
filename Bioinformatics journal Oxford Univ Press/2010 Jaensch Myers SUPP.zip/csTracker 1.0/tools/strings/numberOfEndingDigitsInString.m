function [ n, s, ext, thisNumber ] = numberOfEndingDigitsInString( s, isFilename )
% n - number of digits
% s - the original input if ~isFilename
%     the filename without extention otherwise

if(nargin == 1)
    isFilename = 0;
end

if(isempty(s))
    error('the string is empty');
end

if(isFilename)
    [path, name, ext] = fileparts(s);
    s = name;
else
    ext = '';
end

i = length(s);

n = 0;
while(isNumChar(s(i)))
    n = n + 1;
    i = i - 1;
end

if(nargout == 4)
    if(n > 0)
        thisNumber = str2num(s(end-n+1,end));
    else
        n = nan;
    end
end
    


    
