function str = sprintVector( vector, separator, numFormatter )

if(nargin < 2)
    separator = sprintf('\t');
end
if(nargin < 3)
    numFormatter = '%f';
end
str = '';
for i=1:(length(vector)-1)
    str = [str sprintf([numFormatter '%s'],vector(i),separator)];
end
str = [str sprintf(numFormatter,vector(end))];
