function startsWith = strEndsWith( str, pattern )
    idx = strfind(str, pattern);
    startsWith = ~isempty(idx) && idx(end) == (length(str) - length(pattern) + 1);