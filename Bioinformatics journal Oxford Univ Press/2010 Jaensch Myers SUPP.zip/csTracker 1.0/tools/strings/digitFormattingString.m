function [ s ] = digitFormattingString( n )
s = sprintf('%%0%dd',n);
