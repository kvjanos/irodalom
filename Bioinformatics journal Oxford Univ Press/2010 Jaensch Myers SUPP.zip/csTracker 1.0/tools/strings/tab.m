function [ tab_str ] = tab(  )
%TAB Summary of this function goes here
%   Detailed explanation goes here

tab_str = sprintf('\t');
