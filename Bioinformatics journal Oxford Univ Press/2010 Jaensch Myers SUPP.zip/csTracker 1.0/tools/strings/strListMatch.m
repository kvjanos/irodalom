function [ idx ] = strListMatch( c1, c2, strCmpMethod )
%takes two cell arrays of strings and returns a vector of length(c1)
%containing the index of the first occurrence for each element of c1 in c2
%
%
%example:                  1   2   3   4      1   2   3   4   5          1  2 3 4
%          strListMatch( {'a','b','c','d'}, {'a','c','d','f','g','a'} ) ==> (1,-1,2,3)
%

if(nargin < 3)
    strCmpMethod = @strcmpi;
end

idx = zeros(1, length(c1));

for i = 1 : length(c1)
    TF = find(strCmpMethod(c1{i}, c2));
    
    if(~isempty(TF))
        idx(i) = TF(1);
    else
        idx(i) = -1;
    end
end