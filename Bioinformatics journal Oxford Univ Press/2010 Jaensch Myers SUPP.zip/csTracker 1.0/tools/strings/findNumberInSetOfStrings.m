function [ numbers, colIdx ] = findNumberInSetOfStrings( strList )
% extracts all numbers in each string and represents them as a matrix
% [str1_num1 str1_num2 str1_num3]
%  ...                       ...   
% [strn_num1 strn_num2 strn_num3]
%
% if one of the colums in this matrix contains only unique values, this
% column and its column index is returned (and can be used to sort the string list according to
% the numbers in these strings)
%
% also see: sortStrListNumerically

if(nargin == 0)
    strList = {
        [baseDir filesep '\yTUB-GFP1\workingDir\1']
        [baseDir filesep '\yTUB-GFP10\workingDir\1']
        [baseDir filesep '\yTUB-GFP11\workingDir\1']
        [baseDir filesep '\yTUB-GFP12\workingDir\1']
        [baseDir filesep '\yTUB-GFP13\workingDir\1']
        [baseDir filesep '\yTUB-GFP14\workingDir\1']
        [baseDir filesep '\yTUB-GFP15\workingDir\1']
        [baseDir filesep '\yTUB-GFP16\workingDir\1']
        [baseDir filesep '\yTUB-GFP17\workingDir\1']
        [baseDir filesep '\yTUB-GFP18\workingDir\1']
        [baseDir filesep '\yTUB-GFP19\workingDir\1']
        [baseDir filesep '\yTUB-GFP2\workingDir\1']
        [baseDir filesep '\yTUB-GFP20\workingDir\1']
        [baseDir filesep '\yTUB-GFP3\workingDir\1']
        [baseDir filesep '\yTUB-GFP4\workingDir\1']
        [baseDir filesep '\yTUB-GFP5\workingDir\1']
        [baseDir filesep '\yTUB-GFP6\workingDir\1']
        [baseDir filesep '\yTUB-GFP7\workingDir\1']
        [baseDir filesep '\yTUB-GFP8\workingDir\1']
        [baseDir filesep '\yTUB-GFP9\workingDir\1']
    };

strList = {
        [baseDir filesep 'SPD2-WT_GFP1\workingDir\1']
        [baseDir filesep 'SPD2-WT_GFP2\workingDir\1']
        [baseDir filesep 'SPD2-WT_GFP3\workingDir\1']
        [baseDir filesep 'SPD2-WT_GFP4\workingDir\1']
        [baseDir filesep 'SPD2-WT_GFP5\workingDir\1']
        [baseDir filesep 'SPD2-WT_GFP6\workingDir\1']
        [baseDir filesep 'SPD2-GFP7\workingDir\1']
        [baseDir filesep 'SPD2-GFP8\workingDir\1']
        [baseDir filesep 'SPD2-GFP9\workingDir\1']
        [baseDir filesep 'SPD2-GFP10\workingDir\1']
        [baseDir filesep 'SPD2-GFP11\workingDir\1']
        [baseDir filesep 'SPD2-GFP12\workingDir\1']
        [baseDir filesep 'SPD2-GFP13\workingDir\1']
    };
end

try
    regex = '\d+';
    M = [];
    B = [];
    for i = 1 : length(strList)
        str = strList{i};
        [start_idx, end_idx, extents, matches, tokens, names, splits] = regexp(str, regex);

        for j = 1 : length(matches)
            M(i,j) = str2double(matches{j});
            B(i,j) = 1;
        end
    end
    
    numbers = [];
    colIdx  = -1;
    for j = 1 : size(M,2)
        v = unique(M(B(:,j) == 1,j));
        if(length(v) == size(M,1))
            numbers = M(:,j);
            colIdx  = j;
            break
        end
    end
catch
    numbers = [];
    colIdx = -1;
end