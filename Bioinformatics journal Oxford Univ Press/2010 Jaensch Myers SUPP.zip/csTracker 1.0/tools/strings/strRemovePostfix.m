function [ t ] = strRemovePostfix( s, postfix )
%STRREMOVEPOSTFIX Summary of this function goes here
%   Detailed explanation goes here
m = length(s);
n = length(postfix);


if(n <= m && strcmp( s(end-n+1:end), postfix))
    if(n == m)
        t = '';
    else
        t = s(1:end-n);
    end
else
    t = s;
end
