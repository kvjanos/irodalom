function [ strList, numbers, ix ] = sortStrListNumerically( strList )
% if possible, sorts a list of strings according to unique numbers
% contained in the strings, otherwise the list is sorted alphanumercially
%
% also see: findNumberInSetOfStrings

if(nargin == 0)

    strList = {
        'H:\data\microscopy\SPD2-WT_GFP1\workingDir\1'
        'H:\data\microscopy\SPD2-WT_GFP2\workingDir\1'
        'H:\data\microscopy\SPD2-WT_GFP3\workingDir\1'
        'H:\data\microscopy\SPD2-WT_GFP4\workingDir\1'
        'H:\data\microscopy\SPD2-WT_GFP5\workingDir\1'
        'H:\data\microscopy\SPD2-WT_GFP6\workingDir\1'
        'H:\data\microscopy\SPD2-GFP7\workingDir\1'
        'H:\data\microscopy\SPD2-GFP8\workingDir\1'
        'H:\data\microscopy\SPD2-GFP9\workingDir\1'
        'H:\data\microscopy\SPD2-GFP10\workingDir\1'
        'H:\data\microscopy\SPD2-GFP11\workingDir\1'
        'H:\data\microscopy\SPD2-GFP12\workingDir\1'
        'H:\data\microscopy\SPD2-GFP13\workingDir\1'
    };
end

numbers = findNumberInSetOfStrings( strList );
if(~isempty(numbers))
    [numbers, ix] = sort(numbers);
    strList = strList(ix);
    
else
    [strList, ix] = sort(strList);
    numbers = [];
end
