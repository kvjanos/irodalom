function [ s ] = matchRegularExpression( str, regexpr, s, fieldname )

[start_idx, end_idx, extents, matches, tokens, names, splits] = regexp(str, regexpr);
if(length(tokens) >= 1)
   if(isfield(s, fieldname))
       s.(fieldname){end+1} = tokens{1};
   else
       s.(fieldname) = {tokens{1}};
   end
end
