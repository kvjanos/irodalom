function [ stub, numberOfDigits, theNumber, formattingString ] = stripOffEndingNumber( s )

numberOfDigits = numberOfEndingDigitsInString(s);
stub = s(1:end-numberOfDigits);

if(nargout >= 3)
    if(numberOfDigits > 0)  
        theNumber = str2num(s(end-numberOfDigits+1:end));
    else
        theNumber = nan;
    end
    
    if(nargout >= 4)
        formattingString = digitFormattingString( numberOfDigits );
    end
end


