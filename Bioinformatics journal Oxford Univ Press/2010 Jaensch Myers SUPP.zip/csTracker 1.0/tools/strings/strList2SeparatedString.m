function [ str ] = strList2SeparatedString( strList, separator, skipEmtpyEntries )

if(nargin < 3)
    skipEmtpyEntries = 0;
end

if(ischar(strList))
    str = strList;
    return
end

str = '';
for i = 1 : length(strList) - 1
    if(skipEmtpyEntries && isempty(strList{i}))
        continue
    end
    str = [str strList{i} separator];
end
if(~isempty(strList))
    str = [str strList{end}];
end