function num = strExtractNumber(str, preceedingPattern)
%extracts a number in a string that is preceeded by the given pattern
%
%num = strExtractNumber(str, preceedingPattern) str is single string
%num = strExtractNumber(C, preceedingPattern)
%      C is cell array of strings
%      num is vector with length(C) elements
%
%example:  num = strExtractNumber('tr_trSplt_noNoiseTr_extTr_trID=002.tif', 'trID=')
%          num = 2

if(iscell(str))
    num = strListExtractNumber(str, preceedingPattern);
else
    regex = [preceedingPattern '\d+'];
    [start_idx, end_idx, extents, matches] = regexpi(str, regex);
    len = length(preceedingPattern);
     if(length(matches) >= 1)
        m   = matches{1};
        num = str2double(m(len+1:end));
        
        if(length(matches) > 1)
            warning('pattern "%s" has been found multiple times in "%s"',pattern, str);
        end
     else
       num = [];
     end
end
end

function num = strListExtractNumber(strList, pattern)
    num = zeros(length(strList), 1);
    for i = 1 : length(strList)
        n = strExtractNumber(strList{i}, pattern);
        if(~isempty(n))
            num(i) = n;
        end
    end
end