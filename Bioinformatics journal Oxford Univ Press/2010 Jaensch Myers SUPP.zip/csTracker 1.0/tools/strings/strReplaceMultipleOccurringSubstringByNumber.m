function [ str ] = strReplaceMultipleOccurringSubstringByNumber( str, substringExpr )
%example:
%
% str           = 'aaa_bc'
% substringExpr = '_bc'
% returns:        'aaa_bc[1]' 
%
%
% str           = 'aaa_bc[1]_bc_bc'
% substringExpr = '_bc'
% returns:        'aaa_bc[3]'
%
% str           = 'aaa_bc[4]_bc_bc'
% substringExpr = '_bc'
% returns:        'aaa_bc[6]'

if(nargin == 0)
    str           = 'aaa_bc[1]'
    str           = 'aaa_bc[4]_bc_bc'
    str           = 'aaa_bc[4]ddd_bc_bc'
    str           = 'aaa_bc_bc_bc_bc_test'
    substringExpr = '_bc'
    
    str = 'tr_extTr_mainTr[10]_extTr_mainTr.txt';
    substringExpr = 'extTr_mainTr';
end
[start_idx, end_idx, extents, matches, tokens, names, splits] = regexp(str, substringExpr);
if(~isempty(matches))
    occurrenceCount_in_string = length(matches);
    
    split2 = splits{2}; %first split after the first occurrence of the substring
    [start_idx_brackets, end_idx_brackets, extents_brackets, matches_brackets, tokens_brackets, names_brackets, splits_brackets] = regexp(split2, '\[(\d+)\]');

    if(~isempty(tokens_brackets)) %numbering in brackets already present in str
        num_in_brackets = str2double(tokens_brackets{1});
        split2_brackets = splits_brackets{2};
        splits{2} = split2_brackets(2:end);
    else
        num_in_brackets = 1;
    end
    num_total = occurrenceCount_in_string+num_in_brackets-1;
    str = [splits{1} matches{1} '[' num2str(num_total) ']'];
    for i = 2 : length(splits)
        str = [str splits{i}];
    end
    
    
end
end

