function [ v, keyFound, inputList ] = getVarargin( inputList, key, defaultValue, removeEntry, mode )

%input: mode = 'pairs' {default} | 'single'
%call:  getVarargin( inputList, key, defaultValue )
%       getVarargin( inputList, key, defaultValue, removeEntry )
%       getVarargin( inputList, key, defaultValue, removeEntry, mode )

if(nargin < 4)
    removeEntry = 0;
end

if(nargin < 5)
    mode = 'pairs';
end

arg_idx = find(strcmpi(key, inputList));
if(isempty(arg_idx))
    v = defaultValue;
    keyFound = 0;
else
    keyFound = 1;
    if(strcmpi(mode, 'pairs'))
        v = inputList{arg_idx+1};
        if(removeEntry)
            inputList(arg_idx) = [];
            inputList(arg_idx) = [];
        end
    elseif(strcmpi(mode, 'single'))
        v = keyFound;
        if(removeEntry)
            inputList(arg_idx) = [];
        end
    end
end