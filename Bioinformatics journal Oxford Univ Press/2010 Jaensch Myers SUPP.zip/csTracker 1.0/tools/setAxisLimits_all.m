function setAxisLimits_all( xl, yl, zl )

if(nargin < 2)
    yl = [];
end

if(nargin < 3)
    zl = [];
end
figs=sort(get(0,'Children'));
for count=1:length(figs)
    sfigure(figs(count));
    if(~isempty(xl))
        xlim(xl);
    end
    if(~isempty(yl))
        ylim(yl);
    end
    if(~isempty(zl))
        zlim(zl);
    end
end

end

