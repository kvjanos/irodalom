function [ idxROI ] = BoundingBoxOfMask( bw_Image )
%finds the bounding box of the object in a binary image
%
%input: a binary image
%
%output: idxROI = [miny, maxy, minx, maxx]




onPixelIdxList = find(bw_Image);
[Y,X] = ind2sub(size(bw_Image), onPixelIdxList);

idxROI    = zeros(1,4);
idxROI(1) = min(Y);
idxROI(2) = max(Y);
idxROI(3) = min(X);
idxROI(4) = max(X);
