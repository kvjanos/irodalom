function kernel = GaussKernel3D( size, sigmas )
% size is a vector of length 3 containing the size for each dimension
% sigmas is a vector of length 3 containing the standard deviations for
% each dimension


kernel = zeros(size);
dim = length(size);

covar = eye(dim);
covar(1,1) = sigmas(1);
covar(2,2) = sigmas(2);
covar(3,3) = sigmas(3);

Hx = (size(1) - 1) / 2;
Hy = (size(2) - 1) / 2;
Hz = (size(3) - 1) / 2;

for i = -Hx : Hx
    for j = -Hy : Hy
        for k = -Hz : Hz
            kernel(i+Hx+1,j+Hy+1,k+Hz+1) = ComputeGauss_nD([i;j;k],[0;0;0],covar);
        end
    end
end

s = sum(kernel(:));
kernel = kernel / s;