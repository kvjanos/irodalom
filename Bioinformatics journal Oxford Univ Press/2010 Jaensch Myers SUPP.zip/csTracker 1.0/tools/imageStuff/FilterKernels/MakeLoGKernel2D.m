function [ H ] = MakeLoGKernel2D( siz, sigma )

if(length(siz) == 1)
    siz(2) = siz(1);
end

w = floor(siz/2);
H = zeros(siz);

sigma2 = sigma^2;
sigma4 = sigma2^2;

for i = -w(1) : w(1)
    for j = -w(2) : w(2)
        H(i+w(1)+1,j+w(2)+1) = ((i^2 + j^2 - 2*sigma2)/sigma4) * exp(-(i^2+j^2)/(2*sigma2));
    end
end

H = H ./ max(H(:));


