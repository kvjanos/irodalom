function kernel = GaussKernel2D( size, sigmas )
% size is a vector of length 2 containing the size for each dimension
% sigmas is a vector of length 2 containing the standard deviations for
% each dimension

Hx = (size(1) - 1) / 2;
Hy = (size(2) - 1) / 2;


[X Y] = meshgrid(-Hx:1:Hx,-Hy:1:Hy);
kernel =  Gauss2D(X,Y,[0,0],[sigmas(1) 0 ; 0 sigmas(2)]);
kernel = kernel / sum(kernel(:));



