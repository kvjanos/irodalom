function [ I ] = imadjustFullRange( I )

in = [min(I(:)), max(I(:))];
I = (I - in(1)) / (in(2)-in(1));



end

