function myMontage( stack, margin, strText, rows_cols )
if(iscell(stack))
    Nimages = length(stack);
    if(nargin < 4)
        s = ceil(sqrt(Nimages));
        rows_cols = [ceil(Nimages/s), s];
    end
    if(nargin < 3)
        strText = [];
    end
    if(nargin < 2)
        margin = 0;
    end
    minInt =  inf;
    maxInt = -inf;
    for i = 1 : Nimages
        I = stack{i};
        minInt = min(minInt, min(I(:)));
        maxInt = max(minInt, max(I(:)));
    end
    for i = 1 : Nimages
        subplot(rows_cols(1), rows_cols(2), i);
        imshow(stack{i},[minInt, maxInt]);
        if(length(strText) >= i)
            text(3,8,strText{i},'color','white');
        end
    end
else
    Nimages = size(stack,3);
    if(nargin < 4)
        s = ceil(sqrt(Nimages));
        rows_cols = [ceil(Nimages/s), s];
    end
    if(nargin < 3)
        strText = [];
    end
    if(nargin < 2)
        margin = 0;
    end
    minInt = min(stack(:));
    maxInt = max(stack(:));
    for i = 1 : Nimages
        subplot(rows_cols(1), rows_cols(2), i);
        imshow(stack(:,:,i),[minInt, maxInt]);
        if(length(strText) >= i)
            text(3,8,strText{i},'color','white');
        end
    end
end