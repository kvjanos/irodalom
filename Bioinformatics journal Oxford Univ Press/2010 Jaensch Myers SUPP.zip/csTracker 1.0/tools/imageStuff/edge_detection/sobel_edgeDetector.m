function [ gradientMag, Ix, Iy ] = sobel_edgeDetector( I, sigma )
%SOBEL_EDGEDETECTOR Summary of this function goes here
%   Detailed explanation goes here

hy = fspecial('sobel');
hx = hy';
if(nargin >= 2 && sigma > 0)
    I_smoothed = imsmooth(I, sigma);
    Iy = imfilter(I_smoothed, hy, 'replicate');
    Ix = imfilter(I_smoothed, hx, 'replicate');
else
    Iy = imfilter(I, hy, 'replicate');
    Ix = imfilter(I, hx, 'replicate');
end
gradientMag = sqrt(Ix.^2 + Iy.^2);

end

