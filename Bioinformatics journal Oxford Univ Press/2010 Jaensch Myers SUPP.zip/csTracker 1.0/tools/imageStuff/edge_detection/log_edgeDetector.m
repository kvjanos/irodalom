function [ gradientMag ] = log_edgeDetector( I, sigma, smoothingSigma )

hsize = [6*sigma+1, 6*sigma+1];
h = fspecial('log', hsize, sigma);
if(nargin >= 3 && smoothingSigma > 0)
    I = imsmooth(I, smoothingSigma);
end
gradientMag = imfilter(I, h, 'replicate');

end

