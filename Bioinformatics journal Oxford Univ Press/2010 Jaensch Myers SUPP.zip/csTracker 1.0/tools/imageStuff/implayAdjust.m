function implayAdjust( stack, fps )
%IMPLAYADJUST Summary of this function goes here
%   Detailed explanation goes here
if(nargin == 1)
    fps = 20;
end;
    
maxPrj = Projection2(stack, 'max');
low_high = stretchlim(maxPrj, [0,.9999]);

S = zeros(size(stack));
for i = 1 : size(stack,3)
       S(:,:,i) = imadjust(stack(:,:,i),low_high);
end
implay(S,fps);