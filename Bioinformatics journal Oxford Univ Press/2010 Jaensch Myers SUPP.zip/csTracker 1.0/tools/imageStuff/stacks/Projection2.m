function [ img ] = Projection2( stack, funcName )

switch funcName
    case 'max'
        img = max(stack,[],3); 
    case 'sum'
        img = sum(stack,3); 
    case 'mean'
        img = mean(stack,3);
    case 'median'
        img = median(stack,3);
end


