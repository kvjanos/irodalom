function [ stack_rotated ] = stackRotate( stack, angleInDegree, interpolationMethod )

T = [cosd(angleInDegree) -sind(angleInDegree) 0; sind(angleInDegree) cosd(angleInDegree) 0; 0 0 1];
tform = maketform('affine', T);
stack_rotated = imtransform(stack, tform, interpolationMethod);