function [stack, imgIndices] = imreadStackDouble(fn, imgIndices, varargin )

imgIndicesFromImageInfo = 0;
if(nargin < 2 || isempty(imgIndices))
    info = imfinfo(fn);
    no_pix = length(info);
    imgIndices = 1 : no_pix;
    imgIndicesFromImageInfo = 1;
end

if(imgIndicesFromImageInfo)
    Nmax = getVarargin(varargin, 'Nmax', 9999999);
    if(length(imgIndices) > Nmax)
        stepsize = length(imgIndices) / Nmax;
        ix = 1 : stepsize : length(imgIndices);
        ix = unique(ceil(ix));
        imgIndices = imgIndices(ix);
    end
end
stepsize = getVarargin(varargin, 'stepsize', 1);
if(stepsize > 1)
    imgIndices = imgIndices(1 : stepsize : Nmax);
end

I = im2double(imread(fn, imgIndices(1)));

stack = zeros([size(I), length(imgIndices)],'double');
stack(:,:,1) = I;

for i = 2 : length(imgIndices)
    stack(:,:,i) = im2double(imread(fn, imgIndices(i)));
end

end

