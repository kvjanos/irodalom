function [ p ] = MultiTIFFSequenceProperties( firstMultiTIFFFile, zCount)
%also see: imreadFromMTS

if(nargin < 2)
    zCount = 1;
end

[MTfiles, MTdir] = fileListOfFirstFile(firstMultiTIFFFile);

p.imageFilenames = MTfiles;

for i = 1 : length(MTfiles)
    stackFilename = [MTdir filesep MTfiles{i}];
    info = imfinfo(stackFilename);
    no_pix = length(info);
    if(mod(no_pix,zCount) ~= 0)
        error('The number of images (%d) is not divisble by the number of planes (%d)',no_pix,zCount);
    end
    
    if(i == 1)
        p.imageInfo          = info(1);
        if(isfield(p.imageInfo,'ImageDescription'))
            p.imageInfo.ImageDescription = [];
        end
        p.imageCountCumul(1) = no_pix;
    else
        p.imageCountCumul(i) = p.imageCountCumul(i-1) + no_pix;
    end
    
end

p.zCount            = zCount;
p.tCount            = p.imageCountCumul(end) / zCount;
p.totalImageCount   = p.imageCountCumul(end);
p.imageWidth        = p.imageInfo.Width;
p.imageHeight       = p.imageInfo.Height;