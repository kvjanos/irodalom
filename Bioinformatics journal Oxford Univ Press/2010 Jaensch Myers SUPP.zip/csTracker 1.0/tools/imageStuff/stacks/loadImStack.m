function SEQ = loadImStack(path, firstFrame, lastFrame, info, numberOfImagesInFile)

if(nargin<4)
    info = imfinfo(path);
    no_pix = length(info);
elseif(nargin<5)
    if(isfield(info, 'imCount'))
        no_pix = info.imCount;
    else
        no_pix = length(info);
    end
else
    no_pix = numberOfImagesInFile;
end



if(nargin==1)
  firstFrame = 1;
  lastFrame  = no_pix;
end
firstFrame = max(1,firstFrame);
lastFrame  = min(no_pix,lastFrame);

no_pix = lastFrame - firstFrame + 1;

j = 0;
for i=firstFrame:lastFrame
  Image = imread(path,i);
  j = j + 1;
  %pre-allocate memory for speedup
  if(j==1)
      s = size(Image);
      if(info(1).BitDepth == 16)
        bitDepth = 'uint16';
      else 
        bitDepth = 'uint8';
      end   
      SEQ = zeros(s(1), s(2), size(Image,3), no_pix, bitDepth);
  end

  SEQ(:,:,:,j) = Image;
end
SEQ = squeeze(SEQ);