function [stack, filenames, internalImgIndices] = imreadFromMTS( varargin )
% call one of these, see imreadFromMTS_helper (below) for futher details
%
% - imreadFromMTS(mtsProps, directory, imgIdx)
% - imreadFromMTS(mtsProps, directory, z, t)
% - imreadFromMTS(mtsPropsFilenameWithPath, imgIdx)
% - imreadFromMTS(mtsPropsFilenameWithPath, z, t)
% 
    if(length(varargin) == 3 && isstruct(varargin{1}))
        [stack, filenames, internalImgIndices] = imreadFromMTS_helper(varargin);
    elseif(length(varargin) >= 2 && ischar(varargin{1}))
        fn_mtsProps = varargin{1};
        directory = fileparts(fn_mtsProps);
        mtsProps  = xml_read(fn_mtsProps);
        if(length(varargin) == 2)
            imgIdx = varargin{2};
        elseif(length(varargin) == 3)
            z = varargin{2};
            t = varargin{3};
            checkInput(z,t);
            imgIdx = (t-1)*mtsProps.zCount+z;
        end
         [stack, filenames, internalImgIndices] = imreadFromMTS_helper( mtsProps, directory, imgIdx );
    elseif(length(varargin) == 4 && isstruct(varargin{1}))
        mtsProps  = varargin{1};
        directory = varargin{2};
        z = varargin{3};
        t = varargin{4};
        checkInput(z,t);
        imgIdx = (t-1)*mtsProps.zCount+z;
         [stack, filenames, internalImgIndices] = imreadFromMTS_helper( mtsProps, directory, imgIdx );
    end

    function checkInput(z,t);
        if(length(z) ~= length(t))
            error('vectors z and t must have the same length');
        end
    end

end

function [stack, filenames, internalImgIndices] = imreadFromMTS_helper( mtsProps, directory, imgIdx )
% reads images from a sequence of multi-TIFF files
%
% input:  mtsProps  - properties of the multi-TIFF sequence 
%         directory - containing the multi-TIFF sequence
%         imgIdx    - the (global) indices of the images to load 
%
% output: stack                 - a single image or a stack
%         filenames             - a cell array of strings with the same length as imgIdx 
%         internalImgIndices    - a vector with same length as imgIdx
%                                 containing the indices within the respective mutli-TIFF file
%
%also see: MultiTIFFSequenceProperties

    if(length(imgIdx) == 1)
        [stack, filenames, internalImgIndices] = imreadFromMTS_singleImg( mtsProps, directory, imgIdx );
    else
        filenames = cell(1, length(imgIdx));
        internalImgIndices = zeros(1, length(imgIdx));

        stack = zeros(mtsProps.imageInfo.Height,mtsProps.imageInfo.Width, length(imgIdx)); 

        for i = 1 : length(imgIdx)
            [I, filename, internalImgIdx] = imreadFromMTS_singleImg( mtsProps, directory, imgIdx(i) );
            internalImgIndices(i) = internalImgIdx; 
            filenames{i} = filename;

            if(i==1)
                s = size(I);
                if(mtsProps.imageInfo.BitDepth == 16)
                    bitDepth = 'uint16';
                else 
                    bitDepth = 'uint8';
                end   
                if(size(I,3) == 1)
                    stack = zeros(s(1), s(2), length(imgIdx), bitDepth);
                    isMultiChannel = 0;
                else
                    stack = zeros(s(1), s(2), size(I,3), length(imgIdx), bitDepth);
                    isMultiChannel = 1;
                end
            end

            if(isMultiChannel)
                stack(:,:,:,i) = I;
            else
                stack(:,:,i) = I;
            end
        end
    end
end

function [I, filename, internalImgIdx] = imreadFromMTS_singleImg( mtsProps, directory, imgIdx )

   [fileIdx, internalImgIdx] = getIndices(imgIdx, mtsProps.imageCountCumul);
    filename = fullfile(directory, mtsProps.imageFilenames{fileIdx});
    
    I = imread(filename, internalImgIdx);

end

function [fileIdx, internalImgIdx] = getIndices(imgIdx, imgCntCumul)
    i=1;    
    while imgIdx > imgCntCumul(i)
        i = i + 1;
        if(i > length(imgCntCumul))
            error('image index %d is out of range', imgIdx);
        end
    end
    if(i > 1)
        internalImgIdx = imgIdx - imgCntCumul(i-1);
    else
        internalImgIdx = imgIdx;
    end
    fileIdx = i;
end