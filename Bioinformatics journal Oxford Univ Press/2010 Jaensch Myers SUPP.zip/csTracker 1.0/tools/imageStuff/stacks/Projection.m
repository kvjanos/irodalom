function Projection(stackFilename, outFilename, zCount, funcName, projectionDimension, deleteOutputFileIfExists)
% reads the stack in zCount chunks and computes the given aggregation
% function on each chunk
% see also: ComputeIntensityProjection

if(nargin < 5)
    projectionDimension = 'z';
end
if(nargin < 6)
    deleteOutputFileIfExists = 0;
end
if(nargin == 0)
    stackFilename = 'V:\microscopy\_beads\BF test 2\GFP_BF_test2_substack001.tif';
    zCount = 76;

    stackFilename = 'V:\microscopy\_beads\Alexa 1\Alexa488outsideembryo.tif';
    zCount = 59;

    stackFilename = 'V:\microscopy\_beads\CY5\GFP_CY5_test1.tif';
    zCount = 59;

    stackFilename = 'V:\microscopy\_beads\CY5\GFP_CY5_test2.tif';
    zCount = 61;

    outFilename   = [];
    funcName = 'max';
    projectionDimension = 'y';
end

if(strcmpi(projectionDimension, 'z'))
    dim = 3;
elseif(strcmpi(projectionDimension, 'x'))
    dim = 2;
elseif(strcmpi(projectionDimension, 'y'))
    dim = 1;
else
    error('unknown projection dimension "%s"',projectionDimension);
end

if(isempty(outFilename))
    outFilename = [getPathAndFilenameWithoutExtension(stackFilename) '_' funcName projectionDimension 'Prj.tif'];
end
if(deleteOutputFileIfExists)
    deleteFileIfExists(outFilename);
end
info = imfinfo(stackFilename);
bits = info(1).BitDepth;
no_pix = length(info);
if(mod(no_pix,zCount) ~= 0)
    error('The number of images (%d) is not divisble by the number of planes (%d)',no_pix,zCount);
end
%T = no_pix / zCount; %number of timepoints

if(bits == 8)
    imFormat = 'uint8';
else
    imFormat = 'uint16';
end    

path = fileparts(outFilename);
ensureDirExists(path);

z = 1;
t = 1;
for i = 1:no_pix
  Image = imread(stackFilename,i);
  
  %pre-allocate memory for speedup
  if(i==1)
      SEQ = zeros(size(Image,1), size(Image,2), zCount, imFormat);
  end
  
  SEQ(:,:,z) = Image;
  z = z + 1;
  
  if( z > zCount)      
    fprintf('.')
    switch funcName
    case 'max'
        img = max(SEQ,[],dim); 
    case 'sum'
        img = sum(SEQ,dim); 
    case 'mean'
        img = mean(SEQ,dim);
        if(bits == 8)
          img = uint8(img); %do not use 'im2uint8' here, would lead to incorrect conversion
        else
          img = uint16(img); %do not use 'im2uint16' here, would lead to incorrect conversion 
        end    
    case 'median'
        img = median(SEQ,dim);
    end
        
    img = squeeze(img);
    %filename = [outDir '\' prefix '_' funcName sprintf('%05d',t) '.tif'];
    %imwrite(img, filename, 'Compression', 'none'); 
    imwrite(img, outFilename, 'Compression', 'none', 'WriteMode', 'append'); 
    z = 1;
    t = t + 1;
  end
end
fprintf('\n')
