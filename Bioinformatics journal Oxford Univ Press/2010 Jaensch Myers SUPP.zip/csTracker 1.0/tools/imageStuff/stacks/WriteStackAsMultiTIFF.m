function WriteStackAsMultiTIFF( stack, filename, compression )
%also see: WriteTIFF


 if(nargin == 2)
     compression = 'none';
 end

[dir] = fileparts(filename);
ensureDirExists(dir);
s = size(stack,3);

imwrite(stack(:,:,1), filename, 'Compression', compression);    

for i=2:s
    imwrite(stack(:,:,i), filename, 'Compression', compression, 'WriteMode', 'append');    
end
