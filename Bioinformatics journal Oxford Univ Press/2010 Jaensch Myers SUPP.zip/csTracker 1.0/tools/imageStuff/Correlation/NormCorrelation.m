function [ Icorr ] = NormCorrelation(  I, pattern, boundary )
%NORMCORRELATION computes the normalized correlation of image I with
%pattern and surpresses the output at the boundaries for half the size of
%the pattern

if(nargin < 3)
    boundary = 'invalid';
end

if(strcmpi(boundary, 'symmetric'))
    P = zeros(size(pattern));
    P(ceil(end/2),ceil(end/2)) = 1;
    I = imfilter(I, P, 'symmetric','full');
    
    Icorr = (normxcorr2_mex(pattern, I, 'same')+1)/2; %this version is faster, c++ code from openCV, http://www.cs.ubc.ca/~deaton/remarks_ncc.html
    fprintf('.')
    h = floor(size(pattern)/2);
    Icorr = Icorr(h(1)+1:end-h(1),h(2)+1:end-h(2));
else
    Icorr = (normxcorr2_mex(pattern, I, 'same')+1)/2; %this version is faster, c++ code from openCV, http://www.cs.ubc.ca/~deaton/remarks_ncc.html
    h = floor(size(pattern)/2);
    Icorr(1:end,1:h(2)) = 0;
    Icorr(1:end,end-h(2)+1:end) = 0;
    Icorr(1:h(1),1:end) = 0;
    Icorr(end-h(1)+1:end,1:end) = 0;
end






