Machine hardware:   sun4u
OS version:         5.9
Processor type:     sparc
Hardware:           SUNW,Sun-Fire-280R

The following components are installed on your system:


Forte Developer 7
        Forte Developer 7 Compilers C
        Forte Developer 7 Compilers C++
        Forte Developer 7 Tools.h++ 7.1
        Forte Developer 7 Standard 64-bit Class Library for C++
        Forte Developer 7 Garbage Collector
        Forte Developer 7 Compilers Fortran 95
        Forte Developer 7 DBX Debugging Tools
        Forte Developer 7 Performance Tools
        Forte Developer 7 Performance Library
        Forte Developer 7 LockLint
        Forte Developer 7 Building Software
        Forte Developer 7 Documentation Set
