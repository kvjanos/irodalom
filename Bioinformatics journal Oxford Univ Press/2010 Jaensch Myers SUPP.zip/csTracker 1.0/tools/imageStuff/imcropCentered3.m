function [clipping, idxROI] = imcropCentered3( I, pos, radius )

% crops the image centered at pos, the size of the cropped image will be
% (2ry+1,2rx+1) if it does not exceed the image boundaries
%
% I       - an image or a stack
% pos     - a vector with 2 or 3 elements specifying the position of the
%           cropping center, either (y,x) or (y,x,z)
% radius  - a vector with 1, 2 or 3 elements specifying the radii in y,x
%           and z direction
%
%output:  clipping - the cropped image
%         idxROI   - [ymin, ymax, xmin, xmax] or [ymin, ymax, xmin, xmax, zmin, zmax], 
%                     the actual indices of the clipping area

isStack = size(I,3) > 1;
if(isStack)
    if(length(pos) == 2 && length(radius) <= 2)
        crop2D = 1;
    else
        crop2D = 0;
    end
end
if(length(radius) == 1)
    radius(2) = radius(1);
    if(isStack)
        radius(3) = radius(1);
    end
end
y = pos(1);
x = pos(2);
ry = radius(1);
rx = radius(2);

if(isStack)
    if(crop2D)
        idxROI = [max(1,y-ry),min(size(I,1),y+ry),max(1,x-rx),min(size(I,2),x+rx),1,size(I,3)];
        clipping = I(idxROI(1):idxROI(2),idxROI(3):idxROI(4),idxROI(5):idxROI(6));
    else
        z = pos(3);
        rz = radius(3);
        idxROI = [max(1,y-ry),min(size(I,1),y+ry),max(1,x-rx),min(size(I,2),x+rx),max(1,z-rz),min(size(I,3),z+rz)];
        clipping = I(idxROI(1):idxROI(2),idxROI(3):idxROI(4),idxROI(5):idxROI(6));
    end
else
    idxROI = [max(1,y-ry),min(size(I,1),y+ry),max(1,x-rx),min(size(I,2),x+rx)];
    clipping = I(idxROI(1):idxROI(2),idxROI(3):idxROI(4));
end
