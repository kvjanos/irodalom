function [ props ] = myregionprops( bwlabel, varargin )

idxSF = find(strcmpi('ShapeFactor',varargin));

if(~isempty(idxSF))
    varargin(idxSF) = [];
    if(~any(strcmpi('Area',varargin)))
        varargin{end+1} = 'Area';
    end
    if(~any(strcmpi('Perimeter',varargin)))
        varargin{end+1} = 'Perimeter';
    end
end

props  = regionprops(bwlabel, varargin);

if(~isempty(idxSF))
    for i = 1 : length(props)
        props(i).ShapeFactor = (4*pi) / (max(1,props(i).Perimeter)^2 / props(i).Area); 
    end
end
