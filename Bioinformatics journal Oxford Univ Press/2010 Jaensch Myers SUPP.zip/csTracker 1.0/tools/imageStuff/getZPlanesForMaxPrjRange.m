function [ zPlanes_all ] = getZPlanesForMaxPrjRange( zPlanes, zRange, zCount )
%each zPlane shall be extended by the given zRange for maximum projection
%==> compute which zPlanes are required for a stack with a total of 'zCount' planes
%
% example: zPlanes = [ 30 55], zRange = [-2:2]
%          ==> zPlanes_all: [28 29 30 31 32 53 54 55 56 57]        

zPlanes_all = [];
zPlanes = unique(zPlanes);
for i = 1 : length(zPlanes)
    zPlanes_all = [zPlanes_all zPlanes(i)+zRange];
end
zPlanes_all = min(zPlanes_all, zCount);
zPlanes_all = max(zPlanes_all, 1);
zPlanes_all = unique(zPlanes_all);
zPlanes_all = zPlanes_all(:);
end

