function writeTIFF( I, path, bitDepth )
%also see: WriteStackAsMultiTIFF
    if(nargin == 2)
        imwrite(I, path, 'Compression', 'none');
    else
        if(bitDepth == 8)
            imwrite(im2uint8(I), path, 'Compression', 'none');
        elseif(bitDepth == 16)
            imwrite(im2uint16(I), path, 'Compression', 'none');
        else
            error('bitDepth must either be 8 or 16, but was %d',bitDepth);
        end            
    end
end
