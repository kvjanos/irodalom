function [clipping, idxROI, roi] = imcropCentered( I, y, x, ry, rx )

% crops the image center at (y,x), the size of the cropped image will be
% (2ry+1,2rx+1) if it does not exceed the image boundaries
%
%output:  clipping - the cropped image
%         idxROI   - [ymin, ymax, xmin, xmax], the actual indices of the
%                                              clipping area

if(nargin == 4)
    rx = ry;
end

if(length(ry) > 1)
    error('scalar expected in ry');
end

if(length(rx) > 1)
    error('scalar expected in rx');
end

idxROI = [max(1,y-ry),min(size(I,1),y+ry),max(1,x-rx),min(size(I,2),x+rx)];

clipping = I(idxROI(1):idxROI(2),idxROI(3):idxROI(4));



if(nargout > 2)
    roi    = indexROIToStandardROI(idxROI);
end