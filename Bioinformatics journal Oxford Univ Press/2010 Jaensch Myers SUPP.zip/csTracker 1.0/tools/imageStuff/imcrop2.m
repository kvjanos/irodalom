function [ img ] = imcrop2( I, roi )
%IMCROP2 does the same as imcrop, but the resulting image has the exact
%width and height specified in roi provided that the roi is entirely
%contained in I
%can also handle image stacks
%rio = [x y width height]
Z = size(I,3);
if(Z > 1)
    img1 = imcrop(I(:,:,1), [roi(1) roi(2) roi(3)-1 roi(4)-1]);
    
    c = class(I);
    img = zeros(size(img1),c);
    img(:,:,1) = img1;
    for i = 2 : Z
        img(:,:,i) = imcrop(I(:,:,i), [roi(1) roi(2) roi(3)-1 roi(4)-1]);     
    end
else
    
    img = imcrop(I, [roi(1) roi(2) roi(3)-1 roi(4)-1]);
end
