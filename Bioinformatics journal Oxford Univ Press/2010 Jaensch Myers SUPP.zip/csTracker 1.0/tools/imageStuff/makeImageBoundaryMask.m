function [ bw ] = makeImageBoundaryMask( siz, wl, wr, wt, wb )
%returns a binary image of size 'siz' in which the boundary pixels with given boundary widths are turned on
%
%synax:
%   bw  = makeImageBoundaryMask( siz, wl, wr, wt, wb )
%   bw  = makeImageBoundaryMask( siz, w ) (all boundaries have equal width)

bw = zeros(siz);

if(nargin < 3)
    wr = wl;
    wt = wl;
    wb = wl;
end

bw(1:end, 1:wl) = 1;
bw(1:end, end-wr+1:end) = 1;
bw(1:wt, 1:end) = 1;
bw(end-wb+1:end, 1:end) = 1;

end

