function I_contour = OverlayMask(I, bw, biggestRegionOnly, color, reduceRegionToContour, lineWidth )

if(isempty(bw))
    I_contour = I;
    return;
end

if(nargin < 3)
    biggestRegionOnly = 0;
end
if(nargin < 4)
    color = 'white';
end
if(nargin < 5)
    reduceRegionToContour = 1;
end
if(nargin < 6)
    lineWidth = 1;
end
if(biggestRegionOnly)
    bw = extractBiggestBinaryRegion(bw);
end
if(reduceRegionToContour)
    mask = bwmorph(bw,'remove'); %reduce regions to their boundaries
    if(lineWidth > 1)
        mask = bwmorph(mask, 'dilate', lineWidth-1);
    end
else
    mask = bw;
end
I_contour = OverlayGrayColored(I,mask*max(I(:)),color);
