function [ kernels ] = MakeKernels( type, sigma, siz )
%also see: MakeKernelPyramide

if(length(siz) == 1)
    siz(2) = siz(1);
end

%kernels = cell(length(sigma), 1);
kernels = zeros([siz length(sigma)], 'double');

for i = 1 : length(sigma)
    if(strcmpi(type,'log'))
        H = -fspecial('log', siz, sigma(i));
    elseif(strcmpi(type,'log2'))
        H = -MakeLoGKernel2D(siz,sigma(i));
    elseif(strcmpi(type,'gaussian'))
        H = fspecial('gaussian',siz, sigma(i));
    elseif(strcmpi(type,'disk'))
        H = makeDiskKernel(sigma(i), ceil(sigma(i)*1.5), siz);
    elseif(strcmpi(type,'rim'))
        H = makeRimKernel(sigma(i),2, siz);
    else
        error('unknown type: %s',type);
    end
    kernels(:,:,i) = H ./ max(H(:));
end
end

function H = makeDiskKernel(interalRadius, externalRadius, siz)
if(nargin < 3)
    siz = ceil(2*externalRadius)+1;
    siz(2) = siz(1);
end
H = MakeRingPattern( siz, interalRadius,    1.0, 0);
he = MakeRingPattern( siz, externalRadius, - .5, 0);
ix = H == 0;
H(ix) = he(ix);
end

function H = makeRimKernel(radius, rim_width, siz)
if(nargin < 2 || isempty(siz))
    siz = ceil(1.5*radius)+1;
    siz(2) = siz(1);
end

interalRadius  = radius - ceil(rim_width/2);
externalRadius = radius + ceil(rim_width/2);

H = MakeRingPattern( siz, interalRadius,  -.5, 3);
H_outer = MakeRingPattern( siz, externalRadius, 0, 1);

H(H_outer==1) = -.5;

% circle_ = plot_circle(ceil(siz(2)/2),ceil(siz(1)/2),radius,'bresenham');
% ix = sub2ind(siz, circle_(:,2), circle_(:,1));
% H(ix) = 1;
end