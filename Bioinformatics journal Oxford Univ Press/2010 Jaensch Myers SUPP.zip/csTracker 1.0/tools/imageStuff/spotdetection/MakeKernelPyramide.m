function [ kernels ] = MakeKernelPyramide( type, sigmas )

%input: type    - 'log', 'log2', 'gaussian'
%       sigmas  - vector of sigma values 

kernels = cell(1,length(sigmas));
for i = 1 : length( sigmas )
    siz = ceil(3*sigmas(i))*2+1; %round(3*sigmas(i))*2+1;
    kernels{i} = MakeKernels( type, sigmas(i), siz );
end


end

