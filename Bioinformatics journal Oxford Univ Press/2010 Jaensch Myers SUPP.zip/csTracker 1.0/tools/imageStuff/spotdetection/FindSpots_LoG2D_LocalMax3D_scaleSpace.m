function [ y,x,z,maxXcorrValue, kernelIndex, pixelCnt, detectionscale ] = FindSpots_LoG2D_LocalMax3D_scaleSpace( stack, stack_3DSmoothed, kernels, scale, normxcrossThreshold)
    y               = [];
    x               = [];
    z               = [];
    maxXcorrValue   = [];
    pixelCnt        = [];
    kernelIndex     = [];
    detectionscale  = [];
   
    
    sigmaXY = 2;
    sigmaZ  = 1;
    smoothingKernel = GaussKernel3D([5,5,5],[sigmaXY,sigmaXY,sigmaZ]);
    
    min_scale                   = min(scale); %scale = [.25 .5 1]
    currentScale                = 1.0;
    bwlocalMaxima_pyramid{1}    = imregionalmax(stack_3DSmoothed);
    stack_pyramid{1}            = stack;
    stack_smoothed_pyramid{1}   = stack_3DSmoothed;
    idx2scale(1)                = currentScale;
    i = 1;
    while(currentScale > min_scale)
        i = i + 1;
        currentScale = currentScale / 2;
        idx2scale(i)              = currentScale;

        stack_pyramid{i}          = imresize(stack_pyramid{i-1},.5);
        S                         = imfilter(stack_pyramid{i}, smoothingKernel);
        stack_smoothed_pyramid{i} = S;
        bwlocalMaxima_pyramid{i}  = imregionalmax(S);
    end
    
    for kernelIdx = 1:length(kernels) 
        H = kernels{kernelIdx};
        fprintf('%3d x %3d\t',size(H,1),size(H,2));
        thisScale = scale(kernelIdx);
        scaleIdx = find(idx2scale == thisScale);
        
        bw_localMaxima = bwlocalMaxima_pyramid{scaleIdx};
        stack          = stack_pyramid{scaleIdx};
        stack_3DSmoothed = stack_smoothed_pyramid{scaleIdx};

        stack_corr = zeros(size(stack));
        for i = 1 : size(stack,3)
            fprintf('.')
            stack_corr(:,:,i) = NormCorrelation_scaled(stack(:,:,i), H, thisScale);
        end
        

        [y0,x0,z0,maxXcorrValue0, pixelCnt0] = FindPeaksIn3D(bw_localMaxima, stack_corr, normxcrossThreshold);
        y0 = y0 / thisScale;
        x0 = x0 / thisScale;
       
        if(getDebugLevel() >= 3)
            stack_corr(bw_localMaxima==0) = 0;
            WriteStackAsMultiTIFF(im2uint16(stack_corr),makeFilenameUnique( [myTempDir filesep 'stack_corr.tif']));
            WriteStackAsMultiTIFF(im2uint16(stack), makeFilenameUnique([myTempDir filesep sprintf('stack.tif')]));
            WriteStackAsMultiTIFF(im2uint8(bw_localMaxima), makeFilenameUnique([myTempDir filesep sprintf('stack_localMax.tif')]));
            WriteStackAsMultiTIFF(im2uint16(stack_3DSmoothed), makeFilenameUnique([myTempDir filesep sprintf('stack_3DSmoothed.tif')]));
        end

        if(~isempty(y0))
            y = [y;y0];
            x = [x;x0];
            z = [z;z0];
            maxXcorrValue   = [maxXcorrValue;maxXcorrValue0];
            pixelCnt        = [pixelCnt;pixelCnt0];
            kernelIndex     = [kernelIndex;repmat(kernelIdx, length(y0),1)];
            detectionscale  = [detectionscale;repmat(thisScale, length(y0),1)]; 
        end
    end
end

function Icorr = NormCorrelation_scaled(I, H, scale)
    if(scale ~= 1)
        H = imresize(H, scale);
        scale = 1.0;
    end
    if(scale ~= 1)
        I_scaled = imresize(I, scale);
        H_scaled = imresize(H, scale);

        Icorr_scaled = NormCorrelation(I_scaled, H_scaled);
        Icorr = imresize(Icorr_scaled, size(I));
    else
        Icorr = NormCorrelation(I, H);
    end        
end

function [y0,x0,z0, maxXcorrValue0, pixelCnt0] = FindPeaksIn3D(bw_localMaxima, stack_corr, thresholdLocalMax)
    if(isempty(bw_localMaxima))
        bw_localMaxima = imregionalmax(stack_corr);
    end
    bw_localMaxima(stack_corr(:) < thresholdLocalMax) = 0;

    spotsIdx = find(bw_localMaxima > 0);
    [y0,x0,z0] = ind2sub(size(stack_corr),spotsIdx);
    
    maxXcorrValue0 = stack_corr(spotsIdx);
    pixelCnt0 = zeros(length(y0),1);
    n = length(y0);
    fprintf('\tn = %d\n',n);
end