function [ stackOverlayed ] = OverlayGrayColored( grayStack1, grayStack2, color )
%OVERLAYGRAYCOLORED Summary of this function goes here
%   Detailed explanation goes here

if(isempty(grayStack2))
    stackOverlayed = grayStack1;
    return;
end


s1 = size(grayStack1);
s2 = size(grayStack2);

isRGB1 = 0;
 
if(length(s1) ~= length(s2) || sum(s1 ~= s2) > 0)
    if(size(grayStack1,3) == 3 && size(grayStack2,3) == 1) %%assume stack1 is RGB and stack2 is gray-scale
        isRGB1 = 1;
    else
        error('The stacks must have the same size');
    end
end

if(strcmpi(color, 'white'))
    stackOverlayed = zeros(size(grayStack1));
    for i = 1 : size(grayStack1,3)
        if(isRGB1)
            stackOverlayed(:,:,i) = max(grayStack1(:,:,i),grayStack2);
        else
            stackOverlayed(:,:,i) = max(grayStack1(:,:,i),grayStack2(:,:,i));
        end
    end
elseif(strcmpi(color, 'black'))
    stackOverlayed = zeros(size(grayStack1));
    for i = 1 : size(grayStack1,3)
        I = grayStack1(:,:,i);
        minI = min(I(:));
        if(isRGB1)
            stackOverlayed(:,:,i) = max(minI/2,grayStack1(:,:,i)-grayStack2);
        else
            stackOverlayed(:,:,i) = max(minI/2,grayStack1(:,:,i)-grayStack2(:,:,i));
        end
    end
else
    
    if(strcmpi(color, 'red'))
        if(isRGB1)
            stackOverlayed = zeros([size(grayStack1,1) size(grayStack1,2) 3]);
            stackOverlayed(:,:,1) = max(grayStack1(:,:,1),grayStack2);
            stackOverlayed(:,:,2) = max(0,grayStack1(:,:,2)-grayStack2);
            stackOverlayed(:,:,3) = stackOverlayed(:,:,2);
        else
            stackOverlayed = zeros([size(grayStack1,1) size(grayStack1,2) 3 size(grayStack1,3)]);
            for i = 1 : size(grayStack1,3)
                g1 = grayStack1(:,:,i);
                g2 = grayStack2(:,:,i);
                stackOverlayed(:,:,1,i) = max(g1,g2);
                stackOverlayed(:,:,2,i) = max(0,g1-g2);
                stackOverlayed(:,:,3,i) = stackOverlayed(:,:,2,i);
            end
        end
    elseif(strcmpi(color, 'green'))
        stackOverlayed = zeros([size(grayStack1,1) size(grayStack1,2) 3 size(grayStack1,3)]);
        for i = 1 : size(grayStack1,3)
            stackOverlayed(:,:,1,i) = max(0,grayStack1(:,:,i)-grayStack2(:,:,i));
            stackOverlayed(:,:,2,i) = max(grayStack1(:,:,i),grayStack2(:,:,i));
            stackOverlayed(:,:,3,i) = stackOverlayed(:,:,1,i);
        end
    elseif(strcmpi(color, 'blue'))
        stackOverlayed = zeros([size(grayStack1,1) size(grayStack1,2) 3 size(grayStack1,3)]);
        for i = 1 : size(grayStack1,3)
            stackOverlayed(:,:,1,i) = max(0,grayStack1(:,:,i)-grayStack2(:,:,i));
            stackOverlayed(:,:,2,i) = stackOverlayed(:,:,1,i);
            stackOverlayed(:,:,3,i) = max(grayStack1(:,:,i),grayStack2(:,:,i));
        end
    else
        erorr('color must be one of these: white, black, red, green, blue');
    end
    
end

