function [ I2, bwLabeling ] = extractBiggestBinaryRegion(I)
bwLabeling = bwlabeln(I);  
S = regionprops(bwLabeling, 'Area', 'PixelIdxList');
[maxArea, maxAreaIdx] = max([S.Area]);

I2 = zeros(size(I));
I2(S(maxAreaIdx).PixelIdxList) = 1;
end