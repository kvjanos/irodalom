function [ B ] = embedMatrix( A, newSize, position )
R = size(A,1);
C = size(A,2);

if(nargin == 2)
    position = 'center';
end

if(R <= newSize(1) && C <= newSize(2) && ~(R == newSize(1) && C == newSize(2)))
    B = zeros(newSize,'double');
    if(strcmpi(position, 'center')) 
        offsetY = floor((newSize(1) - R) / 2);
        offsetX = floor((newSize(2) - C) / 2);
    elseif(strcmpi(position, 'topleft'))
        offsetY = 0;
        offsetX = 0;            
    elseif(strcmpi(position, 'topmiddle'))
        offsetY = 0;
        offsetX = floor((newSize(2) - C) / 2);            
    elseif(strcmpi(position, 'topright'))
        offsetY = 0;
        offsetX = newSize(2) - C;            
    elseif(strcmpi(position, 'middleleft'))
        offsetY = floor((newSize(1) - R) / 2);
        offsetX = 0;            
    elseif(strcmpi(position, 'middleright'))
        offsetY = floor((newSize(1) - R) / 2);
        offsetX = newSize(2) - C;            
    elseif(strcmpi(position, 'bottomleft'))
        offsetY = newSize(1) - R;
        offsetX = 0;            
    elseif(strcmpi(position, 'bottommiddle'))
        offsetY = newSize(1) - R;
        offsetX = floor((newSize(2) - C) / 2);            
    elseif(strcmpi(position, 'bottomright'))
        offsetY = newSize(1) - R;
        offsetX = newSize(2) - C;            
    end
    B(1+offsetY : R+offsetY, 1+offsetX : C+offsetX) = A;
else
    B = A;
end
