function [ Dist2Intensity ] = radialIntensityProfile( I, p, varargin)
%see also: ellipticalRadialIntensityProfile

if(nargin < 2 || isempty(p))
    p = ceil(size(I)/2);
end
distanceFunction  = getVarargin(varargin, 'distanceFunction', 'Manhattan');
aggFunctionHandle = getVarargin(varargin, 'aggFunctionHandle', @mean);
normalize         = getVarargin(varargin, 'normalize', 0, 0, 'single');
integerDistances  = getVarargin(varargin, 'integerDistances', 0, 0, 'single');

cenDist = CenterDistanceMatrix(size(I), p, distanceFunction );
if(integerDistances)
    cenDist = round(cenDist);
end
Dist2Intensity = AggregateXGroups(cenDist(:),I(:),aggFunctionHandle);

if(normalize)
    m = min(Dist2Intensity(:,2));
    M = max(Dist2Intensity(:,2));
    Dist2Intensity(:,2) = (Dist2Intensity(:,2)-m) / (M-m);
end
end

