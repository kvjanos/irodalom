function P = ellipticalRadialIntensityProfile(I, center, ratio_minorAxis_majorAxis, alpha, radii, distInterpolation)
% computes the mean spot intensity along an ellipse centered at 'center' with
% axis ratio 'ratio_minorAxis_majorAxis' and rotation 'alpha' with respect
% to the x-axis
%
%input: I                           - image with a spot
%       center                      - center of the spot [x,y] (sub-pixel coordinates)
%       ratio_minorAxis_majorAxis   - minor axis length divided by major axis length
%       alpha                       - orientation of the spot in degree
%       radii                       - vector of radii at which to compute the mean intensity along the ellipse
%       distInterpolation           - distance of readout points on the ellipse

%output: P(:,1) - major axis length
%        P(:,2) - minor axis length
%        P(:,3) - mean intensity
%
% see also: radialIntensityProfile

if(ratio_minorAxis_majorAxis > 1)
    error('ratio_minorAxis_majorAxis is greater than 1. please specify minor axis length divided by major axis length');
end

center = center(:);
cosAlpha = cosd(-alpha);
sinAlpha = sind(-alpha);
R = [cosAlpha -sinAlpha
    sinAlpha  cosAlpha];

P = zeros(length(radii), 2);
r_ix = 1;
for r = radii(:)'
    a = r;
    b = ratio_minorAxis_majorAxis * r;
    if(r == 0)
        p = center;
    else
        w = ((a-b)/(a+b))^2;
        u = pi()*(a+b)*(1+3*w/(10+sqrt(4-3*w)));
        s = 2*pi()*distInterpolation / u;
        t_all = 0 : s : (2*pi());
        
        ix = 1;
        p = zeros(2, length(t_all));
        for k = t_all
            p(:,ix) = R*[a*cos(k);b*sin(k)]+center;
            ix = ix + 1;
        end
        if(getDebugLevel() >= 3)
            figure(1017); clf
            imshow(I,[]); hold on
            plot(p(1,:),p(2,:), 'xr');
        end
    end
    intensitiesOnEllipse = interp2(I,p(1,:),p(2,:));
    P(r_ix,1) = a;
    P(r_ix,2) = b;
    P(r_ix,3) = mean(intensitiesOnEllipse);
    r_ix = r_ix + 1;
end
end