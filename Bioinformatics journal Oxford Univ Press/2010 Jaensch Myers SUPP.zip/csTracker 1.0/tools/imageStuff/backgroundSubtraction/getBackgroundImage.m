function [ imgBG,p ] = getBackgroundImage( x,y,intensity, siz )
%call: getBackgroundImage(I)     - interactive selection of background points   
%      getBackgroundImage(x,y,I) - uses the points specified by x,y as
%                                  background points
%      getBackgroundImage(x,y,intensity, siz) 

if(nargin == 1)
    I = x;
    fig1 = figure;
    imshow(I,[]);
    hold on;

    x = [];
    y = [];
    intensity = [];
    while(1)
        [x1,y1] = ginput(1);
        if(~isempty(x1))
            x(end+1) = x1;
            y(end+1) = y1;
            intensity(end+1) = I(round(y1),round(x1));
            plot(x1,y1,'rx');
        else
            break;
        end
    end
    siz = size(I);
    close(fig1);
end

if(nargin == 3)
    I = intensity;
    intensity = zeros(length(x),1);
    for i = 1 : length(x)
        intensity(i) = I(y(i),x(i));
    end
    siz = size(I);
end

n = 3;
w = ones(length(x),1);

p = polyfitweighted2(x,y,intensity,n,w);

imgBG = polyval2(p,1:siz(2),1:siz(1));

% fig1 = figure;
% maximize(fig1);
% if(exist('I','var'))
%     subplot(1,3,1)
%     imshow(I,[]);
% end
% subplot(1,3,2)
% Z = polyval2(p,1:20:siz(2),1:20:siz(1));
% [X,Y] = meshgrid(1:20:siz(2),1:20:siz(1));
% surf(X,Y,Z);
% axis square
% hold on
% plot3(x,y,intensity,'x')
% subplot(1,3,3)
% imshow(imgBG,[]);
