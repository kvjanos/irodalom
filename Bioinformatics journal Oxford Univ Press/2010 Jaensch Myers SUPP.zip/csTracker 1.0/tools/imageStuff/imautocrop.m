function [ Icropped, idxROI ] = imautocrop( I, bgThr, directions, margins)
% directions = [fromLeft, fromRight, fromTop, fromBottom]
% margins    = [leftMargin rightMargin, topMargin, bottomMargin]
if(nargin < 4)
    margins = [0,0,0,0];
end

if(size(I,3) > 1)
    for i = 1 : size(I,3)
        [I_, idxROI_all(i,:)] = imautocrop2D( I(:,:,i), bgThr, directions, margins);
    end
    idxROI([1,3]) = min(idxROI_all(:,[1,3]), [], 1);
    idxROI([2,4]) = max(idxROI_all(:,[2,4]), [], 1);
    Icropped = I(idxROI(1):idxROI(2),idxROI(3):idxROI(4),:);
else
    [Icropped, idxROI] = imautocrop2D( I, bgThr, directions, margins);
end

end

function [ Icropped, idxROI ] = imautocrop2D( I, bgThr, directions, margins)
% directions = [fromLeft, fromRight, fromTop, fromBottom]

idxROI = [1 size(I,1) 1 size(I,2)];
img = I > bgThr;
if(directions(1) || directions(2)) %from left / right
    m = max(img,[], 1);
    if(directions(1)) %from left
        idxROI(3) = find(m~=0,1,'first');
    end
    if(directions(2)) %from right
        idxROI(4) = find(m~=0,1,'last');
    end
end


if(directions(3) || directions(4)) %from top / bottom
    m = max(img,[], 2);
    if(directions(3)) %from top
        idxROI(1) = find(m~=0,1,'first');
    end
    if(directions(4)) %from bottom
        idxROI(2) = find(m~=0,1,'last');
    end
end
idxROI(1) = max(1, idxROI(1) - margins(3));
idxROI(2) = min(size(I,1), idxROI(2) + margins(4));
idxROI(3) = max(1, idxROI(3) - margins(1));
idxROI(4) = min(size(I,2), idxROI(4) + margins(2));

Icropped = I(idxROI(1):idxROI(2),idxROI(3):idxROI(4));
end 

