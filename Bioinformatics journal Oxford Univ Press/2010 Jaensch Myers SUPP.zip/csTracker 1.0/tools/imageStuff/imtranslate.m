function [ I ] = imtranslate( I, t, interpMethod )
%
%input: I - a 2D image
%       t - translation vector (tx, ty)
%       interpMethod - 'bicubic'    Bicubic interpolation
%                      {'bilinear'} Bilinear interpolation
%                      'nearest'    Nearest-neighbor interpolation
 
if(nargin < 3)
    interpMethod = 'bilinear';
end

tform = maketform('affine',[1 0 0; 0 1 0; t(1) t(2) 1]);
    I = imtransform(I,tform,interpMethod,'XData',[1 size(I,2)],'YData',[1 size(I,1)]);

    
    
   