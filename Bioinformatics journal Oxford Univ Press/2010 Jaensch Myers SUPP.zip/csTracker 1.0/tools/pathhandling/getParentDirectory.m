function [ parentDir ] = getParentDirectory( directory, levelsUp )
%GETPARENTDIRECTORY Summary of this function goes here
%   Detailed explanation goes here

parentDir = directory;
for i = 1 : levelsUp
    [parentDir] = fileparts(parentDir);
end
