function deleteAllImagesInDirectory( dir )
%DELETEALLIMAGESINDIRECTORY Summary of this function goes here
%   Detailed explanation goes here

delete([dir filesep '*.gif']);
delete([dir filesep '*.tif']);
delete([dir filesep '*.jpg']);
delete([dir filesep '*.bmp']);
delete([dir filesep '*.pgn']);
