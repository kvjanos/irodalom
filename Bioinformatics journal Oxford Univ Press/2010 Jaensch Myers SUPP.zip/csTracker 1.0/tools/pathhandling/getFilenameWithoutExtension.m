function [ nameWithoutExt ] = getFilenameWithoutExtension( fullpath )
[p,nameWithoutExt] = fileparts(fullpath);
