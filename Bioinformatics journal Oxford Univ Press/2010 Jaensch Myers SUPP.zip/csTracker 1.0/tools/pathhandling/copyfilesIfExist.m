function [ filesCopiedCount ] = copyfilesIfExist( dirname, regex_pattern, regex_negativePattern, destination )
% copy all files in directory 'dirname' that match 'regex_pattern' but not
% 'regex_negativePattern' to destination

if(isempty(regex_pattern))
    regex_pattern = '.*\..*';
end
D = dirr(dirname,regex_pattern,'name','isdir','0'); % 'isdir','0' ==> do not search recursively

filesCopiedCount = 0;
for i = 1 : length(D)
    name = D(i).name;
    if(isempty(regex_negativePattern) || isempty(regexp(name, regex_negativePattern, 'ONCE')))
        copyfile([dirname filesep name], destination, 'f');
        filesCopiedCount = filesCopiedCount + 1;
    end
end


end
