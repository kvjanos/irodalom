function renameFiles( rootDir, regExprFileFilter, oldString, newString )
%renames all files matching regExprFileFilter under the rootDir (recursively) 
%by replacing the string 'oldString' by 'newString'
%
%see also: nameImageFiles

[files, bytes, fNameList] = dirr(rootDir,regExprFileFilter,'name');
for i = 1 : length(fNameList)
    fprintf('.')
    oldname = fNameList{i};
    newname = strrep(oldname, oldString, newString);
    if(~strcmpi(oldname, newname))
        if(exist(newname, 'file'))
            error('file "%s" already exists',newname);
        else
            movefile_fast(oldname, newname);
        end
    end
end
fprintf('\n')
