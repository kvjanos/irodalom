function [ filename ] = addDirectoryOfPathToFilename( filenameWithPath, filename )
if(isempty(fileparts(filename)))
    filename = [fileparts(filenameWithPath) filesep filename];
end