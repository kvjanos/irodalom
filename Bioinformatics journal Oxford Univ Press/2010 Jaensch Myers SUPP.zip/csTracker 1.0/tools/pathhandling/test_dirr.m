[Files,Bytes,fNameList] = dirr(d, '\<tr\.txt\>','name','isdir','0'); 

for i = 1 : length(fNameList)
     fprintf('%s\n',fNameList{i}); 
end