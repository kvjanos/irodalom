function [ filename ] = addDirectoryToFilename( dir, filename )
if(isempty(fileparts(filename)))
    filename = [dir filesep filename];
end
