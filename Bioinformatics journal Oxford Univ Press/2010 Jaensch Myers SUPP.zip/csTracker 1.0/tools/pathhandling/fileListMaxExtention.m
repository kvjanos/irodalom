function [ filelist ] = fileListMaxExtention( directory )

[ names, extentions, uniqueExt, uniqueExtCount  ] = fileTypesInDirectory( directory );
[maxExt, maxExtIdx] = max(uniqueExtCount);
maxExt = char(uniqueExt(maxExtIdx));
filelist = dir([directory filesep '*' maxExt]);

