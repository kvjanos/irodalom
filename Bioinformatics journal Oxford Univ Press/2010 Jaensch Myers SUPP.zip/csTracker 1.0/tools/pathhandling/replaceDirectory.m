function [ newFullfilename ] = replaceDirectory( fullfilename, dir )
%REPLACEDIRECTORY replace the directory in 'fullfilename' with 'dir'

[path name ext] = fileparts(fullfilename);
newFullfilename = fullfile( dir, [filesep name ext]);