function [ childPath ] = getChildPath( aPath, rootPath )
%
% example: ('E:\data\microscopy\yTUB-GFP1_Background\cropped16bit_tif\ImageSeq',
%           'E:\data\microscopy') ==> 'yTUB-GFP1_Background\cropped16bit_tif\ImageSeq'
%
%see also: getRootDirectoryOfDirectory

if(strStartsWith(lower(aPath), lower(rootPath)))
    if(length(aPath) > length(rootPath))
        childPath = aPath(length(rootPath)+2:end);
    else
        childPath = [];
    end
else
    error('%s is not a root path of %s',rootPath,aPath);
end