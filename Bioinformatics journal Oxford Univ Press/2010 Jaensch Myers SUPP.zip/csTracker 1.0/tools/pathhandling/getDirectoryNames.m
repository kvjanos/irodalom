function [ dirNameList ] = getDirectoryNames( directory )
%GETDIRECTORYNAMES returns the list of names of all the directory names
%along the path 'directory'

dirNameList = {};
while(1)
    [directory,name ] = fileparts(directory);
    if(isempty(name))
        break;
    end
    dirNameList{end+1} = name;
end
    
