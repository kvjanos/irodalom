function [ names, extentions, uniqueExt, uniqueExtCount  ] = fileTypesInDirectory( directory )
%FILETYPESINDIRECTORY Summary of this function goes here
%   Detailed explanation goes here

D = dir(directory);
N = length(D);

c = 1;
extentions = {};
for i = N : -1 : 1
    if(D(i).isdir)
        D(i) = [];
    else
        [path, name, ext] = fileparts(D(i).name);
        names{c} = name;
        extentions{c} = ext;
        c = c + 1;
    end
end
if(isempty(extentions))
    warning(sprintf('No files found in %s',directory));
    return;
end
[A, m, n] = unique(extentions);
[uniqueExt, uniqueExtCount] = countOccurrences(n);
uniqueExt = A(uniqueExt)';

