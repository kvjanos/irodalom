function [ directory ] = getRootDirectoryFromRelativePosition( fullpath, knownPartialPath, levelsUpOrDown, occurrence )
% finds in fullpath the knownPartialPath and goes the given numbers of
% levels up or down from this position
%
% input: fullpath           - a full path
%        knownPartialPath   - a relative path, may include more than one level, e.g. 'subdirA\subdirB'
%        levelsUpOrDown     - number of levels up (positive number) or down
%                             (negative number) relative to the knownPartialPath
%        occurrence         - 'first' or 'last'  
%
if(nargin == 0)
    fullpath = 'V:\microscopy\SPD5-YFP4_multicell\workingDir\8\debug\FilterBelowResolutionCandidates\test.txt';
    knownPartialPath = 'workingDir\8';
    levelsUpOrDown = -1;
end

if(nargin < 4)
    occurrence = 'first';
end

if(knownPartialPath(end) == filesep)
    knownPartialPath = knownPartialPath(1:end-1);
end

k = strfind(fullpath, knownPartialPath);
if(isempty(k))
    directory = [];
    return
end

if(occurrence(1) == 'f')
    k = k(1);
else
    k = k(end);
end


if(levelsUpOrDown == 0)
    directory = fullpath(1:k+length(knownPartialPath)-1); %the path until knownPartialPath (including knownPartialPath)
else
    if(levelsUpOrDown > 0)
        root = fullpath(1:k-2); %the path until knownPartialPath (excluding knownPartialPath)
        directory = getParentDirectory(root, levelsUpOrDown-1);
    else
        levelsDown = -levelsUpOrDown;
        directory = fullpath(1:k+length(knownPartialPath)-1); %the path until knownPartialPath (including knownPartialPath)
        tail = fullpath(k+length(knownPartialPath)+1:end);
        tailnames = getDirectoryNames(tail);
        if(length(tailnames) < levelsDown)
            directory = [];
            return
        end
        for i = 1 : levelsDown
            directory = [directory filesep tailnames{end-i+1}];
        end
    end
end





end

