function [ fn ] = getPathAndFilenameWithoutExtension( fullpath )
[path, name] = fileparts(fullpath);
fn = fullfile(path, name);