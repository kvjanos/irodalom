function [ bool ] = deleteDirectoryIfExists( directory )


if(exist(directory,'dir'))
    rmdir(directory, 's');
    bool = 1;
else
    bool = 0;
end