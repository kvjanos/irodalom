function printFileList( files, fn_filelist )
%also see: listFiles
%
% input: files          - structure array with fields 'directory' and 'filenames'
%        fn_filelist    - name of file to write to
%
for k = 1:length(files)
    PrintToFile(files(k).directory,fn_filelist);
    for j = 1 : length(files(k).filenames)
        PrintToFile(sprintf('\t%s',files(k).filenames{j}),fn_filelist);
    end
end      