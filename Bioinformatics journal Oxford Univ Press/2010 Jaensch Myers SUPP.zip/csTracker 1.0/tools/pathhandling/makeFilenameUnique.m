function [ filename ] = makeFilenameUnique( filename )
%MAKEFILENAMEUNIQUE appends a number to the filename to avoid
%name collisions

[path, name, ext] = fileparts(filename);
ensureDirExists(path);
idx = 1;
filename = [path filesep name sprintf('_%d',idx) ext];
while(exist(filename,'file'))
    idx = idx+1;
    filename = [path filesep name sprintf('_%d',idx) ext];
end

