function allLines = readAllLinesFromTextfile(fn)

% open file
fid = fopen(fn,'rt');     % 'rt' means "read text"

if (fid < 0)
    error('could not open file %s',fn);
end;

allLines = {};
i = 0;
while(1)
    tline = fgetl(fid);
    i = i + 1;
    if(tline < 0)
        break
    else
       allLines{i} = tline;
    end
end
fclose(fid);
