function [ rootDir ] = getRootDirectoryOfDirectory( fullpath, aDirName, occurrence )
%GETROOTDIRECTORYOFDIRECTORY finds in 'fullPath' the first or last occurrence of
%'aDirName' and returns the path until 'aDirName'
%
%input: fullpath, aDirName (see above)
%       occurrence - 'first' or 'last'  
%
%example:
%getRootDirectoryOfDirectory('E:\data\microscopy\yTUB-GFP1_Background\cropped16bit_tif\ImageSeq',
%                                                                          'yTUB-GFP1_Background') ==> 'E:\data\microscopy'
%see also: getChildPath

if(nargin < 3)
    occurrence = 'first';
end

k = strfind(lower(fullpath), lower(aDirName));
if(isempty(k))
    error('"%s" not found in "%s"', aDirName, fullpath);
else
    if(occurrence(1) == 'f')
        idx = k(1);
    else
        idx = k(end);
    end
    rootDir = fullpath(1:idx-2);
end