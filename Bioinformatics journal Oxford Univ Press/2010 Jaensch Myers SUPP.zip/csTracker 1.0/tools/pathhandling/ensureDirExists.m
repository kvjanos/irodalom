function directory = ensureDirExists( directory )
%ENSUREDIREXISTS creates directory if it does not exist

[path, name, ext] = fileparts(directory);
if(~isempty(ext)) %given directory is a filename
    directory = path;
end
if(~exist(directory,'dir'))
    mkdir(directory);
end
