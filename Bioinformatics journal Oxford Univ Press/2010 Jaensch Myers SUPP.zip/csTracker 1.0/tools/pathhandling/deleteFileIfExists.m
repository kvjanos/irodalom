function filename = deleteFileIfExists( filename, varargin )
%input: filename           - the file to be deleted
%       maxModificationDate - a time vector ([Y, M, D] or [Y, M, D, H, MN, S]) or a serial date number

showLogMsg = getVarargin(varargin, 'showLogMessage', 0, 0, 'single');
if(exist(filename, 'file'))
    maxModificationDate = getVarargin(varargin, 'maxModificationDate', []);
    doDelete = 1;
    
    if(~isempty(maxModificationDate))
        if(length(maxModificationDate) > 1)
            N = datenum(maxModificationDate);
        else
            N = maxModificationDate;
        end
        
        d = dir(filename);
        if(d(1).datenum > N)
            doDelete = 0;
            if(showLogMsg)
                fprintf('file modification date: %s\n',datestr(d(1).datenum));
                fprintf('max  modification date: %s\n',datestr(N));
            end
        end
    end
    if(doDelete)
        delete(filename);
        if(showLogMsg)
            fprintf('%s has been deleted\n',filename);
        end
    else
        if(showLogMsg)
            fprintf('%s has not been deleted\n',filename);
        end
    end
else
    if(~isempty(strfind(filename, '*')))
        delete(filename)
    else
        if(showLogMsg)
            fprintf('%s does not exist\n',filename);
        end
        
    end    
end

end
