function [ files, directory ] = fileListOfFirstFile( firstFilename )
%FILELISTOFFIRSTFILE 
% firstFilename ==> any filename with path
% the list 'files' will contain 'firstFilename' as 1st entry and then all
% filenames that are equal to firstFilename except for the numbering at the
% end


[directory, firstName, ext] =  fileparts(firstFilename);
[ nameStub, n, firstNumber, format ] = stripOffEndingNumber( firstName );

files{1} = [firstName  ext];

if(n > 0)
    i = firstNumber;    
    while 1
        i = i + 1;
        name = [nameStub sprintf(format,i) ext];
        if(exist([directory filesep name],'file'))
            files{end+1} = name;
        else
            break;
        end
    end
end