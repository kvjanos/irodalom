function copyFolderContents(rootDir, subDir, destinationRootDir, filesOnly, extensionsToBeIgnored)
    if(nargin < 5)
        extensionsToBeIgnored = {};
    end
    
    fulldir = [rootDir filesep subDir];
    if(~exist(fulldir,'dir'))
        return
    end
    fprintf('copying: %s\n',subDir);
    
    destinationFullDir = [destinationRootDir filesep subDir];
    ensureDirExists(destinationFullDir);
    
    D = dir([fulldir filesep '*.*']);
    
    for i = 1 : length(D)
        if((filesOnly && D(i).isdir) || any(strcmpi(D(i).name, {'.','..'})))
            continue;
        end
        fn = [fulldir filesep D(i).name];
        if(D(i).isdir)
            copyfile(fn, [destinationFullDir filesep D(i).name]);
        else
            [path, name, ext] = fileparts(fn);
            if(~isempty(extensionsToBeIgnored) && any(strcmpi(ext,extensionsToBeIgnored)))
                continue;
            end
            copyfile(fn, destinationFullDir);
        end
    end
end

