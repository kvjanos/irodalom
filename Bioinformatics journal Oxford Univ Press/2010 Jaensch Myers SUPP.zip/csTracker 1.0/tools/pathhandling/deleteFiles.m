function deleteFiles( dirname, regex_pattern, regex_negativePattern )
%deletes all files in directory 'dirname' that match 'regex_pattern' but
%not 'regex_negativePattern'

if(nargin < 3)
    regex_negativePattern = [];
end
D = dirr(dirname,regex_pattern,'name','isdir','0'); % 'isdir','0' ==> do not search recursively

for i = 1 : length(D)
    name = D(i).name;
    if(isempty(regex_negativePattern) || isempty(regexp(name, regex_negativePattern, 'ONCE')))
        delete([dirname filesep name]);
    end
end

end

