function [status,message,messageid] = movefile_fast( source, destination, moveIfDestinationIsReadonly )
% moves files on windows platform by executing system command instead of the slow build-in function 'movefile'
% also see: movefile

if strncmp(computer,'PC',2)
    command = ['move /Y "' source '" "' destination '"'];
    if(isdir(source) && exist(destination, 'dir')) % is source a directory and does destination already exist?
        rmdir(destination, 's');
    else
        if(~isdir(destination))
            deleteFileIfExists(destination);
        end
    end
    [status, message] = system(command);
    messageid = -1;
else  % isunix
    if(nargin < 3)
        [status,message,messageid] = movefile( source, destination );
    else
        [status,message,messageid] = movefile( source, destination, 'f' );
    end
end

end

