function filename = findSimilarFileInDirectory(directory, str2compare, ext)

if(nargin == 2)
    ext = '.*';
end

D = dir([directory filesep '*' ext]);
N = length(D);
if(N == 0)
    error('no file with extention %s in directory %s\n',ext,directory);
end

minDist = 999999999999;

for i = 1 : N
    [path, name] = fileparts(D(i).name);
    dist = edit_dist(str2compare, name);
    if(dist < minDist)
        filename = D(i).name;
        minDist = dist;
    end
end

filename = [directory filesep filename];