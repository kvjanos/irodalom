function [ isAbs ] = isAbsolutePath( abs_or_rel_Path)

isAbs = length(abs_or_rel_Path)>=2 && abs_or_rel_Path(2) == ':';