function [ fn ] = makeFilenameValid( fn )

fn = regexprep(fn, ':', '_');
fn = regexprep(fn, '\\', '_');
fn = regexprep(fn, '/', '_');

end

