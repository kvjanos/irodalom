function dir = ensureEmptyDirExists( dir )

[path, name, ext] = fileparts(dir);
if(~isempty(ext))
    dir = path;
end

if(exist(dir, 'dir'))
    rmdir(dir, 's');
end

mkdir(dir);
