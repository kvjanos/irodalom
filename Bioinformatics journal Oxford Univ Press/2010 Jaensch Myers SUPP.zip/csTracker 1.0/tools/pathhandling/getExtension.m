function [ ext ] = getExtension( fullpath )
[p,name, ext] = fileparts(fullpath);