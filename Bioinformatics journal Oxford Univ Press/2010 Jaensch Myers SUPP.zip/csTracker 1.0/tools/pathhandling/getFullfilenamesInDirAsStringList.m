function [ listOfFilenames ] = getFullfilenamesInDirAsStringList( pattern, regex, negRegex, prependDir )
%
% syntax: getFullfilenamesInDirAsStringList(pattern) - full path, filename part may contain wild card (*)
%         getFullfilenamesInDirAsStringList(dir, regex)
%
if(nargin < 2)
    regex = [];
end
if(nargin < 3)
    negRegex = [];
end
if(nargin < 4)
    prependDir = 1;
end

if(isempty(regex))
    D = dir(pattern);
    dirname = fileparts(pattern);
else
    dirname = pattern;
    D = DIRR(dirname,regex,'name','isdir','0');
end


listOfFilenames = {};
idx = 1;
for i = 1 : length(D)
    name = D(i).name;
    if(isempty(negRegex) || isempty(regexpi(name, negRegex, 'ONCE')))
        if(prependDir)
            listOfFilenames{idx} = [dirname filesep name]; idx = idx + 1;
        else
            listOfFilenames{idx} = name; idx = idx + 1;
        end
    end
end

end

