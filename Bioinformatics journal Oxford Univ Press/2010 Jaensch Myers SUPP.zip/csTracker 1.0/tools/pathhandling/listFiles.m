function [ res ] = listFiles( rootDir, fn, mode )
%LISTWORKINGFILES lists the files specified by fn (may contain wildcards ) in the rootDir
%
%input: rootDir - an absolute path
%            fn - a filename (may include wildcards)
%          mode - 's' (recursive) or 'n' (non-recursive) 
%
%output: a structure array with fields {'directory','filenames'}
%
%

if(nargin < 3)
    mode = 'n'; %non-recursive
end

if(nargin == 0)
    rootDir = [baseDir filesep 'yTUB-GFP14\workingDir\1'];
    fn = '*.avi';
    fn = '*.mov';    
    fn = '*.*';
    fn = 'hungarianTracking_*.txt';
    fn = '*.txt';
end



clear 'res';
if(strcmpi(mode, 's'))
    fn = strrep(fn, '*', '.*');
    fn = strrep(fn, '.', '\.');
    [Files,Bytes,fNameList] = dirr(rootDir,fn,'name','isdir',0);
    N = length(fNameList);
    clear 'res1';
    res1(N).directory = '---';
    res1(N).filename = '---';
    for i = 1 : length(fNameList)
        fullFilename = fNameList{i};
        filename  = getFilenameWithExtension(fullFilename);
        directory = fileparts(fullFilename);
        res1(i).directory = directory;
        res1(i).filename  = filename;
    end
    clusters = clusterStructArray( res1, 'directory' );
    
    res(length(clusters)).directory = '###';
    res(length(clusters)).filenames = {};
    for i = 1 : length(clusters)
        clusters_i = clusters{i};
        res(i).directory = clusters{i}.directory;
        res(i).filenames = cell(1,length(clusters_i.members));
        fprintf('%s\n', res(i).directory);
        for j = 1 : length(clusters_i.members)
            res(i).filenames{j} = clusters_i.members(j).filename;
            fprintf('\t%s\n',res(i).filenames{j});
        end
    end
else
    fprintf('%s\n',rootDir);
    D = dir([rootDir filesep fn]);
    res.directory = rootDir;
    res.filenames = cell(1,length(D));
    
    for i = 1 : length(D)
        res.filenames{i} = D(i).name;
        fprintf('\t%s\n',D(i).name);
    end
end


