function [ parentPaths ] = getAllParentDirectories( fullPath )
%walks up the folder hierarchy until the drive letter

%example: fullPath    = 'C:\test\tmp\1'
%         parentPaths = {'C:\test\tmp','C:\test','C:\'}

if(nargin == 0)
    fullPath = 'C:\test\tmp\1';
end
parentPaths = {};

while(1)
    p = fileparts(fullPath);
    if(strcmpi(p,fullPath))
        break
    end
    parentPaths{end+1} = p;
    fullPath = p;
end
parentPaths = parentPaths(:);
end

