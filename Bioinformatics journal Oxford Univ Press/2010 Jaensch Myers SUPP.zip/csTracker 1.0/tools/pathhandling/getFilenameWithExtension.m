function [ nameWithExt ] = getFilenameWithExtension( fullpath )
[p,name,ext] = fileparts(fullpath);
nameWithExt = [name ext];