function [ E ] = MergeXGroups( x1,y1,x2,y2 )
%MERGEXGROUPS converts the input vectors into a struct array with fields x
%and y
%example:
%x1 = [4;5;6;4;6;5;3];
%y1 = [2;3;4;5;6;7;8];
%x2 = [4;5;7;4;6;5;4];
%y2 = [2;3;4;5;6;7;8]*.1;
%output = E{1}.x = 4, E{1}.y{1} = [2,4], E{1}.y{2} = [2,5,8], .... 


[unique_x1 ] = unique(x1);
[unique_x2 ] = unique(x2);

unique_x = intersect(unique_x1, unique_x2);
E = cell(length(unique_x),1);
for i = 1 : length(unique_x)
    x = unique_x(i);
    E{i}.x = x;
    E{i}.y{1} = y1(x1 == x);
    E{i}.y{2} = y2(x2 == x);    
end