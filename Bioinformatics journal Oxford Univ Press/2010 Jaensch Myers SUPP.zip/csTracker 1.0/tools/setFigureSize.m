function setFigureSize( fig_handle, width_height  )
    oldUnits = get(fig_handle,'units');
    set(fig_handle,'units','pixels');
    cursize = get(fig_handle, 'position');
    cursize(3) = width_height(1);
    cursize(4) = width_height(2);
    
    SZ = getScreenSize();
    
    if(cursize(1) < 10) %left
        cursize(1) = 10;
    end
    if(cursize(2) + cursize(4) + 60 > SZ(4)) %bottom
        cursize(2) = SZ(4) - cursize(4) - 60;
    end
    set(fig_handle,'WindowStyle','normal');

    set(fig_handle, 'position', cursize);
    set(fig_handle,'units',oldUnits);
end

