function lim = extendedAxisLimits(lim, lowHighMultiplier)
if(lim(1) >= lim(2))
    error('axis limit must be strictly increasing');
end
if(nargin < 2)
    lowHighMultiplier = [.9 1.1];
end

if(lim(1) < 0)
    lim(1) = lim(1) * lowHighMultiplier(2);
else
    lim(1) = lim(1) * lowHighMultiplier(1);
end

if(lim(2) < 0)
    lim(2) = lim(2) * lowHighMultiplier(1);
else
    lim(2) = lim(2) * lowHighMultiplier(2);
end

end