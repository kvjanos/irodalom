function [ i,j, maxV ] = index2DOfMax( M, roi ) %roi = [x y width height]
if(nargin==1 || isempty(roi))
    [maxV, maxIdx] = max(M(:));
    [i,j] = ind2sub(size(M),maxIdx);
else
    A = M(max(1,roi(2)):min(size(M,1),roi(2)+roi(4)-1),max(1,roi(1)):min(size(M,2),roi(1)+roi(3)-1));
    [maxV, maxIdx] = max(A(:));
    [i,j] = ind2sub(size(A),maxIdx);
    i = i + roi(2) - 1;
    j = j + roi(1) - 1;
end