function filename = printFigureToPostScript( figureHandleOrFilename, filename, append )
%see also: figures2Postscript

if(nargin < 3)
    append = 1;
end

if(ischar(figureHandleOrFilename))
    h = open(figureHandleOrFilename); 
    doClose = 1;
else
    h = figureHandleOrFilename;
    doClose = 0;
end

prepareFigureForPrint(h);

if(append)
    print(sprintf('-f%d',h),'-dpsc2','-append', filename)
else
    print(sprintf('-f%d',h),'-dpsc2', filename)
end

if(doClose)
    close(h)
end