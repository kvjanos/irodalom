function [ idxROI ] = standardROIToIndexROI( roi )
%input:     roi = [minX minY width height]
%output: idxROI = [minY maxY minX maxX]
idxROI = [roi(2), roi(2)+roi(4)-1, roi(1), roi(1)+roi(3)-1 ];