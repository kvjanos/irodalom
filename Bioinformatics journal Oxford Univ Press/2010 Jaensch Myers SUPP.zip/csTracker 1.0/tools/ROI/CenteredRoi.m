function [ roi ] = CenteredRoi( cen, radius, limits )
%CENTEREDROI 
% cen = [y x]
% radius = [height width]
% limits = [minY minX maxY maxX] ==> the limits of the absolute
% coordinates of the roi, i.e. the resulting roi will satify the following conditions:
%                              roi(1) >= limit(2)
%                              roi(2) >= limit(1)
%                              roi(1)+roi(3) - 1 <= limit(4)                              
%                              roi(2)+roi(4) - 1 <= limit(3)                              
%
% returs: roi = [x y width height], be aware of the changed order of x and y!

if(length(radius) == 1)
   radius(2) = radius(1);
end
roi = [cen(2)-radius(2),cen(1)-radius(1),2*radius(2)+1,2*radius(1)+1];

if(nargin == 3  && ~isempty(limits))
    xExcess = limits(2) - roi(1);
    if(xExcess > 0)
        roi(1) = limits(2);
        roi(3) = roi(3) - xExcess; 
    end
    
    xExcess = (roi(1)+roi(3)-1) - limits(4);
    if(xExcess > 0)
        roi(3) = roi(3) - xExcess; 
    end

    yExcess = limits(1) - roi(2);
    if(yExcess > 0)
        roi(2) = limits(1);
        roi(4) = roi(4) - yExcess; 
    end

     yExcess = (roi(2)+roi(4)-1) - limits(3);
    if(yExcess > 0)
        roi(4) = roi(4) - yExcess; 
    end

end



