function [ roi ] = indexROIToStandardROI( idxROI )
%input:  idxROI = [minY maxY minX maxX]
%output:    roi = [minX minY width height]

roi = [idxROI(3), idxROI(1), idxROI(4)-idxROI(3)+1, idxROI(2)-idxROI(1)+1];
