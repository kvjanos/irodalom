function [E, includedIndex, count] = AggregateXGroupsOutlier( A, aggregationFunction, lowhigh, minNumber, weight )
%AggregateXGroups aggregates the y-values for each unique x using the
%given aggregation function, outlier within each x-group are discarded
%input A: MxN matrix, 1. column contains the x-values, all other columns are (independent) y-values,
%                     2. column (i.e. the first y-column) is used to find the outliers 
%      lowhigh: a 2-element vector, the first lowhigh(1) smallest and the lowhigh(2) greatest values will be discarded
%      minNumber: minimum number of y-values left after discarding extreme
%                 values, otherwise no aggregation value will be computed for the respective x-value
%      weight:    weights for averaging
%output E:             MxN matrix, 1. column: unique x-values
%                      all other columns are the aggregated y-values
%       includedIndex: A(includedIndex,:) contains all rows that where included in the aggregation,
%                      within each x-group the y-values in the 2. column are sorted
%       count:         Mx1 vector, number of elements in the respective x-group
%
%


if(nargin < 3)  
    lowhigh = [0,0];
end
if(nargin < 4)  
    minNumber = 0;
end
if(nargin >= 5)
%     weight = zeros(length(weight),1);
    strFunc = func2str(aggregationFunction);
    if(strcmpi(strFunc, 'mean'))
        weightedMean = 1;
    else
        error('if "weight" is specified then the aggregationFunction must be @mean')
    end
    weight = weight(:);
    if(size(A,1) ~= size(weight,1))
       error('size(A,1) == size(weight,1) required');
    end
else
    weightedMean = 0;
end

if(size(A,2) == 1)
    if(minNumber<=1)
        E = A;
        includedIndex = 1;
    else
        E = [];
        includedIndex = [];
    end
    return;
end
[D,xsortIndex ] = sortrows(A,1);
di   = [1; diff(D(:,1))];
idx  = [find(di);size(A,1)+1];

E = zeros(length(idx)-1,size(A,2));

includedIndex = [];
count         = [];
for i = 1 : length(idx)-1;
    E(i,1) = D(idx(i),1);
    [Y, index] = sortrows(D(idx(i):idx(i+1)-1,2:end),1);
    
%     y = Y(:,1);
%     f = 1;
%     meanY   = mean(y);
%     stddevY = std(y);
%     %index = index(y > (meanY-f*stddevY) & y < (meanY+f*stddevY) );
%     index = index( y < (meanY+f*stddevY) );
      
    index = index(1+lowhigh(1):end-lowhigh(2),:);
      
    if(length(index) < minNumber)
        index = [];
    end
    
    thisXsortIdx = xsortIndex(idx(i):idx(i+1)-1);
    thisXsortIdx = thisXsortIdx(index);
    
    count(i)     = length(thisXsortIdx);
    if(length(thisXsortIdx) > 1)
        if(weightedMean)
            for col = 2 : size(A,2)
                y = A(thisXsortIdx,col);
                w = weight(thisXsortIdx);
                sumW = sum(w);
                if(sumW == 0)
                    E(i,col) = 0;
                else
                    E(i,col) = sum(w.*y)./sum(w);
                end
                count(i) = count(i) - length(find(w==0));
            end
        else
            E(i,2:end) = aggregationFunction(A(thisXsortIdx,2:end));
        end
    elseif(length(thisXsortIdx) == 1)
        E(i,2:end) = A(thisXsortIdx,2:end);
    else
        E(i,2:end) = repmat(NaN,1,size(A,2)-1);
    end
    includedIndex = [includedIndex;thisXsortIdx];
end
validRowsIdx = ~isnan(E(:,2));
E = E(validRowsIdx,:);
count = count(validRowsIdx);
end