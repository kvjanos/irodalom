function FinishMovie(  )
MakeQTMovie('finish');
MakeQTMovie('cleanup');