function InitMovie(filename,width_height, framerate)
    filename = [getPathAndFilenameWithoutExtension(filename) '.mov'];
    MakeQTMovie('start',filename);
   
    MakeQTMovie('quality',1.0);
    if(nargin >= 2 && ~isempty(width_height))
        %MakeQTMovie('size',width_height);
        oldUnits = get(gcf,'units');
        set(gcf,'units','pixels');
        cursize = get(gcf, 'position');
        cursize(1) = 50;
        cursize(2) = 50;
        cursize(3) = width_height(1);
        cursize(4) = width_height(2);
        set(gcf, 'position', cursize);
        set(gcf,'units',oldUnits);
    end
    if(nargin >= 3)
        fr = framerate;
    else
        fr = 5;
    end
    MakeQTMovie('framerate',fr);    %10
end