fig1 = figure;

filenameOut = 'aMovie.mov';
frameRate = 5;
width_height = [500 500];
InitMovie(filenameOut,width_height,frameRate);
for i = 1 : 10
    plot(sin([1:.1:10].^i));
    ylim([-1 1])
    MakeQTMovie('addfigure',fig1);
end

FinishMovie();