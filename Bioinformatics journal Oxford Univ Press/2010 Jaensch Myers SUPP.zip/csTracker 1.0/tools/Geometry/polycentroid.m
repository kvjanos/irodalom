function [ cx,cy ] = polycentroid(x,y)
%computes the centroid (center of mass) of a polygon specified by the
%vertices in the vectors x and y

A = polyarea(x,y);


end