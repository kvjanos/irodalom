function gui_test(  )
%TEST Summary of this function goes here
%   Detailed explanation goes here

user_response = gui_confirm('Title', 'Confirm');

switch user_response
case {'No'}
    disp('No')
case 'Yes'
    disp('Yes')
end
end

