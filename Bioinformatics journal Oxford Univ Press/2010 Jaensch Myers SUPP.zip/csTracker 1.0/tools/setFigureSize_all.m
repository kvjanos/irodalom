function setFigureSize_all( width_height )

if(nargin == 0)
    width_height = [740 705];
end
figs=sort(get(0,'Children'));
for count=1:length(figs)
    setFigureSize(figs(count), width_height);
end

end

