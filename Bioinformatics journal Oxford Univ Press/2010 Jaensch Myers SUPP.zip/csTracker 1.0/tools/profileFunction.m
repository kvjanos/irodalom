function profileFunction( aFunction )

profile on
aFunction();
profile off
profile viewer
p = profile('info');
% profsave(p,[myTempDir filesep 'profile_results'])
fn_matlab = makeFilenameUnique([myTempDir filesep 'profile_results.mat']);

save(fn_matlab, 'p');
fn = [getPathAndFilenameWithoutExtension(fn_matlab) '.txt'];
fid = fopen(fn, 'w+'); %w+ open for writing, discard any contents if any

for i = 1 : length(p.FunctionTable)
    functionFilename = p.FunctionTable(i).FileName;
    fprintf(fid, '%s\n', functionFilename);
end

fclose(fid);

