function [ maxIdx, maxV, roi ] = index1DOfMax( x, roi ) 
%roi = [y_pos height]
%roi = [rel_y1 rel_y2] ==> relative roi, example roi = [.2 .8] means search
%                                        for maximum in the index range .2 to .8
%                                        of the entire vector

if(length(roi) == 1)
    roi(2) = length(x) - roi(1) + 1;
end

if(roi(1) < 1) % relative roi ==> convert to absolut roi
    roi(2) = ceil((roi(2)-roi(1))*length(x));
    roi(1) = ceil(roi(1)*length(x));
end


[maxV, maxIdx] = max(x(roi(1):min(length(x),roi(1)+roi(2)-1)));
maxIdx = maxIdx + roi(1) - 1;
