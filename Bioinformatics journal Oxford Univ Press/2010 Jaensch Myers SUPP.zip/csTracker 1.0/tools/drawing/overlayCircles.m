function Iover = overlayCircles(I_, points, radius, grayValue, lineWidth)
%points: an Nx2 matrix of circle centers, 1. column y, 2. column x
%radius: a scalar or a vector with N elements

    if(nargin < 5)
        lineWidth = 2;
    end
  Npoints = size(points,1);
  Iover = I_;
  Nradii = length(radius);
  for k = 1:Npoints
     x = points(k,2);
     y = points(k,1);
     if(Nradii == 1)
        r = radius;    
     else
        r = radius(k);
     end
     Iover = drawOvalFrame(Iover, [y-r, x-r, y+r, x+r], grayValue, lineWidth);
   end
end