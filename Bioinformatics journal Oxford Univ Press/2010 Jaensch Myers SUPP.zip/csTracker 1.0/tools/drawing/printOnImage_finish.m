function [ Ioverlay, I, I_text ] = printOnImage_finish( I, overlayInGray, whiteBackground )
%see also: printOnImage_init
if(nargin < 3)
    whiteBackground = 0;
end

global printOnImage__figureHandle;

sfigure(printOnImage__figureHandle,0);

F = getframe(gca, [1 1 size(I,2) size(I,1)]);
I_text = F.cdata;

if(overlayInGray && size(I_text,3) == 3)
    I_text = rgb2gray(I_text);
    I_text(end,:) = 0;
end

[Ioverlay, I, I_text] = OverlayImages(I, I_text, whiteBackground);
try
    close(printOnImage__figureHandle);
catch 
    printDebugStack(lasterror)
end
end

function [Ioverlay, I1, I2] = OverlayImages(I1, I2, whiteBackground)
%I2 must be uint8

if(size(I2,3) == 3 && size(I1,3) == 1)
    I1(:,:,2) = I1(:,:,1);
    I1(:,:,3) = I1(:,:,1);
end

if(size(I2,3) == 1 && size(I1,3) == 3)
    I2(:,:,2) = I2(:,:,1);
    I2(:,:,3) = I2(:,:,1);
end

c = class(I1);
if(strcmpi(c, 'double'))
    I2 = im2double(I2);
elseif(strcmpi(c, 'uint16'))
    I2 = uint16(I2);
end

if(whiteBackground)
    I1 = imcomplement(I1);
    I2 = imcomplement(I2);
end

I2 = double(I2);
maxI1 = max(I1(:));
if(maxI1 > 0)
    I2 = I2 ./ max(I2(:)) .* double(maxI1);
end

if(strcmpi(c, 'uint8'))
    I2 = uint8(I2);
elseif(strcmpi(c, 'uint16'))
    I2 = uint16(I2);
end


Ioverlay = zeros(size(I1), c);
for i = 1 : size(I1,3)
    I = I1(:,:,i);
    I2_i = I2(:,:,i);
    ix   = find(I2_i(:) > 0);
    I(ix) = I2_i(ix);
    Ioverlay(:,:,i) = I;
end
if(whiteBackground)
    I1 = imcomplement(I1);
    I2 = imcomplement(I2);
end

% Ioverlay = zeros(size(I1), c);
% for i = 1 : size(I1,3)
%     Ioverlay(:,:,i) = max(I1(:,:,i), I2(:,:,i));
% end

end