function h = printOnImage_init( I )
%see also: printOnImage_finish

global printOnImage__figureHandle;

printOnImage__figureHandle = sfigure([],0); hold on
I0 = zeros(size(I), class(I));
imshow(I,  [], 'InitialMagnification', 100);
imshow(I0, [], 'InitialMagnification', 100);
h = printOnImage__figureHandle;
end

