function [ ix_circ ] = circle_linearIndex( X,Y, Radius, algorithm, siz )
%plots circle(X,Y,radius) and computes the valid linear indices for
%addressing the matrix with size 'siz'

circ = plot_circle(X,Y,Radius, algorithm);
ix_valid = circ(:,2) > 0 & circ(:,1) > 0 & circ(:,2) <= siz(1) & circ(:,1) <= siz(2);
ix_circ = sub2ind(siz, circ(ix_valid,2), circ(ix_valid,1));

end

