function Iover = overlayMarkers(I_, points, radius, grayValue, drawingFunc)
%OVERLAYMARKERS draws a marker specified by the given drawing function for each point onto the image
%drawingFunc is a function handle with signature:  drawingFunc(BaseImage, TopLeft_BotRight, GrayValue, penSize)
if(nargin < 5)
    drawingFunc = @drawOvalFrame;
end
Npoints = size(points,1);
Iover = I_;
for k = 1:Npoints
    x = points(k,2);
    y = points(k,1);
    Iover = drawingFunc(Iover, [y-radius, x-radius, y+radius, x+radius], grayValue, 2);
end
end