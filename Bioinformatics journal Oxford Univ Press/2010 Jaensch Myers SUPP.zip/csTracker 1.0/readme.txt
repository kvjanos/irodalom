*****************************************
*** C. Elegans Centrosome Tracker 1.0 ***
*****************************************

============================================
          What Is This Package/Program
============================================

This package, called C. Elegans Centrosome Tracker 1.0, contains the currently working Matlab source codes for processing 3D confocal time-lapse images 
of fluorescently labelled centrosomes in C. elegans embryos. This is the supplement for the paper

Steffen Jaensch, Markus Decker, Anthony A. Hyman, and Eugene Myers, "Automated tracking and analysis of centrosomes in early Caenorhabditis elegans embryos", 2010.

============================================
  License and Agreement to Use This Package
============================================

You will have to agree the following terms, before downloading/using/running/editing/changing any portion of codes in 
this package.

1. This package is free for non-profit research, but needs a special license for any commercial purpose. Please contact
   Steffen Jaensch for details.

2. This package, or any portion of it, cannot be redistributed in the original or any revised form without the written 
   permission from Steffen Jaensch / Markus Decker / Anthony A. Hyman / Eugene Myers.

3. You agree to appropriately cite this work in your related studies and publications.

4. The software is provided "AS-IS" and without warranty of any kind, expressed, implied or otherwise, including without 
   limitation, any warranty of merchantability or fitness for a particular purpose.

5. In no event shall any of the above authors or the Max-Planck Institute of Molecular Cell Biology or the Howard Hughes Medical Institute 
   be liable for any special,  incidental, indirect or consequential damages of any kind, or any damages whatsoever resulting from loss of use, 
   data or profits, whether or not advised of the possibility of damage, and on any theory of liability, arising out of or in connection with 
   the use or performance of this software.

6. In case the source code is provided in this package, the use of this source code constitutes an agreement not to criticize, 
   in any way, the code-writing style of the authors, including any statements regarding the extent of documentation and 
   comments present.

7. Neither the name of the Max-Planck Institute of Molecular Cell Biology, nor the name of the Howard Hughes Medical Institute, Janelia Farm Research Campus, 
   nor the name of any of the above authors, may be used to endorse or promote products derived from this software without specific prior written permission.

============================================
          How to Run the Programs
============================================

Before running the programs under this directory, you will need the following software ready:

* Matlab (http://mathworks.com): the basic platform to run the codes.

* Matlab toolboxes for image processing and optimization  (http://mathworks.com).

* A C/C++ compiler: only needed in case you cannot run a precompiled mex function for Matlab.

* Make sure this directory and all its sub-directories are on the Matlab path.



To run the program the following folders and naming conventions are necessary: 

* You will need to define a dedicated directory, called a base directory, where the movies to be analyzed are put and where all the output will be written to. 
  In order to do this:
  1. Create a directory of your choice on your hard drive. For example C:\mydata\csmovies
  2. Open 'baseDir.m' and put the name of your directory into the list 'dirs'. For example: dirs = {'C:\mydata\csmovies'};
  
* Each centrosome movie may consist of multiple tif-files. They must be numbered with the suffixes '_t0001', '_t0002', ... 
  For example for a movie called 'yTUB-GFP_wt_1cellstage' that consists of two files we would have 'yTUB-GFP_wt_1cellstage_t0001.tif' 
  and 'yTUB-GFP_wt_1cellstage_t0002.tif'. Movies that consist of only a single tif-file do not need to have this suffix but can.
  
* Each centrosome movie must be put into a separate directory with the same name as the movie under your base directory. 
  For example the movie 'yTUB-GFP_wt_1cellstage' (consisting of 'yTUB-GFP_wt_1cellstage_t0001.tif' and 'yTUB-GFP_wt_1cellstage_t0002.tif') would be placed 
  into a directory called 'yTUB-GFP_wt_1cellstage' in your base directory (i.e., 'C:\mydata\csmovies\yTUB-GFP_wt_1cellstage)'. Furthermore, also 
  the microscope setup file must be placed in this directory and have the same name as the movie. In the example it is called 'yTUB-GFP_wt_1cellstage.txt'. 
  Finally, each movie needs an xml-file called 'properties.xml'. It will be created with default values if you don't specify one. 
  
The demo program is called "cstracker.m", which actually calls "run_all_fromHomeDir". Under Matlab, you can simply type the command

>> cstracker('yTUB-GFP_wt_1cellstage')

to start processing the movie 'yTUB-GFP_wt_1cellstage'. This and other example movies can be downloaded from the website of this package.
 
============================================
            Data Files
============================================

A folder 'workingDir/1' will be created in each movie directory during the tracking process. 
The file 'finalTrackingResults.txt' contains the final output with the centrosomes' positions and all the measured parameters. 
The file 'finalTrackingResults.mov' shows a visualization of the computed tracks on a maximum-intensity projection.

============================================
            Trouble-Shooting
============================================

This package is a snap-shot of the current working version of the C. Elegans Centrosome Tracker.
This package is provided as is, and should not be assumed to be bug-free, especially during the stage of releasing 
the codes we removed some debugging codes that may have unseen effect to the running results, although we tried
to minimize the effect if there were one. Running this package is at your own risk, - please note that we are not 
responsible for any damage by running this package (see the License and Agreement above for details).

Please note that the software has not been optimized for speed and produces a lot of graphical output for verification
purposes which takes a significant proportion of the total processing time. 

If something goes wrong, the first thing to look at is the files in the folder '_temp' in your base directory. 
Errors are catched and written to files called 'error_<mfilename>.log'

No particular operating system is assumed. However, the package has been developed and tested only under Windows XP.

=============================================
           Acknowledgement
=============================================

This package contains programs developed by other people and/or for other projects. Particularly, the following programs
are used:

* Markus Buehren's code for bipartite graph matching: assignmentoptimal.m
* Malcolm Slaney's "QuickTime tools for Matlab"
* Jarek Tuszynski's xml reading / writing library: xml_read.m / xml_write.m

=============================================
             Contact
=============================================

Contact Steffen Jaensch (jaensch@mpi-cbg.de) if you have a question.

<2010-March-25> 